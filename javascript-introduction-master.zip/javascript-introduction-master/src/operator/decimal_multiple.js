const integer = 6;
const decimal = 0.3;

// 整数と小数を乗算する
let result = integer * decimal;

// 単に乗算するだけでは、正しい計算結果は得られない
console.log(result);

// 小数に10を乗算して整数にして整数を乗算し、最後に10を除算する
result = (integer * (10 * decimal)) / 10;

// 正しい計算結果が得られる
console.log(result);
