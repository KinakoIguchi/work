const obj = { A: 'a', B: 'b', C: 'c' };
const { A, B, C } = obj;

console.log(A, B, C);

// 異なる名前を持つ変数への分割代入
const { A: foo, B: bar, C: baz } = obj;

console.log(foo, bar, baz);
