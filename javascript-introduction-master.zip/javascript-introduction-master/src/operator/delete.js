const arr = [1, 2];
delete arr[1];

// 配列の要素をdeleteで削除しても、配列の要素数は変わらない
console.log(arr);

// 削除した要素はundefinedとなる
for (const num of arr) {
  console.log(num);
}

const obj = { A: 'a', B: 'b' };
delete obj.B;

// オブジェクトのプロパティは、deleteで単に削除される
console.log(obj);

for (const key in obj) {
  console.log(obj[key]);
}
