const arr = [1, 2, 3];
[x1, x2, x3] = arr;

console.log(x1, x2, x3);

// 変数宣言(var,let,const)なしの分割代入では変数の再宣言が可能
var x1 = 10;
console.log(x1, x2, x3);

// let・constの変数・定数に対しての分割代入も可能
let [y1, y2, y3] = arr;
const [z1, z2, z3] = arr;

console.log(y1, y2, y3);
console.log(z1, z2, z3);
