let message;

// 値が入っていない場合、||の右辺の値が代入される
message = message || 'hello world';

console.log(message);

// 値が入っている場合、||の左辺の値が代入され、値に変更なし
message = message || 'bye!';

console.log(message);
