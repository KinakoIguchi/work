function display() {
  const todos = document.getElementsByTagName('li');

  for(todo of todos) {
    // 属性名を指定してコンソール出力
    console.log(todo.getAttribute('class'));
    // 属性名をすべてコンソール出力
    console.log(todo.attributes);
    // 要素配下のテキストをコンソール出力
    console.log(todo.textContent);
  }
};

document.addEventListener(
    'DOMContentLoaded',
    function() {
        document.getElementById('btn1').addEventListener(
        'click',
        display,
        false
        );
    },
    false
);
