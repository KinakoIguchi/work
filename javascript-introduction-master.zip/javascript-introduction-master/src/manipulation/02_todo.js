function display() {
  const todos = document.getElementsByTagName('li');

  for (todo of todos) {
    // 属性名を指定してコンソール出力
    console.log(todo.getAttribute('class'));
    // 属性名をすべてコンソール出力
    console.log(todo.attributes);
    // 要素配下のテキストをコンソール出力
    console.log(todo.textContent);
  }
};

function display2() {
  const todos = document.getElementsByTagName('li');

  for (todo of todos) {
    // <li>要素配下のテキストをコンソール出力
    console.log(todo.textContent);
    // <li>要素配下のチェックボックスがチェックされているかをコンソール出力
    console.log('チェック済み:' + todo.firstElementChild.checked);
  }

  const textbox = document.getElementById('textbox');
  console.log('テキストボックスの内容:' + textbox.value);
};

document.addEventListener(
    'DOMContentLoaded',
    function() {
      document.getElementById('btn1').addEventListener(
          'click',
          display,
          false,
      );
      document.getElementById('btn2').addEventListener(
          'click',
          display2,
          false,
      );
    },
    false,
);
