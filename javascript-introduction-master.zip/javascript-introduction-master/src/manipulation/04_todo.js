function display() {
  const todos = document.getElementsByTagName('li');

  for (todo of todos) {
    // 属性名を指定してコンソール出力
    console.log(todo.getAttribute('class'));
    // 属性名をすべてコンソール出力
    console.log(todo.attributes);
    // 要素配下のテキストをコンソール出力
    console.log(todo.textContent);
  }
};

function addTodo() {
  // const todos = document.getElementsByTagName('li');

  // for (todo of todos) {
  //   // <li>要素配下のテキストをコンソール出力
  //   console.log(todo.textContent);
  //   // <li>要素配下のチェックボックスがチェックされているかをコンソール出力
  //   console.log('チェック済み:' + todo.firstElementChild.checked);
  // }

  // <li>要素を生成
  const li = document.createElement('li');

  // チェックボックス用の<input>要素を生成し、idとtypeを設定
  const checkbox = document.createElement('input');
  checkbox.id = 'checkbox';
  checkbox.type = 'checkbox';

  // <li>要素の直下にチェックボックスを追加
  li.appendChild(checkbox);
  // <li>要素の直下に追加に、生成したテキストノードを追加。テキストノードはテキストボックスの記述内容。
  const textbox = document.getElementById('textbox');
  li.appendChild(document.createTextNode(textbox.value));

  // <ul>要素の配下に作成した<li>要素を追加
  document.getElementById('todo').appendChild(li);
};

function deleteTodo() {
  // すべてのToDoを取得
  const todos = document.querySelectorAll('li');

  // コンテンツを一時保存するためのDocumentFragmentオブジェクトを生成
  const fragment = document.createDocumentFragment();

  for (todo of todos) {
    // チェックされていないToDoをDocumentFragmentに追加することで、削除対象ではないToDoのみを抽出
    if (!todo.firstElementChild.checked) {
      fragment.appendChild(todo);
    }
  }

  const ul = document.getElementById('todo');
  // <ul>要素の子要素をDocumentFragmentで置換する
  ul.replaceChildren(fragment);
}

document.addEventListener(
    'DOMContentLoaded',
    function() {
      document.getElementById('btn1').addEventListener(
          'click',
          display,
          false,
      );
      document.getElementById('btn2').addEventListener(
          'click',
          addTodo,
          false,
      );
      document.getElementById('btn3').addEventListener(
          'click',
          deleteTodo,
          false,
      );
    },
    false,
);
