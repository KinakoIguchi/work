const obj = {};

// キー名の頭文字が数字や記号の場合はブラケット構文を使用する
obj['1st'] = 1;
obj['2nd'] = 'String';

// 数字や記号以外の場合はドット演算子でも可
obj.Last = true;

console.log(obj);
