const js = 'JavaScript';
const templete = `  ${js}の文字列は、
""あるいは''で囲みます。`;

console.log(templete);
