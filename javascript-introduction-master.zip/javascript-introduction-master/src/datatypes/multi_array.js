const arr = [1, 'One', 2, 'Two'];

console.log(arr);

for (const elm of arr) {
  console.log(elm);
}
