const str = 'JavaScriptの文字列は、\n""あるいは\'\'で囲みます。';

console.log(str);
