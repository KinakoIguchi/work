const arr = new Array(1, 2, 3);

// 配列の長さを出力
console.log('配列の長さ: ' + arr.length);

// forEachメソッドで配列の全要素を出力
console.log('配列[1,2,3]の全要素を出力');
arr.forEach(function (val) {
  console.log(val);
});

// mapメソッドで配列の各要素を2乗
const arr2 = arr.map(function (val) {
  return val * val;
});

console.log('配列[1,2,3]の各要素を2乗した配列の全要素を出力');
arr2.forEach(function (val) {
  console.log(val);
});
