const date1 = new Date('2020/04/01 00:00:00');
// 第二引数の月は(実際の月-1)となる点に注意(ex. 4月の場合は3)
const date2 = new Date(2020, 3, 1, 0, 0, 0, 0);

console.log(date1.toLocaleString());
console.log(date2.toLocaleString());

// getDateで日を取得し、日数を加算した結果をsetDateで設定する
date1.setDate(date1.getDate() + 100);
console.log(date1.toLocaleString());

console.log(
  '経過した日数は' +
    (date1.getTime() - date2.getTime()) / (1000 * 60 * 60 * 24) +
    '日'
);
