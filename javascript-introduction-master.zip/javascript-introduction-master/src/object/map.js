const map = new Map();
map.set('犬', 'dog');
map.set('猫', 'cat');
map.set('鳥', 'bird');

// forEachメソッドでMapの全要素(キー名と値の組)を出力
map.forEach(function (val, key) {
  console.log(key + ':' + val);
});
