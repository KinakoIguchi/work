const set = new Set([1, 2.5, 'str', true, null, undefined]);

// forEachメソッドでSetの全要素と要素のデータ型を出力
set.forEach(function (val) {
  console.log(typeof val, val);
});
