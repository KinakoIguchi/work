// 名前のバリデーション用関数
const validateName = () => {
  const nameTextbox = document.getElementById('name');
  const nameError = document.getElementById('name_error');
  if (nameTextbox.value === '') {
    nameError.textContent = 'お名前を入力してください。';
    return false; // ボタン押下時に使用するためバリデーション結果を返却しているが、本来は戻り値なしでよい
  } else {
    nameError.textContent = '';
    return true; // ボタン押下時に使用するためバリデーション結果を返却しているが、本来は戻り値なしでよい
  }
};

// 日付のバリデーション用関数
const validateDate = () => {
  const dateTextbox = document.getElementById('date');
  const dateError = document.getElementById('date_error');
  if (dateTextbox.value === '' ||
  (new Date(dateTextbox.value).getTime() < Date.now())) {
    dateError.textContent = '本日以降の日付を入力してください。';
    return false; // ボタン押下時に使用するためバリデーション結果を返却しているが、本来は戻り値なしでよい
  } else {
    dateError.textContent = '';
    return true; // ボタン押下時に使用するためバリデーション結果を返却しているが、本来は戻り値なしでよい
  }
};

// 画面の初期化処理
const initialize = () => {
  validateName();
  validateDate();
};

// 名前のテキストボックス入力時に実行される関数
const changeName = () => {
  const nameTextbox = document.getElementById('name');
  nameTextbox.addEventListener(
      'keyup', // keypressだと、空白状態から1文字入力したときに未入力と判定され、エラーメッセージが表示されてしまう
      ()=>{
        validateName();
      },
      false,
  );
};

// 宿泊日付のテキストボックス入力時に実行される関数
const changeDate = () => {
  const dateTextbox = document.getElementById('date');
  dateTextbox.addEventListener(
      'change',
      ()=>{
        validateDate();
      },
      false,
  );
};

// 送信ボタンの押下時に実行される関数
const submit = () => {
  const submitButton = document.getElementById('submit');

  submitButton.addEventListener(
      'click',
      ()=>{
        const allowCheckbox = document.getElementById('allow');
        let message = '';

        if (!validateName()) {
          message += '・お名前に誤りがあります\n';
        }
        if (!validateDate()) {
          message += '・宿泊日付に誤りがあります\n';
        }
        if (!allowCheckbox.checked) {
          message += '・利用規約への同意が必要です\n';
        }
        if (message === '') {
          message += '予約が完了しました!';
        }

        window.alert(message); // ダイアログボックスを表示
      },
      false,
  );
};

// イベントリスナの登録
document.addEventListener(
    'DOMContentLoaded',
    function() {
      initialize();
      changeName();
      changeDate();
      submit();
    },
    false,
);

