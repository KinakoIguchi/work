function display() {
  const node = document.getElementById('search'); // querySelectorメソッドを使用してもよい
  const children = node.childNodes;
  
  for(child of children) {
    const grandchildren = child.childNodes;
    for(grandchild of grandchildren) {
      if (grandchild.href.match(/yahoo/)) {  // 正規表現を使用してhref属性に「yahoo」を含む<a>要素を判定
        console.log(grandchild);
      }
    }
  }
};

document.addEventListener(
    'DOMContentLoaded',
    function() {
        document.getElementById('btn').addEventListener(
        'click',
        display,
        false
        );
    },
    false
);
