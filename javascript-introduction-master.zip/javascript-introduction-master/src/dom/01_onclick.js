function display() {
  window.alert('ダイアログボックスを表示');
}
