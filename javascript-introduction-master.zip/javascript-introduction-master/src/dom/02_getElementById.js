function display() {
  const elem = document.getElementById('message');
  elem.textContent = 'これがメッセージです';
}
