function display() {
  const node = document.getElementById('search'); // querySelectorメソッドを使用してもよい
  const children = node.childNodes;
  
  for(child of children) {
    const grandchildren = child.childNodes;
    for(grandchild of grandchildren) {
      if (grandchild.href.match(/yahoo/)) {  // 正規表現を使用してhref属性に「yahoo」を含む<a>要素を判定
        console.log(grandchild);
      }
    }
  }
  
  // ノードウォーキングを使用して要素を取得する方法は、条件が複雑になればなるほど記述が煩雑になります。
  // 今回の設問の条件では、querySelectorを使用するのがより適切と考えられます。
  // const yahoo = document.querySelector('#search li [href*="yahoo"]');
  // console.log(yahoo);
}
