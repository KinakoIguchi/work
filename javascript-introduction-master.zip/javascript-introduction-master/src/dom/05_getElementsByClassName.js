function display() {
  const elems = document.getElementsByClassName('foo');
  
  console.log('オブジェクトをそのまま表示する場合');
  for(elem of elems) {
    console.log(elem); 
  }
  
  console.log('入力されている文字を表示する場合');
  for(elem of elems) {
    console.log(elem.innerText); 
  }	
}
