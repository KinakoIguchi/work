function display() {
  const elems = document.getElementsByTagName('div');
  
  console.log('オブジェクトをそのまま表示する場合');
  for(elem of elems) {
    console.log(elem); 
  }
  
  console.log('表示されている文字を表示する場合');
  for(elem of elems) {
    console.log(elem.innerText); 
  }	
}
