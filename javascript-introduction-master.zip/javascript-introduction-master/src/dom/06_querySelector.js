function display() {
  const yahoo = document.querySelector('#search li .liked[href*="yahoo"]');
  
  console.log('オブジェクトをそのまま表示する場合');
  console.log(yahoo);
  console.log('リンク先を表示する場合');
  console.log(yahoo.href);
  
  const elems = document.querySelectorAll('li :not(.liked)');
 
  console.log('オブジェクトをそのまま表示する場合');
  for(elem of elems) {
    console.log(elem); 
  }
  
  console.log('入力されている文字を表示する場合');
  for(elem of elems) {
    console.log(elem.innerText); 
  }	
}
