function doneTodo() {
  // すべてのToDoを取得
  const todos = document.querySelectorAll('li');

  for (todo of todos) {
    // チェックされたToDoのCSS(done)のオフ/オフを切り替え後、チェックを外す
    if (todo.firstElementChild.checked) {
      todo.classList.toggle('done');
      todo.firstElementChild.checked = false;
    }
  }

  storeTodo();
};

function addTodo() {
  // <li>要素を生成
  const li = document.createElement('li');

  // チェックボックス用の<input>要素を生成し、idとtypeを設定
  const checkbox = document.createElement('input');
  checkbox.id = 'checkbox';
  checkbox.type = 'checkbox';

  // <li>要素の直下にチェックボックスを追加
  li.appendChild(checkbox);
  // <li>要素の直下に追加に、生成したテキストノードを追加。テキストノードはテキストボックスの記述内容。
  const textbox = document.getElementById('textbox');
  li.appendChild(document.createTextNode(textbox.value));

  // <ul>要素の配下に作成した<li>要素を追加
  document.getElementById('todo').appendChild(li);

  storeTodo();
};

function deleteTodo() {
  // **ここから関数の定義** //

  // DocumentFragmentを引数に取り、引数で画面上のToDoを置換する関数
  const replaceTodo = (fragment) => {
    const ul = document.getElementById('todo');
    ul.replaceChildren(fragment);
  };

  // メッセージ文字列とNodeListのToDo(削除前の全量)を引数に取り、引数の文字列をメッセージとして表示するモードレスダイアログを返却する関数
  // 関数内では削除を元に戻すボタンを生成して、これもダイアログに表示する
  const createDialog = (message, todos) => {
    // メッセージの表示
    const dialog = document.createElement('dialog');
    dialog.appendChild(document.createTextNode(message));

    // ボタンの生成と表示
    const button = document.createElement('input');
    button.setAttribute('type', 'button');
    button.setAttribute('value', '元に戻す');
    // ボタンにイベントリスナを設定。引数のToDo(削除前の全量)で画面上のToDoを置換することで削除前の状態に戻す
    button.addEventListener('click', ()=>{
      todosFragment = document.createDocumentFragment();
      for (todo of todos) {
        todosFragment.appendChild(todo);
      }
      replaceTodo(todosFragment);
      // ToDoを元に戻したあとはダイアログを閉じる
      dialog.close();
    }, false);
    dialog.appendChild(button);

    return dialog;
  };

  // **ここまで関数の定義** //

  if (!window.confirm('チェックしたToDoを削除しますか?')) {
    e.preventDefault();
  }

  // すべてのToDoを取得
  const todos = document.querySelectorAll('li');

  // 未削除コンテンツを一時保存するためのDocumentFragmentオブジェクトを生成
  const undeletedTodo = document.createDocumentFragment();

  // モードレスダイアログ上に表示するメッセージ
  let message = '以下のTodoを削除しました: ';
  // ToDoを削除した数
  let deleteCount = 0;

  for (todo of todos) {
    // チェックされていないToDoをDocumentFragmentに追加することで、削除対象ではないToDoのみを抽出
    if (!todo.firstElementChild.checked) {
      undeletedTodo.appendChild(todo);
    } else {
      // メッセージに削除したToDoのタイトルを追加
      message = message + todo.textContent;
      deleteCount++;
    }
  }

  // <ul>要素の子要素をDocumentFragment(削除対象を消去済みのToDo)で置換する
  replaceTodo(undeletedTodo);

  // 削除対象が存在する場合(=チェックが1件以上された場合)
  if (deleteCount !== 0) {
    // モードレスダイアログボックスを生成し、<body>の子要素に追加
    const dialog = createDialog(message, todos);
    const body = document.querySelector('body');
    body.appendChild(dialog);

    // モードレスダイアログを表示
    dialog.show();

    // setTimeoutでモードレスダイアログが10秒後に消えるよう設定
    setTimeout(function() {
      storeTodo();
      dialog.close();
    }, 10000);
  }
}

function selectTodo(e) {
  if (e.target.firstElementChild) {
    e.target.firstElementChild.checked = !e.target.firstElementChild.checked;
  }
}

// 引数で受け取ったToDoをセッションストレージに格納する
function storeTodo() {
  // セッションストレージの宣言と初期化
  const storage = sessionStorage;
  sessionStorage.clear();

  // すべてのToDoを取得
  const todos = document.querySelectorAll('li');

  // 各ToDoに対して以下の処理を実行
  // ・ToDoのタイトルを取得
  // ・<li>要素のstyle属性に'done'が含まれるかを真理値で取得
  // ・セッションストレージにタイトルと真理値の組を格納
  todos.forEach((todo) => {
    const title = todo.textContent;
    // Array.fromメソッドでclassList(DOMTokenList型)を配列に変換→配列のsomeメソッドを使用し、引数のコールバック関数で'done'クラスが存在するか調べる
    const isDone = Array.from(todo.classList).some((className) => className === 'done');
    storage.setItem(title, isDone);
  });
}

document.addEventListener(
    'DOMContentLoaded',
    function() {
      document.getElementById('btn1').addEventListener(
          'click',
          doneTodo,
          false,
      );
      document.getElementById('btn2').addEventListener(
          'click',
          addTodo,
          false,
      );
      document.getElementById('btn3').addEventListener(
          'click',
          deleteTodo,
          false,
      );
      document.getElementById('todo').addEventListener(
          'click',
          selectTodo,
          false,
      );
    },
    false,
);
