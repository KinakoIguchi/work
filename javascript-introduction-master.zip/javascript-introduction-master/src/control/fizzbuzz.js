const arr = [];
for (i = 1; i <= 100; i++) {
  arr.push(i);
}

// 1~100までの数字を格納した配列
console.log(arr);

for (const num of arr) {
  if (num % 3 === 0 && num % 5 === 0) console.log('FizzBuzz');
  else if (num % 3 === 0) console.log('Fizz');
  else if (num % 5 === 0) console.log('Buzz');
  else console.log(num);
}
