try {
  // valという変数は未宣言
  console.log(val);
} catch (e) {
  console.log('エラーが発生しました。\n原因: ' + e);
}
