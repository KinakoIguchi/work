let Member = function(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
};

Member.prototype.job;
Member.prototype.getName = function() {
  return this.firstName + ' ' + this.lastName + ' ' + this.job;
};

let mem = new Member('John', 'Doe');
mem.job = 'teacher';
console.log(mem.getName());
