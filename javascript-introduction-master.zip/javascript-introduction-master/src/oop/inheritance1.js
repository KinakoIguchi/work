let Member = function(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
};
Member.prototype = {
  getName: function() {
    return this.firstName + ' ' + this.lastName;
  }
};

let BussinessMember = function(firstName, lastName, job) {
  Member.call(this, firstName, lastName);
  this.job = job;
};
BussinessMember.prototype = new Member();
BussinessMember.prototype.getName = function() {
  return this.firstName + ' ' + this.lastName + ' ' + this.job;
};

let bm = new BussinessMember('John', 'Doe', 'teacher');
console.log(bm.getName());
