class Member {
  constructor(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
  }

  getName() {
    return this.firstName + ' ' + this.lastName;
  }
}

class BusinessMember extends Member {
  constructor(firstName, lastName, job) {
    super(firstName, lastName);
    this.job = job;
  }
  getName() {
    return super.getName() + ' ' + this.job;
  }
}

let bm = new BusinessMember('John', 'Doe', 'teacher');
console.log(bm.getName()); // John Doe
