class Member {
  // コンストラクタの定義
  constructor(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
  }

  // メソッドの定義
  getName() {
    return this.firstName + ' ' + this.lastName;
  }
}

let m = new Member('John', 'Doe');
console.log(m.getName());
