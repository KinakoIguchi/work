let Area = function() {};

Area.version = '1.0';

Area.triangle = function(base, height) {
  return (base * height) / 2;
};

console.log('Areaクラスのバージョン=' + Area.version);
console.log(Area.triangle(5, 3));
