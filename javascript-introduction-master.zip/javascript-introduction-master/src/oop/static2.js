class Area {
  static version = '1.0';
  static getTriangle(base, height) {
    return (base * height) / 2;
  }
}

console.log('Areaクラスのバージョン=' + Area.version);
console.log(Area.getTriangle(5, 3));
