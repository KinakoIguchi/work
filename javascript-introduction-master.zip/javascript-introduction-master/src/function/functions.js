// function命令を使用する
function func(x, y) {
  return x + y;
}

// Functionコンストラクタを使用する
const funcConstructor = new Function('x', 'y', 'return x + y');

// functionリテラルを使用する
const funcLiteral = function(x, y) {
  return x + y;
};

// アロー関数を使用する
const funcArrow = (x, y) => x + y;

// 関数の実行
console.log(func(1, 2));
console.log(funcConstructor(1, 2));
console.log(funcLiteral(1, 2));
console.log(funcArrow(1, 2));
