// ES2015以前の記法(オブジェクトを使用)
function getSquare1(args) {
  if (args.width === undefined) args.width = 1;
  if (args.height === undefined) args.height = 1;

  return args.width * args.height;
}

console.log(getSquare1({ width: 3, height: 5 }));

// ES2015以降の記法(オブジェクトと分割代入を使用)
const getSquare2 = ({ width = 1, height = 1 }) => {
  return width * height;
};

console.log(getSquare2({ width: 3, height: 5 }));
