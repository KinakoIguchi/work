// ES2015以前の記法(argumentsオブジェクト)
const sum1 = function() {
  let result = 0;
  for (const tmp of arguments) {
    result += tmp;
  }
  return result;
};

// ES2015以降の記法(Rest Parameters)
const sum2 = (...nums) => {
  let result = 0;
  for (const tmp of nums) {
    result += tmp;
  }
  return result;
};

console.log(sum1(1, 3, 5, 7, 9));
console.log(sum2(1, 3, 5, 7, 9));
