// ES2015以前の記法
const sum1 = (x, y) => {
  if (x === undefined) x = 0;
  if (y === undefined) y = 0;

  return x + y;
};

// ES2015以降の記法
const sun2 = (x = 0, y = 0) => x + y;

console.log(sum1());
console.log(sun2());
