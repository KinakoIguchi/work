const callback = (arr, func) => {
  const result = [];
  for (const num of arr) {
    result.push(func(num));
  }
  return result;
};

const pow = num => num * num;

const arr = callback([1, 2, 3], pow);
console.log(arr);
