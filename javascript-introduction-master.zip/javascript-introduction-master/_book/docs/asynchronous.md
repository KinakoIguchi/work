# 非同期処理

このセクションでは、JavaScriptで非同期処理を実装する方法を紹介します。非同期処理は、JavaScriptを使用した開発の中でも、やや難しい部類に入る処理です。しかし、この処理を使いこなせないと、外部APIの呼び出しなど、実案件で使用することの多い処理を正しく実装できません。よって、このセクションの内容はしっかりと理解するようにしてください。  
このセクションでは、まず同期処理・非同期処理とはどのような処理か解説します。次に、JavaScriptにおける非同期処理の実装方法の変遷について、サンプルコードを交えて説明します。最後に、ECMAScriptの第8版(ES8、ES2017)以降でサポートされるasync・awaitを使用した実装方法を紹介します。  
非同期処理の実装方法は、JavaScript(ECMAScript)の改定の際に何度か改良されてきています。そのため、ネット上や書籍で非同期処理について調べると、いくつかの異なった実装方法が見つかります。これらの方法は、JavaScriptの最新版であれば、どの方法であっても同じように動作します。しかし、JavaScriptを使用した開発に不慣れな方は、非同期処理そのものが複雑なことも相まって、どの方法で実装すべきか混乱してしまうかもしれません。基本的には、最新の実装方法であるasync function宣言とawait演算子を使用すると最も簡潔に記述することができますが、このセクションでは他の方法についても紹介します。このセクションの目標としては、まずは非同期処理を実装する方法が複数あることを理解し、サンプルコードを読んで処理の流れを理解した上で、最終的には自力で実装できるようになることを目指します。

## 非同期処理とは

### 同期処理について

非同期処理について説明する前に、まずは同期処理について説明します。この理由としては、同期処理のほうが直感的に理解しやすいため、同期処理を説明してから非同期処理について説明したほうが、理解が容易となるためです。  
同期処理(逐次処理)とは、プログラムが書かれた順番に実行される処理のことです。例えば、以下のサンプルコードはスクリプトが書かれた順番に実行される同期処理となり、1、2、3の順番にコンソール出力されます。

```javascript
console.log('1');
console.log('2');
console.log('3');

/*
1
2
3
*/
```

【参考】上記のプログラムは、スクリプトが書かれた順番に処理される同期処理となります。ただし、JavaScriptの挙動としては、スクリプトに特別な記述をしない限り、スクリプトの実行順序そのものは保証されません。あくまで、スクリプトに書かれた順番に関数を実行するためのキューに入れられるだけです。そのため、キューに入れるタイミングが遅延するよう明示的な命令を記述した場合には、それより後に書かれている処理が先に実行されることもありえます。つまり、JavaScriptは基本的には同期処理として動作しますが、記述の仕方によっては非同期処理として実行されることもあります。このことは、[以前のセクションで紹介したsetInterval、setTimeoutメソッドの例](browser_objects.md#setInterval、setTimeoutメソッド)で見たとおりです。  
  
このような処理が「同期処理」と呼ばれる理由は、実行しようとする処理よりも前に書かれた処理の終了と同期して(待って)動作するためです。同期処理と非同期処理は、字面だけを見るとどのような意味かわかりにくいですが、「同期処理」は自分より前のコードの影響を受けるというイメージです。  
  
同期処理は、コードを書いた順番に上の行から下の行へ処理が実行されるため、処理の順番が理解しやすいというメリットがあります(もちろん、関数などを実行する場合はコードを行き来することがあります)。そのため、すべての処理を同期処理として実装できればよいのですが、同期処理ではプログラムの動作に問題が生じることがあります。  
例えば、以下のコードは動作に問題があるプログラムを模式的に表したものです。時間のかかる関数heavy_funcと、すぐに完了する関数light_funcの結果を、関数displayで画面に表示するという想定です。なお、関数の実行結果を画面に表示する順序は、どちらが先でもよいものとします。また、すべての関数は同期処理で動作するものとします。

```javascript
function heavy_func () {
    // 時間のかかる処理
    ~~~
    return 結果1
}

function light_func () {
    // すぐに完了する処理
    ~~~
    return 結果2
}

function display (result) {
    // 画面に結果を表示する処理
    ~~~
}

display(heavy_func());
display(light_func());
```

上記のコードは同期処理で実行される前提のため、処理の順序は以下のようになります。

1. 関数heavy_funcの実行
2. 関数displayの実行
3. 関数light_funcの実行
4. 関数displayの実行

上記の処理を実行した際の、ユーザから見た挙動は以下のようになります。

1. かなり時間がかかった後、heavy_funcの結果が表示される
2. heavy_funcの結果が表示された後、すぐにlight_funcの結果が表示される

先述のとおり、このコードを実行する前提としては、heavy_funcの結果とlight_funcの結果のどちらが先に表示されてもよかったのでした。しかし、このプログラムは同期処理で実行されているため、heavy_funcの処理が終わるのを待たないとlight_funcの結果も表示されません。ユーザから見ると、画面に結果が表示されるまでに時間がかかるため、そもそも処理が正しく開始しているかどうかも不明です。また、light_funcの結果だけを確認したい場合であっても、heavy_funcの時間のかかる処理が終わるのを待つ必要があり、結果的に使い勝手の悪い機能となっています。  
  
同期処理が問題となる別の例について考えてみます。最近のWebページはマルチメディア対応が進み、テキストや画像だけでなく、音声や動画のようにリッチなコンテンツも閲覧できるようになっています。その一方で、音声や動画はファイルサイズが大きいため、回線の状況によってはダウンロードに時間がかかることもあります。もし、Webページの表示が同期処理だった場合、ページに含まれるすべてのコンテンツを順番に読み込むことになります。そのため、ファイルサイズの大きいコンテンツを含むWebページ全体を表示するためにかかる時間は、時として非常に長時間となり、ユーザにとっては使いづらいページとなってしまいます。  
  
上記の問題を解決するためには、以下で述べる非同期処理が有効です。

### 非同期処理について

非同期処理は、前項で説明した同期処理の逆で、必ずしもプログラムに書かれた順番どおりに処理が行われないことを指します。  
これだけではイメージしづらいと思うので、まずはサンプルコードを見ていきます。以下は、非同期処理となるシンプルな例です。

```javascript
console.log('1');
setTimeout(function(){console.log('2')}, 1000);
console.log('3');

/*
1
3
2
*/
```

上記のサンプルコードを実行すると、コンソールには1、3、2と出力されます。上記のコードを同期処理として考えると、上から順番に実行されて1、2、3と出力されるように思えますが、実際には順番どおりにコンソール出力は行われません。これが、非同期処理の例となります。  
上記のサンプルコードでも、同期処理の場合と同様に、JavaScriptは上から順番にスクリプトを読み込んでいきます。そのため、最初に実行されるのは一行目の`console.log('1');`です。その後は、二行目の`setTimeout`、三行目の`console.log('3');`の順番で処理が実行されます。以上は同期処理と同様の挙動となります。  
同期処理のサンプルコードと異なるのは、2行目のコードで、関数setTimeoutを使用しており、かつ引数でさらに別の無名関数(function(){~})を呼び出しているという点です。[以前のセクションで説明したとおり](browser_objects.md#setInterval、setTimeoutメソッド)、setTimeoutは引数に指定した時間の経過後に、引数の処理(関数)をキューに登録する働きがあります。そのため、処理の順番を決めるキューには、以下の順番で処理が格納されていくことになります。

1. console.log('1');
2. setTimeout; (引数内の無名関数はまだ登録されない)
3. console.log('3');
4. setTimeoutの引数の無名関数function(){~}
5. 無名関数のコードブロック内のconsole.log('2')

このキューに登録された順番に処理が実行されるため、コンソールには1、3、2の順番で出力されます。この結果として、コードが書かれた順序どおりに処理が実行されていない(非同期処理となっている)ように見えるのです。  
  
なお、`setTimeout(function(){console.log('2')}, 1000);`のように、ある関数の引数に別の関数を渡すことで、ある関数から別の関数を呼び出すことを**コールバック**といいます。上記のサンプルコードにも言えることですが、コールバックを使用することで非同期処理を実装することができます。この方法は次項の初めに詳しく説明しますが、現在のJavaScriptでは基本的にコールバックを使用した非同期処理の実装は行いません(非推奨です)。  
  
同期処理の問題点は、実行に時間がかかる処理があると、そこでプログラム全体が停止してしまうことでした。この問題は、非同期処理を使用すると解決できることがあります。例えば、先述のWebページの表示について考えます。同期処理の場合は、すべてのコンテンツの読み込みを待つ必要があったため、表示に時間がかかってしまうという問題がありました。この処理を非同期処理にした場合、例えば動画の読み込みが終わっていない段階でも、テキストや画像の表示を行うことができるため、ユーザが体感するWebページのレスポンスは改善することになります。実装のイメージとしては、テキストの読み込み、画像の読み込み、動画の読み込み、...というように、すべての読み込みを同時に開始し、実行が完了したものからブラウザに描画する、といった形式になります。  
  
【参考】非同期処理は処理が並列して実行されるように見えるため、JavaScriptは非同期処理をマルチスレッドで実行しているように思われるかもしれません。しかし、この認識は誤りです。実際には、**JavaScriptは特別な実装をしない限りシングルスレッドで動作します。**非同期処理の動作イメージとしては、各処理を細かい単位に区切って、この単位をシングルスレッド上で順番に実行していると考えてください。例えば、非同期処理の関数a、b、cがあり、これらの処理をa1、a2、a3、b1、b2、b3...、c3と、各関数を3個の単位に区切ったとします。これをシングルスレッド上で、a1、b1、c1、a2、b2、c2、...、c3という順番で実行していくと、あたかも各処理が並列実行されているように見えるのです。  
なお、JavaScriptをマルチスレッドで実行するためには、Web Worker APIを使用して実装する必要があります([Web Worker の使用 - Web API | MDN](https://developer.mozilla.org/ja/docs/Web/API/Web_Workers_API/Using_web_workers))。

### 実装時の注意点

ここまで、同期処理と非同期処理について説明してきました。それぞれの挙動について、その概要が理解できていれば、ここまでは問題ありません。以下では、実際の開発において、同期処理・非同期処理の違いによって問題が起きうる場面について、簡単に説明します。  
  
これまでのセクションで実装してきたサンプルコードは、一部の例外を除いて、すべて同期処理として振る舞っていました。つまり、上から下へ、コードを書いた順番に処理が実行されていました(繰り返しになりますが、関数呼び出しなどでコードを行き来することはあります)。一方で、外部ライブラリ(API)の関数(メソッド)は、非同期処理として実装されていることがあります。このような実装となっている理由は様々ですが、基本的には前述した同期処理で発生する問題(時間がかかる処理の場合にプログラム全体が止まってしまうこと)を防ぎ、効率よくプログラムを実行するためです。  
非同期処理の関数を使用する場合、この関数が同期処理として振る舞うと勘違いして実装してしまうと、全体の処理がうまくいかず、バグを埋め込む可能性もあるため、注意が必要です。  
以下の例は、データベースにアクセスする非同期処理の関数fetchを使用する例を、模式的に表しています。

```javascript
const result = dbLibrary.fetch(検索条件); // 非同期処理
console.log(result); // 結果はどうなる?
```

仮に関数fetchが同期処理として動作する場合、まず関数fetchがデータベースにアクセスして検索結果を取得し、戻り値として定数resultに格納します。その後、resultがコンソール出力される、という処理の流れになります。  
今回の想定では、関数fetchは非同期処理としています。この場合、上記のプログラムはどのような挙動を取るでしょうか。まず、関数fetchが最初に実行されるのは同期処理の場合と同様です。しかし、関数fetchは非同期処理として実装されているため、この段階では定数resultへの検索結果の格納までは行われません。よって、次に実行される処理は、二行目の`console.log(result);`です。この行が実行されるタイミングでは、まだresultに検索結果は格納されていません。この理由は、関数fetchが非同期処理で、データベースへのアクセスを行って検索結果を取得するまでにはある程度の時間がかかるためです。そのため、コンソールには`undefined`が出力されます。この後、関数fetchの内部でデータベースへのアクセスと検索が実行され、resultに検索結果が格納される、という流れになります。  
上記の処理をさらに簡略化したサンプルコードを、以下に示します。以下のコードでは、関数fetchの処理に、非同期処理の関数setTimeoutを記述しています。このプログラムを実行すると、確かに定数resultの出力結果は`undefined`となることが確認できます。また、定数resultが出力された後、setTimeoutのコールバック関数内の`console.log('DBアクセス完了');`が実行され、コンソール出力されることも合わせて確認してください。

```javascript
const result = fetch(); // 非同期処理
console.log(result); // 結果はどうなる?

function fetch () {
    let ret
    setTimeout(() => {
        console.log('DBアクセス完了');
        ret = '検索結果';
    }, 1000);

    return ret;
}
```

上記のサンプルコードのように、非同期処理を含む処理が順序どおりに動作する必要がある場合(同期処理として動作する必要がある場合)には、非同期処理の性質である「必ずしもコードに記述されている順序で実行されるわけではない」という点が問題になります。仮に上記の関数fetchが非同期関数であるという認識がなかった場合、デバッグの際に正しくデータベースにアクセスできていないと誤認し、無駄な調査をしてしまう可能性もあります。そのため、JavaScriptは非同期処理として実行される可能性があることを認識し、非同期処理を順番に(同期処理として)実行することが必要な場合には、後述の同期処理を実装するための記述を明示的に行うことが必要です。  
  
ここまでに解説してきた内容で、特に覚えておきたいポイントは以下のとおりです。

- 同期処理と非同期処理の違い
  - 同期処理は、プログラムが書かれた順番に実行される処理のこと
  - 非同期処理は、プログラムが書かれた順番に(必ずしも)実行されない処理のこと
- JavaScriptは基本的に同期処理として動作するが、実装の仕方によっては非同期処理として動作する

## 実装方法の変遷

ここまでは、同期処理と非同期処理について、その概要を説明してきました。ここからは、実際にJavaScriptで非同期処理を実装する方法について説明します。基本的に非同期処理の実装の仕方について説明しますが、非同期処理を同期処理として実行する方法についても合わせて説明します。  
[以前のセクション](overview.md#再興)で、JavaScriptは標準団体のEcma InternationalによりECMAScriptという名称で規格化され、改定が続けられていると述べました。この改定の中で、非同期処理の実装方法も改善され続けています。以下では、非同期処理の実装方法について、古いものから順番に解説します。また、最新の実装方法であるasync、awaitを使用した方法については、項を分けて説明します。  
実装方法が改善され続けているのであれば、最新の方法だけを知っていればよいのではないかと思われるかもしれませんが、ネット上や書籍では新旧の実装方法が混在して紹介されているため、古い実装方法を知っているとコードの読解に役立つ場合があります。そのため、実際に使用しなくても、古い実装方法について知っておくことは有益です。

### コールバックを使用した実装

まず、最も古い実装の仕方である、コールバックを使用した非同期処理の実装について紹介します。この方法は、前述のsetTimeout関数を使用する方法で、実装の仕方そのものは理解しやすいと思います。しかし、後述のサンプルコードを読むと理解できると思いますが、この実装方法で実装したコードは可読性に問題があります。そのため、今後の開発で実装するJavaScriptのプログラムにおいては、基本的に使用しません。  
  
まず、同期処理を行う関数を実装したサンプルコードを示します。なお、非同期処理については、この後で説明します。この理由は、同期処理・非同期処理の概要説明の際と同様に、同期処理の実装方法から理解したほうが、結果的に非同期処理について理解しやすくなるためです。  
以下のサンプルコードは、ホテルの予約を模した機能です。定数syncReservationには関数リテラルが格納されていて、引数として受け取った予約リスト(配列)に、こちらも引数として受け取った予約者の名前(文字列)を追加して返却します。なお、このホテルの部屋数は5のため、5部屋以上の予約はできません。そのため、引数として受け取った予約リストの長さが5以上の場合には予約リストに名前を追加せず、未変更の予約リストとエラーメッセージを返却します。

```javascript
const syncReservation = (list, name) => {
    if (list.length < 5) {
        list.push(name);
        return {list:list, error:null};
    } else {
        return {list:list, error:'定員超過です'};
    }
}

const list = [];
result = syncReservation(list, 'John');
console.log(result.list); // Array(1) ["John"]
```

では、関数syncReservationを複数回実行してみます。syncReservationの戻り値はオブジェクトです。このオブジェクトには、listプロパティに予約者リストが、errorプロパティにエラーメッセージが、それぞれ格納されています。この戻り値に応じて、メッセージをコンソール出力するように実装します。

```javascript
const syncReservation = (list, name) => {
    if (list.length < 5) {
        list.push(name);
        return {list:list, error:null};
    } else {
        return {list:list, error:'定員超過です'};
    }
}

const list = [];
result = syncReservation(list, 'John');
if (result.list !== null) {
    console.log('1回目の実行結果: ' + result.list);
}
if (result.error !== null) {
    console.log(result.error);
}
result = syncReservation(list, 'Tom');
if (result.list !== null) {
    console.log('2回目の実行結果: ' + result.list);
}
if (result.error !== null) {
    console.log(result.error);
}
result = syncReservation(list, 'Bob');
if (result.list !== null) {
    console.log('3回目の実行結果: ' + result.list);
}
if (result.error !== null) {
    console.log(result.error);
}
result = syncReservation(list, 'Kim');
if (result.list !== null) {
    console.log('4回目の実行結果: ' + result.list);
}
if (result.error !== null) {
    console.log(result.error);
}
result = syncReservation(list, 'George');
if (result.list !== null) {
    console.log('5回目の実行結果: ' + result.list);
}
if (result.error !== null) {
    console.log(result.error);
}
result = syncReservation(list, 'Alice');
if (result.list !== null) {
    console.log('6回目の実行結果: ' + result.list);
}
if (result.error !== null) {
    console.log(result.error);
}
```

上記のプログラムを実行すると、以下のようにコンソール出力されます。

```text
1回目の実行結果: John
2回目の実行結果: John,Tom
3回目の実行結果: John,Tom,Bob
4回目の実行結果: John,Tom,Bob,Kim
5回目の実行結果: John,Tom,Bob,Kim,George
6回目の実行結果: John,Tom,Bob,Kim,George
定員超過です
```

以上の同期処理の挙動は、特に問題なく理解できると思います。また、コードの見た目(可読性)については、同じような処理が何度も繰り返されて冗長ですが、ネストは2階層(resultに代入する階層とif命令のコードブロック内)であり、読解は難しくないことを確認してください。  
  
次に、上記の機能をコールバックを使用した非同期処理として実装する場合を考えます。まず、関数syncReservationを、以下のように書き換えます。

```javascript
const asyncReservation = (list, name, callback) => {
    setTimeout(function () {
        if (list.length < 5) {
            list.push(name);
            callback(list, null);
        } else {
            callback(list, '定員超過です');
        }
    }, 0);
}

const list = [];
asyncReservation(list, 'John', (list, error) => {
    if (error === null) {
        console.log('実行結果: ' + list);
    } else {
        console.log(error);
    }
});

console.log('asyncReservationの後に記述した処理');

/*
asyncReservationの後に記述した処理
実行結果: John
*/
```

関数asyncReservationは、引数として、予約者リスト、予約者名、そして関数リテラルを受け取ります。コードブロック内の処理では、まずsetTimeoutを使用することで非同期処理として実装しています。setTimeoutの引数に指定した関数では、予約者リストの長さが5未満の場合に、予約者リストに予約者名を追加し、予約者リスト(とnull)をasyncReservationの引数として受け取った関数リテラルに渡します。予約者リストの長さが5以上のときは、未変更の予約リストとエラーメッセージを引数としてasyncReservationの引数として受け取った関数リテラルに渡します。  
関数asyncReservationを実行する場合は、引数として予約者リストと予約者名のほか、関数リテラルを渡します。今回の実装では、関数リテラルとして、予約者リストとエラーメッセージを受け取り、エラーメッセージがnullの場合は予約者リストの内容を出力し、そうでない場合は引数として受け取ったエラーメッセージを表示する、という無名関数を渡しています。  
  
上記の説明を読むと、サンプルコードでは難しい処理を実行しているように思えますが、実際にはこれまでに学習した内容で構成されています。setTimeoutで非同期処理を実装しているということがポイントです。また、関数asyncReservationに渡している関数リテラルは、関数内で呼び出されるコールバック関数です。ここの処理の流れはやや複雑なので、コードを読み、実行しながら理解するようにしてください。  
プログラムを実行してコンソール出力を確認すると、確かに関数asyncReservationの後に記述されている`console.log('asyncReservationの後に記述した処理');`が先に出力され、asyncReservationが非同期処理となっていることがわかります。  
  
では、上記のプログラムで作成した関数asyncReservationを複数回、同期処理として(順番に)実行してみます。一回目のasyncReservationの実行が成功したら、asyncReservationの引数のコールバック関数で二回目のasyncReservationを実行する...という形で、処理を6回繰り返します。

```javascript
const asyncReservation = (list, name, callback) => {
    setTimeout(function () {
        if (list.length < 5) {
            list.push(name);
            callback(list, null);
        } else {
            callback(list, '定員超過です');
        }
    }, 0);
}

const list = [];
asyncReservation(list, 'John', (list, error) => {
    if (error === null) {
        console.log('1回目の実行結果: ' + list);
        asyncReservation(list, 'Tom', (list, error) => {
            if (error === null) {
                console.log('2回目の実行結果: ' + list);
                asyncReservation(list, 'Bob', (list, error) => {
                    if (error === null) {
                        console.log('3回目の実行結果: ' + list);
                        asyncReservation(list, 'Kim', (list, error) => {
                            if (error === null) {
                                console.log('4回目の実行結果: ' + list);
                                asyncReservation(list, 'George', (list, error) => {
                                    if (error === null) {
                                        console.log('5回目の実行結果: ' + list);
                                        asyncReservation(list, 'Alice', (list, error) => {
                                            if (error === null) {
                                                console.log('6回目の実行結果: ' + list);
                                            } else {
                                                console.log('定員超過です');
                                            }
                                        })
                                    } else {
                                        console.log('定員超過です');
                                    }
                                })
                            } else {
                                console.log('定員超過です');
                            }
                        })
                    } else {
                        console.log('定員超過です');
                    }
                })
            } else {
                console.log('定員超過です');
            }
        })
    } else {
        console.log('定員超過です');
    }
});
```

上記のプログラムを実行すると、以下のようにコンソール出力されます。

```text
1回目の実行結果: John
2回目の実行結果: John,Tom
3回目の実行結果: John,Tom,Bob
4回目の実行結果: John,Tom,Bob,Kim
5回目の実行結果: John,Tom,Bob,Kim,George
定員超過です
```

上記のコードは確かに期待どおりの結果となりますが、ひと目で見ただけで可読性に乏しいことが理解できると思います。コードの行数や冗長さは言うまでもなく、ネストが非常に深いため、処理の流れをたどることが極めて難しいコードになっています。サンプルコードでは、コールバック関数はそれぞれ同じような処理をしているためいくぶん理解しやすいですが、これがそれぞれ異なった処理を行う関数となっている場合、コードだけを読んで処理を理解することは不可能に近いです(別途、何らかの補足説明が必要でしょう)。  
上記のコードのように、コールバック関数の内部でコールバックを行い、さらにそのコールバック関数の内部でコールバックを行う...というように、コールバックを連続して行うと、ネストが深くなり、可読性が損なわれることが経験的に知られています。このことを、**コールバック地獄**と呼びます。  
このコールバック地獄こそが、コールバックを使用して非同期処理を実装すべきでない理由です。この方法は、単純な処理を実行する場合であれば問題ありませんが、後述の方法と比較すると保守性も可読性も劣ることから、できるだけ使用しないことを推奨します。

### Promiseオブジェクトを使用した実装

Promiseオブジェクトは、非同期処理の完了(もしくは失敗)およびその結果を表現するオブジェクトで、ES6(ES2015)の改定で追加されました。Promiseオブジェクトを使用して非同期処理を実装することで、コールバックを使用した非同期処理よりも可読性に優れたコードを記述することができます。  
  
Promiseオブジェクトを使用して非同期処理を実装すること自体は、これまでのセクションで実装してきたプログラムと比較しても、そこまで難しいものではありません。ただ、Promiseオブジェクトの仕組みはやや複雑であり、その仕組みについて考慮すべき点が多々あることも事実です。その証拠に、[Promiseと非同期処理を扱った100ページを超える解説書(フリー)](https://azu.github.io/promises-book/)も存在するほどです。  
上記のとおり、Promiseオブジェクトの仕組み自体は単純ではありません。よって、このセクションではPromiseオブジェクト自体の仕組みについては深入りせず、非同期処理に使用する方法について重点的に解説します。まずはPromiseオブジェクトの使い方を確認し、その後に仕組みを把握する、という順番で学習すると、内容が理解しやすいと思います。  
また、Promiseオブジェクトの仕組みや非同期処理について興味がある方は、ぜひとも上記の解説書などを参考にして自己学習してみてください。プログラミング全般に言えることですが、使い方だけではなく動作原理そのものを知っていれば、より実行効率がよく、バグの少ないプログラムを書くことができるようになります。  
  
ここからは、Promiseオブジェクトの具体的な使い方を見ていきます。実装するのは、コールバックを使用した非同期処理の際と同様に、ホテル予約を模した機能です。

```javascript
const promiseReservation = (list, name) => {
  return new Promise((resolve, reject) => { // [1]
    if (list.length < 5) {
      list.push(name);
      resolve(list); // [2]
    } else {
      reject('定員超過です'); // [3]
    }
  });
};

const list = [];

promiseReservation(list, 'John')
  .then(list => { // [4]
    console.log(list);
  })
  .catch(error => {
    console.log('エラーが発生しました：' + error);
  });

console.log('promiseReservationの後に記述した処理');

/*
promiseReservationの後に記述した処理
Array(1) ["John"]
*/
```

Promiseオブジェクトを使用する場合は、まず非同期処理を関数にまとめます(promiseReservation)。この関数の戻り値をPromiseオブジェクトとします([1])。  
Promiseは、非同期処理の状態を監視するオブジェクトです。コンストラクタには、実行すべき非同期処理を関数リテラル、もしくはアロー関数として記述します。以下は、アロー関数を使用した場合のPromiseコンストラクタの構文です。

- `new Promise((resolve, reject) => {statements})`
  - resolve: 処理の成功を通知するための関数
  - reject: 処理の失敗を通知するための関数
  - statements: 処理本体

処理本体(statements)の引数であるresolve、rejectは、それぞれ非同期処理の成功と失敗を通知するための関数です。Promiseオブジェクトによって渡されるものなので、開発者は非同期処理の結果をこれらの関数を使用して通知すればよいことになります。  
サンプルコードであれば、関数promiseReservationの引数として受け取ったlistの長さが5未満であれば関数resolve(成功)を([2])、5以上であれば関数reject(失敗)を([3])、それぞれ呼び出しています。関数resolve、rejectの引数には、それぞれ成功したときの結果、エラーメッセージなどを、任意のオブジェクトとして渡すことができます。  
Promiseオブジェクト(関数resolve、reject)の実行結果を受け取るのは、thenメソッドです([4])。

- Promise.then(success, failure)
  - Promise: Promiseオブジェクト
  - success: 成功時のコールバック関数(関数resolveによって呼び出される)
  - failure: 失敗時のコールバック関数(関数rejectによって呼び出される)

引数success、failureは、それぞれ関数resolve、rejectで指定された引数を受け取って、成功・失敗の処理を実行します。ただし、引数success、failureは必須ではありません(指定しないこともできます)。また、サンプルコードのように、thenの引数に対してコールバック関数を1つだけ(successのみ)指定した場合、[関数の引数が不足している場合の挙動に則って](function.md#JavaScriptは引数の数をチェックしない)、引数failureは自動的にundefinedとなります。よって、thenの引数のコールバック関数は正常系(非同期処理の成功時のみ呼び出される)処理という役割になります。  
catchメソッドは、thenメソッドと類似した働きをするメソッドです。

- Promise.catch(failure)
  - Promise: Promiseオブジェクト
  - failure: 失敗コールバック関数(関数rejectによって呼び出される)

catchメソッドの引数は1つで、関数rejectによって呼び出される失敗コールバック関数を指定します。つまり、catchメソッドの動作は、thenメソッドでthen(null, failure)とした場合と等価です。

thenメソッドやcatchメソッドは、新しいPromiseオブジェクトを戻り値として返却します。そのため、thenメソッドやcatchメソッドの後ろに`.then`や`.catch`をつなげることで、複数の非同期処理を順番に(同期処理として)実行できます。この実装方法を**Promiseチェーン**といいます。

#### 非同期処理を順番に呼び出す

以下では、Promiseチェーンの形式で非同期処理を順番に(同期処理として)呼び出す例を示します。以下のサンプルコードは、コールバックを使用して非同期処理を順番に呼び出した場合と同様に、関数promiseReservationを6回呼び出す例です。

```javascript
const promiseReservation = (list, name) => {
  return new Promise((resolve, reject) => { // [1]
    if (list.length < 5) {
      list.push(name);
      resolve(list); // [2]
    } else {
      reject('定員超過です'); // [3]
    }
  });
};

const list = [];

promiseReservation(list, 'John')
  .then(list => {
    console.log('1回目の実行結果:' + list);
    return promiseReservation(list, 'Tom'); // [1]
  })
  .then(list => {
    console.log('2回目の実行結果:' + list);
    return promiseReservation(list, 'Bob');
  })
  .then(list => {
    console.log('3回目の実行結果:' + list);
    return promiseReservation(list, 'Kim');
  })
  .then(list => {
    console.log('4回目の実行結果:' + list);
    return promiseReservation(list, 'George');
  })
  .then(list => {
    console.log('5回目の実行結果:' + list);
    return promiseReservation(list, 'Alice');
  })
  .then(list => {
    console.log('6回目の実行結果:' + list);
  })
  .catch(error => {
    console.log('エラーが発生しました：' + error);
  });

console.log('promiseReservationの後に記述した処理');
```

上記のプログラムを実行すると、以下のようにコンソール出力されます。

```text
promiseReservationの後に記述した処理
1回目の実行結果: John
2回目の実行結果: John,Tom
3回目の実行結果: John,Tom,Bob
4回目の実行結果: John,Tom,Bob,Kim
5回目の実行結果: John,Tom,Bob,Kim,George
エラーが発生しました：定員超過です
```

まず、Promiseチェーンで記述したコードは、コールバックで記述したコードと比較すると、圧倒的に可読性に優れていることが理解できると思います。コールバックの場合よりもコードの行数が減ることはもちろん、ネストが浅いため処理の流れを容易にたどることができます。  
コールバックの場合は、非同期処理の関数を呼び出すたびに戻り値をif文で判定し、エラー処理を記述していました。一方のPromiseチェーンでは、if文によるエラーの判定は不要で、正常に実行されればPromise.then、エラーであればPromise.catchの処理が自動的に実行されます。さらに、エラー処理自体も呼び出しのたびに記述する必要はなく、Promise.catchの引数に与えるコールバック関数として一度だけ記述すればよいため、冗長なコードが削減されて可読性が向上します。

では、Promiseチェーンの記述方法について再確認します。Promiseチェーンは、thenメソッドやcatchメソッドがPromiseオブジェクトを返却するように実装することで、これらのメソッドの後ろに`.then`や`.catch`でメソッドを繋げていく実装方法です。よって、関数promiseReservationを1回だけ実行するサンプルコードではthenメソッドで何も返却していなかったところに、新たにPromiseオブジェクトを返却する行を追加します([1]ほかのthenメソッドの実装)。  
ここでポイントとなるのが、この行で再び関数promiseReservationを呼び出している点です。こうすることで、一回目のpromiseReservationの実行が成功するとthenメソッドが実行され、このthenメソッドのコールバック関数で二回目のpromiseReservationを実行し、この実行が成功したら、返却されたPromiseオブジェクトのthenメソッドが実行される...という処理を繰り返して、非同期処理を順番に実行します。今回の場合は、最終的にpromiseReservationの実行が失敗するまで(catchメソッドが実行されるまで)、繰り返し実行されます。  
先述のとおり、関数promiseReservationの実行が失敗した場合に呼び出される処理は、catchメソッドの引数に与えるコールバック関数で実装します。今回のサンプルコードでは、promiseReservationを6回呼び出した時点でcatchメソッドが実行されますが、promiseReservationの呼び出しが何回目であっても、基本的にはcatchメソッドはPromiseチェーンの末尾に1度だけ記述します。サンプルコードの`const list = []`に、初期値としていくつかの要素を追加して実行すると、Promiseチェーンの途中でエラーとなった場合に途中のthenメソッドを飛ばしてcatchメソッドが実行されることが確認できます。

#### 非同期処理を並行実行する

ここまで、非同期処理を順番に(同期処理として)実行する方法を紹介しました。この項では、複数の非同期処理を並行実行する方法について解説します。  
  
【参考】前述のとおり、以下の実装方法でもJavaScriptはシングルスレッドで動作します。見かけ上、並列実行されるように見えるだけであり、実際にはマルチスレッドで並列実行されるわけではありません。  

- すべての非同期処理が成功した場合にコールバックする(Promise.allメソッド)  
    Promise.allメソッドを使用すると、複数の非同期処理を並行実行し、そのすべてが成功した場合にthen(いずれかが失敗した場合はcatch)メソッドを実行します。

    - Promise.all(promises)
      - promises: 監視するPromiseオブジェクト群(配列)

    以下のサンプルコードでは、引数として受け取った文字列をコンソール出力する非同期処理を実装しています。この非同期処理を並行実行するシンプルな例です。

  ```javascript
  const promiseDisplay = str => {
    return new Promise((resolve, reject) => {
      if (str) {
        resolve(str);
      } else {
        reject('文字列が空です');
      }
    });
  };

  Promise.all([
    promiseDisplay('文字列1'),
    promiseDisplay('文字列2'),
    promiseDisplay('文字列3')
  ])
    .then(arr => {
      console.log(arr);
    })
    .catch(str => {
      console.log('エラーが発生しました：' + str);
    });
  ```

  サンプルコードを実行すると、以下のようにコンソール出力されます。  

  `Array(3) ["文字列1", "文字列2", "文字列3"]`  

  Promise.allメソッドでは、引数promisesで渡されたすべてのPromiseオブジェクトがresolve(成功)した場合にだけ、thenメソッドの成功コールバックを実行します。その際、引数arrには、すべてのPromiseから渡された結果が配列として渡されます。  
  Promiseオブジェクトのいずれかがreject(失敗)した場合には、失敗コールバックが呼び出されます。promiseDisplayメソッドの引数のいずれかを空にして、「エラーが発生しました: 文字列が空です」とコンソール出力されることを確認してください。 

  Promise.allメソッドの使用例としては、非同期処理の外部APIを複数実行する際に、実行順序は処理に影響しないため並行実行でよい場合や、APIの実行が一つでも失敗した場合に、他のAPIの実行終了を待たずにエラーを返却する(エラー時のレスポンス待ち時間を短縮する)、といったパターンがあります。

- ひとつの非同期処理が完了した時点でコールバックする(Promise.raceメソッド)  
    Promise.raceメソッドは、並行して実行した非同期処理のいずれか1つが最初に完了したところで成功コールバックを返却します。以下のサンプルコードにて実装していますが、実行結果はどの処理が最初に終了したかに応じて変化します。

  ```javascript
  const promiseDisplay = str => {
    return new Promise((resolve, reject) => {
      if (str) {
        resolve(str);
      } else {
        reject('文字列が空です');
      }
    });
  };

  Promise.race([
    promiseDisplay('文字列1'),
    promiseDisplay('文字列2'),
    promiseDisplay('文字列3')
  ])
    .then(arr => {
      console.log(arr);
    })
    .catch(str => {
      console.log('エラーが発生しました：' + str);
    });
  ```

  【参考】Promise.raceメソッドは、引数に指定された非同期処理のいずれか1つが完了した時点で成功コールバックを返却するため、すべての処理が終了する前に後続のthenメソッドの処理へ進むことができます。しかし、thenメソッドへ進んだ段階でも、他の非同期処理は依然として実行され続けます。  
  この挙動が確認できる例として、以下のサンプルコードを示します。この例では、2つの非同期関数をPromise.raceメソッドを使用して並行実行しています。

  ```javascript
  const func1 = () => {
    console.log('func1実行');
    return new Promise((resolve, reject) => {
      resolve();
    });
  };

  const func2 = () => {
    setTimeout(function() {
      console.log('func2実行');
    }, 1000);
    return new Promise((resolve, reject) => {
      resolve();
    });
  };

  Promise.race([func1(), func2()])
    .then(console.log('thenメソッド実行'))
    .catch();
  ```

  このプログラムの実行結果は、以下のようになります。この結果から、並行実行していたfunc1だけではなく、func2も最後まで実行されることがわかります。

  ```text
  func1実行
  thenメソッド実行
  func2実行
  ```

  未完了の非同期処理(サンプルコードであればfunc2)を終了する方法はありません。ただし、プログラム全体を終了することで、未完了の非同期処理ごと終了することはできます。非同期処理のいずれか1つが終了した段階でプログラムの実行を終了する場合は、thenメソッドで`process.exit(1)`を呼び出します。

  ```javascript
  Promise.race([func1(), func2()])
  .then(process.exit(1))
  .catch();
  ```

## async function宣言とawait演算子を使用した実装

async function宣言とawait演算子は、ES8(ES2017)の改定で追加された構文です。これらを組み合わせて使用すると、非同期処理や非同期処理の同期実行を簡単かつ可読性に優れたコードとして実装できるようになります。いずれの構文も、前項で解説したPromiseオブジェクトと関連が深いため、必要に応じて前項の内容も確認しながら読み進めてください。  
これ以降の説明ではasync function宣言を「async」、await演算子を「await」と表記します。なお、asyncはasynchronous[`eɪsíŋkrənəs`]の略称で「エイシンク」(アシンクではない)、awaitは「アウェイト」と発音します。

### asyncについて

関数宣言にasyncをつけることで、非同期処理の関数を定義できます。この関数は、暗黙的にPromiseを返却します。前項では、非同期処理として実装する関数で明示的にPromiseオブジェクトを生成して(newして)返却していましたが、asyncを使用するとこの手順が不要になります。その代わり、asyncで生成した関数は、正常終了時の戻り値をreturnで、異常終了時の戻り値をthrowで、それぞれ返却するように実装します。asyncで生成した関数では、これらの戻り値に基づいて自動的にPromiseオブジェクトが生成され、呼び出し元に返却されます。
  
まずは、前項で紹介したPromiseオブジェクトを使用した非同期関数の実装と、asyncを使用した非同期関数の実装を比較しながら、実装方法とその挙動を見ていきます。  
Promiseオブジェクトを使用した実装では、非同期関数内でPromiseオブジェクトを生成して返却する必要がありました。確認のため、前項のサンプルコードを再掲します。

```javascript
const promiseReservation = (list, name) => {
  return new Promise((resolve, reject) => {
    if (list.length < 5) {
      list.push(name);
      resolve(list);
    } else {
      reject('定員超過です');
    }
  });
};
```

上記のコードをasyncを使用して書き換えると、以下のようになります。

```javascript
const asyncReservation = async (list, name) => {
  if (list.length < 5) {
    list.push(name);
    return list; // [1]
  } else {
    throw '定員超過です'; // [2]
  }
};
```

アロー関数に対してasyncを適用する場合、引数の手前(`(list, name)`の手前)に記述します。また、正常終了時の戻り値はreturn([1])として、異常終了時の戻り値はthrow([2])として記述します。

function命令に対してasyncを適用する場合は、以下のようになります。

```javascript
async function asyncReservation(list, name) {
  if (list.length < 5) {
    list.push(name);
    return list;
  } else {
    throw '定員超過です';
  }
} 
```

function命令の場合は、asyncをfunction命令の直前に記述します。戻り値については、アロー関数の場合と同様です。

上記のサンプルコードからわかるように、asyncを使用して定義した関数では明示的にPromiseオブジェクトを返却する必要がありません(暗黙的にPromiseオブジェクトが返却されます)。その代わりに、同期処理の関数のように、呼び出し元に返却したい戻り値をそのままreturn(またはthrow)します。このように、非同期処理であっても、同期処理の場合と同じように記述できることがasyncを使用するメリットの一つです。  
  
次に、asyncで生成した関数の呼び出し方を見ていきます。とはいえ、asyncで生成した関数も、その実体としてはPromiseオブジェクトを返却する関数になります。そのため、呼び出し方はPromiseを明示的に返却する非同期処理の関数とまったく同じです。つまり、前項で紹介したPromise.thenメソッド、Promise.catchメソッドで関数の実行結果を受け取ることができます。  
以下に、asyncで生成した関数を呼び出し、実行結果を受け取るサンプルコードを示します。

```javascript
const asyncReservation = async (list, name) => {
  if (list.length < 5) {
    list.push(name);
    return list;
  } else {
    throw '定員超過です';
  }
};

const list = [];

asyncReservation(list, 'John')
  .then(list => {
    console.log(list);
  })
  .catch(error => {
    console.log('エラーが発生しました：' + error);
  });

console.log('asyncReservationの後に記述した処理');

/*
asyncReservationの後に記述した処理
Array(1) ["John"]
*/
```

上記のサンプルコードから、asyncで生成した関数の実行結果は、Promise.then、Promise.catchで受け取ることができるとわかります。ただし、実際の開発でasyncを使用する場合には、このような呼び出し方をすることは比較的まれです。この理由は、asyncで生成した関数は後述のawaitとセットで使用することが多く、この場合はPromise.then、Promise.catchを使用せずに関数を呼び出すためです。

ここまでに述べたasyncの特徴を、以下にまとめます。

- 関数の宣言にasyncをつけることで、暗黙的にPromiseオブジェクトを返却する非同期関数を生成できる
- asyncで生成した関数は、正常終了時の戻り値をreturnで、異常終了時の戻り値をthrowで、それぞれ返却するように実装する
- asyncで生成した関数の戻り値はPromiseオブジェクトのため、Promise.then、Promise.catchを使用して実行結果を受け取ることができる

### awaitについて

awaitを使用すると、asyncで生成した関数がPromiseオブジェクトを返却するまで待機する(プログラムの実行を一時停止する)ことができます。この性質を利用して、非同期処理を同期処理として逐次実行するためによく使用します。  
  
まずは、Promiseチェーンの形式で非同期処理の関数を複数回実行する例について、再度確認します。前掲のサンプルコードを、一部抜粋して以下に示します。

```javascript
const promiseReservation = (list, name) => {
  return new Promise((resolve, reject) => { // [1]
    if (list.length < 5) {
      list.push(name);
      resolve(list); // [2]
    } else {
      reject('定員超過です'); // [3]
    }
  });
};

const list = [];

promiseReservation(list, 'John')
  .then(list => {
    console.log('1回目の実行結果:' + list);
    return promiseReservation(list, 'Tom'); // [1]
  })
  .then(list => {
    console.log('2回目の実行結果:' + list);
    return promiseReservation(list, 'Bob');
  })
  
  // 以下、Promiseチェーンの形式でthenメソッドが繰り返される
  
  .catch(error => {
    console.log('エラーが発生しました：' + error);
  });
```

次に、上記のコードをasyncとawaitを使用して書き換えます。

```javascript
const asyncReservation = async (list, name) => {
  if (list.length < 5) {
    list.push(name);
    return list;
  } else {
    throw '定員超過です';
  }
};

const sampleFunc = async () => {
  try {
    let list = [];
    list = await asyncReservation(list, 'John');
    console.log('1回目の実行結果:' + list);
    list = await asyncReservation(list, 'Tom');
    console.log('2回目の実行結果:' + list);
    list = await asyncReservation(list, 'Bob');
    console.log('3回目の実行結果:' + list);
    list = await asyncReservation(list, 'Kim');
    console.log('4回目の実行結果:' + list);
    list = await asyncReservation(list, 'George');
    console.log('5回目の実行結果:' + list);
    list = await asyncReservation(list, 'Alice');
    console.log('6回目の実行結果:' + list);
  } catch (error) {
    console.log('エラーが発生しました：' + error);
  }
};

sampleFunc();
console.log('asyncReservationの後に記述した処理');
```

上記のコードでは、Promiseを使用した場合のコードと比較しやすいように、単純にasyncReservationを6回呼び出しています。この記述はやや冗長なので、for文を使用して書き換えます。

```javascript
const asyncReservation = async (list, name) => {
  if (list.length < 5) {
    list.push(name);
    return list;
  } else {
    throw '定員超過です';
  }
};

const sampleFunc = async () => { // [1]
  const memberList = ['John', 'Tom', 'Bob', 'Kim', 'George', 'Alice'];
  let reservationList = [];
  let counter = 1;

  for (member of memberList) {
    try {
      reservationList = await asyncReservation(reservationList, member); // [2]
      console.log(counter + '回目の実行結果:' + reservationList);
      counter++;
    } catch (error) { // [3]
      console.log('エラーが発生しました：' + error);
    }
  }
};

sampleFunc();
console.log('asyncReservationの後に記述した処理');
```

上記のプログラムを実行すると、以下のようにコンソール出力されます。

```text
asyncReservationの後に記述した処理
1回目の実行結果: John
2回目の実行結果: John,Tom
3回目の実行結果: John,Tom,Bob
4回目の実行結果: John,Tom,Bob,Kim
5回目の実行結果: John,Tom,Bob,Kim,George
エラーが発生しました：定員超過です
```

サンプルコードを見てわかるとおり、Promiseを使用する場合と比較しても、コードの行数は少なくて済み、処理が追いやすくなっています。また、非同期処関数の呼び出し方もシンプルになっていて、同期処理の関数と同じように呼び出せていることがわかります。

ここからは、上記のサンプルコードをもとに、awaitの使用方法について説明します。  
まず、awaitはasyncで生成した関数内でしか使用できません([1])。awaitをasyncでない関数で使用するとエラーが発生します。そのため、サンプルコードではasyncの関数としてsampleFuncを生成して、その内部でawaitを使用しています。Promiseを使用して実装する場合と比較すると、この点だけは実装の手間が増えます。  
次に、awaitを記述する位置ですが、asyncで生成した関数を実行する際に、関数名の直前に記述します([2])。このように記述すると、呼び出したasync関数(asyncReservation)がPromiseを返却するまで、呼び出し元のasyncの関数(sampleFunc)の実行が中断されます。つまり、非同期関数を同期処理として逐次実行できます。  
また、非同期関数の戻り値の受け取り方も、これまでと異なります。awaitを付与してasyncの関数を実行した場合、その戻り値は非同期関数がreturn、またはthrowする値そのものとなります。前項で、asyncの関数は暗黙的にPromiseを返却すると説明しましたが、awaitを付与するとPromiseではなくreturn、またはthrowされる値そのものが返却されます。そのため、asyncの関数でも、同期処理の関数と同じように使用することができます。Promiseを使用する場合は、戻り値を受け取るためにコールバック関数を実装する必要がありましたが、awaitを使用した場合は不要です。そのため、awaitを使用するとコードの行数が削減できます。  
asyncの関数を実行する行をtry~catch...で囲むと、エラーが発生した場合にはcatch以下のコードブロックへ移行します([3])。Promiseを使用する場合も、Promise.catchメソッドのコールバック関数に例外処理を集約できましたが、awaitの場合はtry~catch...を使用できるため、より可読性が向上します。  
  
ここまでに述べてきたとおり、asyncとawaitを組み合わせて使用すると、非同期処理や非同期処理の同期実行を、高い可読性を保って容易に実装できます。そのため、JavaScriptの最新版で同期処理を実装する場合は、async・awaitを使用して実装することをおすすめします。  
一方で、asyncとawaitの動作には、Promiseオブジェクトが深く関わっています。そのため、Promiseオブジェクトの仕組みについても理解しておくと、asyncとawaitの挙動についての理解も深まります。よって、Promiseオブジェクトによる実装は使用しないとしても、その動作の仕組みについては理解するようにしてください。

#### 非同期処理を並行実行する（async、await）

Promiseを使用する非同期処理の実装でも紹介しましたが、async、awaitを使用する場合も、非同期処理を並行実行することができます。実装の仕方はPromiseを使用する場合とほぼ同様で、Promise.allメソッドを使用してasyncの関数を呼び出します。Promiseを使用する場合と異なるのは、Promise.allにawaitを付与することです。こうすることで、Promise.allの戻り値のPromiseオブジェクトが、asyncの関数の戻り値の配列(サンプルコードでは文字列の配列)に変換されます。
以下に、並行実行のサンプルコードを示します。

```javascript
const promiseDisplay = async str => {
  if (str) {
    return str;
  } else {
    throw '文字列が空です';
  }
};

const sampleFunc = async () => {
  try {
    const arr = await Promise.all([
      promiseDisplay('文字列1'),
      promiseDisplay('文字列2'),
      promiseDisplay('文字列3')
    ]);
    console.log(arr);
  } catch (error) {
    console.log('エラーが発生しました：' + error);
  }
};

sampleFunc();
```

上記の実装方法は、ひとつの非同期処理が完了した時点で並行実行を終了し、以降の処理へ進む場合でもほぼ同様です。この場合はPromise.raceメソッドを使用します。Promise.raceメソッドの戻り値は、最初に実行が完了した関数がreturnした値です。

```javascript
const promiseDisplay = async str => {
  if (str) {
    return str;
  } else {
    throw '文字列が空です';
  }
};

const sampleFunc = async () => {
  try {
    const str = await Promise.race([
      promiseDisplay('文字列1'),
      promiseDisplay('文字列2'),
      promiseDisplay('文字列3')
    ]);
    console.log(str);
  } catch (error) {
    console.log('エラーが発生しました：' + error);
  }
};

sampleFunc();
```