# クライアントサイドJavaScriptの基本

ここまでのセクションでは、JavaScriptが言語として持っている標準的な機能について解説してきました。JavaScriptは様々な環境で使用することができますが、ここまでに紹介してきた内容は、すべての実行環境で使用することができる標準機能や組み込みモジュールです(一部機能を除く)。  
このセクション以降の内容は、ブラウザ環境での実行を前提としています(クライアントサイドJavaScript)。ブラウザ以外の環境(サーバサイドのNode.jsなど)では実行できないので、注意してください。

## DOMについて

### DOMの概要

[DOM(Document Object Model)](https://developer.mozilla.org/ja/docs/Web/API/Document_Object_Model)は、マークアップ言語(HTML、XMLなど)で書かれたドキュメントにアクセスするための標準的な仕組みで、JavaScript以外の言語でもサポートされています。  
クライアントサイドJavaScriptプログラミングでは、エンドユーザや外部サービスから何らかの入力を受け取って、入力に応じた処理を実行し、処理結果を画面(Webページ)に反映するという流れが一般的です。つまり、JavaScriptからHTMLやCSSを操作することで、Webページに反映するわけです。  
この際に、HTMLを文字列として編集することも可能ですが、複雑な文字列の編集はコードが読みにくくなり、結果としてバグの原因にもなります。HTMLの操作では、`<div>`要素やアンカータグといった意味のある固まりを、JavaScriptのオブジェクトとして操作することでより効率よく開発できます。  
このような場合に使用されるのがDOMです。DOMはWeb技術の標準化団体のW3C(World Wide Web Consortium)で標準化が進められ、現在は4つのレベル(1~4)があります。基本的に、レベルが高いものほど多機能であると考えてください。また、「DOM Level 0」、「DOM 0」という言葉がありますが、これは公式の呼称ではなく、標準化前のDOMの仕様のことを指します。

### 文章ツリーとノード

DOMは、ドキュメント(HTML)を文章ツリー(ドキュメントツリー)として扱います。例えば、以下のHTMLであれば、DOMの世界では図のようなツリー構造として解釈されます。

```html
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>JavaScript入門</title>
</head>

<body>
    <p id="greet">これが<strong>文書ツリー</strong>です</p>
</body>

</html>
```

![DOMツリー](../img/dom/domtree01.png)

Document Object Modelという名前のとおり、DOMでは文書に含まれる要素・属性・テキストをそれぞれオブジェクトとみなして、オブジェクトの集合(階層関係)が文書である、と考えます。  
なお、文書を構成する要素・属性・テキストといったオブジェクトのことをノードと呼び、オブジェクトの種類に応じて要素ノード、属性ノード、テキストノードと呼びます。DOMは、これらのノードを抽出・追加・置換・削除するための汎用的な手段を提供するAPI(関数やオブジェクトの集合)です。  
それぞれのノードは、ツリーにおける上下関係によって、以下のように呼ばれることがあります。

| 名称               | 説明                                                                                                                 |
| :----------------- | :------------------------------------------------------------------------------------------------------------------- |
| ルートノード       | ツリーの最上位に位置するノード。最上位ノードとも呼ぶ                                                                 |
| 親ノード・子ノード | 上下関係にあるノード。直接つながっているノードで、ルートノードに近いノードを親ノード、遠いノードを子ノードと呼ぶ     |
| 兄弟ノード         | 同じ親ノードを持つノード。文書の中で先に書かれているノードを兄ノード、後に書かれているものを弟ノードと呼ぶ |

## クライアントサイドJavaScriptの前提知識

クライアントサイドJavaScript開発を進めていく上で、あらかじめ理解しておくべき事項があります。それは、以下のトピックです。

- HTMLへのJavaScriptの組み込み
- ブラウザ上でのJavaScriptのデバッグ
- 要素ノードの取得
- 文書ツリー間の行き来
- イベントドリブンモデル

### HTMLへのJavaScriptの組み込み

これまでのサンプルコードは、すべてNode.js環境で実行してきました。以降は、Webブラウザ上で実行します。WebブラウザでJavaScriptを実行するためには、HTMLにJavaScriptを組み込む必要があります。  
この項では、まずHTML自体にJavaScriptを記入し、実行する方法を紹介します。次に、今後の開発で主に使用する、外部のJavaScriptをHTMLにインポートする方法を紹介します。

#### HTMLにJavaScriptを記述する

JavaScriptのコードをHTMLに組み込むのは、HTML中の`<script>`要素の役割です。以下に、HTML自体にJavaScriptを記述する例を示します。

```html
<script type="text/javascript">
// ここにjavaScriptのコードを組み込む
</script>
```

type属性は、スクリプトの種類を表します。今回はJavaScriptを組み込むため、`text/javascript`を指定します。なお、HTML5では`text/javascript`がデフォルト値として設定されるため、省略しても構いません。  
  
【参考】`type ="text/javascript"`以外にも、例えば`type="application/json"`とすることで、JSONをHTMLに組み込むことができます。  
  
#### 〈script〉要素を記述する場所

HTMLに`<script>`要素を記述する場所は、大きく以下の3つに分類できます。

- `<body>`要素の配下(任意の位置)  
    `<script>`要素での処理結果を、ページに直接出力するために使用します。以前はよく用いられた方法ですが、Webページのコンテンツとコード(スクリプト)が混在することは、可読性と保守性の観点から望ましいことではありません。そのため、現在ではこの方法はほとんど使用されません。
- `<body>`要素の配下(`<body>`閉じタグの直前)  
    一般的なブラウザでは、スクリプトの読み込みや実行が完了するまで、それ以降のページ描画を行いません。そのため、読み込みや実行に時間がかかるスクリプトは、ページ描画の遅れの原因となりえます。  
    そこで、ページ描画の高速化を狙って、ページの末尾(`</body>`の直前)に`<script>`要素を配置することがよく行われます。これにより、ページの描画を終えた後でスクリプトを読み込み、実行することができるため、ユーザが体感する画面描画速度は向上します。
- `<head>`要素の配下  
    JavaScriptでは、関数を呼び出すための`<script>`要素よりも、関数定義の`<script>`要素を先に記述する必要があります。例えば、`<body>`要素の配下で呼び出す必要がある関数は、`<head>`要素の配下で事前に読み込んでおく必要があります。  
    また、スクリプトからスタイルシート(CSS)を出力する場合でも、本文の出力に先立って`<head>`要素の配下で`<script>`要素を記述する必要があります。  
    この挙動は、function命令で定義した関数がスクリプト内のどの位置からでも呼び出せることとは異なっているため、混同しないように注意が必要です。

#### 外部スクリプトのインポート

JavaScriptのコードは、外部ファイルとして別に定義しておき、HTMLにインポートすることが可能です。  
実際のインポートは、以下の構文で行います。

```html
<script type="text/javascript src="path" [charset="encoding"]></script>
```

ここで、pathはスクリプトファイルのパス、encodingはスクリプトファイルで使用している文字コードを指定します。  
  
以下に、インポートの例を示します。以下のコードは、HTMLファイルと同じディレクトリにsample.jsというJavaScriptファイルが配置されている前提で書かれています。また、`<head>`要素の中で`<script>`要素を記述しているため、このスクリプトに定義された関数は`<body>`要素のどこからでも呼び出すことができます。

```html
<head>
    <meta charset="utf-8">
    <title>JavaScript入門</title>
    <script type="text/javascript" src="sample.js"></script>
</head>
```

コードの外部化には、以下のメリットがあります。

- レイアウトとスクリプトを分離することで、コードを再利用しやすくなる
- スクリプトを外部化することで、htmlファイルの可読性が向上する

これらの理由から、アプリケーション開発の現場ではJavaScriptは外部ファイル化することがほとんどです。よって、本ドキュメントでも、理由がない限りJavaScriptを外部ファイル化して使用します。

### ブラウザ上でのJavaScriptのデバッグ

以上で、HTMLにJavaScriptを組み込む方法を説明しました。次に、ブラウザ上でJavaScriptをデバッグする方法について説明します。

#### 開発者ツールの使用

Webブラウザには、開発者ツール(デベロッパーツール)と呼ばれる、表示しているWebページのJavaScriptやHTMLの確認などができる機能が備わっています。ブラウザ上でJavaScriptをデバッグする場合は、このツールを使用すると便利です。  
以下の簡単なHTMLとJavaScriptを使用して、開発者ツールの使用方法を確認します。

```html
<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="utf-8">
    <title>Developer Tool</title>
    <script type="text/javascript" src="sample.js"></script>
</head>

<body>
    <form>
        <input type="button" value="テスト" onclick="display()" />
    </form>
</body>

</html>
```

```javascript
function display() {
  console.log('コンソール出力のテスト')
  window.alert('ダイアログボックスのテスト'); // ダイアログボックスを表示f
}
```

上記のサンプルコードについて、簡単に説明します。  
まずHTMLですが、`<head>`配下に`<script>`要素があり、ここでJavaScriptの読み込みをしています。`src="sample.js"`となっているので、ここではHTMLファイルと同一ディレクトリに配置したsample.jsというjsファイルを読み込んでいます(ここで指定するファイル名は任意です)。次に、`<body>`配下には`<input type="button">`要素があり、これで画面上にボタンを表示しています。また`onclick="display()"`で属性を指定していますが、この意味は「ボタンがクリックされた際に、読み込んだJavaScriptのdisplayメソッドを引数なしで実行する」ということです。  
一方のJavaScriptは、display関数を定義しているのみです。display関数は、console.logでコンソール出力を行います。また、Webブラウザ上に描画された画面を意味するwindowオブジェクトのalertメソッドを実行します。これで、ブラウザ上でダイアログボックスを表示することができます。
  
ここからは、開発者ツールを使用して、作成したHTMLとJavaScriptの挙動を確認していきます。  
HTMLファイルをブラウザで表示し、F12キーを押すと、画面右側に開発者ツールが表示されます。

![開発者ツール](../img/dom/devtool.png)

開発者ツールの上部には、機能単位に分かれたいくつかのタブが表示されます。それぞれのタブに割り振られた機能について、以下に簡単な説明を記します。

- Elements
  - HTMLの各要素(Element)の状態を確認することができる
- Console
  - JavaScriptのコンソール出力結果を確認することができる
- Sources
  - HTMLに組み込まれたJavaScriptのソースコードを確認することができる

以下の手順で、画面に対する操作によって、開発者ツールにどのような表示がなされるかを確認します。

1. ブラウザ上でF12キーを押して、開発者ツールを表示します。
2. 開発者ツール上部のElementsタブとSourcesタブをクリックし、それぞれ作成したHTMLとJavaScriptが表示されていることを確認します。
3. Consoleタブをクリックします。この時点では、何も表示されていないことを確認します。
4. Webページに表示されている「テスト」ボタンをクリックします。
5. 画面上に「ダイアログボックスのテスト」と書かれたダイアログボックスが表示されます。「OK」ボタンをクリックし、ダイアログボックスを閉じます。
6. Consoleタブをクリックして開いた画面上に、「コンソール出力のテスト」という文字列が表示されていることを確認します。
7. 画面右上の☓ボタンをクリックして、開発者ツールを閉じます。

以上の手順で、HTMLの各要素の状態とJavaScriptの実行状況を確認することができます。  
  
最後に、JavaScript実行時のエラーメッセージを確認する方法を見ていきます。まず、作成したJavaScriptに記述した関数名を、display以外の任意の関数名に変更してください。以下のコードは、変更例です。

```javascript
function func() { // 関数名をdisplayから変更
  console.log('コンソール出力のテスト');
  window.alert('ダイアログボックスのテスト'); // ダイアログボックスを表示
}
```

このように変更した場合、画面上でボタンを押した際の実行対象になっている関数が定義されていないため、エラーが発生すると予想できます。  
では、以下の手順でエラーを発生させ、その内容が開発者ツールのどこに表示されるのかについて確認します。

1. ブラウザ上でF12キーを押して、開発者ツールを表示します。
2. 開発者ツール上部のElementsタブとSourcesタブをクリックし、それぞれ作成したHTMLとJavaScriptが表示されていることを確認します。
3. Consoleタブをクリックします。この時点では、何も表示されていないことを確認します。
4. Webページに表示されている「テスト」ボタンをクリックします。
5. Consoleタブをクリックします。以下のエラーメッセージがコンソール出力されることを確認します。なお。`~~~`は任意のHTMLファイル名です。  
    `~~~.html:12 Uncaught ReferenceError: display is not defined at HTMLInputElement.onclick (~~~.html:12)`
6. Sourcesタブをクリックします。エラーが発生した箇所に赤い波線が引かれていることを確認します。

このように、Consoleタブに表示されるエラーメッセージを確認することで、エラーの原因や発生箇所を確認することができます。また、スクリプトにエラーがあった場合は、Sourcesタブに表示されるスクリプトにエラー箇所が指摘されます。  
  
以上で、ブラウザに付属する開発者ツールの使用方法を説明しました。開発者ツールは、クライアントサイドJavaScriptの開発では必須と言っていいほど頻繁に使用する機能です。これ以降のセクションでは主にブラウザ上でJavaScriptを実行しますので、その過程で開発者ツールの使い方に慣れていくようにしましょう。

### 要素ノードを取得する

クライアントサイドJavaScriptにおいては、文書ツリーから要素ノード(要素)を取り出すという処理が頻繁に行われます。この処理の後に、「要素を取得してその値を取り出す」、「処理した結果をある要素に反映する」、「新規に作成した要素をある要素の配下に追加する」といった処理を行います。  
JavaScriptでHTMLの要素を取得する方法には、以下に示す方法があります。

#### getElementByIdメソッド

取得対象の要素が単一かつ明確な場合、最もシンプルで高速なのはgetElementByIdメソッドを使用する方法です。このメソッドは、指定されたid値を持つ要素をElementオブジェクトとして返却します。

- document.getElementById(id)
  - id: 取得する要素のid値

例えば、以下のサンプルコードは`<span id="result">`要素に現在時刻を表示します。

```html
<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="utf-8">
    <title>getElementById</title>
    <script type="text/javascript" src="sample.js"></script>
</head>

<body>
    <span id="result"></span>
</body>

</html>
```

```javascript
window.onload = function() { // [1]
  const current = new Date();
  const elem = document.getElementById('result'); // [2]

  elem.textContent = current.toLocaleString(); // [3]
};
```

上記のサンプルコードの下段(JavaScript)について、以下で説明します。  
まず、[1]で`window.onload`に無名関数(関数リテラル)を代入しています。この`window.onload`は、後述するイベントハンドラの一種です。ここの意味としては、Webページの描画が完了したときに、代入されている関数を実行する、という挙動を実現するために必要な一文と理解してください。  
取得した要素(Elementオブジェクト)に対してテキストを埋め込むには、textContentというプロパティを使用します。テキストの操作については後述しますが、よく使用するので、まずは使い方を理解してください。  
ここで、id値が重複する要素が存在する場合の`getElementId(id)`メソッドの挙動について説明します。この場合、メソッドは最初に一致した要素を1つだけ返却します。ただし、この挙動はブラウザやブラウザのバージョンによって異なります。よって、原則としてページ内でid値は一意となるように実装してください。  
  
【参考】イベントハンドラについては後述しますが、これを記述せずに無名関数のみを記述した場合について考えます。この場合、HTMLの`<head>`要素の配下に`<script>`要素が記述されているため、ページ描画の前にスクリプトが実行されることになります。この段階では、ページ(`<body>`配下)の描画が始まっていないため、まだ`<span id="result">`要素は画面上に存在しません。よって、[2]の`document.getElementById('result')`は存在しない要素を取得することになり、戻り値はnullとなります。最終的に、戻り値nullに対して[3]の`current.toLocaleString()`を代入することになるため、この時点でエラーが発生してスクリプトは正常に実行されません。  
この挙動を回避するためには、画面描画が完了したタイミングで関数を実行すればよいことがわかります。これを実現するのがwindow.onloadというイベントハンドラです。

#### getElementsByTagNameメソッド

次に、HTMLタグ名をキーとして要素を取得するgetElementsByTagNameメソッドについて説明します。

- document.getElementsByTagName(name)
  - name: タグ名

id値をキーとする場合とは異なり、複数の要素が一致する場合があるため、getElementsByTagNameメソッドの戻り値は要素の集合となります(メソッド名もElementsで複数形です)。  
引数nameに「`*`」を指定すると、すべての要素を取り出すことができます。  
以下の例では、ページに含まれるアンカータグ(`<a>`タグ)をすべて取得し、そのリンク先をコンソール出力しています。

```html
<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="utf-8">
    <title>getElementsByTagName</title>
    <script type="text/javascript" src="sample.js"></script>
</head>

<body>
    <ul>
        <li><a href="https://www.google.co.jp/">Google</a></li>
        <li><a href="https://www.yahoo.co.jp/">Yahoo!</a></li>
        <li><a href="https://www.bing.com/">Bing</a></li>
    </ul>
</body>

</html>
```

```javascript
window.onload = function() {
  const list = document.getElementsByTagName('a');

  for (item of list) {
    console.log(item.href);
  }
};

/*
(ブラウザのコンソールに以下の文字列が出力される)
https://www.google.co.jp/
https://www.yahoo.co.jp/
https://www.bing.com/
*/
```

getElementsByTagNameメソッドの戻り値は、HTMLCollectionオブジェクト(要素の集合)です。HTMLCollectionオブジェクトから使用できるメンバは、以下のとおりです。

| メンバ          | 説明                             |
| :-------------- | :------------------------------- |
| length          | リストに含まれる要素数           |
| item(i)         | i番目の要素(iは0~length-1の範囲) |
| namedItem(name) | id、またはname属性が一致する要素  |

つまり、サンプルコードではリストから要素ノード(アンカータグ)をそれぞれ取り出しているわけです。属性にアクセスする方法については後述しますが、ここでは「要素ノード.属性名」でアクセスできると理解してください(ここでは`item.href`)。

### getElementsByNameメソッド

getElementsByNameメソッドは、name属性をキーに要素(群)を取得するメソッドです。一般的には、`<input>`や`<select>`などのフォーム要素へのアクセスで使用します。ただし、単一の要素を取得するのであれば、getElementByIdメソッドのほうがコードがシンプルになります。そのため、getElementsByNameメソッドの用途は、ラジオボタンやチェックボタンなど`<name>`属性が等しい要素群を取得する場合に限られます。

- document.getElementsByName(name)
  - name: name属性の値

以下の例で挙動を確認します。以下のサンプルコードは、送信ボタンをクリックした際にJavaScriptの関数が実行され、チェックボックスにチェックが入っている名前がダイアログボックスに表示される例です。

```html
<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="utf-8">
    <title>getElementsByName</title>
    <script type="text/javascript" src="sample.js"></script>
</head>

<body>
    <form>
        <label><input type="checkbox" name="person" value="John">John</label>
        <label><input type="checkbox" name="person" value="Tom">Tom</label>
        <label><input type="checkbox" name="person" value="Bob">Bob</label>
        <input type="button" value="送信" onclick="display()" />
    </form>
</body>

</html>
```

```javascript
function display() {
  const persons = document.getElementsByName('person'); // [1]
  let result = [];

  for (person of persons) { // [2]
    if (person.checked) {
      result.push(person.value); // [3]
    }
  }

  window.alert(result); // ダイアログボックスを表示
}
```

スクリプトでは、[1]でgetElementsByNameの引数に`'person'`を指定しているので、`<input>`要素のうち`name`属性に`"person"`が設定されているすべての要素を取得しています。取得結果は、引数の条件に一致したノードの集合(NodeListオブジェクト)であり、[2]で各要素をfor...ofで順番に取得しています。各ノードはチェックボックスなので、チェックの有無を保持するcheckedプロパティ(真理値)は、チェックがされていたらtrue、されていなければfalseとなります。よって、checkedプロパティがtrueのノード(オブジェクト)のvalue(今回は名前)プロパティを、ダイアログボックスに表示するresult配列に格納します([3]の処理)。最終的に、result配列をダイアログボックスに表示しますが、これはwindow.alertメソッドで実現できます。  

ここで、NodeListオブジェクトが新しく登場しました。このオブジェクトは、名前のとおりノードのリストを表すためのオブジェクトです。このオブジェクトはHTMLCollectionオブジェクトとほぼ同じ機能を持ったオブジェクトです。使用できるメンバもほぼ同一ですが、namedItemメソッドは使用できません。

#### getElementsByClassNameメソッド

getElementsByClassNameメソッドは、class属性(スタイルクラスの名前)をキーとして要素群(HTMLCollectionオブジェクト)を取得するメソッドです。特定の役割を持った要素に対して共通のクラス名を付与しておけば、getElementsByClassNameメソッドで目的の要素をまとめて取り出せるようになります。

- document.getElementsByClassName(clazz)
  - clazz: class属性の値

以下に、具体例を示します。以下のサンプルコードは、あるページからclass属性がlikedである要素だけを取得し、そのリンク先をコンソール出力する例です。

```html
<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="utf-8">
    <title>getElementsByClassName</title>
    <script type="text/javascript" src="sample.js"></script>
</head>

<body>
    <ul>
        <li><a href="https://www.google.co.jp/" class="liked">Google</a></li>
        <li><a href="https://www.yahoo.co.jp/" class="liked">Yahoo!</a></li>
        <li><a href="https://www.bing.com/">Bing</a></li>
    </ul>
</body>

</html>
```

```javascript
window.onload = function() {
  const list = document.getElementsByClassName('liked');

  for (item of list) {
    console.log(item.href);
  }
};

/*
(ブラウザのコンソールに以下の文字列が出力される)
https://www.google.co.jp/
https://www.yahoo.co.jp/
*/
```

getElementsByClassNameメソッドの引数には、「clazz01 clazz02」のように空白区切りで(カンマ区切りではない)複数のクラス名を列記することができます。この場合、class属性としてclazz01とclazz02の両方が指定された要素だけを検索します。

#### querySelector、querySelectorAllメソッド

これまでのget~メソッドが特定の名前や属性値をキーとして要素を検索するのに対して、より複雑な条件での検索を可能にするのがquerySelector、querySelectorAllメソッドです。これらのメソッドを使用すると、セレクター式で文書を検索し、一致した要素を取得できます。

- document.querySelector(selector)
- document.querySelectorAll(selector)
  - selector: セレクター式

セレクター式は、もともとCSS(Cascading StyleSheet)で使用されていた記法で、スタイルを適用する対象を特定するための仕組みです。セレクター式を使用することで、例えば「id="list"である要素の配下からclass="new"である`<img>`要素」を検索する場合でも、複雑なコードを書く必要がありません。この場合は、`#list img.new`という短い式で、目的の要素を検索することができます。  
以下の表に、よく使用されるセレクター式をまとめます。セレクター式には多くのパターンがありますが、これらを組み合わせるだけでも、多くの用途をまかなうことができます。

| セレクター                | 説明                                           | 使用例                   |
| ------------------------- | ---------------------------------------------- | ------------------------ |
| `*`                       | すべての要素を取得                             | `*`                      |
| #id                       | 指定したIDの要素を取得                         | #main                    |
| .class                    | 指定したクラス名の要素を取得                   | .external                |
| elem                      | 指定したタグ名の要素を取得                     | li                       |
| serecrot1, serector2,...  | いずれかのセレクターに一致する要素をすべて取得 | #main, li                |
| parent > child            | parent要素の子要素childを取得                  | #main>div                |
| ancestor descendant       | ancestor要素の子孫要素descendantをすべて取得   | #list li                 |
| prev + next               | prev要素の直後のnext要素を取得                 | #main + div              |
| prev ~ siblings           | prev要素以降のsiblings兄弟要素を取得           | #main ~ div              |
| [attr]                    | 指定した属性を持つ要素を取得                   | `input[type]`            |
| [attr = value]            | 属性がvalue値に等しい要素を取得                | `input[type = "button"]` |
| [attr `^=` value]           | 属性valueから始まる値を持つ要素を取得          | `a[href^="https://"]`    |
|                           |
| [arrt $= value]           | 属性がvalueで終わる値を持つ要素を取得          | `img[src$=".gif"]`       |
| `[attr *= value]`         | 属性がvalueを含む値を持つ要素を取得            | `[title*="sample"]`      |
| [selector1][selector2]... | 複数の属性フィルタすべてにマッチする要素を取得 | `img[src][alt]`          |

以下で、具体的な使用例を見ていきます。以下のサンプルコードは、「id="weather"である要素配下でclass="liked"であるアンカータグ(`<a>`タグ))」を取り出し、そのリンク先をコンソール出力する例です。

```html
<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="utf-8">
    <title>querySelectorAll</title>
    <script type="text/javascript" src="sample.js"></script>
</head>

<body>
    <ul id="search">
        <li><a href="https://www.google.co.jp/" class="liked">Google</a></li>
        <li><a href="https://www.yahoo.co.jp/" class="liked">Yahoo!</a></li>
        <li><a href="https://www.bing.com/">Bing</a></li>
    </ul>
    <ul id="weather">
        <li><a href="https://weathernews.jp/s/" class="liked">Weather News</a></li>
        <li><a href="https://weather.yahoo.co.jp/weather/">Yahoo! 天気</a></li>
    </ul>
</body>

</html>
```

```javascript
window.onload = function() {
  const list = document.querySelectorAll('#weather .liked');

  for (item of list) {
    console.log(item.href);
  }
};

/*
(ブラウザのコンソールに以下の文字列が出力される)
https://weathernews.jp/s/
*/
```

querySelectorAllメソッドの戻り値は、getElementsByNameメソッドと同様に、条件に一致した要素をすべて含んだNodeListオブジェクトです。もしも最初から取得すべき要素が1つとわかっている場合、もしくは要素群の最初の1つだけを取り出したい場合には、querySelectorメソッドを使用してください。この場合、メソッドの戻り値はElementオブジェクト(単一の要素)です。  
  
本項で紹介したquery~メソッドは複雑な検索条件を指定できるメソッドですが、getElementByIdメソッドやgetElements~メソッドと比較すると処理が低速です。そのため、一般的には以下のように使い分けます。

- 特定のid値、class属性などで要素を検索できる場合 → get~メソッド
- より複雑な条件で検索したい場合 → query~メソッド

### ノードウォーキング

ここまでに紹介してきた各メソッドは、いずれも特定の要素ノード(群)を取得するためのメソッドです。しかし、いちいち文書全体から目的の要素を検索するのは無駄が多く、それはそのままパフォーマンス低下の原因ともなります。  
そこでDOMでは、あるノードを起点として、相対的な位置関係からノードを取得することができます。ツリー状になったノード間を枝をたどって渡り歩く様子から、このことをノードウォーキングと呼びます。  
具体的には、以下の図に示すプロパティを使用します。

![DOMツリー](../img/dom/domtree02.png)

get~メソッドやquery~メソッドと比べると冗長なコードになりやすいですが、より細かい処理にはノードウォーキングが向いています。よって、get~メソッドやquery~メソッドでは特定の要素を取得し、その後に近接するノードを取得する場合はノードウォーキングを使用するという使い分けが一般的です。

#### ノードウォーキングの基本

以下で、具体的な使用例を見ていきます。以下は、`<form id="persons">`要素の配下に含まれる`<option>`要素を取り出し、そのvalue属性の値を取り出して列挙する例です。

```html
<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="utf-8">
    <title>NodeWalking</title>
    <script type="text/javascript" src="sample.js"></script>
</head>

<body>
    <form id="persons">
        <option value="John">John</option>
        <option value="Tom">Tom</option>
        <option value="Bob">Bob</option>
    </form>
</body>

</html>
```

```javascript
window.onload = function() {
  // <form id="persons">を取得
  const node = document.getElementById('persons');
  // <form>要素配下の子ノードを取得
  const children = node.childNodes;

  for (child of children) {
    // 子ノードが要素ノードである場合、そのvalueをコンソール出力
    if (child.nodeType === 1) {
      console.log(child.value);
    }
  }
};

/*
(ブラウザのコンソールに以下の文字列が出力される)
John
Tom
Bob
*/
```

ノード直下の子ノード群を取得するのは、childNodesプロパティの役割です。childNodesプロパティは、getElementsByNameメソッドやquerySelectorAllメソッドなどと同様に、取得したノード群をNodeListオブジェクトとして返却します。ただし、リストに含まれるノードは要素だけではない点に注意が必要です。今回の場合、取得対象の`<option>`要素以外にも、改行が含まれています。これらのタグの間にある改行や空白はテキストノードとみなされるため、サンプルコードのchildNodesプロパティもまた、要素ノードとテキストノードを取得します。  
今回のように`<option>`ノードだけを取り出したい場合には、取り出したノードが要素ノードであるかどうかを判定する必要があります。ノードの種類を判定するのは、nodeTypeプロパティの役割です。以下にnodeTypeプロパティの戻り値をまとめます。

| 戻り値 | 説明                       |
| :----- | :------------------------- |
| 1      | 要素ノード                 |
| 2      | 属性ノード                 |
| 3      | テキストノード             |
| 4      | CDATAノード(`!<CDATA[~]>`) |
| 5      | 実体参照ノード             |
| 6      | 実体宣言ノード             |
| 7      | 処理命令ノード             |
| 8      | コメントノード             |
| 9      | 文書ノード                 |
| 10     | 文書型宣言ノード           |
| 11     | 文書の断片(フラグメント)   |
| 12     | 記法宣言ノード             |

サンプルコードでは、nodeTypeプロパティが1(要素ノード)である場合のみ、その値(valueプロパティ)を取得しています。

#### 子要素リストを取得する方法（別解）

上記のサンプルコードでは、子要素リストを取得するためにchildNodesプロパティを使用しました。そのほかにも、以下に示す方法で子要素リストを取得することができます。いずれの方法を使用するかは、その時々の文脈にもよりますが、ここでは複数の方法が存在することを理解してください。

- firstChild・nextSiblingプロパティ  
    firstChild・nextSiblingプロパティを使用すれば、以下のように書き換えることができます。

    ```javascript
    window.onload = function() {
    // <form id="persons">を取得
    const node = document.getElementById('persons');
    // <form>要素配下の子ノードを取得
    let child = node.firstChild;

    while (child) {
        if (child.nodeType === 1) {
        console.log(child.value);
        }

        child = child.nextSibling;
    }
    };
    ```

    ここでは、`<form>`要素配下の最初の子ノードから、順番に次の兄弟ノードを、次のノード(弟ノード)がなくなるまで順番に取得しています。ちなみに、lastChild・previousSiblingプロパティを使用しても、ほぼ同じような処理を実装できます。

- firstElementChild・nextElementSiblingプロパティ

firstElementChildプロパティは配下の子要素を返却し、nextElementSiblingプロパティは次の兄弟要素を返却します。firstChild・nexSiblingプロパティとは異なり、戻り値がElement(要素)オブジェクトに限定されるため、nodeTypeプロパティによる判定は不要となります。  
以下に、サンプルコードを示します。

```javascript
window.onload = function() {
  // <form id="persons">を取得
  const node = document.getElementById('persons');
  // <form>要素配下の子ノードを取得
  let child = node.firstElementChild;

  while (child) {
    console.log(child.value);
    child = child.nextElementSibling;
  }
};
```

こちらの方法も、lastElementChild・previousElementSiblingプロパティで、末尾の子要素から順にアクセスすることが可能です。

### イベントドリブンモデル

ブラウザ上で表示されたページでは、例えば以下のイベントが発生します。

- ボタンがクリックされた
- マウスポインターが文字列の上に乗った
- テキストボックスの内容が変更された

クライアントサイドJavaScriptでは、イベントの発生に対応して実行するコードを記述するのが特徴です。このプログラミングモデルのことをイベントドリブンモデル(イベント駆動型モデル)といいます。  
このとき、イベントに対応してその処理内容を定義するコードの固まり(関数)のことをイベントハンドラ、またはイベントリスナといいます。  
以下に、クライアントサイドJavaScriptで使用できる主なイベントをまとめます。もちろん、ここですべてを理解する必要はありません。どのようなイベントがあるのかをおおまかに確認してください。

| 分類       | イベント名  | 発生タイミング                       | 主な対象要素        |
| :--------- | :---------- | :----------------------------------- | :------------------ |
| 読み込み   | abort       | 画像の読み込みを中断したとき         | img                 |
|            | load        | ページ、画像の読み込みが完了したとき | body、img           |
|            | unload      | 他のページに移動するとき             | body                |
| マウス     | click       | クリック時                           | -                   |
|            | dblclick    | ダブルクリック時                     | -                   |
|            | mousedown   | マウスボタンを押したとき             | -                   |
|            | mouseup     | マウスボタンを離したとき             | -                   |
|            | mousemove   | マウスポインターが移動したとき       | -                   |
|            | mouseover   | マウスポインターが要素に乗ったとき   | -                   |
|            | mouseout    | マウスポインターが要素から外れたとき | -                   |
|            | mouseenter  | マウスポインターが要素に乗ったとき   | -                   |
|            | mouseleave  | マウスポインターが要素から外れたとき | -                   |
|            | contextmenu | コンテキストメニューが表示される前   | body                |
| キー       | keydown     | キーを押したとき                     | -                   |
|            | keypress    | キーを押しているとき                 | -                   |
|            | keyup       | キーを離したとき                     | -                   |
| フォーム   | change      | 内容が変更されたとき                 | input(text)、select |
|            | reset       | リセットボタンを押したとき           | form                |
|            | submit      | サブミットボタンを押したとき         | form                |
| フォーカス | blur        | 要素からフォーカスが離れたとき       | -                   |
|            | focus       | 要素がフォーカスされたとき           | -                   |
| その他     | resize      | 要素のサイズを変更したとき           | -                   |
|            | scroll      | スクロールしたとき                   | -                   |

#### イベントハンドラ・イベントリスナを定義する

先述のとおり、イベントドリブンモデルの中心となるのは「イベント」と「イベントハンドラ・イベントリスナ」です。イベントドリブンモデルでは、まず以下の3点を定義する必要があります。

- どの要素で発生したか
- どのイベントか
- どのイベントハンドラ・イベントリスナに関連付けられるのか

クライアントサイドJavaScriptでは、これらの関連付けを行うために、以下の方法を提供しています。

1. タグ内の属性として宣言する
2. 要素オブジェクトのプロパティとして宣言する
3. addEventListenerメソッドを使って宣言する

このうち、3.の方法が最も汎用性が高いため、これを優先的に使用すべきです。ただ、1.と2.の方法も実装が簡単でよく使用されるため、こちらも併せて紹介します。  
なお、上記の1.と2.で宣言されたイベント処理を「イベントハンドラ」、3.で宣言されたものを「イベントリスナ」と呼び、区別します。

1.タグ内の属性として宣言する  
最もシンプルな記法です。以下は、submitボタンをクリックしたタイミングでダイアログボックスを表示する例です。

```html
<input type="button" value="ダイアログボックス表示" onclick="btn_click()">
<script type="text/javascript" src="sample.js"></script>
```

```javascript
function btn_click() {
  window.alert('ボタンがクリックされました');
}
```

ポイントになるのは、HTMLの`<input>`要素の「onclick」です。HTMLタグ内でイベントハンドラを宣言する場合は、以下のように記述します。

`<タグ名 onイベント名="JavaScriptのコード">`

一般的に、`JavaScriptのコード`には、上記の例のようにイベントハンドラ(関数)を呼び出すコードを記述します。しかし、処理が単純な場合には、以下のようにJavaScriptのコードそのものを記述することもできます。

```html
<input type="button" value="ダイアログボックス表示" onclick="window.alert('ダイアログボックスを表示')">
```

ただし、HTMLタグ内にあまりに複雑なJavaScriptのコードを記述することは、コードの可読性を損ねます。さらに、ページ構成と処理(スクリプト)を分離するというWebアプリケーションの開発原則を鑑みても、好ましいものではありません。よって、この方法は簡単な処理を記述するための記法として考えるべきです。原則として、タグ内でのJavaScriptの記述は、イベントハンドラ(関数)の呼び出しに留めることを推奨します。

2.要素オブジェクトのプロパティとして宣言する  
イベントハンドラ(関数)の呼び出しだけであるとはいえ、本来はレイアウトを定義する役割に専念すべきHTMLの中に、JavaScriptのコードを混在させるのは好ましくありません。そこで、関連付けとイベントハンドラ自体の宣言をまとめて、JavaScriptのコード内に記述することができます。  
以下は、上述のサンプルコードを書き換えた例です。

```html
<input id="btn" type="button" value="ダイアログボックス表示">
<script type="text/javascript" src="sample.js"></script>
```

```javascript
window.onload = function() {
  document.getElementById('btn').onclick = function() {
    window.alert('ダイアログボックス表示');
  };
};
```

構文は以下のとおりです。

- obj.on.event = function() { statements }
  - obj: windowオブジェクト、または要素オブジェクト
  - event: イベント名
  - statements: イベント発生時に実行する処理

この例であれば、window(Webページ)がロードされたときに実行する処理と、`<input id="btn">`要素がクリックされたときの処理を定義しています。  
匿名関数(関数リテラル)ではなく、以下のように関数名を記述して、イベントハンドラ(関数)自体は別に定義することもできます。

- obj.on event = func
  - obj: windowオブジェクト、または要素オブジェクト
  - event: イベント名
  - func: 関数名

ただし、イベントハンドラはその性質上、複数の場所で使い回すことがほとんどありません。それを考えれば、名前付き関数を別に定義するよりも、匿名関数として直接定義したほうが、グローバルな名前空間を汚すことがなく、コード自体もシンプルに記述できます。  

この記法を使用する場合、以下の点に注意してください。

- イベント名はすべて小文字で記述  
    イベント名はすべて小文字で記述する必要があります。つまり、window.**onLoad**や~.**onClick**のような記述は不可です。

- プロパティとして設定するのは関数オブジェクト  
    プロパティとして設定するのは、あくまで関数オブジェクトであって、関数呼び出しではありません。例えば、onloadイベントにiniイベントハンドラを関連付ける場合、

    ```javascript
    window.onload = init();
    ```

    という記述は不可です。正しくは、以下のように記述します。

    ```javascript
    windows.onload = init;
    ```

- 個別要素のイベントハンドラはwindow.onloadイベントハンドラの配下
    「document.getElementById.~」の形式でイベントハンドラを登録する場合、基本的にはwindows.onloadイベントハンドラの配下に記述する必要があります。onloadイベントハンドラを使用することで、ページ読み込みが完了した後にスクリプトが実行されます。  
    ページ全体が読み込まれる前にgetElementByIdメソッドを呼び出してしまうと、要素の描画が完了していないので目的の要素を取得できません。その結果として、イベントハンドラの設定にも失敗します。  
    本ドキュメントでは、基本的にはHTMLの`<head>`配下に`<script>`要素を記述することを推奨しているため、windows.onloadイベントハンドラの記述は必須となります。  
    なお、サンプルコードのようにHTMLの`</body>`閉じタグの直前に`<script>`要素を記述すれば、ページ読み込みが完了した後にスクリプトが実行されるため、onloadイベントハンドラは不要です。しかし、onloadイベントハンドラを記述しても特に害はないので、この場合でも念のため記述しておくべきです。

3.addEventListenerメソッドで宣言する  
on~プロパティによるイベントハンドラの設定は、クライアントサイドJavaScriptの開発で以前から使用されてきた手法ですが、この方法には問題があります。それは、**同一の要素、同一のイベントに対して、複数のイベントハンドラを紐付けられない**ということです。  
これは、シンプルなアプリケーションであれば問題にはなりません。しかし、複数のライブラリを組み合わせて開発するケースでは問題になりえます。例えば、1つのライブラリが、ある要素のイベントを使ってしまったとしたら、他のライブラリでは、同一要素の同一イベントを使った処理が動作しなくなってしまいます。  
そこで登場するのがイベントリスナです。イベントリスナは「同一要素の同一イベントに対しても複数紐付けることができるイベントハンドラ」と理解してください。  
イベントリスナを設定するのは、addEventListenerメソッドの役割です。

- elem.addEventListener(type, listener, capture)
  - elem: 要素オブジェクト
  - type: イベントの種類
  - listener: イベントに応じて実行すべき処理
  - capture: イベントの方向(後続のセクションで説明)

以下は、サンプルコードをaddEventListenerメソッドで書き換えた例です。

```html
<input id="btn" type="button" value="ダイアログボックス表示">
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
    'DOMContentLoaded',
    function() {
        document.getElementById('btn').addEventListener(
        'click',
        function() {
            window.alert('ダイアログボックス表示');
        },
        false
        );
    },
    false
);
```

DOMContentLoadedイベントリスナは、先ほどのwindows.onloadイベントハンドラと同様に、ページがロードされたタイミングで処理を実行するという意味です。  
ただし、onloadイベントハンドラとは実行タイミングが異なります。

- onloadイベントハンドラ → コンテンツ本体とすべての画像がロードされたところで実行
- DOMContentLoadedイベントリスナ → コンテンツ本体がロードされたところで実行(=画像のロードを待たない)

大抵の処理は画像のロードを待つ必要がないため、DOMContentLoadedイベントリスナを使用することでスクリプトの開始タイミングを早めることができます。よって、画像に関わる処理があるなどの理由がない限り、**ページの初期化処理は、DOMContentLoadedイベントリスナで表すのが基本**です。
