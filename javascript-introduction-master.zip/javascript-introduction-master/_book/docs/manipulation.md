# Webページの操作

前のセクションでは、クライアントサイドJavaScriptの基本的な考え方とDOMについて解説しました。このセクションでは、スクリプトからページを操作する方法について学習します。

## 属性値とテキストの取得・設定

前のセクションで見てきたとおり、要素ノードに対してアクセスできれば、属性値にアクセスすることは簡単です。なぜなら、多くの属性は要素ノードが持つ同名のプロパティとしてアクセスできるからです。  
例えば、アンカータグのhref属性を取得・設定するためには、以下のように記述します(変数linkはアンカータグを表すものとします)。

```javascript
const url = link.href; // 取得
link.href = 'https://www.google.co.jp/' // 設定
```

他の属性の場合もほとんど同様ですが、一部に属性名とプロパティ名が一致していないケースもあるので、注意してください。例えば、要素に適用するCSSクラスを表す属性は、HTMLでは「class」ですが、これに対応するDOMプロパティ名は「className」です。

```html
<p class="default">サンプル</p>
```

```javascript
node.className = 'liked';
```

属性とプロパティの名前の違いを意識したくない場合には、getAttributeメソッドとsetAttributeメソッドを使用します。

- elem.getAttribute(name)
- elem.setArttribute(name, value)
  - elem: 要素オブジェクト
  - name: 属性名
  - value: 属性値

例えば、アンカータグ(変数link)のhref属性を取得・設定する場合は、以下のようにします。

```javascript
const url = link.getAttraibute('href'); // 取得
link.setAttibute('href' 'https://www.google.co.jp'); // 設定
```

getAttributeメソッドとsetAttributeメソッドを使用する方法は、プロパティでアクセスする方法と比較して、やや冗長な記述となります。ただし、以下のメリットがあるため、用途に応じて使い分けるようにします。

- HTMLとJavaScriptとで名前の相違を意識する必要がない
- 文字列として指定できるため、取得・設定する属性名をスクリプトから動的に変更できる

### 不特定の属性を取得する

特定の要素ノードに属するすべての属性を取得したい場合は、attributesプロパティを使用します。  
以下は、取得した`<img>`要素に含まれるすべての属性を一覧表示するサンプルコードです。

```html
<input id="btn" type="button" value="ダイアログボックス表示">
<script type="text/javascript" src="sample.js"></script>
```

```javascript
const attrs = document.getElementById('btn').attributes; // [1]

for (attr of attrs) {
    console.log(attr.name + ': ' + attr.value); // [2]
}

/*
id: btn
type: button
value: ダイアログボックス表示
*/
```

attributesプロパティは、要素ノードに含まれる全属性を、NamedNodeMapオブジェクトとして返却します([1])。NamedNodeMapは、先述したHTMLCollectionにも似たオブジェクトで、個別のノードに名前、インデックス番号のいずれを使ってもアクセスできるという特徴があります。  
NamedNodeMapオブジェクトに含まれる属性(Attrオブジェクト)を順に取得する流れは、HTMLCollectionオブジェクトの場合と同じです。for...of内で属性ノードを1つずつ取り出しています。  
取り出した属性ノードの名前・値にアクセスするには、[2]のようにname・valueプロパティを使用します。  
  
NamedNodeMapはインデックス番号でもアクセスできますが、ノードの順序は保証されません。例えば、1番目のノードがインデックス番号0に格納されていない可能性があるので、注意が必要です。  
また、NamedNodeMapオブジェクトでは、配下のノード(属性)を追加・削除することもできます。

```javascript
// 新規にname属性を追加
const name = document.createAttribute('name');
name.value = 'button';
attrs.setNamedItem(name);

// 既存のvalue属性を削除
attrs.removeNamedItem('value');
```

### テキストを取得・設定する

要素配下のテキストを取得・設定するには、innerHTML、textContentというプロパティを使用します。  
両者の性質を理解するために、まずは具体的な例を見ていきます。以下は、`<div>`要素に対して指定されたテキスト(アンカータグ)を埋め込む例です。

```html
<div id="result_text">
    <p style="color:red" ;>設定されていません</p>
</div>
<div id="result_html">
    <p style=" color:red" ;>設定されていません</p>
</div>

<script type=" text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    document.getElementById('result_text').textContent =
      '<a href="http://www.google.co.jp">Google</a>';
    document.getElementById('result_html').innerHTML =
      '<a href="http://www.google.co.jp">Google</a>';
  },
  false
);
```

上記のHTMLをブラウザで表示すると、以下のようになります。

`<a href="http://www.google.co.jp">Google</a>` → 文字列として表示される  
`Google` → リンクとして表示される

この結果について、以下で説明します。  
まず、いずれのプロパティにも共通している点は、配下の子要素・テキストを完全に置換するという点です。この例であれば、元のHTMLに記述されていた`<p>`要素は置換され、残っていないことに注目してください。  
一方、プロパティ間で異なるのは、与えられたテキストをHTML文字列として認識するかどうかという点です。innerHTMLプロパティは与えられた文字列を完全にHTMLとして埋め込むので、リンクとして有効になっています。他方、textContentプロパティはプレーンテキストとして埋め込むので、タグ文字列がそのまま文字列として表示されていることが確認できます。  
一般的には、HTML文字列を埋め込む必要がなければ、まずは**textContentプロパティを優先して使用する**ことを推奨します。理由としては、テキストの解析が不要である分、textContentプロパティの方が動作が高速で、セキュリティ上の問題も発生しにくいからです(セキュリティリスクについては後述)。

#### テキスト取得時の違い

innetHTML、textContextプロパティは、テキストを取得する際の挙動についても異なります。以下の例で、挙動を確認します。

```html
<ul id="list">
    <li><a href="https://www.google.co.jp/">Google</a></li>
    <li><a href="https://www.yahoo.co.jp/">Yahoo!</a></li>
    <li><a href="https://www.bing.com/">Bing</a></li>
</ul>
<script type=" text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    const list = document.getElementById('list');
    console.log(list.innerHTML);
    console.log(list.textContent);
  },
  false
);

/*
(innerHTMLの内容)
<li><a href="https://www.google.co.jp/">Google</a></li>
<li><a href="https://www.yahoo.co.jp/">Yahoo!</a></li>
<li><a href="https://www.bing.com/">Bing</a></li>

(textContentの内容)
Google
Yahoo!
Bing
*/
```

innerHTMLプロパティは、対象となる要素の配下をHTML文字列として返却します。一方、textContentプロパティは、子要素それぞれからテキストだけを取り出して結合した文字列を返却します。

#### innerHTMLプロパティの注意

innerHTMLプロパティを使用する場合、ユーザからの入力値をはじめ、外部からの入力をそのまま渡さないでください。  
以下のコードは、テキストボックスに入力された名前に応じて「hello, ○○」というメッセージを画面上に出力する例です。しかし、このコードには、セキュリティ上好ましくないコードが含まれています。

```html
<form>
    <label for="name">Name:</label>
    <input id="name" name="name" type="text" size="30" />
    <input id="btn" type="button" value="送信">
</form>
<div id="result"></div>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    document.getElementById('btn').addEventListener(
      'click',
      function() {
        const name = document.getElementById('name');
        const result = document.getElementById('result');
        result.innerHTML = 'hello, ' + name.value;
      },
      false
    );
  },
  false
);
```

まずは、テキストボックスに任意の文字列を入力し、送信ボタンをクリックして動作を確認してください。正常に動作していることが確認できたら、テキストボックスに以下の文字列を入力し、送信ボタンを押してください。ページ下部に「Alert!」という文字列が表示され、これをクリックするとダイアログボックスが表示されます。

```html
<div onclick="alert('Alert!')">Alert!</div>
```

以上の結果から、ユーザが入力したスクリプトが、ページ上で実行されていることがわかります。今回の例であれば、ユーザ自身が入力したコードを実行しただけなので、大きな問題にはなりません。しかし、外部のサービスから取得したコンテンツに不正な文字列が入っていた場合はどうでしょうか。この場合、ページの提供者が意図していないコードがユーザのブラウザ上で勝手に実行されてしまう可能性があり、セキュリティ上の問題があります。  
上記の脆弱性のことを、**クロスサイトスクリプティング(XSS)**脆弱性と呼びます。  
XSSを防ぐ最も有効な手段は、ユーザからの入力値などの外部の入力値をinnetHTMLプロパティで出力しないことです。この例であれば、innerHTMLプロパティをtextContextプロパティに書き換えることで問題を解決できます。入力値がHTML文字列を含まない場合は、これで十分です。  
ただし、入力値をもとにHTMLを組み立て、ページに反映する場合はtextContextプロパティを使用できません。この場合は、createElement・createTextNodeメソッドを使用してください。これによって、安全にHTML文字列を操作できます。これらのcreate~メソッドについては後ほど説明します。

## フォーム要素へのアクセス

クライアントサイドJavaScriptにおいて、フォームはユーザからの入力を受け取る代表的な手段です。JavaScript自体の話題からは若干外れますが、ここでWebページで使用できる主なフォーム要素(入力要素)から値を受け取る方法についてまとめます。

### 入力ボックス・選択ボックス

入力ボックスや選択ボックスから値を取得する方法は、単にvalueプロパティにアクセスするだけです。  
以下は、ボタンクリック時に、フォームに入力された値をログに列挙する例です。

```html
<form>
    <label for="name">Name:</label>
    <input id="name" name="name" type="text" size="30" />
    <input id="btn" type="button" value="送信">
</form>
<div id="result"></div>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    document.getElementById('btn').addEventListener(
      'click',
      function() {
        const name = document.getElementById('name');
        console.log(name.value);
      },
      false
    );
  },
  false
);
```

ここでは、入力の例として`<input type="text">`を挙げていますが、以下の要素と`<select>`要素(単一選択)は、すべて同じ方法で値を取得できます。

- text
- number
- password
- range
- time
- date
- textarea
- color
- datetime-local
- monty
- week

また、これらの要素に値を設定する場合は、以下のようにvalueプロパティに対して値を代入します。

```javascript
name.value = 'John';
```

### チェックボックス・ラジオボタン

チェックボックスやラジオボタンへのアクセス方法は、やや複雑です。  
まず、具体的な実装例を見ていきます。以下は、画面上で選択されたチェックボックスの値を、サブミットのタイミングでダイアログボックスに表示するサンプルコードです。

```html
<form>
    <label><input type="checkbox" name="person" value="John">John</label>
    <label><input type="checkbox" name="person" value="Tom">Tom</label>
    <label><input type="checkbox" name="person" value="Bob">Bob</label>
    <input id="btn" type="button" value="送信" />
</form>

<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    document.getElementById('btn').addEventListener(
      'click',
      function() {
        const persons = document.getElementsByName('person');
        let result = [];

        for (person of persons) {
          // チェックされている項目の値を配列に追加
          if (person.checked) {
            result.push(person.value);
          }
        }
        window.alert(result); // 配列をダイアログボックスを表示
      },
      false
    );
  },
  false
);
```

チェックボックスのように、id属性は異なっていてname属性が共通である要素群を取得する場合は、getElementsByNameメソッドを使用すると便利です。この場合、getElementsByNameメソッドは、チェックボックスのリストをNodeListオブジェクトとして返却するので、これまでと同じくfor...of命令で個々の要素を順番に取り出します。  
チェックボックスやラジオボタンが選択(チェック)されているかどうかを表すのは、checkedプロパティです。valueプロパティも使用できますが、ラジオボタンとチェックボックスでは、**valueプロパティは選択の有無に関わらず、value属性で指定された値を返却**します。よって、valueプロパティを参照しても、選択の有無はわかりません。選択の有無を調べる場合は、checkedプロパティのtrue(選択されている)、false(未選択)から確認します。  
上記の例ではチェックボックスの値を取得しましたが、ラジオボタンでも同様の処理で値を取得できます。ただし、ラジオボタンの場合は単一選択なので、選択された要素が見つかった段階でfor...ofループを抜けるように実装すると、処理効率が良くなります。  
  
次に、値の設定方法について見ていきます。こちらも、値の取得と同様に、NodeListオブジェクトを取得し、for...of命令で個々の要素にアクセスするという流れです。個々の要素を取り出した後は、設定したい値と同じvalueを持つラジオボタン・チェックボックスを探し出し、一致した要素のcheckedプロパティをtrueに設定します。  
以下に、サンプルコードを示します。この例では、`value="John"`であるチェックボックスに最初からチェックが入るようにしています。

```html
<form>
    <label><input type="checkbox" name="person" value="John">John</label>
    <label><input type="checkbox" name="person" value="Tom">Tom</label>
    <label><input type="checkbox" name="person" value="Bob">Bob</label>
    <input id="btn" type="button" value="送信" />
</form>

<script type="text/javascript" src="sample.js"></script>
```

```javascript
const initialize = (name, value) => {
  const persons = document.getElementsByName(name);

  for (person of persons) {
    // チェックされている項目の値を配列に追加
    if (person.value === value) {
      person.checked = true;
    }
  }
};

document.addEventListener(
  'DOMContentLoaded',
  initialize('person', 'John'),
  false
);
```

HTMLは先述の選択状態取得のサンプルコードと同一ですが、JavaScriptには変更があります。まず、今までfunction命令で関数リテラルを生成していたところを外出しにして、変数とアロー関数に書き換えました。これによって、コードの可読性が向上しています。関数はnameとvalueの2つの引数を取るようにして、汎用性を持たせています。  
アロー関数に実装した処理はそこまで難しいものではありません。引数nameに一致するname属性を持つ要素群をgetElementsByNameメソッドで取得し、これらの要素のうちvalue属性が引数valueと一致する要素のcheckedプロパティにtrueを設定しています。

### リストボックス

リストボックスは複数選択が可能なフォーム要素で、操作の方法自体はチェックボックスのそれと似ています。`<select>`要素のvalueプロパティを参照しても、選択された値の最初の一つしか取得できないため、注意してください。

```html
<form>
    <select id="persons" multiple>
        <option value="John">John</option>
        <option value="Tom">Tom</option>
        <option value="Bob">Bob</option>
    </select>
    <input id="btn" type="button" value="送信" />
</form>

<script type="text/javascript" src="sample.js"></script>
```

```javascript
const alert = () => {
  const opts = document.getElementById('persons').options; // [1]
  const result = [];

  for (opt of opts) { // [2]
    if (opt.selected) { // [3]
      result.push(opt.value);
    }
  }
  window.alert(result);
};

document.addEventListener(
  'DOMContentLoaded',
  function() {
    document.getElementById('btn').addEventListener('click', alert, false);
  },
  false
);
```

リストボックスの選択値を判定するには、まず`<select>`要素配下の`<option>`要素(群)を取得します。これには、取得したElementオブジェクト(`<select>`要素)からoptionsプロパティにアクセスするだけです([1])。  
optionsプロパティは、戻り値として`<option>`要素群(HTMLOptionsCollentionオブジェクト)を返却します。したがって、[2]でfor...ofループで順番に`<option>`要素を取り出し、選択状態を確認しています。ただし、`<option>`要素が選択されているかどうかを確認するには、checkedプロパティではなくselectedプロパティを使用します([3])。  
  
続いて、リストボックスに値を設定する例を、以下に示します。内容については、これまでとほぼ同様です。JavaScriptの[1]では、以前のセクションで解説した[Array.someメソッド](object.md#someメソッド)とアロー関数を使用して、少ないコード量で配列内の要素を検索しています。

```html
<form>
    <select id="persons" multiple>
        <option value="John">John</option>
        <option value="Tom">Tom</option>
        <option value="Bob">Bob</option>
    </select>
    <input id="btn" type="button" value="送信" />
</form>

<script type="text/javascript" src="sample.js"></script>
```

```javascript
const initialize = (name, value) => {
  const opts = document.getElementById(name).options;

  for (opt of opts) {
    if (value.some(item => item === opt.value)) { // [1]
      opt.selected = true;
    }
  }
};

document.addEventListener(
  'DOMContentLoaded',
  initialize('persons', ['John', 'Bob']),
  false
);
```

## ノードの追加・置換・削除

ここまで、DOMを使用してすでに存在するノードを参照する方法について解説しました。DOMは、参照以外にも、文書ツリーに対して新規のノードを追加するほか、既存のノードを置換・削除することもできます。

### innerHTMLプロパティの使い分け

HTMLの編集には、先述のinnerHTMLプロパティを使用することができます。しかし、innerHTMLプロパティでは、コンテンツを文字列として操作する必要があるため、以下の問題があります。

- コンテンツが複雑になる場合、コードの見通しが悪くなる
- ユーザからの入力値に基づいてコンテンツを作成した場合、任意のスクリプトが実行されてしまう可能性がある(クロスサイトスクリプティングの脆弱性)

一方、この後に紹介する方法であれば、上記の問題を解決できます。

- オブジェクトツリーとして操作できるので、対象となるコンテンツが複雑になった場合にも、コードの可読性が劣化しにくい
- 要素・属性とテキストを区別して扱えるので、ユーザからの入力によってスクリプトが混入する可能性を低減できる

上記のメリットがある反面、簡易なコンテンツを埋め込むためにもオブジェクトによる操作が必要となるため、コードは冗長になりがちです。よって、基本的は以下のように使い分けることが多いです。

- シンプルなコンテンツの編集 → innerHTMLプロパティ
- 複雑なコンテンツの編集 → 以下で紹介する方法

### 新規ノードの作成

まず、新規ノードを追加するサンプルコードを見ていきます。コードのおおまかの説明については、コードコメントを参照してください。

```html
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>ノードの新規作成</title>
    <script type="text/javascript" src="sample.js"></script>
</head>

<body>
    <form>
        <label>サイト名：<br />
            <input id="name" type="text" size="30" /></label><br />
        <label>URL：<br />
            <input id="url" type="text" size="50" /></label><br />
        <input id="btn" type="button" value="追加" />
    </form>
    <div id="list"></div>
</body>

</html>
```

```javascript
const initialize = () => {
  document.getElementById('btn').addEventListener(
    'click',
    function() {
      const name = document.getElementById('name');
      const url = document.getElementById('url');

      // <a>要素を生成
      const anchor = document.createElement('a'); // [1]
      // <a>要素のhref属性を設定
      anchor.href = url.value; // [3]
      // テキストノードを生成し、<a>要素の直下に追加
      anchor.appendChild(document.createTextNode(name.value)); // [2]
      // <div id='list'>を取得
      const list = document.getElementById('list');
      // <div>要素の直下に<a>、<br>要素の順に追加
      list.appendChild(anchor); // [2]
      list.appendChild(document.createElement('br')); // [1],[2]
    },
    false
  );
};

document.addEventListener('DOMContentLoaded', initialize, false);
```

以下では、上記のサンプルコードを3つのポイントに分け、ノード追加の流れについて確認します。

**1. 要素・テキストノードを生成する**  
コンテンツを追加するには、まずcreateElementメソッド、またはcreateTextNodeメソッドを使用して、新規に挿入する要素・テキストノードを生成します。

- document.createElement(name)
- document.createTextNode(text)
  - name: 要素名
  - text: テキスト

create~メソッドには、そのほかにも以下のメソッドがあります。

| メソッド                                          | 生成するノード     |
| :- | :- |
| createElement(要素名)                             | 要素ノード         |
| createAttribute(属性名)                           | 属性ノード         |
| createTextNode(テキスト)                          | テキストノード     |
| createCDATASection(テキスト)                      | CDATAセクション    |
| createComment(テキスト)                           | コメントノード     |
| createEntityReference(実体名)                     | 実体参照ノード     |
| createProcessingInstruction(ターゲット名, データ) | 処理命令ノード     |
| createDocumentFragment()                          | ドキュメントの断片 |

create~メソッドでノードを生成した時点では、まだコンテンツ同士の階層関係を意識する必要はありません。この時点では、生成された個々のノードはどこにも関連付けられていないため、単体のパーツのような状態です。

**2. ノード同士を組み立てる**  
次に、関連付けられていないノード群を組み立て、ドキュメントに追加する作業が必要になります。この作業を行うのがapeendChildメソッドの役割です。**appendChildメソッドは、指定された要素を現在の要素の最後の子要素として追加**します。

- elem.appendChild(node)
  - elem: 要素オブジェクト
  - node: 追加するノード

サンプルコードでは、まずテキストノードtextを要素ノードanchorに追加した上で、この要素ノードanchorとbrを、文書ツリー内の要素ノードlist配下に追加しています。

![appendChild](../img/manipulation/appendChild.png)

apeendChildメソッドは、insertBeforeメソッドで置き換えることもできます。例えば、以下の2文は同等の処理となります。

```javascript
list.appendChild(anchor);
list.insertBefore(anchor, null);
```

insertBeforeメソッドは、第1引数で指定したノードを、第2引数で指定した子ノードの直前に挿入します。apeendChildメソッドと同様、最後尾にノードを追加したい場合は、第2引数にnull(後ろに子ノードはない)を指定します。  
逆に、先頭の子ノードとして追加したい場合には、以下のように書き換えることができます。

```javascript
list.insertBefore(br, list.firstChild);
list.insertBefore(anchor, br);
```

**3. 属性ノードを追加する**  
このセクションの先頭で紹介したとおり、属性ノードの指定は、属性と同名のプロパティを設定するだけで済みます。サンプルコードでもこの方法を使用していますが、createAttributeメソッドを使用して属性ノードを生成することもできます。プロパティで設定する場合と比較してコードが冗長になりますが、属性名を文字列で設定できるため、スクリプトから属性名を動的に変更できるというメリットがあります。そのため、より汎用的なコードを記述する必要がある場合に使用されます。  
例えば、サンプルコードの以下の部分をcreateAttributeメソッドに書き換えます。

```javascript
anchor.href = url.value;
```

書き換え後のコードは、以下のとおりです。

```javascript
const href = document.createAttribute('href');
href.value = url.value;
anchor.setAttributeNode(href);
```

属性ノードの値を設定するには、valueプロパティを使用します。  
また、属性ノードを要素ノードに関連付けるには、appendChild・insertBeforeメソッドではなく、setAttributeNodeメソッドを使用する点に注意してください。この理由は、属性ノードは要素ノードの子ノードではなく、要素ノード自体の属性という扱いだからです。

#### 【補足】テキストノードは自動的にエスケープされる

上述のサンプルコードで、サイト名の記入欄に`<h1>テスト</h1>`のようにHTML文字列を入力した場合、どのような挙動となるでしょうか。  
HTMLの`<h1>`タグが含まれる文字列のため、フォントサイズが大きな文字列が表示されるようにも思えますが、`<h1>テスト</h1>`という文字列がそのまま画面に表示されます。  
createTextNodeメソッドで生成したテキストノードは、要素ではなくプレーンなテキストとして生成されます。そのため、ここにHTMLタグが含まれていたとしても、そのままテキストとして扱われます。このことが、入力値をもとにHTML文字列を組み立てる場合には、createElementメソッド、またはcreateTextNodeメソッドを使用すべきである理由です。

#### 【注意】複雑なコンテンツを生成する場合

例として、配列numbersの内容に基づいて、数字のリストを生成することを考えます。  
以下にサンプルコードを示します。

```html
<ul id="list"></ul>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    numbers = [];

    for (let i = 0; i < 10; i++) {
      numbers.push(i);
    }

    const list = document.getElementById('list');

    // 配列numbersの内容を順番に<li>要素に整形
    for (number of numbers) {
      const li = document.createElement('li');
      const text = document.createTextNode('number: ' + number);
      li.appendChild(text);
      list.appendChild(li); // [1]
    }
  },
  false
);
```

このコード自体は正しく動作します。ただし、パフォーマンスの観点からは、好ましいコードではありません。この理由は、[1]で文書ツリーに`<li>`要素を追加したタイミングで、画面上のコンテンツが再描画されるからです。再描画はオーバーヘッドの高い処理でもあり、頻繁に発生することは望ましい挙動ではありません。  
このような状況では、いったんDocumentFragementオブジェクト上でコンテンツを組み立ててから、まとめて文書ツリーに追加すべきです。DocumentFragmentオブジェクトは、名前のとおり「文書の断片」で、組み立てたノードを一時保存するためのオブジェクトです。  
以下に、修正後のサンプルコードを示します。

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    numbers = [];

    for (let i = 0; i < 10; i++) {
      numbers.push(i);
    }

    // コンテンツを一時保存するためのDocumentFragmentオブジェクトを生成
    const fragment = document.createDocumentFragment();

    // 配列numbersの内容を順番に<li>要素に整形
    for (number of numbers) {
      const li = document.createElement('li');
      const text = document.createTextNode('number: ' + number);
      li.appendChild(text);
      fragment.appendChild(li);
    }

    // <li>要素群をまとめて文書ツリーに追加 - [1]
    document.getElementById('list').appendChild(fragment);
  },
  false
);
```

上記のコードでは、文書ツリー自体の更新は[1]の一回だけなので、再描画にかかるオーバーヘッドも最小限に抑えられます。

### 既存ノードの置換、削除

次に、すでに存在するノードを置換、削除する方法を見ていきます。以下は、検索エンジン名をクリックしたときに、画面下部にその検索エンジンのページへのリンクを表示する例です。画面上の削除ボタンをクリックすると、表示したリンクを削除することができます。

```html
<ul id="list">
    <li><a href="JavaScript:void(0)" name='Google' data-url="https://www.google.co.jp/">Google</a></li>
    <li><a href="JavaScript:void(0)" name='Yahoo!' data-url="https://www.yahoo.co.jp/">Yahoo!</a></li>
    <li><a href="JavaScript:void(0)" name='Bing' data-url="https://www.bing.com/">Bing</a></li>
</ul>
<input id='del' type="button" value="削除" disabled />
<div id='div'></div>

<script type="text/javascript" src="sample.js">
</script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    const list = document.getElementById('list');
    const div = document.getElementById('div');
    const del = document.getElementById('del');

    // <ul id="list">配下(リンク)をクリックしたときの処理
    list.addEventListener('click', function(e) {
      // data-url属性からURLを取得。e.targetについては後述
      const url = e.target.getAttribute('data-url');

      // URLが設定されていた場合に実行
      if (url) {
        // <a>要素を生成
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.appendChild(
          document.createTextNode(e.target.getAttribute('name'))
        );

        // <div>要素配下に要素が存在するか(リンクが表示されているか)をチェック
        if (div.childElementCount > 0) {
          // 要素が存在する場合、新たな<a>要素で置換
          div.replaceChild(anchor, div.lastChild); // [1]
        } else {
          // 要素が存在しない場合、<a>要素を追加して削除ボタンを有効にする
          div.appendChild(anchor);
          del.disabled = false;
        }
      }
    });

    // 削除ボタンがクリックされたときの処理
    del.addEventListener('click', function() {
      // <div>要素配下の子要素を削除し、削除ボタンを有効にする
      div.removeChild(div.lastChild); // [2]
      del.disabled = true;
    });
  },
  false
);
```

処理のおおまかな流れについては、コード内のコメントを参照してください。以下では、ノードの置換と削除を行っている部分について解説します。

- ノードの置換  
  子ノードの置換は、replaceChildメソッドで実現できます。

  - elem.replaceChild(after, before)
    - elem: 要素オブジェクト
    - after: 置換後のノード
    - before: 置換対象のノード

  ```javascript
  div.replaceChild(anchor, div.lastChild) // [1]
  ```

  サンプルコードでは、置換後のノードとして新たに作成した`<a>`要素を指定し、置換対象のノードとして`<div id='div'>`配下の`<a>`要素を指定しています。  
  置換対象のノードは、現在のノードに対する子ノードでなければならない点に注意してください。子ノード以外を指定した場合にはエラーとなります。  
  なお、サンプルコードでは、lastChildプロパティで`<div>`要素の最初の子ノードを取得していますが、今回の場合は`<div>`要素配下に存在する子ノードが1つのみであることがわかっているため、firstChildプロパティを使用しても同じ結果になります。

- ノードの削除  
  子ノードの削除は、removeChildメソッドで実現できます。

  - elem.removeChild(node)
    - elem: 要素オブジェクト
    - node: 削除対象のノード

  ```javascript
  div.removeChild(div.lastChild); // [2]
  ```

  サンプルコードでは、置換対象のノードとして`<div id='div'>`配下の`<a>`要素を指定しています。replaceChildメソッドと同様に、削除対象のノードは現在のノードに対する子ノードである必要があります。  
  サンプルコードでは、lastChildプロパティで`<div>`要素の最初の子ノードを取得していますが、同様の理由で、firstChildプロパティを使用しても同じ結果になります。

- 【補足】属性ノードの削除  
  属性は、要素の子ノードではありません。したがって、属性を削除する場合にはremoveChildメソッドではなく、専用のremoveAttributeメソッドを使用する必要があります。書式は以下のとおりです。

  `要素オブジェクト.removeAttribute(属性名);`

#### data-~属性について

data-~属性は、開発者が目的に応じて、自由に値を設定できる特別な属性です。基本的には、スクリプト(イベントリスナ)で使用するためのパラメータを埋め込む属性として使用します。  
サンプルコードでは、検索エンジンのURLを表すために、data-url属性をアンカータグごとに設定しています。このように、可変な情報(パラメータ)と機能(イベントリスナ)を切り離すことで、後からコードを再利用しやすくなるというメリットがあります。  
data-~の「~」部分には、小文字のアルファベット、ハイフン、アンダースコアなどの文字を使用して、自由に命名することができます。data-~はカスタムデータ属性とも呼ばれます。

#### void演算子

サンプルコードのHTML中のアンカータグのhref属性では、JavaScript疑似プロトコル形式(JavaScript:の後にスクリプトを記述)でvoid(0)を呼び出しています。このようにする理由は、アンカータグ本来のリンクとしての機能(ページ遷移)を抑制するためです。void演算子は「何も返却しない」ことを表す演算子で、今回のように「リンク形式でテキストを表示したいが、処理そのものはスクリプトで実施したい = リンクとしては働かせたくない」場合によく使用します。

### HTMLCollection・NodeListを繰り返し処理する場合の注意点

getElementsByTagName、getElementsByName、getElementsByClassNameメソッドは、戻り値としてHTMLCollection、またはNodeListオブジェクトを返却します。ただし、このHTMLCollection、NodeListオブジェクトは生きた(Liveな)オブジェクトである点に注意が必要です。  
「生きた」とは、オブジェクトが文書ツリーを参照していて、文書ツリーへの変更がHTMLCollection、NodeListにもリアルタイムに反映されるということです。  
以下のコードで、挙動を確認します。

```html
<ul id="list">
    <li><a href="JavaScript:void(0)" name='Google' data-url="https://www.google.co.jp/">Google</a></li>
    <li><a href="JavaScript:void(0)" name='Yahoo!' data-url="https://www.yahoo.co.jp/">Yahoo!</a></li>
    <li><a href="JavaScript:void(0)" name='Bing' data-url="https://www.bing.com/">Bing</a></li>
</ul>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    const li = document.getElementsByTagName('li');
    console.log('Before: ' + li.length);

    const ul = document.getElementById('list');
    ul.appendChild(document.createElement('li'));
    console.log('After: ' + li.length);
  },
  false
);
```

上記のHTMLをブラウザで表示すると、コンソールに`Before: 3 After: 4`と表示されます。この結果から、appendChildメソッドで`<li>`要素を追加したことがHTMLCollectionオブジェクトにも反映されていることが確認できます。  
HTMLCollectionオブジェクトのこのような性質は便利なように思えますが、注意すべき点もあります。例えば、以下のコードは、`<ul id="first">`要素から取得した`<li>`要素と同じ要素を`<ul id="second">`要素に追加する例です。

```html
<ul id="first">
    <li><a href="JavaScript:void(0)" name='Google' data-url="https://www.google.co.jp/">Google</a></li>
    <li><a href="JavaScript:void(0)" name='Yahoo!' data-url="https://www.yahoo.co.jp/">Yahoo!</a></li>
    <li><a href="JavaScript:void(0)" name='Bing' data-url="https://www.bing.com/">Bing</a></li>
</ul>
<ul id="second"></ul>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    const second = document.getElementById('second');
    const li = document.getElementsByTagName('li');

    for (item of li) {
      const new_li = document.createElement('li');
      const new_text = document.createTextNode(item.textContent);
      new_li.appendChild(new_text);
      second.appendChild(new_li); // [1]
    }
  },
  false
);
```

上記のコードは`<ul id="first">`要素配下の`<li>`要素を`<ul id="second>`要素にコピーすることを期待したコードですが、正しく動作しません(ページ読み込みが終わりません)。HTMLCollectionは生きたオブジェクトなので、[1]でforループの都度、変数liに格納されているノードの個数が変化してしまうからです。これによって、forブロックの終了条件である「次の要素が存在しない」は成立せず、無限ループとなってしまうのです。  
この問題は、コードを以下のように書き換えることで回避できます。以下の実装例では、for文をfor...ofから通常のfor文に書き換えていますが、この理由はこちらのほうがシンプルに実装できるためです。

```javascript
    for (let i = 0, len = li.length; i < len; i++) {
      const item = li.item(i);
      const new_li = document.createElement('li');
      const new_text = document.createTextNode(item.textContent);
      new_li.appendChild(new_text);
      second.appendChild(new_li);
    }
```

for文の初期化式でlengthプロパティを変数lenに格納することで、lengthプロパティの変化が終了条件に影響することがなくなります。  
また、lengthプロパティへのアクセスは、相応のオーバーヘッドが発生する処理です。終了条件式として毎回評価するよりも、初期化式で1回だけアクセスするほうが、パフォーマンスの面でも有利です。

## JavaScriptからスタイルシートを操作する

かつてのWebページ開発では、HTMLに文書の構造と見た目(スタイル)をすべて記述してしまうことがありました。しかし近年では、HTMLは文書の構造を表現する役割に専念し、スタイルの設定はスタイルシートに委ねるという役割分担が一般的です。これによって、HTMLの可読性が向上し、デザイン変更の際にはデザインの差し替えが容易となります。  
ここまでのセクションでは、もっぱら文書構造(HTML)を操作する方法を解説してきましたが、DOMを使用すればスタイルシートを操作することもできます。DOMでスタイルシートを操作するには、以下のアプローチがあります。

- インラインスタイルにアクセスする(styleプロパティ)
- 外部のスタイルシートを適用する(classNameプロパティ)

以下で、それぞれの方法について見ていきます。

### styleプロパティ

JavaScriptでスタイルを操作する最もシンプルな方法は、インラインスタイルに対してアクセスする方法です。インラインスタイルとは、個々の要素に対して設定されたスタイルのことです。例えば、以下は`<div>`要素に対して適用されたインラインスタイルの例です。

```html
<div style="color:red;">赤い文字です。</div>
```

インラインスタイルにアクセスするには、styleプロパティを使用します。

- elem.style.prop [= value]
  - elem: 要素オブジェクト
  - prop: スタイルプロパティ
  - value: 設定値

以下の例は、`<div>`要素にマウスポインターを乗せたタイミングで背景色を黄色にし、外したタイミングで元の白色に切り替えるコードです。

```html
<div id="elem">マウスポインターを乗せると色が変わります</div>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    const elem = document.getElementById('elem');

    // マウスポインターが乗ったタイミングで背景色を変更
    elem.addEventListener(
      'mouseover',
      function() {
        this.style.backgroundColor = 'Yellow';
      },
      false
    );

    elem.addEventListener(
      'mouseout',
      function() {
        this.style.backgroundColor = '';
      },
      false
    );
  },
  false
);
```

[以前のセクション](oop.md#文脈によって中身が変化するthis)で解説したとおり、イベントリスナの配下では、thisはイベントの発生元を表します。上記の例であれば、thisはmouseover、mouseoutイベントが発生した`<div id="elem">`要素を指します。要素オブジェクトを取得しさえすれば、スタイルの指定には上で示した構文がそのまま使用できます。  
しかし、スタイルプロパティ名の指定については注意が必要です。なぜなら、スタイルプロパティの名前にはハイフンを含むものがありますが(例えばbackground-color)、これらのプロパティ名は、JavaScriptでは「ハイフンを取り除き、2単語目の頭文字は大文字」とする必要があるからです。以下に変更例を示します。

- background-color → backgroundColor
- border-top-style → borderTopStyle

ただし、floatプロパティ(CSS)だけは例外で、styleFloatとなる点に注意してください。  
スタイルプロパティの設定値の種類は非常に多いため、詳細については以下のリファレンスを参照してください。なお、リファレンスの表記はCSSに設定するプロパティ名なので、JavaScriptで設定するプロパティ名に適宜読み替える必要があります。

[CSS リファレンス - CSS: カスケーディングスタイルシート | MDN](https://developer.mozilla.org/ja/docs/Web/CSS/Reference)

## classNameプロパティ

styleプロパティによるスタイルの設定は、シンプルに記述できるという利点があります。一方で、スタイル定義とスクリプトが混在してしまい、デザインの変更に対応しにくいというデメリットもあります。アプリケーションの保守性を考慮すると、スタイル定義はスタイルシート(CSSファイル)にまとめておき、スクリプト側ではスタイルの関連付けを切り替えるように実装すべきです。  
外部スタイルシートで定義されたスタイル(=スタイルクラス)にアクセスするのは、classNameプロパティの役割です。なお、HTMLでこれに対応する属性はclass属性です。

- elem.className [= clazz]
  - elem: 要素オブジェクト
  - clazz: スタイルクラス
  
以下のサンプルコードは、上述のサンプルコードをclassNameプロパティを使用する形に書き換えたものです。これまで作成してきたHTMLファイルと.jsファイルに加えて、今回のサンプルコードでは新たに.cssファイル(style.css)を作成する必要があります。

(HTML)
```html
<link rel="stylesheet" href="style.css">
<div id="elem">マウスポインターを乗せると色が変わります</div>
<script type="text/javascript" src="sample.js"></script>
```

(CSS)
```css
.highlight {
  background-color: yellow;
}
```

(JavaScript)
```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    const elem = document.getElementById('elem');

    // マウスポインターが乗ったタイミングで背景色を変更
    elem.addEventListener(
      'mouseover',
      function() {
        this.className = 'highlight';
      },
      false
    );

    elem.addEventListener(
      'mouseout',
      function() {
        this.className = '';
      },
      false
    );
  },
  false
);
```

上記の実装では、スクリプトからスタイルプロパティやその設定値が除去され、スタイルをすべてCSSファイル上にまとめることができました。また、スタイル設定がより複雑になった場合でも、スクリプト側からはクラスの1つとして操作できるので、コードに影響が及ぶことはありません。  
なお、classNameプロパティには複数のクラスを関連付けることもできます。その場合は、以下のようにスタイルクラス名を半角スペース区切りで指定してください。

```javascript
this.className = 'clazz1 clazz2'
```

### スタイルクラスの着脱

classNameプロパティを使用して、特定のスタイルクラスを着脱することもできます。例えば、以下は`<div id='elem'>`要素をクリックするたびに、背景色を黄色⇔透明と交互に切り替えるコードです。上述のサンプルコードに対して、あらかじめ1つのスタイルクラスが適用されている状態(赤色の枠線を表示)として、文字列をクリックした場合には背景色を変更するようにしています。

```html
<link rel="stylesheet" href="style.css">
<div id="elem" class="line">クリックすると色が変わります</div>
<script type="text/javascript" src="sample.js"></script>
```

```css
.highlight {
  background-color: yellow;
}

.line {
  border: 1px solid red;
}
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    const elem = document.getElementById('elem');

    // 文字列をクリックしたタイミングで背景色を変更
    elem.addEventListener(
      'click',
      function() {
        // 空白区切りの文字列を分割し、配列にする
        let classes = this.className.split(' ');

        // classにhighlightが存在するか確認
        if (classes.some(item => item === 'highlight')) {
          // highlightが存在する場合、その要素を除去した配列をclassesに再代入
          classes = classes.filter(item => item !== 'highlight');
        } else {
          // highlightが存在しない場合、配列に要素を追加
          classes.push('highlight');
        }

        // 配列を空白区切りの文字列に変換し、class属性に設定
        this.className = classes.join(' ');
      },
      false
    );
  },
  false
);
```

classNameプロパティは複数のスタイルクラスが適用されている場合、「clazz1 clazz2」のように空白区切りの文字列を返却します。そのため、String.splitメソッドで配列に分割してから比較します。  
上記の例では、以前に紹介したArray.someメソッドでhighlight要素の存在を確認し、存在した場合にArray.filterメソッドでhighlightを削除した配列を再生成しています。これらのメソッドは記述の仕方にクセがありますが、覚えてしまえば処理をシンプルに記述できますので、ぜひ使い方を理解するようにしてください。  
  
【参考】someやfilterメソッドを使用しない場合は、以下のような実装となります(抜粋)。indexOfメソッドがsomeメソッドの処理に、spliceメソッドがfilterメソッドの処理に、それぞれ対応しています。今回のサンプルコードではあまり違いがありませんが、someとfilterを使用した場合には変数indexに出現位置を保持する必要がない点が異なっています。

```javascript
// highlightの存在位置を検出
const index = classes.indexOf('highlight');
if(index === -1) {
  // 存在しなければ、新たに追加
  classes.push('highlight');
} else {
  // 存在する場合は、highlightを除去
  classes.splice(index, 1);
}
```

### classListプロパティ

classListプロパティを使用することで、class属性の値(空白区切りの文字列)をDOMTokenListオブジェクトとして取得できます。DOMTokenListオブジェクトで使用できるメンバは、以下のとおりです。

| メンバ          | 説明                           |
| :--------------- | :------------------------------ |
| length          | リストの長さ                   |
| item(index)     | index番目のクラスを取得        |
| contains(clazz) | 指定したクラスが含まれているか |
| add(clazz)      | リストにクラスを追加           |
| remove(clazz)   | リストからクラスを削除         |
| toggle(clazz)   | クラスのオン・オフを切り替え   |

これらのメンバを使用することで、classNameプロパティよりも直感的にclass属性の値を操作できます。  
以下は、上記のサンプルコードをclassListプロパティを使用して書き換えたものです。書き換えるのはJavaScriptのみのため、HTMLとCSSは省略します。

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    const elem = document.getElementById('elem');

    // 文字列をクリックしたタイミングで背景色を変更
    elem.addEventListener(
      'click',
      function() {
        this.classList.toggle('highlight')
      },
      false
    );
  },
  false
);
```

toggleメソッドを使用することで、条件演算子による判定が不要となり、コードがシンプルになりました。今回の例では、単一のスタイルクラスをオン・オフするだけですが、複数のスタイルクラスが設定されている場合でも文字列の分割は不要なので、便利さをより実感できると思います。

## 高度なイベント処理

イベントハンドラやイベントリスナについては、以前のセクションで紹介しました。以下では、より細かなイベント処理について解説します。

### イベントハンドラ・イベントリスナの削除

一度設定したイベントハンドラやイベントリスナは、削除することができます。それぞれの削除方法について、例を挙げて説明します。

#### イベントハンドラの削除

イベントハンドラを削除するには、on~メソッドに対してnullを設定します。

```html
<form>
    <input id="btn" type="button" value="ダイアログ表示" />
</form>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
window.onload = function() {
  const btn = document.getElementById('btn');

  // イベントハンドラの登録
  btn.onclick = function() {
    window.alert('hello world');
  };

  // イベントハンドラを削除
  btn.onclick = null;
};
```

上記の例では、一度登録したイベントハンドラに対してnullを設定することで、イベントハンドラを削除しています。ブラウザから挙動を確認すると、確かにボタンをクリックしてもダイアログボックスが表示されないことが確認できます。また、nullを設定している行をコメントアウトすると、ダイアログボックスが表示されることも確認してください。

#### イベントリスナの削除

イベントリスナを削除するには、removeEventListenerメソッドを使用します。

- elem.removeEventListener(type, listener, capture)
  - elem: 要素オブジェクト
  - type: イベントの種類
  - listener: 削除するイベントリスナ
  - capture: イベントの伝播方向(デフォルトはfalse、詳細については後述)

上記のサンプルコードを、イベントリスナとremoveEventListerメソッドで書き換えたコードを、以下に示します。

```html
<form>
    <input id="btn" type="button" value="ダイアログ表示" />
</form>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    const btn = document.getElementById('btn');
    const listener = () => {
      window.alert('hello world');
    };

    // イベントリスナを登録
    btn.addEventListener('click', listener, false);

    // イベントリスナを削除
    btn.removeEventListener('click', listener, false);
  },
  false
);
```

上記の例では、addEventListenerメソッドで登録したイベントリスナを、removeEventListenerメソッドで削除しています。ブラウザから挙動を確認すると、確かにボタンをクリックしてもダイアログボックスが表示されないことが確認できます。また、removeEventListenerメソッドを記述している行をコメントアウトすると、ダイアログボックスが表示されることも確認してください。  
なお、removeEventListenerメソッドを使用する場合には、引数listenerで削除対象のリスナを指定する必要があります。よって、addEventListenerメソッドでイベントリスナを登録する際には、後から参照できるように名前を付けてください(上記の例ではlistener)。

### イベントオブジェクト

イベントハンドラ・イベントリスナは、引数としてイベントオブジェクトと呼ばれるオブジェクトを受け取ります。イベントハンドラ・イベントリスナ配下では、イベントオブジェクトのプロパティにアクセスすることで、イベント発生時の様々な情報に対してアクセスできます。

#### イベントオブジェクトの基本

まず、具体例を確認します。以下のサンプルコードは、ボタンをクリックしたときに、イベントの発生元・種類・イベントが生成されてからの経過時間(ミリ秒)をコンソール出力する例です。

```html
<form>
    <input id="btn" type="button" value="クリック" />
</form>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    document.getElementById('btn').addEventListener(
      'click',
      function(e) {
        const target = e.target;
        console.log('発生元: ' + target.nodeName + '/' + target.id);
        console.log('種類: ' + e.type);
        console.log('経過時間: ' + e.timeStamp);
      },
      false
    );
  },
  false
);
```

イベントオブジェクトを受け取るためには、イベントリスナに引数を指定します。引数名は任意ですが、eventを表現する「e」、または「ev」とすることが一般的です。イベントオブジェクトを使用しない場合は、引数を省略します。ちなみに、ここまでのサンプルコードではイベントオブジェクトを使用しなかったため、イベントリスナを設定する際には引数を省略していました。  
  
イベントオブジェクトで使用できるメンバを、以下に示します。なお、以下のリファレンスも併せて参照してください。

[Event - Web API | MDN](https://developer.mozilla.org/ja/docs/Web/API/Event#Properties)

| 分類                   | メンバ           | 説明                                                                             |
| :---------------------- | :---------------- | :-------------------------------------------------------------------------------- |
| 一般                   | bubbles          | イベントがバブリングか                                                           |
|                        | cancelable       | イベントがキャンセル可能か                                                       |
|                        | currentTarget    | イベントバブルでの現在の要素を取得                                               |
|                        | defaultPrevented | preventDefaultメソッドが呼ばれたか                                               |
|                        | eventPhase       | イベントの流れのどの段階にあるか                                                 |
|                        | target           | イベント発生元の要素                                                             |
|                        | type             | イベントの種類(click、mouseoverなど)                                             |
|                        | timeStamp        | イベントが生成されてからの経過時間をミリ秒で取得                                 |
| 座標                   | clientX          | イベントの発生座標(ブラウザ上のX座標)                                            |
|                        | clientY          | イベントの発生座標(ブラウザ上のY座標)                                            |
|                        | screenX          | イベントの発生座標(スクリーン上のX座標)                                          |
|                        | screenY          | イベントの発生座標(スクリーン上のY座標)                                          |
|                        | pageX            | イベントの発生座標(ページ上のX座標)                                              |
|                        | pageY            | イベントの発生座標(ページ上のY座標)                                              |
|                        | offsetX          | イベントの発生座標(要素上のX座標)                                                |
|                        | offsetY          | イベントの発生座標(要素上のY座標)                                                |
| キーボード・マウス操作 | button           | マウスのどのボタンが押されているか。<br>左ボタン:0<br>右ボタン:2<br>中央ボタン:1 |
|                        | key              | 押されたキーの値                                                                 |
|                        | keyCode          | 押されたキーのコード                                                             |
|                        | altKey           | Altキーが押されているか                                                          |
|                        | ctrlKey          | Ctrlキーが押されているか                                                         |
|                        | shiftKey         | Shiftキーが押されているか                                                        |
|                        | metaKey          | Metaキーが押されているか                                                         |

イベントオブジェクトで取得できるメンバは、発生したイベントによって異なります。例えば、後続のセクションで説明するstorageイベントリスナでは、ストレージ操作に関わる情報(変更前後の値、変更されたストレージなど)をイベントオブジェクト経由で取得します。  
以下では、イベントオブジェクトの主な使用方法について解説します。

#### イベント発生時のマウス情報を取得する

~X・~Yプロパティを使用することで、clickやmouseoverなどのイベント発生時のマウスポインターの座標を取得できます。  
以下に、サンプルコードを示します。以下のコードは、ある領域内をマウスポインターが移動したときの座標を画面に表示します。

```html
<div id="main" style="position:absolute; margin: 100px; top: 100px; width:200px; height: 200px; border:1px solid black">
</div>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    const main = document.getElementById('main');
    main.addEventListener(
      'mousemove',
      function(e) {
        main.innerHTML =
          'screen: ' +
          e.screenX +
          '/' +
          e.screenY +
          '<br>' +
          'page: ' +
          e.pageX +
          '/' +
          e.pageY +
          '<br>' +
          'client: ' +
          e.clientX +
          '/' +
          e.clientY +
          '<br>' +
          'offset: ' +
          e.offsetX +
          '/' +
          e.offsetY +
          '<br>';
      },
      false
    );
  },
  false
);
```

それぞれの座標は、座標の原点とする位置によって値が異なります。

| プロパティ | 説明                                 |
| :---------- | :------------------------------------ |
| screenX,Y  | スクリーン上の座標(画面全体)         |
| pageX,Y    | ページ上の座標(Webページ全体)        |
| clientX,Y  | 表示領域上の座標(ブラウザの表示領域) |
| offsetX,Y  | 要素領域上の座標                     |

#### イベント発生時のキー情報を取得する

keypress、keydownなどのキーイベントでは、押されたキーの種類を取得することができます。

```html
<form>
    <label for="key">キー入力</label>
    <input type="text" id="key" size="10">
</form>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    document.getElementById('key').addEventListener(
      'keydown',
      function(e) {
        console.log('キーコード: ' + e.keyCode);
      },
      false
    );
  },
  false
);
```

上記の例ではkeyCodeプロパティで押されたキーコードを出力しているだけですが、実際のアプリケーションでは、押されたキーに応じて何らかの処理を実行することになります。また、altKeyやshiftKeyなどのプロパティを使用することで、特定のキーが押されたかどうかをtrue/falseで取得できます。

### イベント処理のキャンセル

イベントオブジェクトのstopPropagation、stopImmediatePropagation、preventDefaultメソッドを使用することで、イベント処理を途中でキャンセルすることができます。本項では、これらのメソッドの使用方法と使い分けについて解説します。

#### イベントの伝播

イベント処理のキャンセルについて解説する前に、イベント処理が呼び出されるまでのプロセスについて確認します。これまでは「イベントが発生したら対応するイベントリスナが呼び出される」と説明してきましたが、実際にはイベントが特定の要素まで到達するまでには、以下の各フェーズを経ています。

1. キャプチャフェーズ  
  最上位のwindowオブジェクトから文書ツリーをたどって、下位の要素にイベントが伝播します。
2. ターゲットフェーズ  
  イベントの発生元(要素)を特定します。
3. バブリングフェーズ  
  イベントの発生元からルート要素に向かって、イベントが伝播します。最終的には、最上位のwindowオブジェクトに到達したところで終了します。イベントが親ノードへと伝わる挙動は泡が浮かび上がる様子と似ているため、このような名前になっています。

ここで押さえておくべきポイントは、イベントリスナはイベント発生元の要素だけで実行されるわけではないという点です。キャプチャフェーズ、バブリングフェーズの過程で、対応するイベントリスナが存在する場合には、それらも順番に実行されます。  
以下のサンプルコードで、具体例を確認します。

```html
<div id="outer">
    <p>outer要素</p>
    <a id="inner" href="https://www.google.co.jp">inner要素(Googleへ移動します)</a>
</div>

<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    // <a id="inner">要素のclickイベントリスナ
    document.getElementById('inner').addEventListener(
      'click',
      function(e) {
        window.alert('#innerリスナ01が発生しました');
      },
      false
    );

    document.getElementById('inner').addEventListener(
      'click',
      function(e) {
        window.alert('#innerリスナ02が発生しました');
      },
      false
    );

    // <div id="outer">要素のclickイベントリスナ
    document.getElementById('outer').addEventListener(
      'click',
      function(e) {
        window.alert('#outerイベントリスナが発生しました');
      },
      false
    );
  },
  false
);
```

入れ子関係にある`<div>`と`<a>`要素にに対して、それぞれclickイベントリスナが設定されています。この状態で画面上のリンクをクリックすると、以下の順序で処理が実行されます。

1. ダイアログ表示(#innerリスナ01が発生しました)
2. ダイアログ表示(#innerリスナ02が発生しました)
3. ダイアログ表示(#outerリスナが発生しました)
4. リンクによるページ移動

イベントの発生元を起点として、上位ノードへ向かって順番にイベントリスナが実行されています。これを言い換えると、バブリングフェーズでイベントが処理されているということです。同じ要素に対して、複数のイベントリスナが設定されている場合には、記述した順番に実行されます(サンプルコードの`<a id="inner">`要素に対するイベントリスナ)。  
この順序は、addEventListenerメソッドの第3引数で変更することができます。サンプルコードのaddEventListenerメソッドの第3引数は一律falseとなっていますが、これをすべてtrueに変更して、再度実行してみましょう。今度は、以下の結果が得られます。

1. ダイアログ表示(#outerリスナが発生しました)
2. ダイアログ表示(#innerリスナ01が発生しました)
3. ダイアログ表示(#innerリスナ02が発生しました)
4. リンクによるページ移動

今度は、上位のノードからイベントの発生元に向かってイベントリスナが実行されています。つまり、キャプチャフェーズでイベントが処理されているということです。

#### イベントの伝播をキャンセルする

次に、これらのイベントの伝播をキャンセルする方法について解説します。イベントの伝播をキャンセルするためには、stopPropagationメソッドを使用します。  
以下のサンプルコードは、先述のサンプルコードの`<a id='inner'>`要素に対して、stopPropagationメソッドを追加した例です。なお、HTMLには変更がないため、ここでは割愛します。

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    // <a id="inner">要素のclickイベントリスナ
    document.getElementById('inner').addEventListener(
      'click',
      function(e) {
        window.alert('#innerリスナ01が発生しました');
        e.stopPropagation(); // [1]
      },
      false
    );

    document.getElementById('inner').addEventListener(
      'click',
      function(e) {
        window.alert('#innerリスナ02が発生しました');
      },
      false
    );

    // <div id="outer">要素のclickイベントリスナ
    document.getElementById('outer').addEventListener(
      'click',
      function(e) {
        window.alert('#outerイベントリスナが発生しました');
      },
      false
    );
  },
  false
);
```

上記のサンプルコードの[1]で、stopPropagationメソッドを使用しています。画面上でリンクをクリックすると、以下の結果が得られます。

1. ダイアログ表示(#innerリスナ01が発生しました)
2. ダイアログ表示(#innerリスナ02が発生しました)
3. リンクによるページ移動

以上の結果から、親ノードへのバブリングがキャンセルされていることがわかります。同様に、キャプチャフェーズでイベントリスナが実行される場合にも、上位ノードでstopPropagationメソッドを呼び出すことで、同様にイベントの伝播をキャンセルできます。

#### イベントの伝播を直ちにキャンセルする

stopPropagationメソッドが上位・下位要素への伝播をキャンセルするのに対して、直ちに伝播をキャンセルする(=同じ要素に登録されたリスナも実行しない)ためには、stopImmediatePropagationメソッドを使用します。  
上記のサンプルコードのstopPropagationをstopImmediatePropagationに書き換えて、画面でリンクをクリックすると、以下の結果が得られます。

1. ダイアログ表示(#innerリスナ01が発生しました)
2. リンクによるページ移動

確かに、`<a id='inner'>`要素に対して2個目に登録したclickイベントリスナも、実行されないことがわかります。

#### イベント本来の挙動をキャンセルする

イベント本来の挙動とは、アンカータグをクリックした際にページを移動する、テキストボックスへのキー押下で入力した文字がテキストボックス内に反映される、といった動作です。これらは、ブラウザで標準的に決められている動作です。  
これらの動作をキャンセルするためには、preventDefaultメソッドを使用します。上記のサンプルコードのstopImmediatePropagationメソッドをpreventDefaultに書き換えて、画面でリンクをクリックすると、以下の結果が得られます。

1. ダイアログ表示(#outerリスナが発生しました)
2. ダイアログ表示(#innerリスナ01が発生しました)
3. ダイアログ表示(#innerリスナ02が発生しました)

上記の結果から、確かにすべてのイベントの伝播が終了した後、ページが移動しない(本来の挙動がキャンセルされる)ことが確認できます。  
  
【補足】イベントの種類によっては、preventDefaultメソッドを使用してもキャンセルができません。キャンセル可能なイベントかどうかは、同じくイベントオブジェクトのcancelableプロパティで確認できます。これがtrueであれば、キャンセルが可能です。  
  
【補足】イベントハンドラでは、戻り値としてfalseを返却することで、イベント本来の挙動をキャンセルできます。以下の例は、oncontextmenuイベントをキャンセルすることで、コンテキストメニューを表示できないようにしています。アプリケーション独自のコンテキストメニューを実装する場合には、このようにしてブラウザ標準のメニューを無効にします。

```html
<div oncontextmenu="return false">...</div>
```

ここまでに、いくつかのキャンセル系メソッドを紹介しました。以下で、これらのメソッドの違いを整理します。

|メソッド|伝播|別のリスナ|デフォルトの挙動|
|-|-|-|-|
|stopPropagation|停止|-|-|
|stopImmediatePropagation|停止|停止|-|
|preventDefault|-|-|停止|

つまり、以降のイベント伝播と標準の挙動を全てキャンセルするためには、stopImmediatePropagationとpreventDefaultメソッドを呼び出せばよいということです。

### イベントリスナ、イベントハンドラ配下のthisキーワード

[以前のセクションでも確認したとおり](oop.md#文脈によって中身が変化するthis)、thisキーワードは文脈によって指し示す対象が変わるオブジェクトです。そして、イベントリスナやイベントハンドラ配下のthisキーワードは、イベントの発生元(要素)を指します。  
では、以下のコードの挙動について考えます。コンソールにはどのような文字列が出力されるでしょうか。

```html
<button id="btn">ボタン</button>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    const data = {
      name: 'Google',
      url: 'https://www.google.co.jp',
      show: function() {
        console.log(this.name + ' : ' + this.url);
      }
    };
    document.getElementById('btn').addEventListener('click', data.show, false);
  },
  false
);
```

このサンプルコードは、ボタンがクリックされたらdata.showメソッドが呼び出され、文字列「`Google: http://www.google.co.jp`」がコンソール出力されることを意図して作成しています。  
しかし、実行結果は「: undefined」です。この原因は、イベントリスナ(data.show)配下のthis.name、this.urlが意図した値(data.name、data.url)を指していないためです。一見すると、メソッド配下のthisはオブジェクト自身を指すように思えますが、イベントリスナ配下では、thisはイベントの発生元(ここではボタン)を指しています。

```javascript
 const data = {
   name: 'Google',
   url: 'https://www.google.co.jp',
   show: function() {
     // thisは現在のオブジェクトを表すため、イベントリスナ配下でなければname、titleを指す
     console.log(this.name + ' : ' + this.url); 
   }
 };
```

```javascript
// data.showのthisは、イベントの発生元であるボタンを指す
document.getElementById('btn').addEventListener('click', data.show, false);
```

このような挙動は一見して理解しづらく、バグが発生する原因にもなります。そこで、thisが指すものを明示的に指定する方法があります。それは、Functionオブジェクトのbindメソッドです。  
サンプルコードの`data.show`を呼び出す箇所を、以下のように書き換えます。bindメソッドを使用することで、thisの対象を明示的に指定することができ、想定どおりの挙動となります。

```javascript
document.getElementById('btn').addEventListener('click', data.show.bind(data), false);
```

bindメソッドの構文は以下のとおりです。

- func.bind(that [,arg [,arg2 [,...]]])
  - func: 関数オブジェクト
  - that: 関数内でthisキーワードが示すもの
  - arg1、arg2...: 関数に渡す値

bindメソッドを使用することで、関数func配下のthisが引数thatに紐付けられます。サンプルコードであれば、thisがオブジェクトdataを指すので、想定どおりに「`Google : https://google.co.jp`」とコンソール出力されます。

#### イベントリスナにEventListenerオブジェクトを指定する

addEventListenerメソッドの第2引数には、これまで関数(Functionオブジェクト)を指定してきましたが、オブジェクトを指定することもできます。イベントリスナとして指定するオブジェクト(EventListenerオブジェクト)の条件は、handleEventメソッドを持っているということだけです。EventListenerオブジェクトでは、配下のthisが(要素の発生元ではなく)EventListenerオブジェクトを示すので、bindメソッドに頼ることなく、上述の問題を回避できます。  
以下のサンプルコードで、handleEventメソッドの使用方法を確認します。

```html
<button id="btn">ボタン</button>

<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    const data = {
      name: 'Google',
      url: 'https://www.google.co.jp',
      handleEvent: function() {
        console.log(this.name + ' : ' + this.url);
      }
    };
    document.getElementById('btn').addEventListener('click', data, false);
  },
  false
);
```

EventListenerオブジェクト(ここではdata)は、最低限、イベントリスナとしてhandleEventメソッドを持っていれば、そのほかにどのようなプロパティ、メソッドを持っていても構いません。  
addEventListenerメソッドでイベントリスナを追加する際には、メソッド(data.handleEvent)ではなく、オブジェクト(data)そのものを設定している点にも注目してください。  
先述のとおり、EventListenerオブジェクトを使用した場合には、handleEventメソッド配下のthisはEventListenerオブジェクト自身で固定されます。よって、今回はbindメソッドを介さなくても、this.name、this.urlが意図した値を参照しており、正しいコンソール出力がなされます。