# 演習問題の解答例

解答例の表記は以下の通りです。

(凡例)

1. 問題文(・の見出しの一部のみ)
   - 【解答】解答例、またはソースコード・テキストの該当箇所へのリンク
   - (【解答 2】同上)

- [演習問題](#演習問題)
  - [変数・定数](#変数定数)
  - [データ型](#データ型)
  - [演算子](#演算子)
  - [制御構文](#制御構文)
  - [オブジェクト](#オブジェクト)
  - [関数](#関数)
  - [オブジェクト指向構文](#オブジェクト指向構文)
  - [クライアントサイドJavaScriptの基本](#クライアントサイドjavascriptの基本)
  - [Webページの操作](#webページの操作)
  - [ブラウザオブジェクト](#ブラウザオブジェクト)

## [変数・定数](../docs/variable.md)

1. var、let、const の機能的な違いは何ですか。
   - 【解答】  
     ・var: 再代入・再宣言可。ブロックスコープを認識しない。  
     ・let: 再代入可能、再宣言不可。ブロックスコープを認識する。  
     ・const: 再宣言・再代入不可。ブロックスコープを認識する。

1. 以下のプログラムを作成し、var 命令と let 命令の挙動を比較してください。
   - 【解答】var を使用した場合は「メッセージ」と 2 回コンソール出力される。let を使用した場合は 1 回コンソール出力され(ブロックスコープ内の処理)、その後 「message is not defined」 でエラーとなる(ブロックスコープ外の処理)。let 命令はブロックスコープを認識するため、{}の外側はスコープ外であり変数が宣言されていないため。

## [データ型](../docs/datatypes.md)

1. プリミティブ型と参照型の違いは何ですか。
   - 【解答】  
     ・プリミティブ型: 変数に直接、値そのものを代入する。  
      ・参照型: 変数にはアドレスが代入され、データそのものはアドレスが指し示すメモリ上の場所に格納される。  
      参照型の変数に格納されるのはアドレスで、値そのものではない。

1. 文字列とエスケープシーケンスを組み合わせて、以下の文字をコンソール出力するプログラムを作成してください。
   - 【解答】[string.js](../src/datatypes/string.js)

1. 上記の文字列を、テンプレートリテラルを使用してコンソール出力するプログラムを作成してください。
   - 【解答】[templete.js](../src/datatypes/templete.js)

1. 複数のデータ型を含む配列を作成し、配列の内容をコンソール出力するプログラムを作成してください。
   - 【解答】[multi_array.js](../src/datatypes/multi_array.js)

1. 以下のキー名と値を持つオブジェクトを作成し、すべての値をコンソール出力するプログラムを作成してください。
   - 【解答】[object.js](../src/datatypes/object.js)

1. 値を代入していない変数をコンソール出力すると、どのような結果が出力されますか。
   - 【解答】undefined(未定義)

## [演算子](../docs/operator.md)

1. 文字列型の数字(例えば '100')と数値型(例えば 10)を加算演算子(+)で足し合わせた結果はどうなりますか。コンソール出力して確認してください。
   - 【解答】[plus.js](../src/operator/plus.js)

1. 文字列と真理値型(true/false)、null 型などを加算演算子(+)で足し合わせた結果はどうなりますか。
   - 【解答】[plus.js](../src/operator/plus.js)

1. 数値型から数値型以外の型(例えば文字列型の数字や数字以外)を減算演算子(-)で減算した結果はどうなりますか。(テキストで説明していない結果となる場合は、Web 検索などでその意味を確認してください)
   - 【解答】[minus.js](../src/operator/minus.js)

1. 6 × 0.3 は 1.8 となるはずですが、JavaScript ではこのまま計算すると(`6 * 0.3`)期待した計算結果が得られません。正しい結果が得られるように計算し、結果をコンソール出力してください。
   - 【解答】[decimal_multiple.js](../src/operator/decimal_multiple.js)

1. 定数(const)に配列を代入した後、代入済みの配列の内容を操作(要素の追加・変更・削除)することはできますか。あるいは、すでに宣言した定数に対して別の配列を再代入することはできますか。また、その理由は何ですか。
   - 【解答 1】再代入はできないが、代入済みの配列を操作することは可能。const で宣言した定数は再代入不可であるが、代入された参照型の値が指しているメモリ上のデータ自体の変更は制限しないため。  
     上記をまとめると、const の定数は再代入不可であるが、参照型の場合は「不変(immutable)」ではないということ。
   - 【解答 2】[operator.md#定数と参照型](../docs/operator.md#定数と参照型)

1. 分割代入を使用して、配列(例えば `[1, 2, 3]`)の内容を個別の変数(例えば`x1=1, x2 = 2, x3=3`)に取り出してください。
   - 【解答】[destructuring_assignment_array.js](../src/operator/destructuring_assignment_array.js)

1. 分割代入を使用して、オブジェクト(例えば`{A: 'a', B: 'b', C: 'c'}`)の内容を個別の変数(例えば `A = a, B = b, C = c`)に取り出してください。
   - 【解答】[destructuring_assignment_object.js](../src/operator/destructuring_assignment_object.js)

1. 等価演算子(==)を使用して`1 == true;`を評価すると、どのような結果になりますか。また、その理由は何ですか。
   - 【解答 1】評価の結果は true。等価演算子(==)は、左辺と右辺の型が合うように暗黙の型変換し、比較を行うため。
   - 【解答 2】[operator.md#等価演算子](../docs/operator.md#等価演算子)

1. 同値演算子(===)は、等価演算子(==)よりも優先的に使うべきとされていますが、その理由は何ですか。
   - 【解答】等価演算子は暗黙の型変換を行うので、true(真)となるべきではない値同士の比較が true となってしまうなどの気づきにくいバグを埋め込む原因になるため。

1. すでに宣言されている変数に値が代入されていない場合(null、空文字''など)、何らかの値を代入し、変数の内容をコンソール出力するプログラムを作成してください。なお、if 文などの制御構文は使用せずに実装してください。
   - 【解答】[shortcut.js](../src/operator/shortcut.js)

1. 配列`[1, 2]`から 2 を削除するプログラムを作成してください。また、オブジェクト`{A: 'a',B: 'b'}`から B の要素を削除するプログラムを作成してください。
   - 【解答】[delete.js](../src/operator/delete.js)

## [制御構文](../docs/control.md)

1. 1 ~ 100 までの数値について、その値が満たす条件に応じて以下の文字列をコンソール出力するプログラムを作成してください([FizzBuzz 問題](https://ja.wikipedia.org/wiki/Fizz_Buzz))。ただし、必ず条件分岐構文と繰り返し(反復)構文を使用すること。
   - 【解答】[fizzbuzz.js](../src/control/fizzbuzz.js)

1. 未宣言の変数にアクセスしようとした場合に、エラーの原因と任意のエラーメッセージをコンソール出力するプログラムを作成してください。ただし、try...catch 構文を使用すること。
   - 【解答】[try.js](../src/control/try.js)

## [オブジェクト](../docs/object.md)

1. 以下の要素を持つ Array オブジェクトを作成してください。なお、`new` で Array オブジェクトのコンストラクタを使用すること。
   - 【解答】[array.js](../src/object/array.js)

1. Array オブジェクトはリテラル表現を使用して生成することもできますが、Array オブジェクトのコンストラクタを用いて(new で)生成することもできます。以下の方法で Array オブジェクトを生成した場合、どのような配列が生成されますか。
   - 【解答 1】長さが 10 の配列。10 という要素を持つ配列ではないことに注意。
   - 【解答 2】[object.md#array オブジェクト](../docs/object.md#arrayオブジェクト)

1. 任意の Array オブジェクトを生成し、その長さをコンソール出力してください。
   - 【解答】[array.js](../src/object/array.js)

1. 任意の Array オブジェクトを生成し、forEach メソッドを用いて配列の全要素をコンソール出力してください。
   - 【解答】[array.js](../src/object/array.js)

1. 各要素が数値の Array オブジェクトを生成し、map メソッドを用いて配列の各要素を二乗した配列を生成してください。
   - 【解答】[array.js](../src/object/array.js)

1. 以下の要素を持つ Map オブジェクトを作成してください。
   - 【解答】[map.js](../src/object/map.js)

1. (発展) 任意の Map オブジェクトを生成し、forEach メソッドを用いて配列の全要素(キー名と値の組)をコンソール出力してください。
   - 【解答】[map.js](../src/object/map.js)

1. 以下の要素を持つ Set オブジェクトを作成してください。
   - 【解答】[set.js](../src/object/set.js)

1. (発展) 任意の Set オブジェクトを生成し、forEach メソッドを用いて配列の全要素と要素のデータ型をコンソール出力してください。
   - 【解答】[set.js](../src/object/set.js)

1. 2020 年 4 月 1 日 0 時 0 分 0 秒を表す Date オブジェクトを 2 つ作成し、これらの Date オブジェクトに対して以下の処理を実行してください。
   - 【解答】[date.js](../src/object/date.js)

## [関数](../docs/function.md)

1. 2 つの引数を受け取って、それらを足した値を返却する関数を、それぞれ以下の構文で作成してください。
   - 【解答】[functions.js](../src/function/functions.js)

1. function 命令を使用して関数を定義した場合、その関数はどこからでも呼び出すことができます。これはなぜですか。
   - 【解答 1】静的な構造としてコンパイル時に関数が登録されるため。
   - 【解答 2】[function.md#function 命令は静的な構造を定義する](../docs/function.md#function命令は静的な構造を定義する)

1. 2 つの引数を受け取って、それらを足した値を返却する関数を作成してください。ただし、引数が与えられなかった場合は、0 を受け取ったものとして処理(=引数にデフォルト値を設定)するように実装してください。
   - 【解答 1】[default.js](../src/function/default.js)
   - 【解答 2】[function.md#引数のデフォルト値](../docs/function.md#引数のデフォルト値)
   - 【解答 3】[function.md#引数のデフォルト値（ES2015 以降）](../docs/function.md#引数のデフォルト値es2015以降)

1. 任意の個数の引数を受け取り、それらをすべて足した値を返却する関数を作成してください。
   - 【解答 1】[rest_parameter.js](../src/function/rest_parameter.js)
   - 【解答 2】[function.md#可変長引数の関数を定義する](../docs/function.md#可変長引数の関数を定義する)
   - 【解答 3】[function.md#可変長引数の関数を定義する（ES2015 以降）](../docs/function.md#可変長引数の関数を定義するes2015以降)

1. 引数として幅と高さを受け取り、その幅と高さの四角形の面積を返却するプログラムを作成してください。
   - 【解答 1】[named_parameter.js](../src/function/named_parameter.js)
   - 【解答 2】[function.md#名前付き引数](../docs/function.md#名前付き引数)
   - 【解答 3】[function.md#名前付き引数（ES2015 以降）](../docs/function.md#名前付き引数es2015以降)

1. 引数として配列(各要素は数値)と関数を受け取り、配列の各要素を二乗した配列を返却する関数を作成してください。
   - 【解答 1】[callback.js](../src/function/callback.js)
   - 【解答 2】[function.md#高階関数](../docs/function.md#高階関数)

## [オブジェクト指向構文](../docs/oop.md)

1. 以下のクラスを作成してください(クラス名は任意)。ただし、Function オブジェクトを使用して宣言すること(ES2015 以前の構文)。  
   **以下の解答は、同一見出しの問題 3 問分です。**
   - 【解答 1】[member1.js](../src/oop/member1.js)
   - 【解答 2】[static1.js](../src/oop/static1.js)
   - 【解答 3】[inheritance1.js](../src/oop/inheritance1.js)

1. 以下のクラスを作成してください(クラス名は任意)。ただし、class 命令を使用して宣言すること(ES2015 以降の構文)。  
   **以下の解答は、同一見出しの問題 3 問分です。**
   - 【解答 1】[member2.js](../src/oop/member2.js)
   - 【解答 2】[static2.js](../src/oop/static2.js)
   - 【解答 3】[inheritance2.js](../src/oop/inheritance2.js)

## [クライアントサイドJavaScriptの基本](../docs/dom.md)

1. ブラウザ上にボタンを表示し、それをクリックしたときに任意のダイアログボックスを表示してください。
   - 【解答】[01_onclick.html](../src/dom/01_onclick.html)、[01_onclick.js](../src/dom/01_onclick.js)

1. ブラウザ上にボタンを表示し、それをクリックしたときにJavaScriptでHTML上の任意のIDを指定して要素ノード(文字列を表示するための領域)を取得し、任意の文字列をブラウザ上に表示してください。
   - 【解答】[02_getElementById.html](../src/dom/02_getElementById.html)、[02_getElementById.js](../src/dom/02_getElementById.js)

1. HTML内にボタンと複数の`<div>`要素と複数の`<p>`要素を作成し、ボタンをクリックしたときにJavaScriptでHTML上の`<div>`要素のみを指定して要素ノードを取得し、それらをコンソール出力してください。
   - 【解答】[03_getElementsByTagName.html](../src/dom/03_getElementsByTagName.html)、[03_getElementsByTagName.js](../src/dom/03_getElementsByTagName.js)

1. HTML内にボタンと`<input>`タグで複数のテキストボックスを作成し、うち1つ以上のテキストボックスの`name`属性に`textbox`を指定します。ボタンをクリックしたときにJavaScriptでHTML上の`name`属性が`textbox`である要素のみを指定して要素ノードを取得し、それらをコンソール出力してください。
   - 【解答】[04_getElementsByName.html](../src/dom/04_getElementsByName.html)、[04_getElementsByName.js](../src/dom/04_getElementsByName.js)

1. HTML内にボタンと`<ul>`タグと`<li>`タグを使用して複数のリストを作成してください。このうち、`<li>`要素の`class`属性が`foo`である要素を作成してください。ボタンをクリックしたときにJavaScriptでHTML上の`class`属性が`foo`である要素のみを指定して要素ノードを取得し、それらをコンソール出力してください。
   - 【解答】[05_getElementsByClassName.html](../src/dom/05_getElementsByClassName.html)、[05_getElementsByClassName.js](../src/dom/05_getElementsByClassName.js)

1. HTML内にボタンと`<ul>`タグと`<li>`タグを使用して複数のリストを作成し、ボタンをクリックしたときにJavaScriptで以下の処理を実行してください。
   - 【解答】[06_querySelector.html](../src/dom/06_querySelector.html)、[06_querySelector.js](../src/dom/06_querySelector.js)

1. 1つ前の設問で作成したHTMLを使用して、ボタンをクリックしたときにJavaScriptで以下の処理を実行してください。
   - 【解答】[07_nodeWalking.html](../src/dom/07_nodeWalking.html)、[07_nodeWalking.js](../src/dom/07_nodeWalking.js)

1. 1つ前の設問で作成したHTMLとJavaScriptを使用して、ボタンをクリックしたときにJavaScriptで以下の処理を実行してください。
   - 【解答】[08_eventHandler.html](../src/dom/08_eventHandler.html)、[08_eventHandler.js](../src/dom/08_eventHandler.js)

1. 1つ前の設問で作成したHTMLとJavaScriptを使用して、ボタンをクリックしたときにJavaScriptで以下の処理を実行してください。
   - 【解答】[09_eventListener.html](../src/dom/09_eventListener.html)、[09_eventListener.js](../src/dom/09_eventListener.js)

1. (総合演習) これまでに学習してきた文法を使用して、ホテルの部屋予約機能を模した画面を実装します。
   - 【解答】[10_hotelReservation.html](../src/dom/10_hotelReservation.html)、[10_hotelReservation.js](../src/dom/10_hotelReservation.js)

## [Webページの操作](../docs/manipulation.md)

1. ブラウザ上に仮のToDoリストとしてリスト要素(`<ul>`と`<li>`タグを使用)を表示し、`<li>`要素には任意の属性(classなど)を設定してください。
   - 【解答】[01_todo.html](../src/manipulation/01_todo.html)、[01_todo.js](../src/manipulation/01_todo.js)
   - (備考) CSSファイルは不要なため、解答はありません。

1. 1つ前の設問で作成したボタンとは別のボタンを作成します。また、テキストボックスも新規に作成します。さらに、すでに作成済みの各`<li>`要素の子要素にチェックボックスを追加します。  
新規に作成したボタンをクリックしたときに、以下の処理を実行してください。
   - 【解答】[02_todo.html](../src/manipulation/02_todo.html)、[02_todo.js](../src/manipulation/02_todo.js)
   - (備考) CSSファイルは不要なため、解答はありません。

1. 1つ前の設問で作成したボタンをクリックしたときに以下の処理を実行してください。なお、すでに実装済みのコードで不要な部分はコメントアウトしてください。
   - 【解答】[03_todo.html](../src/manipulation/03_todo.html)、[03_todo.js](../src/manipulation/03_todo.js)
   - (備考) CSSファイルは不要なため、解答はありません。

1. 新規にボタンを作成し、ボタンをクリックしたときに以下の処理を実行してください。
   - 【解答】[04_todo.html](../src/manipulation/04_todo.html)、[04_todo.js](../src/manipulation/04_todo.js)
   - (備考) CSSファイルは不要なため、解答はありません。

1. 最初の設問で作成したボタンを「完了/完了解除」ボタンとし、クリックしたときに以下の処理を実行してください。
   - 【解答】[05_todo.html](../src/manipulation/05_todo.html)、[05_todo.js](../src/manipulation/05_todo.js)、[05_todo.css](../src/manipulation/05_todo.css)

1. ここまでの設問で作成したToDoアプリに、以下の機能を追加してください。
   - 【解答】[06_todo.html](../src/manipulation/06_todo.html)、[06_todo.js](../src/manipulation/06_todo.js)、[06_todo.css](../src/manipulation/06_todo.css)

## [ブラウザオブジェクト](../docs/browser_objects.md)

1. ToDoの削除機能に削除確認機能を追加します。confirmメソッドを使用し、ToDoの削除可否を確認するダイアログボックスを表示してください。
   - 【解答】[01_confirm.html](../src/browser_objects/01_confirm.html)、[01_confirm.js](../src/browser_objects/01_confirm.js)、[01_confirm.css](../src/browser_objects/01_confirm.css)

1. (やや難しいため実施は任意) setIntervalメソッドを使用し、一定時間が経過するまでは削除したToDoを元に戻すことができる機能を追加してください。
   - 【解答】[02_setInterval.html](../src/browser_objects/02_setInterval.html)、[02_setInterval.js](../src/browser_objects/02_setInterval.js)、[02_setInterval.css](../src/browser_objects/02_setInterval.css)

1. Storageオブジェクトを使用し、セッションストレージにToDoを保存してください(Todoのタイトル、完了未済/済の情報を保存)。
   - 【解答】[03_storage.html](../src/browser_objects/03_storage.html)、[03_storage.js](../src/browser_objects/03_storage.js)、[03_storage.css](../src/browser_objects/03_storage.css)

1. (発展問題のため実施は任意) 1つ前の設問で作成したセッションストレージへのToDo保存機能を、**ToDoの追加・更新・削除の実装は1つ前の設問より前の状態のままで**、各関数の処理が終わった後に必ず実行される処理(事後処理)として実装してください。
   - 【解答】[04_storage_02.html](../src/browser_objects/04_storage_02.html)、[04_storage_02.js](../src/browser_objects/04_storage_02.js)、[04_storage_02.css](../src/browser_objects/04_storage_02.css)
