# 開発環境の構築

このセクションでは、開発環境の構築を実施します。ソースコードエディタとしてVisual Studio Code、サーバサイドのJavaScript実行環境としてNode.jsをインストールします。

- [開発環境の構築](#開発環境の構築)
  - [Visual Studio Codeのインストールと設定](#visual-studio-codeのインストールと設定)
      - [Visual Studio Codeについて](#visual-studio-codeについて)
      - [インストーラのダウンロード（VSCode）](#インストーラのダウンロードvscode)
      - [インストールの実施（VSCode）](#インストールの実施vscode)
          - [文字コード、改行コードの設定](#文字コード改行コードの設定)
      - [エクステンションの導入](#エクステンションの導入)
          - [VSCodeのProxy設定【社内LAN環境から実施する場合のみ】](#vscodeのproxy設定社内lan環境から実施する場合のみ)
          - [エクステンションのインストール](#エクステンションのインストール)
          - [保存時のコード自動整形の設定](#保存時のコード自動整形の設定)
  - [Node.jsのインストール](#nodejsのインストール)
      - [Node.jsについて](#nodejsについて)
      - [インストーラのダウンロード（Node.js）](#インストーラのダウンロードnodejs)
      - [インストールの実施（Node.js）](#インストールの実施nodejs)
      - [インストールの確認](#インストールの確認)
      - [npmのProxy設定【社内LAN環境から実施する場合のみ】](#npmのproxy設定社内lan環境から実施する場合のみ)
  - [ESLintの導入](#eslintの導入)
      - [ESLintのインストール](#eslintのインストール)
      - [VSCodeにおけるESLintの動作確認](#vscodeにおけるeslintの動作確認)

## Visual Studio Codeのインストールと設定

### Visual Studio Codeについて

[Visual Studio Code](https://code.visualstudio.com/)(以下、VSCode)は、Microsoftが開発しているソースコードエディタです。様々なプログラミング言語の開発に対応しており、機能を追加するためのエクステンションも豊富に公開されています。  
類似のソースコードエディタとしては、[Atom](https://atom.io/)や[Sublime Text](http://www.sublimetext.com/)などがあります。それぞれの基本的な機能に大きな違いはありませんが、UIなどの細かい使い勝手が異なります。  
どのソースコードエディタを使用するかは、開発者個人の好みで決める場合が多いです。今回はVSCodeを使用して開発を行いますが、これは社内の開発案件でVSCodeを採用する場合が多いためです(特に軽量プログラミング言語の開発を行う場合)。  
【参考】使い慣れたソースコードエディタがある場合は、そちらを使用しても構いません。ただし、以降の各手順はVSCodeを使用することを前提としています。

### インストーラのダウンロード（VSCode）

1. [Visual Studio Code - Code Editing. Redefined](https://code.visualstudio.com/)にアクセスし、「Download for Windows」と書かれたボタンをクリックします。  
![VSCodeのダウンロード](../img/environment/vscode_download.png)
1. 画面が遷移し、ダウンロードのダイアログボックスが表示されます。インストーラを任意の場所にダウンロードします。

### インストールの実施（VSCode）

1. ダウンロードしたインストーラを起動します。
1. 「同意する」ラジオボタンをクリックし、「次へ」ボタンをクリックします。  
![使用許諾契約書の同意](../img/environment/vscode_consent.png)
1. 「次へ」ボタンをクリックします。  
![インストール先の指定](../img/environment/vscode_destination.png)
1. 「次へ」ボタンをクリックします。  
![プログラムグループの指定](../img/environment/vscode_programgroup.png)
1. 「デスクトップ上にアイコンを作成する」と「PATHへの追加(再起動後に使用可能)」チェックボックスを選択し、「次へ」ボタンをクリックします。  
![追加タスクの選択](../img/environment/vscode_addition.png)
1. 「インストール」ボタンをクリックします。  
![インストール準備の完了](../img/environment/vscode_install.png)
1. インストールが完了すると、以下のウィンドウが表示されます。「完了」ボタンをクリックし、VSCodeを起動します。  
![インストールの完了](../img/environment/vscode_finished.png)

#### 文字コード、改行コードの設定

1. VSCodeを起動後、Ctrlキーを押しながら,キーを押して、設定画面を表示します。
![設定画面](../img/environment/vscode_settings.png)
1. 設定画面上部のテキストボックスに「files.encoding」と入力し、文字コードの設定を表示します。プルダウンメニューから、以下のとおり選択します。
   - Files: Encoding → 「utf8」を選択  
        ![文字コード・改行コード設定](../img/environment/vscode_encodingsettings.png)  
1. 同様に、設定画面上部のテキストボックスに「files.eol」と入力し、改行コードの設定を表示します。プルダウンメニューから、以下のとおり選択します。
   - Files: Eol → \nを選択
1. VSCode上でCtrlキー + Wキーを押して、設定画面を閉じます。

### エクステンションの導入

ここまでの手順でVSCodeのインストールが完了したので、JavaScriptの開発を始めることができます。ここにエクステンションと呼ばれる拡張機能を導入して、開発を効率よく実施できる機能を追加します。

#### VSCodeのProxy設定【社内LAN環境(テレワークも含む)から実施する場合のみ】

1. VSCode上でCtrlキー + ,キーを押して、設定画面を表示します。
![設定画面](../img/environment/vscode_settings.png)
1. 設定画面上部のテキストボックスに「proxy」と入力し、Proxyの設定を表示します。「Http Proxy」と表示された設定項目のテキストボックスに、以下のURLを入力します。

    ```sh
    http://gienah.in.dcs.co.jp:8080
    ```

    ![Proxy設定](../img/environment/vscode_proxy.png)

1. VSCode上でCtrlキー + Wキーを押して、設定画面を閉じます。

以下の手順で、各種エクステンションをインストールします。

#### エクステンションのインストール

以下の3つのエクステンション(追加機能)をインストールします。インストールの手順は、どのエクステンションでも同一です。

- Japanese Language Pack for Visual Studio Code
  - VSCodeのUIを日本語化するエクステンションです。
- Prettier
  - JavaScriptなどのコードを、フォーマット(ルール)に従って自動整形するためのエクステンションです。このエクステンションを使用することで、開発者がフォーマットをいちいち確認しなくても、読みやすく表記が統一されたコードを書くことができます。このような機能を持つツールをコードフォーマッターと呼び、特に多人数で開発を行う際には必須のツールです。
- ESLint
  - JavaScriptのコードを実行する前に明らかなバグを指摘する機能や、括弧やスペースの使い方などのスタイルを統一する機能を持つエクステンションです。
  - 【参考】後続のセクションで解説しますが、JavaScriptは作成したソースコード(プログラム)を、一行ずつコンピュータが実行できる形式(機械語)に逐次翻訳して実行します。そのため、プログラムをコンピュータが実行するまでエラーが発生するかどうかがわかりません。この状態ですと、プログラムにバグがあるか確認するために、開発者はプログラムの作成→実行を繰り返す必要があり、開発効率が悪くなります。よって、プログラムの実行前にあらかじめバグのチェックを行うことができるエクステンションを導入します。  
  - 【参考】上記のような機能を持つツールを、静的検証ツール(Linter)と呼びます。JavaScriptの静的検証ツールとしては、ESLintの他に、JSLint、JSHintがあります。

1. VSCodeのウィンドウの左側、Extensionのアイコン(正方形が4つ)をクリックします。または、Ctrlキー + Shiftキー + Xキーを押します。  
![ExtensionPaneの表示](../img/environment/vscode_extensionpane.png)  
1. エクステンションペイン(帯状の表示領域)が表示されます。画面上部のテキストボックスに各エクステンションの名称を入力し、エクステンションを検索します(以下の例ではJapanese Language Pack for Visual Studio Codeをテキストボックスに入力し、検索しています)。  
![Extensionの検索](../img/environment/vscode_extensionsearch.png)
1. 検索結果から、インストールするエクステンションをクリックします。新しいタブが開き、エクステンションの説明が表示されます。  
![Extensionの説明](../img/environment/vscode_extensiondetail.png)
1. 新しく開いたタブの画面上部にある「Install」ボタンをクリックします。  
![Extensionのインストール](../img/environment/vscode_extensioninstall.png)
1. インストールが開始し、しばらくすると「Install」ボタンが「アンインストール」ボタンに変わります。これで、インストールは完了です。インストールが失敗する場合は、何度か繰り返し「Install」ボタンをクリックしてください。  
![Extensionのインストール完了](../img/environment/vscode_extensioninstalled.png)
1. 【参考】 上記以外にも、さまざまな機能を追加するエクステンションが公開されています。必要に応じて、自分の好みに合ったエクステンションをインストールしても構いません。Web検索で「VSCode エクステンション」などで検索をすると、便利なエクステンションを紹介する記事が見つかります。ただし、あまりに多くのエクステンションを導入すると、VSCodeの動作が遅くなる場合があります。また、以降の手順では、上記のエクステンションのみを導入した状態を前提として解説します。

#### 保存時のコード自動整形の設定

1. VSCode上でCtrlキー + ,キーを押して、設定画面を表示します。
![設定画面](../img/environment/vscode_settings.png)
1. 設定画面上部のテキストボックスに「Format On Save」と入力し、「Editor: Format On Save」と表示された設定項目のチェックボックスにチェックを入れます。

    ![format On Save](../img/environment/vscode_formatonsave.png)

1. 同様に、設定画面上部のテキストボックスに「Prettier Single Quote」と入力し、「Prettier: Single Quote」と表示された設定項目のチェックボックスにチェックを入れます。

    ![Prettier Single Quote](../img/environment/vscode_singlequote.png)

1. VSCode上でCtrlキー + Wキーを押して、設定画面を閉じます。

## Node.jsのインストール

### Node.jsについて

Node.jsは、サーバサイド(⇔クライアントサイド)のJavaScript実行環境です。後述しますが、JavaScriptはもともと、Webブラウザ上(=クライアントサイド)で動作するプログラミング言語として開発されました。時代が下り、JavaScriptの言語仕様がサーバ上で動作するアプリケーションに適していることがわかり、その結果Node.jsが開発されるに至りました。

- 【参考】[node.js とは何か - I am bad at math](https://badatmath.hatenablog.com/entry/20101020/1287587240)

このドキュメントの演習で作成するプログラムは、サーバ上で動作させることを意図したものではありません。これはつまり、外部からネットワークを経由してアクセスすることを想定したプログラムを作成するわけではないということです。  
その一方で、Node.jsは導入が容易であり、JavaScriptの実行も簡単に行えるため、JavaScriptの学習を効率よく行うための環境として適しています。このような特性から、本ドキュメントではNode.jsをJavaScriptの実行環境として採用しています。

- 【参考】JavaScriptの実行自体は、Node.jsを導入しなくても行うことができます。先述のとおり、JavaScriptはWebブラウザ上で動作するプログラミング言語です。そのため、Webブラウザに付属する「開発者ツール」を使用することで、JavaScriptを実行することができます。ただしこの方法ですと、プログラムの編集や実行の効率が良くないため、今回はNode.jsを使用して開発を行います。

以下の手順でNode.jsをインストールし、JavaScriptを実行するための環境を準備します。

### インストーラのダウンロード（Node.js）

1. [Node.js](https://nodejs.org/ja/)にアクセスし、「xx.yy.zz LTS」(x、y、zはいずれも任意の数字)と書かれたボタンをクリックします。  
![nodejsのダウンロード](../img/environment/nodejs_download.png)
1. ダウンロードのダイアログボックスが表示されます。インストーラを任意の場所にダウンロードします。

### インストールの実施（Node.js）

1. ダウンロードしたインストーラを起動します。
1. 以降は、設定を変更せずにすべて「Next」ボタンをクリックし、インストールを完了してください。

### インストールの確認

1. コマンドプロンプトを起動します。Windowsキー + Rキーを押して「ファイル名を指定して実行」ウィンドウを開き、テキストボックスに「cmd」と入力して「OK」ボタンをクリックします。  
![ファイル名を指定して実行](../img/environment/exec.png)
1. 以下のコマンドを入力し、Enterキーを押します。以下のスクリーンショットのように、Node.jsのバージョン名が表示されれば、正しくインストールが完了しています。確認後は、**コマンドプロンプトは閉じずに後続の手順に進んでください。**  

    ```PowerShell
    node -v
    ```

    ![nodejsの確認](../img/environment/nodejs_installed.png)  

### npmのProxy設定【社内LAN環境(テレワークも含む)から実施する場合のみ】

1. コマンドプロンプトに以下のコマンドをそれぞれ入力し、Enterキーを押します。この設定により、npm install時のパッケージ取得が社内プロキシ経由となります。

    ```PowerShell
    npm -g config set proxy http://gienah.in.dcs.co.jp:8080
    ```

    ```PowerShell
    npm -g config set https-proxy http://gienah.in.dcs.co.jp:8080
    ```

1. コマンドプロンプトに以下のコマンドを入力し、Enterキーを押します。この設定により、npm install時にSSL証明書を無視する設定となります。

    ```PowerShell
    npm -g config set strict-ssl false
    ```

1. 以下のコマンドを入力し、proxy、https-proxy、それにstrict-sslの設定値が以下のスクリーンショットの反転部分のようになっていることを確認します。確認後は、**コマンドプロンプトは閉じずに後続の手順に進んでください。**  

    ```PowerShell
    npm config list
    ```

    ![npmのプロキシ設定](../img/environment/npm_proxysettings.png)

## ESLintの導入

VSCodeのエクステンションを導入する手順にて、ESLintエクステンションをインストールしました。このエクステンションは、実際にはESLintの本体ではなく、あくまでVSCode上でESLintを使用するためのエクステンションです。そのため、別途ESLint本体をインストールし、設定することが必要となります。  
以下の手順では、ESLintをインストールします。インストールの際は、Node.jsに付属するパッケージ管理ツールであるnpmを使用します。

### ESLintのインストール

1. コマンドプロンプトを起動し、今回開発するJavaScriptのソースコードを格納する任意のフォルダ(**後続手順の簡略化のため、フォルダ名は英数字のみとしてください**)へ移動します。以下の例では、C:\Users\dcs\workspaceにソースコードを格納します。このフォルダを、以下では「ワーキングフォルダ」と呼びます。  
コマンドプロンプト上でワーキングフォルダへ移動した後、以下のコマンドを入力してEnterキーを押します。

    ```PowerShell
    npm init
    ```

    何回か入力を求められますが、すべて何も入力せずにEnterキーを押し、最後の「Is this OK? (yes)」のみ「yes」と入力してEnterキーを押します。  

    ![npm init](../img/environment/npm_init.png)

    上記のコマンド実行後、ワーキングフォルダにpackage.jsonが作成されたことを確認します。  
    【参考】package.jsonは、インストールするパッケージの依存関係などを管理するためのファイルです。

1. 以下のコマンドを入力してEnterキーを押し、ESLintのインストールを開始します。

    ```PowerShell
    npm install eslint
    ```

1. しばらく待つと「added \~\~\~ packages from \~\~\~ contributors in \~\~\~ s」と表示され、インストールが完了します。  
    npm installを実行すると、「WARN」と書かれたメッセージが表示されることがあります。この場合でも、インストール自体は正常に完了しているので、メッセージは無視してください(以降の手順でも同様)。

    ![ESLintのインストール](../img/environment/eslint_installed.png)

1. 同様に、以下のコマンドを入力してEnterキーを押し、Google準拠のコードスタイルをインストールします。

    ```PowerShell
    npm install eslint-config-google
    ```

1. 同様に、以下のコマンドを入力してEnterキーを押し、EslintとPrettierを併用するための設定をインストールします。

    ```PowerShell
    npm install eslint-config-prettier
    ```

1. 同様に、以下のコマンドを入力して Enter キーを押し、コマンドプロンプトからeslint コマンドを実行できるようにします。

    ```PowerShell
    npm install -g eslint-cli
    ```

1. 以下のコマンドを入力して、Enterキーを押します。以下のスクリーンショットのように、ESLintのバージョン名が表示されていれば正しくインストールが完了しています。  
確認後、コマンドプロンプトを閉じます。

    ```PowerShell
    eslint -v
    ```

    ![ESLintのバージョン](../img/environment/eslint_version.png)

1. ESLintの設定ファイルを作成します。任意のテキストエディタを開き、以下の文字列をコピー&ペーストします。このファイルを、ワーキングフォルダに「.eslintrc.json」という名前で配置します。**拡張子が「.txt」とならないように注意してください。**

   ```json
   {
     "env": {
       "browser": true,
       "node": true,
       "es2021": true
     },
     "extends": ["eslint-config-google", "eslint-config-prettier"],
     "globals": {
       "Atomics": "readonly",
       "SharedArrayBuffer": "readonly"
     },
     "parserOptions": {
       "sourceType": "module"
     }
   }
   ```

### VSCodeにおけるESLintの動作確認

1. VSCodeを起動している場合は、いったん終了し、再度起動します。
1. 画面上部のメニューバーから「ファイル(F)」をクリックし、「フォルダを開く」をクリックします。
1. ワーキングフォルダを選択し、「フォルダーの選択」ボタンをクリックします。
1. ワーキングフォルダが正しく選択されていれば、画面左側のエクスプローラーペインに、ワーキングフォルダの名称と、その中に格納されているフォルダ・ファイルの名称が表示されます。

    ![VSCode_エクスプローラー](../img/environment/vscode_explorer.png)

1. エクスプローラーペイン上で右クリックし、表示される右クリックメニュー内の「新しいファイル」をクリックします。その後に表示されるテキストボックスに「(任意の名前).js」と入力し、Enterキーを押します。これにより、ワーキングフォルダ内に新しいjsファイルが生成されます。  
jsファイルは、JavaScriptのソースコードを保存するためのファイルです。jsファイルは通常のテキストファイル(.txt)と同じファイル形式なので、メモ帳などのテキストエディタでも内容を表示・編集することができます。

    ![VSCode_新しいファイル](../img/environment/vscode_newfile.png)

    ![VSCode_新しいファイル](../img/environment/vscode_newfile02.png)

1. エクスプローラーペインから新規作成したjsファイルをクリックします。画面中央にエディタが表示され、作成したjsファイルを編集する準備ができました。

    ![VSCode_新しいファイル](../img/environment/vscode_newfile03.png)

1. 開いたjsファイルに、以下の文字列をコピー&ペーストします。その後、Ctrlキー + Sキーを押して、ファイルを保存します。

    ```javascript
    var str = "test"
    ```

1. jsファイルを保存した後、ファイルが以下のように変更されることを確認してください(変更されない場合やフォーマッターの選択を求められた場合は次の手順を参照してください)。  
   - Prettierによるコード変更
     - "(ダブルクォーテーション)が'(シングルクォーテーション)に変更されていること
     - 行末に;(セミコロン)が追記されていること
   - ESLintによるコード指摘
     - コピー&ペーストした文字列の直下に波線が引かれていること
   - 保存後のソースコード  

        ```javascript
        var str = 'test';
        (空行)
        ```


    上述の変更は導入した各種エクステンションによるものですが、今の段階では変更の意味や理由を理解する必要はありません。

1. 【フォーマッターの設定】 プログラムが自動整形されない場合や、フォーマッターの設定を求められた場合は、以下の手順を実施してください。
   1. VSCode上でjsファイルを開き、コードが表示されている領域上で右クリック
   1. 右クリックメニューから「ドキュメントのフォーマット...」をクリック
   1. 開いたメニューから「既定のフォーマッタを構成...」をクリック
   1. 「Prettier - Code formatter」をクリック

以上で、開発環境の準備が整いました。
