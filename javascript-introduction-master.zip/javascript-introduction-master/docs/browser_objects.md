# ブラウザオブジェクト

ブラウザオブジェクトとは、ブラウザ操作のための機能を持つオブジェクト群の総称です。このセクションでは、これらのオブジェクトの中でも特に重要な機能を持っているものに絞って解説します。

- [ブラウザオブジェクト](#ブラウザオブジェクト)
  - [ブラウザオブジェクトの基礎知識](#ブラウザオブジェクトの基礎知識)
      - [アクセスの方法](#アクセスの方法)
      - [confirmメソッド](#confirmメソッド)
      - [setInterval、setTimeoutメソッド](#setintervalsettimeoutメソッド)
      - [locationオブジェクト](#locationオブジェクト)
      - [historyオブジェクト](#historyオブジェクト)
      - [pushStateメソッド](#pushstateメソッド)
      - [navigatorオブジェクト](#navigatorオブジェクト)
  - [Consoleオブジェクト](#consoleオブジェクト)
      - [コンソールにログを出力する](#コンソールにログを出力する)
      - [ログメソッドの便利な使い方](#ログメソッドの便利な使い方)
  - [Storageオブジェクト](#storageオブジェクト)
      - [ストレージへのデータ保存、取得](#ストレージへのデータ保存取得)
          - [開発者ツールでストレージの内容を確認](#開発者ツールでストレージの内容を確認)
      - [既存データの削除](#既存データの削除)
      - [全データの取り出し](#全データの取り出し)
      - [オブジェクトの保存、取得](#オブジェクトの保存取得)
      - [ストレージの変更監視](#ストレージの変更監視)

## ブラウザオブジェクトの基礎知識

### アクセスの方法

ブラウザオブジェクトは、グローバルオブジェクトであるWindowオブジェクトの配下のプロパティとして定義されています。[以前のセクションで説明したとおり](object.md#globalオブジェクト)、グローバルオブジェクトは、基本的に開発者は直接アクセスすることがないオブジェクトであるため、開発の際にはWindowオブジェクトを意識する必要はありません。例えば、ブラウザオブジェクトであるlocationオブジェクトのreloadメソッドにアクセスする場合、以下のように直接locationプロパティを呼び出すことができます。

```javascript
location.reload();
```

一方、以下の記述は実行不可です。

```javascript
Window.location.reload();
```

Windowオブジェクトは自分自身を参照するwindowプロパティを持っており、これを介してブラウザオブジェクトにアクセスすることもできます。そのため、以下の例のように記述してアクセスできますが、このような実装は冗長なだけです。

```javascript
window.location.reload();
```

再確認となりますが、このように記述したときのlocationはオブジェクト名ではなく、Windowオブジェクトのプロパティ名です。つまり、locationは、あくまでLocationオブジェクトを参照するプロパティを意味しています。  
しかし、locationプロパティは実態としてオブジェクトを表していることから、便宜上「locationオブジェクト」と表記することがあります。この区別を意識する必要はありませんが、実際にはプロパティに対するアクセスであることは理解してください。

### confirmメソッド

ここからは、ブラウザオブジェクトが提供する中でも、特に基本的なメソッドを紹介します。  
まず、確認ダイアログを表示するconfirmメソッドを紹介します。ここまでのサンプルコードで何度か使用したalertメソッドが単にメッセージを表示するだけなのに対して、confirmメソッドはユーザに何らかの意思確認を行う意味合いで使用します。

```html
<form id="form">
    <input type="submit" value="送信" />
</form>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('form').addEventListener('submit', function(e) {
    if (!window.confirm('ページを送信しても良いですか?')) {
      e.preventDefault();
    }
  });
});
```

confirmメソッドは、ダイアログボックス上で押されたボタンに応じて、以下の戻り値を返却します。

- [OK]ボタンがクリックされた場合 → true
- [キャンセル]ボタンがクリックされた場合 → false

ここでは、confirmメソッドの性質を使用して、[キャンセル]ボタンがクリックされた場合には、以前のセクションで紹介したpreventDefaultメソッドを呼び出して、本来のサブミットイベントをキャンセルしています。  
  
なお、Windowオブジェクト配下のメソッドやプロパティにアクセスする際には、`window.`は省略することができます。ただし、このドキュメントでは、それぞれのメソッドやプロパティがWindowオブジェクトに属していることを明示するため、基本的に`window.`を省略しないで記述します。

### setInterval、setTimeoutメソッド

一定時間ごとに、あるいは一定時間が経過したあとに何らかの処理を実行したい、というケースはよくあります。このような場合に使用できるのがsetInterval、setTimeoutメソッドです。以下で、実装例を見ていきます。

```html
<input id="btn" type="button" value="タイマー停止" />
<div id="result"></div>
<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener('DOMContentLoaded', function() {
    const timer = window.setInterval(
        function() {
            const date = new Date();
            document.getElementById('result').textContent = date.toLocaleTimeString();
        }, 1000
    );

    document.getElementById('btn').addEventListener('click', function() {
        window.clearInterval(timer);
    }, false);
}, false);
```

setInterval、setTimeoutメソッドの構文は、以下のとおりです。

- window.setInterval(func, dur)
- window.setTimeout(func, dur)
  - func: 実行される処理
  - dur: 時間間隔(単位はミリ秒)

両者はよく似ていますが、以下の違いがあります。

- setInterval → 指定した時間間隔で処理を繰り返し実行する
- setTimeout → 指定した時間が経過したところで処理を1回だけ実行する

動作の違いを確認するため、サンプルコードのsetIntervalをsetTimeoutに書き換えてみてください。今度は、1000ミリ秒(1秒)後に一度だけ現在時刻が表示されることが確認できます。  
setInterval、setTimeoutメソッドは、いずれもタイマーを一意に識別するためのid値を返却します。このid値は、clearIntervalメソッド(setIntervalの場合)、clearTimeoutメソッド(setTimeoutの場合)に渡すことで、タイマーを破棄できます。サンプルコードでは、[タイマー停止]ボタンをクリックすることで、時間の更新が停止することを確認してください。  
  
setInterval、setTimeoutメソッドの使用に際しては、以下の注意点があります。

- 引数funcに文字列を使用しない  
    setInterval、setTimeoutメソッドの引数funcには、実行するスクリプトを文字列で指定することもできます。

    ```javascript
    setTimeout('console.log("実行された")', 1000);
    ```

    しかし、この記法はevalメソッドと同様の理由から避けるべきです。よって、引数funcは必ず関数リテラルで指定してください。

- 指定した時間(間隔)で実行されるわけではない  
    setInterval、setTimeoutメソッドの引数dur(時間間隔)は、その時間で処理が実行されることを保証するわけではありません。setInterval、setTimeoutメソッドでは、あくまで指定された時間に、処理をキュー(処理を実行するための待ち行列)に登録するに過ぎません。キューに実行すべき処理が残っている場合、先行する処理が終了するまで待たなければなりません。

- 引数durが0の場合の処理  
    以下のようなコードでは、どのような挙動になるでしょうか。

    ```javascript
    function func() {
        console.log('1');
        setTimeout(function() {
            console.log('2');
        }, 0);
        console.log('3');
    }

    func();
    ```

    引数durにゼロが設定されているため、setTimeoutの処理内容は即座に実行され、1、2、3とコンソール出力されると考えがちですが、実際に実行してみると、1、3、2となります。  
    setTimeoutメソッドが与えられた処理をタイマーに引き渡している間に、JavaScriptは後続のコードを実行しているということです。このような処理を、非同期処理をいいます。  
    非同期処理については、[後続のセクション](asynchronous.md#非同期処理)で説明します。ここでは、JavaScriptでは処理が並行実行されることがあり、必ずしもコードを記述した順番で処理が実行されるわけではないことを理解してください。

### locationオブジェクト

ボタンをクリックすることで別ページに移動したい、あるいは現在のページをリロードしたいといった状況はよくあります。そのようなケースで使用するのがlocationオブジェクトです。  
locationオブジェクト(Locationオブジェクト)で使用可能な主なプロパティとメソッドは、以下のとおりです。なお、以下に示す戻り値の例は、現在のURLが「`http://localhost:8080/js/sample.html#anchor?id=12345`」の場合に得られる戻り値です。また、*のついたメンバは、読み取り専用です。

| メンバ       | 説明                                                          | 戻り値の例                                             |
| :----------- | :------------------------------------------------------------ | :----------------------------------------------------- |
| hash         | アンカー名(#~)                                                | #anchor?id=12345                                       |
| host         | ホスト(ホスト名+ポート番号。ただし80の場合はポート番号は省略) | localhost:8080                                         |
| hostName     | ホスト名                                                      | localhost                                              |
| href         | リンク先                                                      | `http://localhost:8080/js/sample.html#anchor?id=12345` |
| *pathname    | パス名                                                        | js/sample.html                                         |
| *port        | ポート番号                                                    | 8080                                                   |
| *protocol    | プロトコル名                                                  | http:                                                  |
| search       | クエリ情報                                                    | ?id~12345                                              |
| reload()     | 現在のページを再読み込み                                      | -                                                      |
| replace(url) | 指定ページurlに移動                                           | -                                                      |

この中でもよく使用するのが、JavaScriptからページを再読み込みして移動するためのhrefプロパティです。以下で、具体例について見ていきます。以下のサンプルコードは、選択ボックスで移動先のページを選択すると自動的にそのページへ移動するサンプルです。

```html
<form>
    <label for="page">DCS ポータル</label>
    <select id="page" name="page">
        <option value="">(以下から選択してください)</option>
        <option value="index.html">トップページ</option>
        <option value="solution/index.html">ソリューション・サービス</option>
        <option value="casestudy/index.html">導入事例</option>
        <option value="event/index.html">イベント・セミナー</option>
        <option value="company/index.html">会社情報</option>
        <option value="saiyo/index.html">採用情報</option>
    </select>
</form>

<script type="text/javascript" src="sample.js"></script>
```

```javascript
document.addEventListener(
  'DOMContentLoaded',
  function() {
    document.getElementById('page').addEventListener(
      'change',
      function() {
        location.href = 'https://www.dcs.co.jp/' + this.value;
      },
      false
    );
  },
  false
);
```

選択ボックスの値を取得する方法については、以前のセクションで説明したとおりです。ここでは、changeイベントが発生したタイミングで選択ボックスの値を取得し、以下のようなURLを生成しています。

`https://www.dcs.co.jp/選択した値`

上記のURLをlocation.hrefプロパティに渡すことで、目的のページに移動できます。

### historyオブジェクト

履歴に沿って前後のページへの移動を制御する場合は、ブラウザのページ履歴を管理しているhistoryオブジェクトを使用します。以下のように、back、forwardメソッドを使用することで、ページ履歴上の前後のページへ移動できます。

```html
<a href="JavaScript:history.back()">戻る</a>
<a href="JavaScript:history.forward()">進む</a>
```

なお、history.goメソッドを使用することで、指定されたページ分だけ進む(負数の場合は戻る)こともできます。

```javascript
history.go(-3); // 3ページ前に戻る
```

### pushStateメソッド

JavaScriptでページを更新した場合、そのままではページの状態を保持することはできません。例えば、ボタンをクリックしてJavaScriptでページを更新したあと、クリック前の状態に戻したいと思い、戻るボタンをクリックした場合を考えます。この場合は、期待した挙動とはならずに、そのまま1つ前のページに戻ってしまいます。  
このような場合に使用するのがpushStateメソッドです(History APIと呼ばれることもあります)。pushStateメソッドを使用すると、JavaScriptから任意のタイミングでブラウザの履歴を追加することが可能となります。  

**【注意】以下のコードは、今回の環境では動作しません。参考資料として確認してください。**  

まずは、以下のサンプルコードで具体的な動作を見ていきます。[カウントアップ]ボタンをクリックすると、ブラウザの履歴が追加されていくサンプルです。[カウントアップ]ボタンを何回か押したときにブラウザのアドレス欄が変化すること、その後、ブラウザの[戻る]ボタンを押すことでページの状態が戻っていくことを確認してください。

```html
<input id="btn" type="button" value="カウントアップ" />
<span id="result">-</span>回クリックされました
<script type="text/javascript" src="sample.js"></script>
```

```javascript
let count = 0;
const result = document.getElementById('result');

// [カウントアップ]ボタンをクリックしたときに履歴を追加
document.getElementById('btn').addEventListener('click', function() {
    result.textContent = ++count;
    history.pushState(count, null, '/aaa/bbb/count/' + count);
});

window.addEventListener('popstate', function(e) {
    count = e.state;
    result.textContent = count;
});
```

ブラウザに履歴を追加するのはhistory.pushStateメソッドの役割です。

- history.pushState(data, title [,url])
  - data: 履歴に紐付けるデータ
  - title: 識別タイトル
  - url: 履歴に紐付けるURL

引数dataには、後からその時点での状態を復元する際に必要となる情報を設定します。ここでは現在のカウント値(変数count)をセットしています。  
[戻る]ボタンで履歴をさかのぼったときの挙動は、popStateイベントリスナで補足できます。pushStateメソッドで追加したデータ(引数data)には、イベントオブジェクトeのstateプロパティでアクセスできます。ここでは、stateプロパティから得たカウント値を変数countに書き戻した上で、その値をページにも反映しています。

### navigatorオブジェクト

JavaScriptでクライアントサイド開発を進める場合には、アプリケーションがサポートするWebブラウザを意識する必要があります。アプリケーションは、サポートするブラウザすべてで同じ動作をするように実装する必要があります。近年は、ブラウザ間の動作の差異は少なくなってきていますが、同じオブジェクトであっても特定のブラウザにおいては異なった挙動をすることがあります。このような挙動に対応することを、クロスブラウザ対応(対策)といいます。  
クロスブラウザ対応には、大きく分けて以下の2手法があります。

- ブラウザの種類・バージョンに応じてコードを分岐する
- 特定の機能の有無によってコードを分岐する

これらの手法について、以下で具体的な例を見ていきましょう。

- ブラウザの種類・バージョンによるコード分岐  
    ブラウザの種類やバージョンなど、クライアントの種類を判定するための情報をユーザエージェント(UA)といいます。ユーザエージェントは、navigatorオブジェクトのuserAgentプロパティで取得できます。これを使用して、コードを分岐させます。  

    【参考】具体的な取得方法や、userAgentプロパティに含まれる文字列がブラウザごとにどのように変化するかについては、以下を確認してください。  
    [ユーザーエージェント文字列を用いたブラウザーの判定 - HTTP | MDN](https://developer.mozilla.org/ja/docs/Web/HTTP/Browser_detection_using_the_user_agent)

- 特定の機能の有無によるコード分岐  
    ブラウザごとの機能差を検出する方法として、機能テストと呼ばれる方法があります。機能テストとは、あるプロパティやメソッドを使用する前に試しに呼び出してみて、存在が確認できればその機能を実際に呼び出す、という手法です。  
    例えば、以下のサンプルコードでは、ブラウザがFileオブジェクトを提供しているか(=その戻り値がundefinedではないか)を確認し、提供されている場合だけ、Fileオブジェクトを使用した処理を実行します。FileオブジェクトはInternet Explorer 10未満では使用できないため、呼び出す前にあらかじめ使用可能かチェックしておくのが安全です。

    ```javascript
    if (window.File) {
        // Fileオブジェクトを使用した処理
    } else {
        windows.alert('File APIは使用できません')
    }
    ```

    以上で、クロスブラウザ対応について2種類の方法を紹介しました。2つの方法のうち、どちらを優先して使用すべきかですが、機能テストを優先して使用することが好ましいとされています。その理由は、userAgentプロパティによる分岐では、新たなブラウザやバージョンがリリースされた場合、そのたびに分岐条件を追加する必要があり、改修の手間が発生するためです。よって、userAgentプロパティを使用するのは、あくまで特定ブラウザやバージョンに起因するバグを回避するケースに留めるのが無難です。

## Consoleオブジェクト

現在使用されている主要なブラウザには、クライアントサイド開発の際に有用な開発者ツールが備わっています。console(Console)オブジェクトは、この開発者ツールのコンソールに対してログなどを出力するための機能を提供します。スクリプトの実行状態を確認するなどの、簡易的なデバッグ作業に有用なオブジェクトです。  
ブラウザによって挙動や表示が異なる場合もありますが、主に開発・デバッグ用途のオブジェクトのため、クロスブラウザ対応については気にすることなく、積極的に使用していくことをおすすめします。

### コンソールにログを出力する

consoleオブジェクトには、これまでに使用してきたlogメソッドの他にも、以下のメソッドが用意されています。

| メソッド   | 説明         |
| :--------- | :----------- |
| log(str)   | 一般的なログ |
| info(str)  | 一般情報     |
| warn(str)  | 警告         |
| error(str) | エラー       |

実行ログを出力するだけであればlogメソッドで十分ですが、log、info、warn、errorの各メソッドを使い分けると、以下のメリットがあります。

- メッセージにアイコンや色がつくので、ログを視認しやすくなる
- コンソール上で[Errors]、[Warnings]、[Info]、[Logs]などのボタンをオン・オフすることで、表示するログを絞り込むことができる

複雑なアプリケーションでログの個数が多い場合には、目的に応じてメソッドを使い分けることをおすすめします。  
  
log、info、warn、errorの各メソッドには、以下の構文もあります(以下ではlogメソッドの例を示しますが、他のメソッドも同様の構文です)。

- console.log(format, args...)
  - format: 書式文字列
  - args...: 書式文字列に埋め込む値

引数formatには、以下の書式指定子を埋め込むことができます。

| 書式指定子 | 説明                                                       |
| :--------- | :--------------------------------------------------------- |
| %s         | 文字列を出力                                               |
| %d、%i     | 整数値を出力(%.2dで2桁の整数を表す)                        |
| %f         | 浮動小数点を出力(%.2fで小数点以下2桁の小数点数を表す)      |
| %o、%O     | JavaScriptオブジェクトを出力(コンソール上で詳細を表示可能) |

### ログメソッドの便利な使い方

consoleオブジェクトには、ログをまとめて見やすくするメソッドや、特定の条件、形式でログを出力するためのメソッドが用意されています。用途に応じて使い分けることで、ログを使用したデバッグがより容易となります。  
以下で、主要なものを紹介します。

- ログをグループ化する  
    group、groupEndメソッドを使用することで、groupメソッドを呼び出してからgroupEndメソッドを呼び出すまでのログをグループ化できます。ログが大量に出力される場合でも、メソッド、ループなどの単位にまとめることで、ログの可読性を改善できます。group、groupEndメソッドは入れ子にすることも可能です。

  - console.group(label)
  - console.groupEnd(label)
    - label: ラベル文字列

  以下のサンプルコードは、外側のforループでログ全体をグループ化し、内側のforループでそれぞれ子グループを作成する例です。

  ```javascript
  console.group('上位グループ');
  for (let i = 0; i < 3; i++) {
    console.log('下位グループ');
    for (let j = 0; j < 3; j++) {
      console.log(i, j);
    }
    console.groupEnd();
  }
  ```

  また、groupメソッドによく似た機能を持つgroupCollapsedメソッドもあります。groupメソッドと異なる点は、出力されるロググループが折りたたまれた状態で出力される点です。ロググループが増えてきて、かつ全体を見渡したい場合には、groupCollapsedメソッドを使用すると見通しが良くなります。

- 特定のコードが何回実行されたかをカウントする  
    countメソッドを使用すると、その行が何回呼び出されたかをログに出力できます。

  - console.count([label])
    - label: ラベル文字列

  以下は、ループの内部でcountメソッドを呼び出した例です。

  ```javascript
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      console.count('LOOP');
    }
    console.count('LOOP');
  }
  ```

- 実行時のスタックトレースを出力する  
    traceメソッドを使用することで、実行時のスタックトレースを出力できます。スタックトレースとは、traceメソッドを実行する行に至るまでに経てきたメソッド(関数)の呼び出し階層を表す情報です。  
    以下のサンプルコードのように、関数1内で関数2が呼び出され、関数2内で関数3が呼び出されるといった、複数の関数が連動して動作している状況では、関数呼び出しの関係を確認しやすくなります。

  ```javascript
  function func01 () {
    func02();
  }
  function func02 () {
    func03();
  }
  function func03 () {
    console.trace();
  }

  func01();
  ```

- スクリプトの実行時間を計測する  
    time、timeEndメソッドを使用することで、timeメソッドを呼び出してからtimeEndメソッドを呼び出すまでの実行時間を計測できます。

  - console.time(label)
  - console.timeEnd(label)
    - label: ラベル文字列

  引数labelはタイマーを識別するための文字列なので、time、timeEndで対応している必要があります。タイマーは、一度に複数動作させることも可能です。  
  以下のサンプルコードは、for命令内の処理が終了するまでの時間を計測する例です。

  ```javascript
  let result = 0;
  console.time('myTimer');
  for (let i = 0; i < 10000; i++) {
    result += i;
  }
  console.timeEnd('myTimer');
  ```

- 条件式がfalseの場合にだけログ出力する  
    assertメソッドを使用することで、指定した条件式がfalseの場合にログを出力します。

  - console.assert(exp, message)
    - exp: 条件式
    - message: sログ文字列

  以下のサンプルコードでは、関数に対して不適切な値が渡された場合に、assertメソッドを使用してログを出力する例です。

  ```javascript
  function circle(radius) {
    console.assert(typeof radius === 'number' && radius > 0,
    '引数radiusが正数ではありません');
    return radius * radius * Math.PI;
  }

  circle(-5);
  ```

## Storageオブジェクト

JavaScriptでは、原則としてスクリプトからコンピュータの記憶領域に勝手に書き込むことは許されません。その例外となる手段として、Webブラウザにはクッキー(Cookie)という仕組みがあります。Webアプリケーションでは、Cookieを使用することで、クライアント上に小さなテキストを保存できます。  
もっとも、CookieはJavaScriptから操作しづらく、サイズも制限されています。そのため現在では、代替手段としてWeb Storageという仕組みが使用されます。  
ストレージとは、ブラウザ内蔵のデータストア(データの保管場所)です。データを特定するキーと、それに紐づく値の組み合わせでデータを保管することから、Key-Value型データストア(KVS)と呼ばれることもあります。

(Web Storageのデータ保管例)

| Key(キー) | Value(値) |
| :-------- | :-------- |
| name1     | John      |
| name2     | Tom       |
| name3     | Bob       |

以下に、ストレージとCookieの違いをまとめます。

| 項目               | ストレージ                                                        | Cookie                                                                            |
| :----------------- | :---------------------------------------------------------------- | :-------------------------------------------------------------------------------- |
| データサイズの上限 | 大きい(5MB)                                                       | 小さい(4KB)                                                                       |
| データの有効期限   | なし                                                              | あり                                                                              |
| データ通信         | 発生しない → 主にクライアントサイドJavaScriptで使用する情報を格納 | リクエストの都度、サーバに送信 → 主にサーバサイドのプログラムで使用する情報を格納 |

以下では、ストレージの基本的な使用方法について、サンプルコードを交えて紹介します。

### ストレージへのデータ保存、取得

まず、ストレージに対してデータを保存して、取り出してみます。

```javascript
const storage = localStorage;
storage.setItem('name1', 'John');
storage.name2 = 'Tom';
storage['name3'] = 'Bob';
console.log(storage.getItem('name1'));
console.log(storage.name2);
console.log(storage['name3']);
```

ストレージは、ローカルストレージ(Local Storage)とセッションストレージ(Session Storage)に分類され、それぞれlocalStorage、sessionStorageプロパティでアクセスできます。  
両者には、データの有効期限や有効な範囲について、以下の違いがあります。

- ローカルストレージ
  - オリジン単位でデータを管理
  - ブラウザを閉じてもデータが保持される
  - ウィンドウやタブをまたいでデータの共有が可能
- セッションストレージ
  - 現在のセッション(=ブラウザを開いている間 or セッションタイムアウトまでの間)だけで保持されるデータを管理
  - ブラウザを閉じるとデータが破棄される
  - ウィンドウやタブをまたいでデータを共有することはできない

両者は用途に応じて使い分けるべきものですが、一般的にはセッションストレージを優先的に使用します。この理由は、ローカルストレージの挙動には以下の問題があるからです。

- 明示的にデータを削除しない限り、データが消えない(=不要なデータがたまりやすい)
- 同一のオリジンで複数のアプリケーションを実行している場合、変数名が衝突しやすい

【補足】オリジン(origin)とは、「`http://localhost:8080`」のように「スキーマ名://ホスト名:ポート番号」の組み合わせで表現できる単位のことです。ストレージでは、オリジンの単位でデータを管理するので、現在のホストで保存したデータを、ほかのホストのアプリケーションから読み出すことはできません。  
  
ローカルストレージとセッションストレージは、アクセスのためのプロパティが異なるだけで、それ以降の操作方法については共通です。よって、最初にlocalStorage、sessionStorageプロパティの戻り値(Storageオブジェクト)を、変数に格納しておくことをおすすめします。これにより、後からストレージを切り替えたいという場合にも、変数に格納するプロパティの戻り値を書き換えるだけで済みます。  
サンプルコードに記述しているとおり、データの設定と取得には複数の構文があります。構文を、以下にまとめます。

| 構文               | 例                        |
| :----------------- | :------------------------ |
| プロパティ構文     | storage.キー名            |
| ブラケット構文     | storage['キー名']         |
| メソッド構文(取得) | storage.getItem('キー名') |
| メソッド構文(設定) | storage.setItem('キー名') |

一般的には、シンプルに表現できるプロパティ構文が便利です。ただし、識別子が「123」のように、識別子として使用できない名前の場合は、プロパティ構文が使用できません。このような場合や、キー名を文字列で指定したい(=入力値などに応じて変更したい)場合は、ブラケット構文を使用します。メソッド構文も同じ用途で使用できますが、記述がやや冗長になることから、どちらかといえばブラケット構文のほうが好まれるようです。

#### 開発者ツールでストレージの内容を確認

ストレージの内容は、開発者ツールから確認できます。Google Chromeであれば、[Application]タブからLocal Storage(または[Session Storage])を選択し、[IPアドレス、またはlocalhost]でストレージの内容を確認できます。個々の行からデータを挿入、編集、削除することも可能です。

![開発者ツール](../img/browser_object/devtool.png)

### 既存データの削除

ストレージから既存データを削除するためには、removeItemメソッド、またはdelete演算子を使用します。例えば、以下のサンプルコードの3行はすべて等価の処理で、キーname1を持つデータをストレージから削除します。

```javascript
storage.removeItem('name1');
delete storage.name1;
delete storage['name1'];
```

無条件にすべてのデータを削除する場合は、clearメソッドを使用します。

```javascript
storage.clear();
```

先述のとおり、ローカルストレージは明示的にデータを削除しない限り、永続的にデータを保持し続けます。そのため、ローカルストレージを使用する場合は、どのタイミングでデータを削除するかについて、あらかじめルールを決めておくべきです。

### 全データの取り出し

以下のコードで、ストレージからすべてのデータを取り出すことができます。

```javascript
const storage = localStorage;
storage.setItem('name1', 'John');
storage.name2 = 'Tom';
storage['name3'] = 'Bob';

for (let i = 0, len = storage.length; i < len; i++) {
  let key = storage.key(i);
  let value = storage[key];
  console.log(key + ':' + value);
}
```

lengthプロパティは、ストレージに格納されているデータの個数を表します。ここではforループを使用して、0~storage.length-1個目のデータをストレージから取り出しています。  
i番目のデータのキーを取得するには、keyメソッドを使用します。

- storage.key(index)
  - index: インデックス番号(スタートは0)

キー名を取得できれば、あとは前項で紹介したブラケット構文で値にアクセスできます。別の方法としては、getItemメソッドを使用しても同様にアクセスすることができます。

### オブジェクトの保存、取得

ストレージに保存できる型は、文字列が前提です。オブジェクトを保存してもエラーにはなりませんが、内部的にはtoStringメソッドで文字列化されていまうため、保存後はオブジェクトに復元することができません。  
そこで、オブジェクトをストレージに保存する場合は、あらかじめオブジェクトを復元可能な文字列に変換する必要があります。以下のサンプルコードで、具体的な方法を示します。

```javascript
const storage = localStorage;
const person = {name: 'John', age: 32};
storage.setItem('person1', JSON.stringify(person));

const data = JSON.parse(storage.getItem('person1'));
console.log(data); // {name: "John", age: 32}
```

オブジェクトを復元可能な文字列に変換するためには、JSON.stringifyメソッドを使用します。変換後の値は、以下のようにオブジェクトリテラルに似た記法で表現された文字列となるので、これをそのままストレージに保存できます。

`{"name":"John","age":32}`

データを取り出す際は、上記の文字列をJSON.parseメソッドに渡すことで、オブジェクトとして復元できます。  
  
前述のとおり、ローカルストレージでは、オリジン単位でデータを管理します。そのため、特に1つのオリジンで複数のアプリケーションが動作している場合には、名前の衝突を防ぐため、1つのアプリケーションで使用するデータはできるだけ1つのオブジェクトに格納することをおすすめします。  

(アプリケーションごとにデータを保存する例)

| Key(アプリケーション名) | Value                                               |
| :---------------------- | :-------------------------------------------------- |
| MyApp                   | {"name":"John", "age":32}                           |
| JSSample                | {"name":"Google", "url":"`https://www.google.com`"} |

### ストレージの変更監視

ストレージを使用していると、「別のウィンドウやタブで発生したストレージの変更を検知して、現在のページに反映したい」という状況が出てきます。このような場合には、storageイベントを使用します。  
以下のサンプルコードは、ストレージへの変更を監視して、変更内容をログに出力する例です。実行手順としては、HTMLファイルとJSファイルを2つずつ用意し、storageイベントリスナを使用したJavaScript(sample.js)を読み込むHTMLファイルをあらかじめ開いておきます。その後、他方のHTMLファイルを開いてローカルストレージを書き換えると変更が検知され、ログがコンソール出力されます。

(1つ目のHTMLファイル)

```html
<script type="text/javascript" src="sample.js"></script>
```

(2つ目のHTMLファイル)

```html
<script type="text/javascript" src="sample2.js"></script>
```

(sample.js)

```javascript
window.addEventListener('storage', function (e) {
  console.log('変更されたキー:' + e.key);
  console.log('変更前の値:' + e.oldValue);
  console.log('変更後の値:' + e.newValue);
  console.log('発生元ページ:' + e.url);
}, false)
```

(sample2.js)

```javascript
const storage = localStorage;
storage.setItem('person1', 'Tom');
```

storageイベントリスナでは、イベントオブジェクトeを経由して、以下の情報にアクセスできます。

| プロパティ  | 説明                                                             |
| :---------- | :--------------------------------------------------------------- |
| key         | 変更されたキー                                                   |
| oldValue    | 変更前の値                                                       |
| newValue    | 変更後の値                                                       |
| url         | 変更発生元のページ                                               |
| storageArea | 影響を受けたストレージ(localStorage、sessionStorageオブジェクト) |

ここまでのサンプルコードの実行が終了したら、ローカルストレージ内に保存したデータを削除します。先述のとおり、Google Chromeの開発者ツールには、ストレージに保存したデータを確認するほか、データを追加・変更・削除することができます。  
データを削除するためには、[Application]タブからLocal Storage(または[Session Storage])を選択し、[IPアドレス、またはlocalhost名]を選択してストレージの内容を確認し、不要なデータを右クリックしてDeleteをクリックします。
