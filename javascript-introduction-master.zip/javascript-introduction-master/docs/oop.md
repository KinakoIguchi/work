# オブジェクト指向構文

このセクションでは、JavaScript でオブジェクト指向プログラミングを実現する各種構文について解説します。セクションの前半では、ES2015 以前に使用されていた構文について説明し、後半で ES2015 から追加された構文について解説します。  
なお、オブジェクト指向自体の考え方や各種の用語については、詳しい説明を省略します。

- [オブジェクト指向構文](#オブジェクト指向構文)
  - [JavaScript におけるオブジェクトの特徴](#javascript-におけるオブジェクトの特徴)
      - [クラスではなくプロトタイプ](#クラスではなくプロトタイプ)
      - [最もシンプルなクラスを定義する](#最もシンプルなクラスを定義する)
      - [コンストラクタによる初期化](#コンストラクタによる初期化)
      - [動的にメソッドを追加する](#動的にメソッドを追加する)
      - [文脈によって中身が変化する this](#文脈によって中身が変化する-this)
      - [コンストラクタの強制的な呼び出し](#コンストラクタの強制的な呼び出し)
  - [コンストラクタの問題点とプロトタイプ](#コンストラクタの問題点とプロトタイプ)
      - [prototype プロパティ](#prototype-プロパティ)
      - [プロトタイプオブジェクトを使用することのメリット](#プロトタイプオブジェクトを使用することのメリット)
      - [プロトタイプにおけるプロパティの設定](#プロトタイプにおけるプロパティの設定)
      - [プロトタイプにおけるプロパティの削除](#プロトタイプにおけるプロパティの削除)
      - [オブジェクトリテラルでプロトタイプを定義する](#オブジェクトリテラルでプロトタイプを定義する)
      - [静的プロパティ、静的メソッドを定義する](#静的プロパティ静的メソッドを定義する)
  - [プロトタイプチェーン（オブジェクトの継承）](#プロトタイプチェーンオブジェクトの継承)
      - [プロトタイプチェーンの基礎](#プロトタイプチェーンの基礎)
      - [継承関係は動的に変更可能](#継承関係は動的に変更可能)
      - [オブジェクトの型を判定する](#オブジェクトの型を判定する)
  - [ES2015 のオブジェクト指向構文](#es2015-のオブジェクト指向構文)
      - [class 命令](#class-命令)
          - [クラスは function コンストラクタと等価ではない](#クラスは-function-コンストラクタと等価ではない)
          - [プロパティを定義する](#プロパティを定義する)
          - [静的メソッドを定義する](#静的メソッドを定義する)
          - [既存のクラスを継承する](#既存のクラスを継承する)
          - [基底クラスのメソッド・コンストラクタを呼び出す](#基底クラスのメソッドコンストラクタを呼び出す)
      - [オブジェクトリテラルの改善](#オブジェクトリテラルの改善)
          - [メソッドを定義する](#メソッドを定義する)
          - [変数を同名のプロパティに割り当てる](#変数を同名のプロパティに割り当てる)
          - [プロパティを動的に生成する](#プロパティを動的に生成する)
      - [モジュール](#モジュール)
          - [モジュールの基本](#モジュールの基本)
          - [import 命令の記法](#import-命令の記法)
      - [イテレータ](#イテレータ)
      - [ジェネレータ](#ジェネレータ)
      - [Proxy オブジェクト](#proxy-オブジェクト)

## JavaScript におけるオブジェクトの特徴

### クラスではなくプロトタイプ

ここまで見てきたとおり、JavaScript はオブジェクト指向言語としての機能を備えています。しかし、Java や C#といった他言語と比較すると、考え方が異なる点があります。それは「インスタンス・インスタンス化」という概念はあるものの、「クラス」が存在せず「プロトタイプ」という概念のみが存在する、という点です。  
プロトタイプとは、あるオブジェクトの元となるオブジェクトのことです。JavaScript では、クラスの代わりにプロトタイプを使用して、新たなオブジェクトを生成することになります。このような性質から、JavaScript のオブジェクト指向は、プロトタイプベースのオブジェクト指向と呼ばれることもあります。  
Java などのクラスベースのオブジェクト指向言語を習得された方ですと、ややイメージがつかみにくいかもしれませんが、プロトタイプとは「制限がゆるいクラスのようなもの」と考えてください。また、このドキュメントでは、プロトタイプを便宜的に「クラス」と呼ぶことがあります。

### 最もシンプルなクラスを定義する

では、具体例を見てみましょう。以下に、中身を持たない最もシンプルな「クラス」を定義した例を示します。

```javascript
let Member = function() {};
```

変数 Member に対して空の関数リテラルを代入しているだけですが、これが JavaScript におけるクラスです。  
実際、この Member クラスは、以下のように new 演算子でインスタンス化できます。

```javascript
let mem = new Member();
```

JavaScript には、厳密な意味でのクラスは存在しません。その代わり、関数(Function オブジェクト)にクラスとしての役割を与えている、と理解してください。  
なお、ES2015 環境では後述の class 命令を使用することで、より簡単にクラスを宣言できます。

### コンストラクタによる初期化

コンストラクタとは、インスタンス(オブジェクト)を生成する際に使用する、オブジェクトを初期化する処理を記述した特殊なメソッド(関数)です。  
前項で定義した Member 関数も同様に、new 演算子によって呼び出され、オブジェクトを生成するという意味では、クラスと言うよりもコンストラクタと呼ぶのがより正確です。  
コンストラクタの名前は、コンストラクタ以外の関数と区別するため、大文字で始めるのが一般的です。

では、このコンストラクタに初期化処理を記述していきます。以下の例で、Member 関数に初期化処理を追記します。

```javascript
let Member = function(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
  this.getName = function() {
    return this.firstName + ' ' + this.lastName;
  };
};

let mem = new Member('John', 'Doe');
console.log(mem.getName()); // John Doe
```

this キーワードは、コンストラクタによって生成されるインスタンス(つまり自分自身)を表すものです。this キーワードに対して変数を指定することで、インスタンスのプロパティを設定できます。  
また、プロパティには文字列や整数、日付だけではなく、関数オブジェクト(関数リテラル)も指定できます(例の this.getName)。JavaScript においては、厳密にはメソッドという概念は存在せず、**値が関数オブジェクトであるプロパティがメソッドとみなされる**のです。ここでは、getName プロパティに関数リテラルを引き渡しているため、事実上 getName メソッドを宣言したことになります。  
実際に、Member オブジェクトをインスタンス化して getName メソッドを呼び出すと、`John Doe`とコンソール出力されることが確認できます。

なお、アロー関数はコンストラクタとして振る舞うことができません。例えば、以下のコードはエラーとなります。

```javascript
let Member = () => { ...コンストラクタの中身... };
let mem = new Member();
```

### 動的にメソッドを追加する

メソッドはコンストラクタで定義することもできますが、new 演算子でいったんインスタンス化したオブジェクトに対して、あとからメソッドを追加することもできます。例えば以下の例では、インスタンス化した後に getName メソッドの定義を追記しています。

```javascript
let Member = function(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
};

let mem = new Member('John', 'Doe');
mem.getName = function() {
  return this.firstName + ' ' + this.lastName;
};

console.log(mem.getName()); // John Doe
```

ただし、インスタンスに対して直接メンバ(プロパティやメソッド)を追加した場合には、注意すべき点があります。以下の例を確認してください。

```javascript
let Member = function(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
};

let mem = new Member('John', 'Doe');
mem.getName = function() {
  return this.firstName + ' ' + this.lastName;
};

console.log(mem.getName()); // John Doe

let mem2 = new Member('Jane', 'Doe');
console.log(mem2.getName()); // TypeError: mem2.getName is not a function
```

上記のサンプルコードの、末尾の 2 行に注目してください。新たに宣言したインスタンスである mem2 から getName メソッドを呼び出したところ、エラー(getName は関数ではない)が発生します。  
つまり、インスタンス化の後に追加されたメンバは、そのインスタンスのみに追加されるということです。ゆえに、Member オブジェクトからインスタンス化した mem2 には getName というメンバは存在しないため、エラーとなります。  
Java のようなクラスベースのオブジェクト指向言語では、同一のクラスから生成したインスタンスは同一のメンバを持つことが基本です。一方、JavaScript のようにプロトタイプベースのオブジェクト指向では、**同一クラスを元に生成されたインスタンスであっても、それぞれが持つメンバは同一であるとは限りません**。ここでは、新たにメンバを追加しているだけですが、逆にインスタンスから既存のメンバを削除することもできます。

インスタンスに対して、あとからプロパティを追加・削除されたくない場合には、Object.seal メソッドを使用します。上述の例であれば、コンストラクタの末尾に以下の行を追加することで、プロパティの追加・削除を禁止することができます。

```javascript
Object.seal(this);
```

### 文脈によって中身が変化する this

前項で、this キーワードはコンストラクタによって生成されるインスタンス自身を表すと説明しました。ただし、厳密には「コンストラクタという文脈では」という条件が付きます。  
this は、スクリプトのどこからでも参照できる特別な変数です。さらに、呼び出す場所、または呼び出しの方法(文脈)によって中身が変化する、という特殊な性質を持っています。この性質により、this はバグを発生させる要因になることもあります。  
以下の表で、this キーワードが示すものを整理します。this キーワードの参照先は、以下に示す条件に応じて変化します。

| 場所                   | this の参照先                                       |
| ---------------------- | --------------------------------------------------- |
| トップレベル(関数の外) | グローバルオブジェクト                              |
| 関数                   | グローバルオブジェクト(Strict モードでは undefined) |
| call、apply メソッド   | 引数で指定されたオブジェクト                        |
| イベントリスナ         | イベントの発生元                                    |
| コンストラクタ         | 生成したインスタンス                                |
| メソッド               | 呼び出し元のメソッド(=レシーバーオブジェクト)       |

イベントリスナについては、後続のセクションで改めて説明します。ここでは、call メソッドと apply メソッドについて補足します。  
call、apply メソッドは、いずれも関数(Function オブジェクト)が提供するメンバで、その関数を呼び出します。call メソッドと apply メソッドの違いは、実行すべき関数 func に渡す引数の指定方法だけです。call メソッドは個々の値で指定するのに対して、apply メソッドは配列として渡します。

- func.call(that, [,arg1 [,arg2][,...]])
- func.apply(that [,args])
  - func: 関数オブジェクト
  - that: 関数の中で this キーワードが示すもの
  - arg1、arg2、...: 関数に渡す引数
  - args: 関数に渡す引数(配列)

引数 that を渡すことで、関数オブジェクト配下の this キーワードが指し示すオブジェクトを切り替えることができます。  
以下で、具体的な例を見ていきます。ここでは call メソッドの例を示しますが、apply メソッドの場合も同様です。

```javascript
let obj1 = { data: 'obj1 data' };
let obj2 = { data: 'obj2 data' };

function func() {
  console.log(this);
}

func.call(null); // global {DTRACE_NET_SERVER_CONNECTION: ,...
func.call(obj1); // Object {data: "obj1 data"}
func.call(obj2); // Object {data: "obj2 data"}
```

引数 that にそれぞれ異なるオブジェクトを渡すことで、func 配下の this の内容が変化していることが確認できます。なお、引数 that に null を渡した場合は、暗黙的にグローバルオブジェクトが渡されたものとみなされます。

### コンストラクタの強制的な呼び出し

JavaScript では関数がコンストラクタの役割をしますが、これには問題もあります。この問題とは、構文上はコンストラクタを関数として呼び出せてしまうことです。以下のコードでは、コンストラクタを関数として呼び出しています。

```javascript
let Member = function(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
};

let m = Member('John', 'Doe');
console.log(m); // undefined
console.log(firstName); // John
console.log(m.firstName); // エラー(TypeError: Cannot read property 'firstName' of undefined)
```

コンストラクタを直接実行した場合(new しなかった場合)、Member オブジェクトは生成されず、代わりにグローバル変数として firstName と lastName が生成されてしまいます(this がグローバルオブジェクトを示すため)。  
このような状態になることを防ぐためには、コンストラクタに以下のような処理を追加します。

```javascript
let Member = function(firstName, lastName) {
  if (!(this instanceof Member)) {
    return new Member(firstName, lastName);
  }
  this.firstName = firstName;
  this.lastName = lastName;
};
```

コンストラクタが関数として呼び出された場合、this は Member オブジェクトではなく、グローバルオブジェクトを指し示すはずです(Strict モードでは undefined)。コンストラクタでは、その性質を利用して、this が Member オブジェクトではない場合に、改めて new 演算子でコンストラクタを呼び出しています。instanceof 演算子は、オブジェクトが指定されたクラスのインスタンスであるかを判定するものです。これによって、コンストラクタの関数呼び出しを防ぐことができます。

## コンストラクタの問題点とプロトタイプ

上述のとおり、インスタンス共通のメソッドを定義するためには、少なくともコンストラクタでメソッドを定義する必要があります。ここで問題となるのが、コンストラクタによるメソッドの追加は、メソッドの数に比例して無駄なメモリを消費してしまうということです。  
コンストラクタはインスタンスを生成するたびに、それぞれのインスタンスのためにメモリを確保します。例えば、以下の Member クラスであれば、Member クラスに属する firstName プロパティと lastName プロパティ、プロトタイプ、getName メソッドを各インスタンスにコピーします。

```javascript
let Member = function(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
  this.getName = function() {
    return this.lastName + ' ' + this.firstName;
  };
};
```

しかし、getName のようなメソッド(関数リテラル)は、すべてのインスタンスで同じ内容(処理)なので、インスタンス単位でメモリを確保することは無駄です。この例では getName メソッド 1 つだけなのでさほど問題にはならないですが、これがさらに複雑なメソッドを大量に持ったクラスの場合には、無駄が大きくなる可能性があります。

### prototype プロパティ

上述の問題を解決するため、JavaScript では、オブジェクトにメンバーを追加する prototype というプロパティが存在します。prototype プロパティはデフォルトで空のオブジェクトを参照していますが、これにプロパティやメソッドを追加することができます。  
そして、この prototype プロパティに格納されたメンバは、インスタンス化された先のオブジェクトに引き継がれます。つまり、prototype プロパティに対して追加されたメンバは、そのクラス(コンストラクタ)を元に生成されたすべてのインスタンスから使用できるのです。このことを言い換えると、オブジェクトをインスタンス化した場合、インスタンスは元のオブジェクトに属する prototype に対して、暗黙的な参照を持つことになる、ということです。  
次に、具体的なコードを見ていきます。以下のコードは、先ほどの Member オブジェクトに含まれる getName メソッドを、プロトタイプとして定義したものです。

```javascript
let Member = function(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
};

Member.prototype.getName = function() {
  return this.firstName + ' ' + this.lastName;
};

let mem = new Member('John', 'Doe');
console.log(mem.getName()); // John Doe
```

以上のコードを実行すると、プロトタイプオブジェクト(prototype プロパティ)に追加された getName メソッドが、Member クラスのインスタンス(変数 mem)からも正しく参照できていることが確認できます。

JavaScript にあるのはあくまで実体化したオブジェクトだけで、新しいオブジェクトを生成するにも(クラスではなく)オブジェクトが元になっています。そして、新しいオブジェクトを作るためのひな形(プロトタイプ)を表しているのが、それぞれのオブジェクトに属するプロトタイプという特別なオブジェクトということです。

### プロトタイプオブジェクトを使用することのメリット

プロトタイプオブジェクトを定義することのメリットは、以下の 2 点です。

- メモリの使用量を削減できる  
   プロトタイプオブジェクトの内容は、あくまでインスタンスから暗黙的に参照されるだけで、各インスタンスにコピーされるわけではありません。  
   したがって、JavaScript では、オブジェクトのメンバーが呼び出されたときに、以下の流れでメンバを取得することになります。これによって、コンストラクタ経由でメソッドを定義する場合に起こる、メモリを無駄に消費してしまう問題を回避することができます。

  1. インスタンスに要求されたメンバが存在するか確認する
  2. 存在しない場合は、暗黙の参照をたどってプロトタイプオブジェクトを検索する

- メンバの追加や変更をインスタンスがリアルタイムに認識できる  
   インスタンスにメンバをコピーしないということは、プロトタイプオブジェクトの変更(追加や削除)を、インスタンス側で認識できるということでもあります。  
   以下のサンプルコードでも実際の挙動を確認します。

  ```javascript
  let Member = function(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
  };

  let mem = new Member('John', 'Doe');

  // インスタンス化した後にメソッドを追加
  Member.prototype.getName = function() {
    return this.firstName + ' ' + this.lastName;
  };

  console.log(mem.getName()); // John Doe
  ```

  以前のコードと異なる点は、getName メソッドを new 演算子によってインスタンス化した後に追加しているという点です。この場合でも、問題なくメソッドを認識できています。  
   インスタンスがオブジェクトのコピー(クラスベース)と考えていると、この挙動には違和感があるかと思います。先述の prototype による暗黙の参照の考え方(プロトタイプベース)を把握していれば、問題なく理解できると思います。

### プロトタイプにおけるプロパティの設定

プロトタイプオブジェクトに対して、プロパティを設定することを考えます。暗黙の参照という考え方からすれば、プロパティ値はすべてのインスタンスで共有されるように思えます。そうであれば、あるインスタンスでプロパティの値を変更した場合、すべてのインスタンスに対してその変更が反映されるのでしょうか。  
以下のコードで、挙動を確認します。

```javascript
let Member = function() {};
Member.prototype.job = 'teacher';

let mem1 = new Member();
let mem2 = new Member();

console.log(mem1.job, mem2.job); // teacher teacher - [1]
mem2.job = 'doctor'; // [2]
console.log(mem1.job, mem2.job); // teacher doctor - [3]
```

注目すべきは、[3]の部分です。  
[2]で、インスタンス mem2 から job プロパティを変更しているため、大本のプロトタイプオブジェクトも書き換えられて、[3]では双方ともに`doctor`となるように思えます。しかし実行結果は、インスタンス mem1 の内容はそのままで、mem2 の内容だけが書き換えられています。  
このようになる理由は、プロトタイプオブジェクトが使用されるのは、値の参照時だけであるためです。今回のような値の設定は、常にインスタンス自身に対して行われます。  
上記のコードの流れに沿って、JavaScript の挙動を詳説します。まず、[1]の時点では、インスタンス mem1、mem2 は両方とも job プロパティを持っていないので、プロトタイプオブジェクトの job プロパティを暗黙的に参照します。ところが、[2]でインスタンス mem2 の job プロパティが書き換えられたタイミングで、インスタンス mem2 自身が job プロパティを持つようになり、プロトタイプを参照する必要がなくなります。この結果、[3]ではインスタンス mem2 自身が持つ job プロパティが参照されるのです(この挙動を、インスタンス mem2 の job プロパティが、プロトタイプの job プロパティを隠蔽するといいます)。  
以上のように、プロパティをプロトタイプで定義しても、動作上はインスタンスが個別にプロパティを保有しているように見えるため、問題はありません。ただし、インスタンス単位で値が異なるはずのプロパティを、プロトタイプオブジェクトで宣言する必要はありません(読み取り専用のプロパティを除く)。通常は、以下のように使い分けます。

- プロパティの宣言 → コンストラクタで行う
- メソッドの宣言 → プロトタイプで行う

### プロトタイプにおけるプロパティの削除

前項では、プロトタイプにメンバを追加する方法について説明しました。では、メンバを削除する場合はどのようになるでしょうか。以下のコードで、実際の動作を見ていきます。

```javascript
let Member = function() {};
Member.prototype.job = 'teacher';

let mem1 = new Member();
let mem2 = new Member();

console.log(mem1.job, mem2.job); // teacher teacher
mem2.job = 'doctor';
console.log(mem1.job, mem2.job); // teacher doctor

delete mem1.job; // [1]
delete mem2.job; // [2]

console.log(mem1.job, mem2.job); // teacher teacher - [3]
```

上記のコードは、前項で使用したサンプルコードの末尾に、delete 演算子によるプロパティの削除を追加したものです。  
まず[1]で、delete 演算子はインスタンス mem1 の job プロパティを削除しようとします。しかし、インスタンス mem1 は自分自身に job プロパティを持っていないため、delete 演算子は何らの処理も行いません(プロトタイプまでさかのぼって削除しません)。その結果、[3]でインスタンス mem1 は、暗黙の参照をたどって、プロトタイプオブジェクトの job プロパティを返却します。  
一方[2]では、インスタンス mem2 の job プロパティを delete 演算子で削除します。結果として、[3]でインスタンス mem2 は job プロパティを持たなくなったため、mem1 と同様にプロトタイプオブジェクトの job プロパティを返却するようになります。  
上記の挙動をまとめると、**インスタンスに対するメンバの追加や削除といった操作が、プロトタイプオブジェクトにまで影響を及ぼすことはない**、ということです。

### オブジェクトリテラルでプロトタイプを定義する

ここまでの例では、ドット演算子(.)を使用してプロトタイプにメンバを追加してきました。しかし、メンバが多くなってきた場合、コードが冗長になってしまうため、この書き方は好ましくありません。  
細かいことではありますが、毎回「Member.prototype~」という記述を繰り返すのは面倒ですし、そもそもオブジェクト名(Member)が変更になった場合に、すべての定義箇所を書き換えるのは手間です。また、個々のメンバー定義が独立したブロックで記述されていることから、どこからどこまでが同じオブジェクトのメンバ定義なのか、一見して理解しづらいという問題もあります。  
ここで使用するのが、オブジェクトのリテラル表現です。まず、リテラル表現を使用しないコードを以下に示します。

```javascript
let Member = function(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
};

Member.prototype.getName = function() {
  return this.lastName + ' ' + this.firstName;
};

Member.prototype.toString = function() {
  return this.lastName + this.firstName;
};
```

同じような表現が何度も出てきていて、やや冗長です。そこで、以下のコードのようにリテラル表現を使用して書き換えると、重複する表現がなくなって可読性が高くなります。

```javascript
let Member = function(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
};

Member.prototype = {
  getName: function() {
    return this.lastName + ' ' + this.firstName;
  },
  toString: function() {
    return this.lastName + this.firstName;
  }
};
```

以上のように、オブジェクトリテラルを使用することで、

- Member.prototype~の記述は最小限で済む
- オブジェクト名に変更があった場合にも、影響箇所を限定できる
- 同一オブジェクトのメンバ定義が 1 つのブロックに収まっているため、コードの可読性が向上する

といったメリットがあります。よって、プロトタイプを定義する場合は、通常はこのようなリテラル表現を使用することを推奨します。

### 静的プロパティ、静的メソッドを定義する

静的プロパティ、静的メソッドとは、インスタンスを生成しなくてもオブジェクトから直接呼び出すことのできるプロパティやメソッドのことです。  
このような**静的プロパティ、静的メソッドを定義する場合、プロトタイプオブジェクトには登録できない**ので、注意してください。静的プロパティ、静的メソッドは、以下のようにコンストラクタに直接追加します。

```javascript
オブジェクト名.プロパティ名 = 値;
オブジェクト名.メソッド名 = function() {
  メソッドの定義;
};
```

具体的な例で確認します。以下は、基本図形の面積を求める機能をまとめたユーティリティクラスである Area クラスを定義した例です。Area クラスには、クラスのバージョン番号を示す静的プロパティ version をはじめ、三角形、ひし形の面積を求める静的メソッド triangle、dianond が含まれるものとします。

```javascript
let Area = function() {};

Area.version = 1.0;

Area.triangle = function(base, height) {
  return (base * height) / 2;
};

Area.diamond = function(width, height) {
  return (width * height) / 2;
};

console.log('Areaクラスのバージョン=' + Area.version); // Areaクラスのバージョン=1
console.log('三角形の面積=' + Area.triangle(5, 3)); // 三角形の面積=7.5

let a = new Area();
console.log('ひし形の面積=' + a.diamond(7, 5)); // TypeError: a.diamond is not a function
```

以上のコードで、オブジェクトから静的プロパティ、静的メソッドを直接呼び出せることが確認できます。また、インスタンス経由で静的メソッドを呼び出そうとすると「a.diamond is not a function(a.diamond は関数ではありません)」というエラーが発生します。この原因は、静的メンバはあくまで Area という関数オブジェクトに動的に追加されたメンバであって、Area が生成するインスタンスに追加されるわけではないからです。

静的プロパティ、静的メンバを追加する場合、以下の点にも注意してください。

- 静的プロパティは、基本的に読み取り専用の用途で使用する  
   静的プロパティは、インスタンスプロパティとは異なり、クラス単位で保有される情報です。つまり、その内容を変更した場合、スクリプト内のすべての変更が反映されてしまいます。原則として、静的プロパティで定義する値は、読み取り専用の用途に限定すべきです。
- 静的メソッドの中では、this キーワードは使用できない  
   インスタンスメソッドの中での this キーワードは、インスタンス自身を表します。  
   一方、静的メソッドの中での this キーワードは、コンストラクタ(関数オブジェクト)を表します。インスタンスではないので当然ですが、静的メソッドからインスタンスプロパティの値にアクセスすることはできないので注意してください。

## プロトタイプチェーン（オブジェクトの継承）

オブジェクト指向言語を理解する上で、重要な概念の 1 つが継承です。継承とは、元になるオブジェクト(クラス)の機能を引き継いで、新しいクラスを定義する機能です。  
クラスを継承することで、共通した機能を複数のクラスで重複して定義する必要がなくなり、元となるクラスからの差分を記述するだけで済むようになります(これを差分プログラミングと言います)。
継承において、継承元となるクラスのことをスーパークラスまたは基底クラス、継承によってできたクラスをサブクラスまたは派生クラスと言います。

### プロトタイプチェーンの基礎

継承の仕組みを JavaScript で実現しているのが、プロトタイプチェーンという考え方です。まずは、以下のサンプルコードを見てください。

```javascript
let Member = function(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
};
Member.prototype = {
  getName: function() {
    return this.firstName + ' ' + this.lastName;
  }
};

let BussinessMember = function(firstName, lastName, job) {
  Member.call(this, firstName, lastName); // [2]
  this.job = job;
};
BussinessMember.prototype = new Member(); // [1]
BussinessMember.prototype.getJob = function() {
  return this.job;
};

let bm = new BussinessMember('John', 'Doe', 'teacher');
console.log(bm.getName()); // John Doe
console.log(bm.getJob()); // teacher
```

注目すべき点は[1]です。ここでは、BussinessMember オブジェクトのプロトタイプ(BusinessMember.prototype)として、Member オブジェクトのインスタンスをセットしています。これによって、BusinessMember オブジェクトのインスタンスから、Member オブジェクトで定義された getName メソッドを呼び出せるようになります。  
この挙動は、前項で説明したプロトタイプの暗黙の参照と同様です。なお、具体的なメソッド呼び出しの流れは以下のとおりです。

1. BusinessMember オブジェクトのインスタンス bm からメンバの有無を検索する
2. 該当するメンバが存在しない場合は、BusinessMember オブジェクトのプロトタイプである Member オブジェクトのインスタンスを検索する
3. そこにも目的のメンバが存在しない場合は、さらに Member オブジェクトのプロトタイプを検索する

この例では、Member オブジェクトで getName メソッドが見つかるので、検索はそこで終了します。もし見つからなかった場合には、さらに上位のプロトタイプ(具体的には最上位の Object.prototype まで)をたどっていくことになります。  
このように、JavaScript ではプロトタイプにインスタンスを設定することで、インスタンス同士を暗黙の参照で連結し、互いに継承関係をもたせています。このようなプロトタイプの連なりを**プロトタイプチェーン**と呼びます。

プロトタイプチェーンの終端は、必ず Object.prototype です。これは、すべてのオブジェクトのルートが Object オブジェクトであり、明示的にプロトタイプを指定しなくても、暗黙的に Object オブジェクトを継承しているためです。

サンプルコードの[2]は、Member コンストラクタを現在の this と仮引数の firstName、lastName で呼び出すという意味です。基底クラスでプロパティの定義といった初期化処理を実行している場合は、例のようにまず基底クラスのコンストラクタを実行したあとに、派生クラス(BusinessMember)の初期化処理を実施します。

### 継承関係は動的に変更可能

以上で見てきたように、プロトタイプチェーンは、JavaScript で継承機能を実現するための仕組みですが、Java や C#のオブジェクト指向プログラミングにおける継承とは異なる点もあります。それは、Java や C#における継承は静的なものですが(いったん決定した継承関係は途中から変更できない)、JavaScript における継承は動的であるということです。つまり、同一のオブジェクトが、あるタイミングではオブジェクト X を継承し、別のタイミングではオブジェクト Y を継承しているということが起こり得ます。  
以下の例で、JavaScript における動的な継承について、挙動を確認します。

```javascript
let Member = function() {};
Member.prototype = {
  getProfile: function() {
    return 'Memberオブジェクトのメソッド';
  }
};

let BussinessMember = function() {};
BussinessMember.prototype = {
  getProfile: function() {
    return 'BusinessMemberオブジェクトのメソッド';
  }
};

let InheritanceMember = function() {};
InheritanceMember.prototype = new Member(); // Memberオブジェクトを継承

let m1 = new InheritanceMember(); // [1]
console.log(m1.getProfile()); // Memberオブジェクトのメソッド - [3]

InheritanceMember.prototype = new BussinessMember(); // BusinessMemberオブジェクトを継承

let m2 = new InheritanceMember(); // [2]
console.log(m2.getProfile()); // BusinessMemberオブジェクトのメソッド - [4]
console.log(m1.getProfile()); // Memberオブジェクトのメソッド - [5]
```

[1]では、InheritanceMember.prototype に Member インスタンスをセットした状態で、インスタンス m1 を生成しています。また、[2]では、InheritanceMember.prototype に BusinessMember インスタンスをセットした状態で、インスタンス m2 を生成しています。この結果、[3]と[4]では、Member オブジェクトと BusinessMember オブジェクト(正確にはそのプロトタイプ)で定義された getProfile メソッドが実行されることが確認できます。  
以上の挙動は、ここまでに解説してきた内容のとおりになっています。  
しかし、最終行の[5]の挙動は、これまでになかったケースです。インスタンス m1 を生成した時点では、InheritanceMember のプロトタイプは Member オブジェクトです。しかし、[5]の時点では、すでに BusinessMember オブジェクトに差し替えられています。  
暗黙の参照がリアルタイムに変更されることを考えると、[5]では BusinessMember オブジェクトの getProfile メソッドが呼び出されることが予想されます。しかし、結果としては Member オブジェクトの getProfile メソッドが呼び出されます。  
以上のことから、**JavaScript のプロトタイプチェーンはインスタンスが生成された時点で固定され、その後の変更にかかわらず保存される**ことがわかります。JavaScript は動的な性質を持っていることは確かですが、この場合は例外的に静的な挙動となるため、注意してください。

### オブジェクトの型を判定する

これまでも説明してきたとおり、JavaScript には厳密な意味でのクラスという概念は存在しません。あるオブジェクトを元に生成したインスタンスが、必ずしも同じメンバを持つとは限らないのが JavaScript のルールです。  
したがって、クラスベースのオブジェクト指向でいうところの型という概念も、厳密には存在しません。しかし、それでも以下で説明する機能を使用することで、ゆるく型を判定できます。  
ここでは、スクリプト上で扱っている型を判定する 4 つの方法について解説します。

- constructor プロパティ  
   constructor プロパティを使用することで、オブジェクトの元になったコンストラクタ(関数オブジェクト)を取得できます。

  ```javascript
  let Member = function() {};
  let BusinessMember = function() {};
  BusinessMember.prototype = new Member();

  let m = new Member();
  let bm = new BusinessMember();
  console.log(m.constructor === Member); // true
  console.log(bm.constructor === Member); // true
  console.log(bm.constructor === BusinessMember); // false
  ```

  ただし、プロトタイプ継承している場合、constructor プロパティが示すものは、継承元のクラス(ここでは Member クラス)となります。BusinessMember クラスのインスタンスであるかどうかを判定するためには、以下の instanceof 演算子を使用してください。

- instanceof 演算子  
   constructor プロパティがオブジェクトに対応するコンストラクタを返却するのに対して、instanceof 演算子は以下のように「オブジェクト instanceof コンストラクタ」の形式で、オブジェクトが特定のコンストラクタにょって生成されたインスタンスであるかどうかを判定します。

  ```javascript
  console.log(bm instanceof Member); // true
  console.log(bm instanceof BusinessMember); // true
  ```

  instanceof 演算子では、本来のコンストラクタ(BusinessMember)はもちろん、プロトタイプチェーンをさかのぼっての判定(この場合は Member)も可能です。

- isPrototypeOf  
   isPrototypeOf メソッドは、instanceOf 演算子とも似ていますが、こちらはオブジェクトが参照しているプロトタイプを確認するために使用します。

  ```javascript
  console.log(BusinessMember.prototype.isPrototypeOf(bm)); // true
  console.log(Member.prototype.isPrototypeOf(bm)); // true
  ```

- in 演算子  
   JavaScript では、同じクラスを元にしたインスタンスが、必ずしも同じメンバを持つとは限りません。なぜなら、これまで見てきたとおり、インスタンスに動的にメンバが追加される場合もあるためです。  
   そこで、ある時点で特定のメンバが使用できるかチェックする場合には、in 演算子を使用すると便利です。型そのものよりも、特定のメンバの有無に関心がある場合には、in 演算子を使用すべきです。

  ```javascript
  let obj = { foo: function() {}, bar: function() {} };

  console.log('foo' in obj); // true
  console.log('baz' in obj); // false
  ```

## ES2015 のオブジェクト指向構文

ES2015 では、オブジェクト指向構文が大幅に変更されました。旧来の構文も使用することはできますが、class 命令の導入によって、これまで JavaScript 独特であったクラス定義が、より記述しやすくなっています。Java や C#などのオブジェクト指向言語を学んだことがある方であれば、ES2015 以降のオブジェクト指向構文は理解しやすいと思います。

### class 命令

まずは、class 命令を使用して Member クラスを定義するサンプルコードを、以下に示します。Member クラスは、firstName と lastName をプロパティとして、また getName をメソッドとして持ちます。  
なお、今回の環境で上記のコードを書いた場合、class 内のコードの下に赤い波線が表示されます。これは、class とその配下のメソッドに、JSDoc(クラスやメソッドの説明を記述するためのコメント)がないことを ESLint が指摘するためです。実案件で作成するコードには JSDoc を記述すべきですが、今回は割愛します。

```javascript
class Member {
  // コンストラクタの定義
  constructor(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
  }

  // メソッドの定義
  getName() {
    return this.firstName + ' ' + this.lastName;
  }
}

let m = new Member('John', 'Doe');
console.log(m.getName()); // John Doe
```

class 命令の構文は、以下のとおりです。

```javascript
class クラス名 {
    ...コンストラクタの定義...
    ...プロパティの定義...
    ...メソッドの定義...
}
```

サンプルコードでは、まずコンストラクタとメソッドを定義しています。コンストラクタとメソッドは、ともに同じ構文で定義します。

```javascript
メソッド名(引数, ...) {
    ...メソッドの本体...
}
```

ただし、コンストラクタの名前(メソッド名)は constructor で固定です。コンストラクタ配下で this.プロパティ=値の形式でプロパティを設定する記述は、これまで定義してきたクラスと同様です。  
なお、Java や C#のように、コンストラクタやメソッドの定義に際して、public や private などのアクセス修飾子は使用できません。JavaScript のクラスは、すべてのメンバが public(どこからでもアクセスできる)となります。

また、class 命令を使用すると、匿名クラスを作成することもできます。class {...}の形式で定義されたクラスリテラルは、関数リテラルと同様に式の中で使用できます。例えば、上記のサンプルコードを匿名クラスとして定義する場合、以下のように記述します。

```javascript
const Member = class { ... };
```

#### クラスは function コンストラクタと等価ではない

class 命令で定義されたクラスは、内部的には関数です。つまり、JavaScript にクラスの概念が導入されたわけではなく、あくまでこれまで Function オブジェクトで表現していたクラス(コンストラクタ)を、よりわかりやすく表現できるようになったということです。言い換えると、class 命令は、プロトタイプベースのオブジェクト指向構文を扱いやすくする糖衣構文(シンタックスシュガー)です。  
ただし、class 命令で定義されたクラスは、Function オブジェクトと完全に等価ではありません。以下の点に注意してください。

- 関数としての呼び出しはできない  
   例えば、class 命令で定義された Member クラスを、以下のコードで呼び出すことはできません。

  ```javascript
  let m = Member('John', 'Doe'); // new演算子なしで呼び出そうとしている
  // TypeError: Class constructor Member cannot be invoked without 'new'
  ```

  function 命令によるコンストラクタでは、このような new なしでのコンストラクタ呼び出しを防ぐため、[コンストラクタに前述の判定](oop.md#コンストラクタの強制的な呼び出し)を記述する必要がありました。class 命令で作成したクラスのコンストラクタを呼び出した場合はエラーとなるため、コンストラクタに判定処理を記述する必要がありません。

- 定義前のクラスを呼び出すことはできない  
   function 命令で定義した場合と異なり、以下のコードは実行できません。

  ```javaScript
  let m = new Member('John', 'Doe');
  class Member { ... }
  ```

  一方、function 命令は静的な構造のため、定義前のクラスも呼び出すことができます(ただし、アロー関数などの関数リテラルによる宣言では呼び出しできません)。

#### プロパティを定義する

ここまでのサンプルコードでは、コンストラクタの中で`this.プロパティ名 = 値`の形式でプロパティを設定していました。class ブロックでは、コンストラクタで設定する以外にも、get・set 構文を使用してプロパティを定義することもできます。

```javascript
class Member {
  // コンストラクタの定義
  constructor(firstName, lastName) {
    this._firstName = firstName;
    this.lastName = lastName;
  }

  // getter
  get firstName() {
    return this._firstName;
  }

  // setter
  set firstName(firstName) {
    this._firstName = firstName;
  }

  // メソッドの定義
  getName() {
    return this.firstName + ' ' + this.lastName;
  }
}

let m = new Member('John', 'Doe');
console.log(m.getName()); // John Doe

m.firstName = 'Jane';
console.log(m.getName()); // Jane Doe
```

get、set 構文は、アクセサーメソッド(Accessor Method)と呼ばれるメソッドを実装するための構文です。Java などの言語におけるアクセサーメソッドは、get+変数名、set+変数名という名前で定義することが一般的ですが、JavaScript では以下の構文で定義します。

```javascript
get プロパティ名 {
    ...値を取得するコード...
}
set プロパティ名 {
    ...値を設定するためのコード
}
```

この get、set 構文でアクセサーメソッドを定義すると、プロパティ名に指定した変数に対してアクセスがあった場合、これらのメソッドが自動的に呼び出されます。サンプルコードでは、getName()メソッド内の`return this.firstName + ' ' + this.lastName;`で firstName を参照しているので get firstName()メソッドが呼び出されます。また、サンプルコード末尾から 2 行目の`m.firstName = 'Jane';`では、Member インスタンスの firstName の値を更新しています。そのため、ここで set firstName(firstName)メソッドが呼び出されます。  
ところで、get、set 構文で定義したアクセサーメソッドの内部では、いずれも\_firstName というプロパティに対して値の参照・更新をしています。仮に set メソッドを`this.firstName = firstName`とした場合、ここで firstName の値を更新しているため、自分自身(set firstName(firstName)メソッド)が呼び出されてしまいます。さらに、この内部でも同様に自分自身が呼び出されるため、終了条件のない再帰処理となってしまい、プログラムは正しく動作しません(無限ループとなって停止します)。そのため、set メソッドの内部では、メソッド名と同名の変数に対する値の更新はしないで、別の変数に対して更新をするように処理を記述する必要があります。  
アクセサーメソッド自体は、Member インスタンスに対して`m.firstName`、あるいは Member クラス内で`this.firstname`の形で使用しますが、実際に参照・更新しているプロパティは firstName ではなく\_firstName です。firstName 自体にアクセスしているように見えますが、実際には異なりますので注意してください。  
なお、JavaScript では、プライベートプロパティには慣習的にプロパティ名に「\_」(アンダースコア)を付けます。先述のとおり、JavaScript には public や private といったアクセス修飾子は存在しません。そのため、プロパティ名に「\_」を付けたとしても、プロパティはすべて public です。とはいえ、外部からのアクセスをコントロールしたいということもあるので、private という実装の意図がわかるように、プロパティ名に「\_」を付けることが慣習となりました。「\_」は、プロパティ名の前か後に付けますが、このドキュメントでは前に「\_」を付けることにします。

#### 静的メソッドを定義する

static キーワードをメソッド定義の先頭の付与することで、静的メソッドを定義することができます。以下のサンプルコードは、Area クラスに静的メソッド getTriangle を定義した例です。

```javascript
class Area {
  static getTriangle(base, height) {
    return (base * height) / 2;
  }
}

console.log(Area.getTriangle(5, 3)); // 7.5
```

#### 既存のクラスを継承する

extends キーワードを使用すると、既存のクラスを継承したサブクラスを定義できます。

```javascript
class Member {
  // コンストラクタの定義
  constructor(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
  }

  // メソッドの定義
  getName() {
    return this.firstName + ' ' + this.lastName;
  }
}

class BusinessMember extends Member {
  work() {
    return this.getName() + 'は働いています';
  }
}

let bm = new BusinessMember('John', 'Doe');
console.log(bm.getName()); // John Doe
console.log(bm.work()); // John Doeは働いています
```

BusinessMember クラスで定義された work メソッドはもちろんのこと、Member クラスで定義されたコンストラクタや getName メソッドが、BusinessMember クラスのメンバとして呼び出せていることが確認できます。

#### 基底クラスのメソッド・コンストラクタを呼び出す

基底クラス(継承したクラス)で定義されたメソッドやコンストラクタは、サブクラスで上書きすることもできます。これをオーバーライドと呼びます。  
以下のサンプルコードは、Member クラスで定義されたコンストラクタと getName メソッドを、BusinessMember クラスでオーバーライド(上書き)する例です。

```javascript
class Member {
  // コンストラクタの定義
  constructor(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
  }

  // メソッドの定義
  getName() {
    return this.firstName + ' ' + this.lastName;
  }
}

class BusinessMember extends Member {
  constructor(firstName, lastName, job) {
    super(firstName, lastName);
    this.job = job;
  }

  getName() {
    return super.getName() + ' job:' + this.job;
  }
}

let bm = new BusinessMember('John', 'Doe', 'teacher');
console.log(bm.getName()); // John Doe job: teacher
```

オーバーライドの用途は、基底クラスの機能をすべて書き換えることだけではありません。基底クラスの処理を引き継ぎつつ、派生クラスでは差分の処理だけを追加する場合もあります。  
そのような場合には、super キーワードで基底クラスのメソッドやコンストラクタを参照します。サンプルコードでは、コンストラクタで firstName と lastName のプロパティを、getName メソッドであれば表示する文字列の一部を、それぞれ基底クラスの処理に委ねています。  
super キーワードの構文は、以下のとおりです。

- super(args,...) : コンストラクタの場合
- super.method(args,...) : メソッドの場合
  - method: メソッド名
  - args,...: 引数

ただし、コンストラクタで super キーワードを呼び出す位置は、先頭の文でなければならない点に注意してください。よって、以下のコンストラクタは不可です。

```javascript
  constructor(firstName, lastName, job) {
    this.job = job;
    super(firstName, lastName); // 先頭の文で呼び出していない
  }
```

### オブジェクトリテラルの改善

ES2015 ではオブジェクトリテラルの構文も改善し、プロパティやメソッドの定義をよりシンプルに記述できるようになりました。

#### メソッドを定義する

ES2015 以前は、メソッドはあくまで関数型のプロパティとして定義する必要がありました。メソッドを直接的に表現する方法がなかったのです。

```javascript
メソッド名: function(args,...){ ...メソッド本体の処理... }
```

ES2015 からは、class ブロックの構文に合わせて、以下の表記が可能となりました。この表記は他のプログラミング言語のメソッド定義と類似するもので、シンプルかつ理解しやすいものです。

```javascript
メソッド名(args,...) {...}
```

以下に、使用例を示します。

```javascript
let member = {
  name: 'John',
  job: 'teacher',
  toString() {
    return 'name: ' + this.name + ' job: ' + this.job;
  }
};

console.log(member.toString()); // name: John job: teacher
```

#### 変数を同名のプロパティに割り当てる

プロパティの名前と、その値を表した変数名が同一の場合は、値の指定を省略できます。

```javascript
let name = 'John';
let job = 'teacher';

let member = {
  name,
  job
};

console.log(member); // Object {name: "John", job: "teacher"}
```

ES2015 以前の構文では、以下のように記述する必要がありました。ES2015 では、記述がシンプルになったことがわかると思います。

```javascript
let member = {
  name: name,
  job: job
};
```

#### プロパティを動的に生成する

プロパティ名をブラケットで囲むことで、式の値から動的にプロパティ名を生成できます。これを Computed property names といいます。以下のサンプルコードでは、変数 i を順に加算していくことで、memo1、memo2...といったプロパティ名を生成しています。

```javascript
let i = 0;
let member = {
  name: 'John',
  job: 'teacher',
  ['memo' + ++i]: 'football',
  ['memo' + ++i]: 'joe'
};

console.log(member); // Object {name: "John", job: "teacher", memo1: "football", memo2: "joe"}
```

### モジュール

**【注意】以下に示すモジュール機能は、Node.js 環境では動作しません(一部のブラウザ環境で動作)。参考資料として確認してください。**

アプリケーションの規模が大きくなるほど、機能単位に分割・整理するモジュール機能は欠かせなくなっていきます。ES2015 以前の JavaScript では、モジュール機能を言語としてサポートしていませんでした。ES2015 から言語としてモジュール機能がサポートされるようになり、大規模なアプリケーション開発や、ライブラリの公開といった用途でよく使われる機能になっています。

#### モジュールの基本

まずは、基本的なモジュールの例を見ていきます。以下は、定数 AUTHOR や Member クラス、Area クラスをモジュールとしてまとめたものです。

```javascript
const AUTHOR = 'John Doe';

export class Member { ... }
export class Area { ... }
```

モジュールは 1 つのファイルとして定義するのが基本です。例えば、上記のコードを Util.js という 1 ファイルにまとめるということです。  
モジュールとして外部からアクセスできるメンバには、export キーワードを付与します。ここでは Member クラスと Area クラスに export キーワードを付与していますが、変数、定数、関数なども同様に付与できます。  
モジュール内のメンバはデフォルトで非公開です。ここでは、定数 AUTHOR には export が指定されていないので、モジュールの外部から参照できません。この点は、プロパティがデフォルトでパブリックなオブジェクトとはルールが異なるため、注意してください。  
定義したモジュールには、以下の方法でアクセスできます。

```javascript
import { Member, Area } from './dir/Util';

let m = new Member('John', 'Doe');
console.log(m.getName()); // John Doe
```

別ファイルで定義されたモジュールをインポートするのは、import 命令の役割です。

- import {name, ...} from module
  - name: インポートする要素
  - module: モジュール(拡張子を抜いたパス)

これで、モジュール配下の Member、Area クラスにアクセスできるようになります。  
モジュール側で明示的に export 宣言をしていても、使用する側でインポートされなかったものにはアクセスできません。例えば、import 命令を以下のようにした場合、Area クラスにはアクセスできません。

```javascript
import { Member } from './dir/Util';
```

#### import 命令の記法

import 命令には、目的に応じて様々な書き方があります。以下に代表的なものをまとめます。

- モジュール全体をまとめてインポート  
   アスタリスク(\*)でモジュール内のすべての要素をインポートできます。この場合、as 句でモジュールの別名を指定する必要があります。

  ```javascript
  import * as util from './dir/Util';

  let m = new util.Member('John', 'Doe');
  console.log(m.getName()); // John Doe
  ```

  これで、Util モジュールのすべてのエクスポートを util.~の形式で参照できるようになります。

- モジュール内の個々の要素に別名を付与する  
   モジュール内の個々の要素に対して、別名を付与することもできます。

  ```javascript
  import { Member as Me, Area as Ar } from './dir/Util';

  let m = new Me('John', 'Doe');
  console.log(m.getName()); // John Doe
  console.log(Ar.getArea(5, 3)); // 7.5
  ```

- デフォルトのエクスポートをインポートする  
   モジュールに含まれる要素が 1 つだけであれば、デフォルトのエクスポートを宣言することができます。これには、以下のように default キーワードを付与してください。デフォルトエクスポートでは、クラスや関数などの名前は不要です。

  ```javascript
  export default class {
    static getTriangle(base, height) {
      return (base * height) / 2;
    }
  }
  ```

  これをインポートするには、以下のように import 命令を記述します。これで Util モジュールのデフォルトエクスポートに対して、Area という名前でアクセスできるようになります。

  ```javascript
  import Area from './dir/Util';
  console.log(Area.getTriangle(5, 3)); // 7.5
  ```

### イテレータ

イテレータとは、オブジェクトの内容を列挙するための仕組みを備えたオブジェクトです。例えば、Array、String、Map、Set などの組み込みオブジェクトは、いずれもデフォルトでイテレータを備えているので、for...of 命令で配下の要素を列挙できます。  
開発者による実装において、イテレータが必要となる場面はそう多くないため、ここでは説明を省略します。ここでは、列挙可能なオブジェクトには、イテレータが実装されていることを理解してください。

【参考】[イテレーターとジェネレーター - JavaScript | MDN](https://developer.mozilla.org/ja/docs/Web/JavaScript/Guide/Iterators_and_Generators)

### ジェネレータ

列挙可能なオブジェクトは、イテレータを実装するだけではなく、ジェネレータを使用することで、より簡単に実装することができます。以下に、ジェネレータを使用した簡単なサンプルコードを示します。

```javascript
function* myGenerator() {
  yield 1;
  yield 2;
  yield 3;
}

for (const ret of myGenerator()) {
  console.log(ret);
}

/*
1
2
3
*/
```

ジェネレータは、通常の関数とほぼ同じように実装しますが、以下の 2 点が異なります。

- `function* {...}`で定義する(function の後に「`*`」)
- yield 命令で値を返却する

yield は、return とよく似た命令で、呼び出し元に値を返却します。しかし、return 命令がその文で関数を終了するのに対して、yield 命令は処理を一時停止するだけです。つまり、次に呼び出されたときには、前回の呼び出しで値を返却した yield 命令の次の文から処理を再開します。 よって、サンプルコードで定義した myGenerator を for...of 命令に渡すことで、ループのたびに yield 命令によって値が返却されます。  
ジェネレータの使い所としては、何らかのルールに従って値を生成するような処理などが挙げられます。例えば、素数を生成する処理であれば、素数を発見した時点で yield 命令で素数を返却し、次回に呼び出されたときには、前回返却した素数に+1 した値から素数の検索をスタートする、という処理になります。

### Proxy オブジェクト

Proxy オブジェクトは、例えばプロパティの設定・取得・削除、for...of、for...in 命令といったオブジェクトの基本動作を、アプリケーション独自の動作に差し替えるために使用します。  
Proxy オブジェクトを使用することで、例えば「オブジェクトを操作したタイミングでログを出力する」、「プロパティの取得時に値検証(バリデーション)を行う」といった処理を、既存のオブジェクトに手を加えずに実装できます。  
以下に、具体例を示します。以下のサンプルコードは、存在しないプロパティにアクセスした場合に、デフォルト値として「?」を返却する例です。

```javascript
let data = { red: '赤', blue: '青' };
let proxy = new Proxy(data, {
  get(target, prop) {
    return prop in target ? target[prop] : '?';
  }
});

console.log(proxy.red); // 赤
console.log(proxy.yellow); // ?
```

Proxy コンストラクタの構文は、以下のとおりです。

- new Proxy(target, handler)
  - target: 操作を差し替える対象となるオブジェクト(ターゲット)
  - handler: ターゲットの操作を定義するためのオブジェクト(ハンドラー)

Proxy オブジェクトの世界では、操作を差し替える対象のオブジェクトをターゲット、ターゲットに対する操作を表すオブジェクトをハンドラーといいます。  
ハンドラーで定義できるメソッドは、以下のとおりです。ハンドラーメソッドのことをトラップともいいます。

| メソッド(トラップ)                | 戻り値             | ターゲットに対する操作                |
| --------------------------------- | ------------------ | ------------------------------------- |
| getPrototypeOf(target)            | オブジェクト、null | プロトタイプの取得                    |
| setPrototypeOf(target, prototype) | -                  | プロトタイプの設定                    |
| get(target, prop, receiver)       | 任意の型           | プロパティの取得(receiver はプロキシ) |
| set(target, prop, val, receiver)  | boolean            | プロパティの設定                      |
| has(target, prop)                 | boolean            | in 演算子によるメンバの存在確認       |
| deleteProperty(target, prop)      | boolean            | delete 命令によるプロパティの削除     |
| construct(target, args)           | オブジェクト       | new 演算子によるインスタンス化        |
| apply(target, thisArg, args)      | 任意の型           | apply メソッドによる関数呼び出し      |

なお、Proxy に対する操作は、ターゲットのオブジェクトにもそのまま反映されます。以下に、追加分のコードを示します。

```javascript
proxy.red = 'レッド';
console.log(data.red); // レッド
console.log(proxy.red); // レッド
```
