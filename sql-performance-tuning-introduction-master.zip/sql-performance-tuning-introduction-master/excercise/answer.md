# 演習の解説

演習の解答例です。

---

- [演習の解説](#演習の解説)
  - [実行計画と統計情報](#実行計画と統計情報)
  - [結合](#結合)
    - [意図しないクロス結合](#意図しないクロス結合)
    - [内部結合と外部結合のパフォーマンス差](#内部結合と外部結合のパフォーマンス差)
    - [WHERE句の絞り込みタイミング](#where句の絞り込みタイミング)
    - [結合条件列に対するインデックス](#結合条件列に対するインデックス)
      - [Sort Mergeの場合](#sort-mergeの場合)
      - [Hash Joinの場合](#hash-joinの場合)
  - [サブクエリ](#サブクエリ)
    - [サブクエリの書き換え](#サブクエリの書き換え)
      - [INの書き換え](#inの書き換え)
      - [外部結合への書き換え](#外部結合への書き換え)
    - [サブクエリによるパフォーマンス改善](#サブクエリによるパフォーマンス改善)
  - [更新系SQLのチューニング](#更新系sqlのチューニング)
    - [INSERT](#insert)
    - [DELETE](#delete)

## [実行計画と統計情報](../documents/analyze_sql.md)

[テキスト内に解説と演習用のSQLがあります](../documents/analyze_sql.md)ので、こちらを確認・実行してください。

## [結合](../documents/join.md)

### 意図しないクロス結合

SQLに結合条件を書き忘れると、意図しないクロス結合が発生します。クロス結合は多くの場合で取得レコード数が膨大になるうえ、通常は用途がない結合方法です。そのため、クロス結合は使用しないことが望ましいです。  
**意図しないクロス結合の発生を防ぐためには、JOIN句を使用しない結合構文を使用せず、INNER JOINなどを使用することが重要**です。また、事情によりJOIN句が使用できない場合は、結合条件を必ず記述するように注意してください。  

---

問題からの再掲となりますが、意図通りの結合結果とならないSQLは以下の通りです。

```sql
select
    * 
from
    books as b
    , orders as o
;
```

このSQLが意図通りに動作しない原因は、「結合条件がない」ためです。上記のSQLをよく見ると、FROM句の後ろにWHERE句の結合条件がありません。このことが原因で、結合の一種である「クロス結合」が発生しています。

クロス結合は、各テーブルのレコードのすべての組み合わせを取得する結合です。そのため、booksテーブルとordersテーブルのレコード数を掛け算した件数が取得され、想定よりも多いレコードが取得される結果となりました(初期データ投入直後であれば7*9 = 63レコード)。

クロス結合を回避するためには、単に結合条件を記述します。以下のSQLを実行し、意図通りに結合(内部結合)ができていることを確認してください。

```sql
select
    * 
from
    books as b
    , orders as o 
where
    b.book_no = o.book_no
;
```

上記の例は2テーブルの結合なので、ミスは発生しづらいと思います。しかし、これが3つ以上の複数テーブルの結合になると、見落としが発生しやすくなります。

例えば、以下のSQLは3つのテーブルの内部結合を意図したSQLです。しかし、ここまでに紹介したSQLと同様に一部の結合条件がないため、クロス結合が発生してしまいます。具体的には、ordersテーブルとcustomersテーブルの結合条件がなく、これが原因でクロス結合が発生します。

```sql
select
    * 
from
    books
    , orders
    , customers 
where
    books.book_no = orders.book_no
;
```

上記のSQLで正しく内部結合を行うためには、ここまでに述べてきた通り結合条件をすべて記述します。以下のSQLのように、`and orders.cust_no = customers.cust_no`と結合条件を追加すると、意図通りに内部結合が実行されます。

```sql
select
    * 
from
    books
    , orders
    , customers 
where
    books.book_no = orders.book_no 
    and orders.cust_no = customers.cust_no
;
```

以上で、クロス結合と結合条件の関係性について解説しました。

ここまでに解説したSQLでも正しく結合を行うことができますが、この記法自体が現在では古いものです。ここまで見てきた通り、この記法では結合条件を記述し忘れた場合に意図しないクロス結合が発生してしまい、結果的にデータアクセスの効率が悪くなる可能性があります。

現在では、**内部結合を行う際にはINNER JOINを使用する記法が一般的なので、この記法を使用してください。** 特別な事情がない限り(もともとのSQLが古い記法で書かれており、この記法自体は変えずに改修する必要がある場合など)、INNER JOINを使用してください。  
INNER JOINを使用した場合、結合条件を書き忘れるとエラーが発生し、SQLは実行できません。そのため、意図しないクロス結合の発生も未然に防げるというメリットがあります。

以下のSQLを実行し、内部結合ができていることを確認してください。

```sql
select
    * 
from
    books as b 
    inner join orders as o 
        on b.book_no = o.book_no
;
```

3つのテーブルの結合については、以下の通りです。

```sql
select
    * 
from
    books 
    inner join orders 
        on books.book_no = orders.book_no 
    inner join customers 
        on orders.cust_no = customers.cust_no
;
```

### 内部結合と外部結合のパフォーマンス差

内部結合と比較して、(左)外部結合を使用したSQLの方が実行時間がかかり、パフォーマンスが悪いです。  
この原因は、内部結合が結合条件に一致したレコードのみを取得するのに対して、(左)外部結合の場合はsample_parentテーブルにしか存在しないレコード(sample_childに対応するレコードが存在しない)も取得してしまうためです。

今回の例では(左)外部結合を使用する必要はなく、内部結合を使用すれば求める結果が取得できます。**内部結合で必要なレコードが取得できるケースでは、外部結合は使用しない** ことで、パフォーマンスを保つことができます。

---

比較対象のSQLを、以下に再掲します。

(内部結合)

```sql
select
    * 
from
    sample_parent as sp 
    inner join sample_child as sc 
        on sp.id = sc.parent_id 
where
    sp.id <= 100000
order by sp.id
;
```

(外部結合)

```sql
select
    * 
from
    sample_parent as sp 
    left outer join sample_child as sc 
        on sp.id = sc.parent_id 
where
    sp.id <= 100000
order by sp.id
;
```

内部結合のSQLの実行計画は、以下の通りです。

```text
QUERY PLAN
Gather Merge  (cost=15355.70..16357.01 rows=8582 width=24)
  Workers Planned: 2
  ->  Sort  (cost=14355.68..14366.41 rows=4291 width=24)
        Sort Key: sp.id
        ->  Parallel Hash Join  (cost=3430.36..14096.78 rows=4291 width=24)
              Hash Cond: (sc.parent_id = sp.id)
              ->  Parallel Seq Scan on sample_child sc  (cost=0.00..9572.67 rows=416667 width=12)
              ->  Parallel Hash  (cost=2893.96..2893.96 rows=42912 width=12)
                    ->  Parallel Index Scan using sample_parent_pkey on sample_parent sp  (cost=0.43..2893.96 rows=42912 width=12)
                          Index Cond: (id <= 100000)
```

外部結合のSQLの実行計画は、以下の通りです。

```text
QUERY PLAN
Gather Merge  (cost=26645.67..36659.17 rows=85824 width=24)
  Workers Planned: 2
  ->  Sort  (cost=25645.65..25752.93 rows=42912 width=24)
        Sort Key: sp.id
        ->  Parallel Hash Left Join  (cost=16816.44..22343.77 rows=42912 width=24)
              Hash Cond: (sp.id = sc.parent_id)
              ->  Parallel Index Scan using sample_parent_pkey on sample_parent sp  (cost=0.43..2893.96 rows=42912 width=12)
                    Index Cond: (id <= 100000)
              ->  Parallel Hash  (cost=9572.67..9572.67 rows=416667 width=12)
                    ->  Parallel Seq Scan on sample_child sc  (cost=0.00..9572.67 rows=416667 width=12)
```

いずれも[パラレルクエリ](https://www.postgresql.jp/document/11/html/how-parallel-query-works.html)が実行されるため、やや複雑な実行計画となっています(Gather Merge、Workers Planned: 2などがパラレルクエリ特有の実行計画です)。ただ、この辺りの表記は今回のパフォーマンス差に直接の関係はないので、いったん無視してください。

特に注目すべき点は、各SQLで扱っているレコード数(rows)です。結合対象のレコード数はいずれのSQLでも同じで、sample_parentテーブルについては「rows=42912」、sample_childテーブルで「rows=416667」です。一方、結合後のレコード数は、内部結合の場合(Parallel Hash Join)は「rows=4291」、外部結合の場合(Parallel Hash Left Join)は「rows=42912」であり、外部結合のほうがより多くのレコードを取得する結果となっています(実際の結合結果のレコードは10万行でrowsの値と一致しないが、これはパラレルクエリを実行していることが原因と考えられる)。

以上のことから、外部結合では内部結合よりも多くの(不要な)レコードを取得しており、これが原因で実行時間がかかっていると言えます。

### WHERE句の絞り込みタイミング

結論としては、2つのSQLはいずれも実行計画が同一となるため、パフォーマンスに差はありません。一般論として、**SQLだけを見てもパフォーマンスを比較・予想することはできません。** 2つのSQLのいずれのパフォーマンスが優れているのか確認するためには、**実行計画を取得して内容を確認し、SQLを実行して性能テストを実施する必要があります。**

---

以下にSQLを再掲します。これらのSQLを一見すると、後者のSQLのように結合前のテーブルをあらかじめ絞り込むほうが、前者のSQLのように結合後のテーブルを絞り込むよりもパフォーマンスが優れているように思えます。

(結合後のテーブルを絞り込むように見えるSQL)

```sql
select
    * 
from
    sample_child as sc 
    inner join sample_parent as sp 
        on sc.parent_id = sp.id 
where
    sc.id >= 1 
    and sc.id < 10000
;
```

(結合前のテーブルを絞り込むように見えるSQL)

```sql
select
    * 
from
    ( 
        select
            * 
        from
            sample_child 
        where
            sample_child.id >= 1 
            and sample_child.id < 10000
    ) as sc 
    inner join sample_parent as sp 
        on sc.parent_id = sp.id
;
```

ここで、それぞれのSQLについて、実行計画を取得します。すると、いずれのSQLも同一の実行計画となります。このことから、**SQLだけを見てオプティマイザがどのようなデータアクセスの方法を選択するか予想することは難しい** と言えます。

```text
QUERY PLAN
Gather  (cost=2051.09..29414.14 rows=10169 width=24)
  Workers Planned: 2
  ->  Merge Join  (cost=1051.09..27397.24 rows=4237 width=24)
        Merge Cond: (sp.id = sc.parent_id)
        ->  Parallel Index Scan using sample_parent_pkey on sample_parent sp  (cost=0.43..255407.82 rows=4166608 width=12)
        ->  Sort  (cost=1050.65..1076.07 rows=10169 width=12)
              Sort Key: sc.parent_id
              ->  Index Scan using sample_child_pkey on sample_child sc  (cost=0.42..373.81 rows=10169 width=12)
                    Index Cond: ((id >= 1) AND (id < 10000))
```

[パラレルクエリ](https://www.postgresql.jp/document/11/html/how-parallel-query-works.html)が実行されるため、やや複雑な実行計画となっています(Gather Merge、Workers Planned: 2などがパラレルクエリ特有の実行計画です)。ただ、この辺りの表記は今回確認したいことには関係がないので、いったん無視してください。

ここで注目すべきは、sample_childテーブルに対してIndex Scanが実行されていることです。つまり、sample_childテーブルは結合前にあらかじめWHERE句の条件で絞り込まれています。よって、**前者のSQLのように結合後のテーブル(のレコード)をWHERE句で絞り込んでいるように見えるSQLであっても、実際のデータアクセスでは結合前のテーブルに対して絞り込みを行っています。**

繰り返しになりますが、SQLだけを見ても実際のデータアクセスの方法を予想することはできません。したがって、ある目的を達するためのSQLが複数考えられる場合は、それぞれのSQLの実行計画を取得し、性能テストを実施することが重要です。  
また、今回は2つのSQLで同じ実行計画となりましたが、どのような条件下であっても今回と同様の結果となる保証はありません。WHERE句の条件や各テーブルの状態、さらには使用するDB製品によって、2つのSQLの実行計画に差異が出てくる可能性はあります。このことからも、実行計画を確認することの重要性が理解できます。

### 結合条件列に対するインデックス

**一般に、結合条件列にインデックスを設定すると、結合を使用しているSQLの高速化が期待できます。** テキストでは[インデックスを使用したNested Loopsの性能改善について言及しましたが](../documents/join.md#nested-loopsの性能改善)、インデックスによる性能改善はNested Loops以外の結合アルゴリズム(特にSort Merge)でも有効な場合があります。

---

#### Sort Mergeの場合

初期データ投入状態で、以下のSQLを実行してください。その際、SQLの実行時間を記録しておいてください(おおむね数秒で実行できるはずです)。

```sql
select
    * 
from
    sample_parent as sp 
    inner join sample_child as sc 
        on sp.id = sc.parent_id
;
```

このSQLは、単にsample_parentテーブルとsample_childテーブルを結合しています。結合条件列はsample_parentのid列とsample_childのparent_id列です。

次に、実行計画を見ていきます。

```text
QUERY PLAN
Merge Join  (cost=8.08..77344.01 rows=1000000 width=24)
  Merge Cond: (sp.id = sc.parent_id)
  ->  Index Scan using sample_parent_pkey on sample_parent sp  (cost=0.43..313740.34 rows=9999860 width=12)
  ->  Index Scan using idx_parent_id on sample_child sc  (cost=0.42..31389.42 rows=1000000 width=12)
```

この実行計画から、以下のことがわかります。

- 結合のアルゴリズムはMerge Join(Sort Merge)が採用されている
- 結合対象の各テーブルに対して、いずれもインデックスを使用したIndex Scanが実行されている = 結合対象列にインデックスが設定されている
  - sample_parentテーブルのid列は主キーのためインデックスが設定されている
  - sample_childテーブルのparent_id列は主キーではないが、初期データ投入時のCREATE INDEXによってインデックスが設定されている(`create index idx_parent_id on public.sample_child(parent_id);`)

ここで、sample_childテーブルのparent_id列に対して作成済みのインデックスを削除します。また、念のため統計情報も更新しておきます。  
インデックスを削除するために、以下のSQLを実行してください。

```sql
drop index idx_parent_id;
analyze sample_child;
```

そして、再び以下のSQLを実行し、結合の実行時間を確認してください。

```sql
select
    * 
from
    sample_parent as sp 
    inner join sample_child as sc 
        on sp.id = sc.parent_id
;
```

インデックスが設定されていた時と比べて、実行時間がかかっている(パフォーマンスが悪くなっている)ことがわかると思います。当方の環境では、0.5秒ほど余計に時間がかかるようになり(インデックス削除前は約1.8秒、インデックス削除後は約2.3秒)、率にして30%弱のパフォーマンス悪化です。

実行計画は、以下の通りです。

```text
QUERY PLAN
Merge Join  (cost=132158.25..183120.85 rows=1000000 width=24)
  Merge Cond: (sp.id = sc.parent_id)
  ->  Index Scan using sample_parent_pkey on sample_parent sp  (cost=0.43..313740.34 rows=9999860 width=12)
  ->  Materialize  (cost=132154.34..137154.34 rows=1000000 width=12)
        ->  Sort  (cost=132154.34..134654.34 rows=1000000 width=12)
              Sort Key: sc.parent_id
              ->  Seq Scan on sample_child sc  (cost=0.00..15406.00 rows=1000000 width=12)
```

まず注目すべきは、sample_childテーブルに対してSeq Scanが実行される点です。インデックスがなくなったので当然ではありますが、全件スキャンはそれだけ重い処理となりがちです。  
さらに悪いことに、sample_childのparent_id列に基づくSortが発生しています。ソート(並び替え)は数ある処理の中でもかなり重い部類です。実際、Costを確認すると、Sortでかなりのコストがかさんでいることがわかります(Seq Scanの段階で15406.00、Sortで137154.34)。  
インデックスがなくなったことでSortが発生する理由ですが、インデックスのない列はソート済みという保証がないため、明示的なソートが必要となることが原因です。一方、インデックス自体がソートされているため、インデックスが存在する列はソート処理が不要となります。  
なお、結合アルゴリズムについては、インデックスが設定されている場合と同様にMerge Join(Sort Merge)が採用されます。Sort Mergeの場合、アルゴリズムの動作の関係で[結合列でソート済みの場合に性能が良いケースがある](../documents/join.md#sort-mergeの注意点)ことがあり、この点もインデックスが性能改善に寄与しているものと思われます。

ここまでの確認が完了したら、parent_id列のインデックスを忘れずに再作成してください。

```sql
create index idx_parent_id on public.sample_child(parent_id);
```

#### Hash Joinの場合

次に、Hash Joinのパターンも見ていきましょう。  
以下のSQLは、sample_parentテーブル同士を結合するSQLです(実用上は特に意味がありません)。結合列は、id列とid_noindex列です。その際、SQLの実行時間を記録しておいてください(1分以内で実行できるはずです)。

```sql
select
    * 
from
    sample_parent as sp1 
    inner join sample_parent as sp2 
        on sp1.id = sp2.id_noindex
;
```

sample_parentテーブルのid_noindex列は、その名の通りインデックスが設定されていません。ちなみに、この列に入っている値はid列とまったく同じものです(例えば、id=1のレコードであればid_noindex=1)。

実行計画も確認します。

```text
QUERY PLAN
Hash Join  (cost=327879.85..654667.09 rows=9999860 width=24)
  Hash Cond: (sp2.id_noindex = sp1.id)
  ->  Seq Scan on sample_parent sp2  (cost=0.00..154053.60 rows=9999860 width=12)
  ->  Hash  (cost=154053.60..154053.60 rows=9999860 width=12)
        ->  Seq Scan on sample_parent sp1  (cost=0.00..154053.60 rows=9999860 width=12)
```

実行計画を見ると、Hash Join(ハッシュ結合)が実行されていることがわかります。また、sample_parentに対しては、いずれもSeq Scanが実行されていて、全件スキャンとなっていることがわかります。

では、id_noindex列にインデックスを設定しましょう。以下のSQLで、インデックスを設定してください。念のため、統計情報も更新します。

```sql
create index idx_id_noindex on public.sample_parent(id_noindex);
analyze sample_parent;
```

そして、再び以下のSQLを実行します。SQLの実行時間を記録して、インデックス設定前の実行時間と比較してください。なお、当方の環境では実行時間にほとんど変化がありませんでした。

```sql
select
    * 
from
    sample_parent as sp1 
    inner join sample_parent as sp2 
        on sp1.id = sp2.id_noindex
;
```

実行計画も確認します。

```text
QUERY PLAN
Hash Join  (cost=327879.85..654667.09 rows=9999860 width=24)
  Hash Cond: (sp2.id_noindex = sp1.id)
  ->  Seq Scan on sample_parent sp2  (cost=0.00..154053.60 rows=9999860 width=12)
  ->  Hash  (cost=154053.60..154053.60 rows=9999860 width=12)
        ->  Seq Scan on sample_parent sp1  (cost=0.00..154053.60 rows=9999860 width=12)
```

上記の実行計画は、インデックスが設定されていなかったときとまったく同じです。つまり、インデックスを設定しても性能は改善されないということです。以上のことから、結合列にインデックスを設定した場合であっても、結合のアルゴリズムによっては必ずしも性能改善にはつながらないということが理解できたと思います。

ここまでの確認が完了したら、id_noindex列のインデックスを忘れずに削除してください。

```sql
drop index idx_id_noindex;
```

ここまで、結合と結合列のインデックスとの関係について見てきました。Nested LoopsやSort Mergeといった結合アルゴリズムが採用された場合には、結合列にインデックスを設定することでパフォーマンスを改善できるケースがある一方、Hash Joinの場合にはインデックスは有効ではなく、実行計画自体が変わらないという結果となりました。  
このことから、**Nested LoopsやSort Mergeといった結合アルゴリズムが採用されるようなSQLのパフォーマンスを改善する場合に、「結合列に対するインデックスの設定」は試す価値がある**、と言えます。また、Hash Joinの場合であっても、インデックスを設定することでオプティマイザが結合アルゴリズムを変更する可能性もあることから、可能であればインデックスを設定して、性能テストで有用性を検討するとよいでしょう。

## [サブクエリ](../documents/subquery.md)

### サブクエリの書き換え

書き換えには2つの方法があります。それは、「サブクエリは使用するがINをEXISTSに書き換える方法」と、「サブクエリを使用せず外部結合を使用する方法」です。本演習のポイントは、

1. **INを使用したSQLのパフォーマンスは悪い(場合がある)**
1. **サブクエリを結合に書き換えることができる(場合がある)**

という点です。

EXISTSを使用する方法と外部結合を使用する方法のいずれが優れているか、という点ですが、一般に**サブクエリよりも外部結合を使用する方法のほうがパフォーマンスがよい**、とされています。したがって、外部結合で書き換えができるのであれば、そのようにSQLを実装すべきです。ただし、以下で述べる通り、本演習ではいずれも方法もパフォーマンスはまったくの同一であるため、どちらの方法を選んでも性能は変わりません。

---

まずは、INを使用したSQLについて実行計画を確認します。

```text
QUERY PLAN
Gather  (cost=1000.00..55862001372.00 rows=5000088 width=12)
  Workers Planned: 2
  ->  Parallel Seq Scan on sample_parent  (cost=0.00..55861500363.20 rows=2083370 width=12)
        Filter: (NOT (SubPlan 1))
        SubPlan 1
          ->  Materialize  (cost=0.00..24313.00 rows=1000000 width=4)
                ->  Seq Scan on sample_child  (cost=0.00..15406.00 rows=1000000 width=4)
```

特に目に付く点として、Costが非常に高い点が挙げられます。最終的なCostは「55862001372.00」という値になっているため、実行計画を見ただけで処理時間がかかりすぎることがわかります。

このSQLの改修方針としては、以下の2つがあります。

#### INの書き換え

サブクエリを使用するという方略はそのままに、INを別の構文に書き換えることで性能改善を図る方法です。

**INの書き換えによく使用されるのが、EXISTSです。** 書き換え後のSQLは以下の通りで、not exists以降のかっこ内は「相関サブクエリ」となっています。

```sql
select
    * 
from
    sample_parent 
where
    not exists (select parent_id from sample_child where sample_parent.id = sample_child.parent_id)
;
```

EXISTSや相関サブクエリの挙動について苦手意識を持っている方もいると思うので、ここで簡単に解説します。  
上記のSQLも含め、WHERE句の判定は「1行ごとに実行されている」と考えると、理解しやすいと思います。今回はFROM句でsample_parentテーブルが指定されており、この各行ごとにWHERE句の判定が行われると考えます。  
例えば、sample_parentテーブルのid = 1であるレコードについて考えます。この場合、WHERE句内の相関サブクエリの「sample_parent.id」が「1」に置き換わります。

```sql
select
    * 
from
    sample_parent 
where
    not exists (select parent_id from sample_child where 1 = sample_child.parent_id)
;
```

サブクエリの`where 1 = sample_child.parent_id`は、sample_childテーブルのparent_id列が1となるレコードが存在するためTRUEです。よって、サブクエリ`(select parent_id from sample_child where 1 = sample_child.parent_id)`はレコードを返します。EXISTSはサブクエリがレコードが返す場合にTRUEを返す仕組みになっているため、EXISTS全体がTRUEとなります。

```sql
select
    * 
from
    sample_parent 
where
    not true
;
```

今回はNOT EXISTSとなっているため、where句内の`not exists ~`は全体としてFALSEとなります。この結果として、sample_parentテーブルのid = 1であるレコードは取得されません。  

```sql
select
    * 
from
    sample_parent 
where
    false
;
```

以下、同様の処理をsample_parentテーブルすべてのレコードに対して実行し、条件に合致したレコードを取得する、という挙動になります。

次に、EXISTSに書き換えたSQLの実行計画を確認します。

```text
QUERY PLAN
Merge Anti Join  (cost=6.02..377230.92 rows=9000175 width=12)
  Merge Cond: (sample_parent.id = sample_child.parent_id)
  ->  Index Scan using sample_parent_pkey on sample_parent  (cost=0.43..313745.06 rows=10000175 width=12)
  ->  Index Only Scan using idx_parent_id on sample_child  (cost=0.42..25985.42 rows=1000000 width=4)
```

まず、Sort Mergeの一種である「Merge Anti Join」が実行されていることがポイントです。「Merge Anti Join」はsample_parentテーブルの全レコードから、sample_parentテーブルとsample_childテーブルの「Merge Join(内部結合)」で取得されたレコードを差し引く、という操作を表しています。  
ここで注目すべきは、**SQLには明示的に結合(INNER JOINなど)を記述していないのに、実行計画では結合という操作が選択されている**ことです。このように、**オプティマイザはSQL自体の表現にかかわらず、最適なデータアクセスの仕方を選択する**という挙動を取ります。

テーブルに対するScanの方法を見ると、sample_parentテーブルに対してはIndex Scanが、sample_childテーブルに対してはIndex Only Scanが、それぞれ実行されています。どちらのScanもインデックスが使用されており、効率の良いデータアクセスが行われています。sample_childに対してIndex Only Scanが実行されている理由ですが、サブクエリ内で取得する列がparent_id列のみであり、この列にインデックスとして「idx_parent_id」が設定されているためです。これにより、テーブル自体をScanするのではなく、インデックスだけをScanすることでより高速なデータアクセスが実現されています。

上述のデータアクセスの効率化により、INを使用したSQLと比べてCostが大きく低下しています。最終的なCostは、INを使用したSQLでは「55862001372.00」、EXISTSを使用したSQLでは「377230.92」となり、圧倒的に低いことがわかります。このことからも、性能改善が図られたことが確認できます。Costの高低のみでSQLの性能が比較できるケースはまれですが、今回のように**Costに非常に大きな差がある場合に限って、Costを見るだけでパフォーマンスの差異が判断できる場合もあります。**

#### 外部結合への書き換え

上述の[INの書き換え](answer.md#INの書き換え)で紹介した、EXISTSへの書き換え後の実行計画を再掲します。

```text
QUERY PLAN
Merge Anti Join  (cost=6.02..377230.92 rows=9000175 width=12)
  Merge Cond: (sample_parent.id = sample_child.parent_id)
  ->  Index Scan using sample_parent_pkey on sample_parent  (cost=0.43..313745.06 rows=10000175 width=12)
  ->  Index Only Scan using idx_parent_id on sample_child  (cost=0.42..25985.42 rows=1000000 width=4)
```

この実行計画では結合(Merge Anti Join)が実行されています。先述の通り、「Merge Anti Join」はsample_parentテーブルの全レコードから、sample_parentテーブルとsample_childテーブルの「Merge Join(内部結合)」で取得されたレコードを差し引く、という操作を意味します。よって、このような操作を**テーブル結合の構文で記述することで、EXISTSへの書き換えと同じ結果が得られる**ことがわかります。

INを使用したSQLを結合の構文で書き換えたSQLを、以下に示します。

```sql
select
    sp.* 
from
    sample_parent as sp 
    left outer join sample_child as sc 
        on sp.id = sc.parent_id 
where
    sc.parent_id is null
;
```

このSQLを実行してみると、EXISTSで書き換えたSQLとほとんど同じ実行時間となるはずです。

実行計画についても、以下で確認します。

```text
QUERY PLAN
Merge Anti Join  (cost=27.12..377230.92 rows=9000175 width=12)
  Merge Cond: (sp.id = sc.parent_id)
  ->  Index Scan using sample_parent_pkey on sample_parent sp  (cost=0.43..313745.06 rows=10000175 width=12)
  ->  Index Only Scan using idx_parent_id on sample_child sc  (cost=0.42..25985.42 rows=1000000 width=4)
```

実行計画は、EXISTSを使用したSQLとまったく同一です。

### サブクエリによるパフォーマンス改善

「集約を先に行うパターン(サブクエリを使用する)」の方がより高速に動作します(当方の環境では実行時間が約1/2)。この理由は、「集約を先に行うパターン」ではサブクエリ内で集約を行うことにより、sample_parentテーブルに結合するレコードを絞り込んでいるためです。  
今回のように、**サブクエリで結合対象の行数を減らすことができる場合、パフォーマンスを改善できる可能性があります。** 一般にサブクエリを使用するとパフォーマンスは悪くなるケースが多いですが、上記の条件に当てはまる場合はサブクエリの使用を検討するとよいでしょう。

---

設問の条件を満たすSQLは、以下の通りです。

「結合を先に行うパターン(サブクエリを使用しない)」

```sql
select
    max(sp.id) as sample_parent_id
    , count(sp.id) as count 
from
    sample_parent as sp 
    inner join sample_child as sc 
        on sp.id = cast(sc.col_01 as int) 
group by
    sc.col_01 
order by
    max(sp.id)
;
```

「集約を先に行うパターン(サブクエリを使用する)」

```sql
select
    sp.id as sample_parent_id
    , sc.count 
from
    sample_parent as sp 
    inner join ( 
        select
            col_01
            , count(id) as count 
        from
            sample_child 
        group by
            col_01
    ) as sc 
        on sp.id = cast(sc.col_01 as int) 
order by
    sp.id
;
```

それぞれのSQLの実行計画は、以下の通りです。

「結合を先に行うパターン(サブクエリを使用しない)」

```text
QUERY PLAN
Sort  (cost=29486.85..29511.82 rows=9988 width=16)
  Sort Key: (max(sp.id))
  ->  Finalize HashAggregate  (cost=28723.47..28823.35 rows=9988 width=16)
        Group Key: sc.col_01
        ->  Gather  (cost=26476.17..28573.65 rows=19976 width=16)
              Workers Planned: 2
              ->  Partial HashAggregate  (cost=25476.17..25576.05 rows=9988 width=16)
                    Group Key: sc.col_01
                    ->  Nested Loop  (cost=0.45..22351.16 rows=416667 width=8)
                          ->  Parallel Seq Scan on sample_child sc  (cost=0.00..9572.67 rows=416667 width=4)
                          ->  Memoize  (cost=0.45..0.58 rows=1 width=4)
                                Cache Key: (sc.col_01)::integer
                                ->  Index Only Scan using sample_parent_pkey on sample_parent sp  (cost=0.44..0.57 rows=1 width=4)
                                      Index Cond: (id = (sc.col_01)::integer)
```

「集約を先に行うパターン(サブクエリを使用する)」

```text
QUERY PLAN
Sort  (cost=54122.13..54147.10 rows=9988 width=12)
  Sort Key: sp.id
  ->  Nested Loop  (cost=14853.80..53458.63 rows=9988 width=12)
        ->  Finalize HashAggregate  (cost=14853.36..14953.24 rows=9988 width=12)
              Group Key: sample_child.col_01
              ->  Gather  (cost=12656.00..14753.48 rows=19976 width=12)
                    Workers Planned: 2
                    ->  Partial HashAggregate  (cost=11656.00..11755.88 rows=9988 width=12)
                          Group Key: sample_child.col_01
                          ->  Parallel Seq Scan on sample_child  (cost=0.00..9572.67 rows=416667 width=8)
        ->  Index Only Scan using sample_parent_pkey on sample_parent sp  (cost=0.44..3.85 rows=1 width=4)
              Index Cond: (id = (sample_child.col_01)::integer)
```

実行計画を見比べると、いずれのSQLでもNested Loopによる内部結合が実行されています。ただし、「結合を先に行うパターン(サブクエリを使用しない)」では結合が実行された後に集約(Finalize HashAggregate)が行われているのに対して、「集約を先に行うパターン(サブクエリを使用する)」では集約が先に実行され、その後に結合が実行されています。  
以上の動作の違いが、パフォーマンスにも影響します。「集約を先に行うパターン(サブクエリを使用する)」では、集約により結合対象行を絞り込んだ上で結合を実施しています(`Finalize HashAggregate  (cost=14853.36..14953.24 rows=9988 width=12)`)。一方、「結合を先に行うパターン(サブクエリを使用しない)」では、結合対象行はsample_childテーブルの全量となります(`Parallel Seq Scan on sample_child sc  (cost=0.00..9572.67 rows=416667 width=4)`、rowsがsample_childテーブルのレコード数と一致しないのはパラレルクエリのため)。この結合対象となるレコード数の違いが、パフォーマンス差異の理由となっています。

## [更新系SQLのチューニング](../documents/update.md)

### INSERT

通常のINSERT文(`INSERT INTO テーブル名(列名1, ..., 列名n) VALUES (値1, ..., 値n);`)では、1レコードの挿入につき1回のトランザクションが発生します。「[analyze_sql.md#実行計画とは](../documents/analyze_sql.md#実行計画とは)」でも説明している通り、SQLの実行時には、SQLの変換やオプティマイザによる実行計画の作成などの準備処理(データアクセス以外にかかるオーバーヘッド)が発生します。  
これらの処理には、相応の実行時間が必要です。ゆえに、**通常のINSERT文による大量データのINSERTでは挿入行数分のオーバーヘッドが発生し、これが原因で処理に時間がかかります。**

一方、バルクインサートの構文(`INSERT INTO テーブル名(列名1, ..., 列名n) VALUES (値1, ..., 値n), ..., (値1, ..., 値n);`)では、複数のレコードを挿入する場合であってもトランザクションは1回で済みます。そのため、**バルクインサートを使用するとSQLの実行に必要なオーバーヘッドも少なくて済み、結果として効率よく大量のレコードを挿入できます。**

### DELETE

DELETEについては、`delete from テーブル名 where 条件式;`で記述するため、基本的には複数レコードを1つのSQLで削除することが前提となっています。そのため、INSERTのように複数のSQLが実行されることによるオーバーヘッドの問題は起こりにくいです(もちろんDELETE文を分割して複数回実行した場合はオーバーヘッドが無視できなくなります)。

**あるテーブルの全レコードを削除する場合に限り、DELETEよりもTRUNCATEの方が高速です。** これは両者のデータアクセス(レコード削除)の仕方によるものです。  

sample_childテーブルの全レコードを削除するSQL「`delete from sample_child;`」の実行計画を以下に示します。

```text
QUERY PLAN
Delete on sample_child  (cost=0.00..15406.00 rows=0 width=0)
  ->  Seq Scan on sample_child  (cost=0.00..15406.00 rows=1000000 width=6)
```

DELETEはレコード削除を行うSQLですが、実行計画を見ると`Seq Scan on sample_child`とあります。つまり、**DELETEを実行するとテーブルに対するスキャンが実行されます。** 今回は全レコードの削除なので、必然的にフルスキャンとなります。フルスキャンはレコード数に比例して処理時間も増加する処理なので、DELETEは大量レコードの削除には不向きと言えます。  
一方、TRUNCATEの挙動はDELETEとは異なります。**TRUNCATEはレコードを削除するのではなく、テーブルごと削除してから再度テーブルを作成する**、という挙動を取ります。それゆえ、**TRUNCATEはDELETEのようにレコードをScanする必要がない分、高速で動作します。**  
なお、DELETEはDML(データ操作言語、Data Manipulation Language)なのに対して、TRUNCATEはDDL(データ定義言語、Data Definition Language)で、CREATE TABLEやDROP TABLEの仲間です。そのため、TRUNCATEを実行する際にはDBのユーザにDDL(DROP TABLE)を実行できる権限が必要なので注意が必要です。さらに、レコード削除後のロールバックができない点にも注意してください(DELETEはロールバック可能)。
