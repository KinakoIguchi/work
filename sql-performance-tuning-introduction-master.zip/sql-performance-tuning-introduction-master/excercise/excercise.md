# 演習問題

- 各章の内容と関連した演習問題です。
- 演習の実施前に[環境構築](../documents/environment.md)の手順に従って実行環境を準備し、[事前準備](excercise.md#事前準備)で演習に使用するデータを用意してください。
- [一部の演習の解答例はこちらです。](./answer.md)

---

- [演習問題](#演習問題)
  - [事前準備](#事前準備)
  - [実行計画と統計情報](#実行計画と統計情報)
  - [結合](#結合)
    - [意図しないクロス結合](#意図しないクロス結合)
    - [内部結合と外部結合のパフォーマンス差](#内部結合と外部結合のパフォーマンス差)
    - [WHERE句の絞り込みタイミング](#where句の絞り込みタイミング)
    - [結合条件列に対するインデックス](#結合条件列に対するインデックス)
  - [サブクエリ](#サブクエリ)
    - [サブクエリの書き換え](#サブクエリの書き換え)
    - [サブクエリによるパフォーマンス改善](#サブクエリによるパフォーマンス改善)
  - [更新系SQLのチューニング](#更新系sqlのチューニング)
    - [INSERT](#insert)
    - [DELETE](#delete)
    - [演習が終わったら](#演習が終わったら)
  - [インデックス](#インデックス)
    - [インデックスの有無によるパフォーマンス差](#インデックスの有無によるパフォーマンス差)
    - [インデックスによる性能向上が難しいケース](#インデックスによる性能向上が難しいケース)
      - [絞り込み条件が存在しない](#絞り込み条件が存在しない)
      - [ほとんどレコードを絞り込めない](#ほとんどレコードを絞り込めない)
      - [索引列で演算を行っている](#索引列で演算を行っている)
      - [索引列に対して関数を使用している](#索引列に対して関数を使用している)
      - [否定形を使用している](#否定形を使用している)
    - [インデックス更新のコスト](#インデックス更新のコスト)

## 事前準備

[init.txt](resources/init.txt)のSQLをすべて実行してください。これらのSQLを実行することで、演習で使用するテーブルの作成と初期データの投入が実行されます。

## [実行計画と統計情報](../documents/analyze_sql.md)

[テキスト内に解説と演習用のSQLがあります](../documents/analyze_sql.md)ので、こちらを確認・実行してください。

## [結合](../documents/join.md)

### 意図しないクロス結合

まず、以下のSQLを実行し、2つのテーブルのレコードを確認してください。

```sql
select
    * 
from
    books
;
```

``` sql
select
    * 
from
    orders
;
```

初期データ投入直後であれば、booksテーブルには7レコード、ordersテーブルには9レコードが入っていることが確認できます。なお、booksテーブルのbook_no列とordersテーブルのbook_no列は外部キー(1対多)の関係にあります。

次に、以下のSQLを実行し、各書籍(book_no)に対する注文が何件入っているかを確認してください。

```sql
select
    book_no
    , count(*) 
from
    orders 
group by
    book_no 
order by
    book_no
;
```

次に、以下のSQLを実行し、実行結果を確認してください。このSQLは、booksテーブルとordersテーブルのbook_no列を結合条件としてテーブルを内部結合することを意図したSQLです。  

実行前に、何件のレコードが取得されるか予想してください。

```sql
select
    * 
from
    books as b
    , orders as o
;
```

以上のSQLの実行結果から、「book_no列を結合条件としてテーブルを内部結合」という意図通りに実行できていないことがわかります。初期データ投入直後であれば9レコードが取得されるはずですが、それよりも多くのレコードが取得されてしまいます(初期データ投入直後であれば63レコード)。

このような結果となった理由と、意図通りの結果を取得するためのSQLの書き換えについて考えてください。

【ヒント】

- この問題に関して、[テキストにおいて解説している箇所はこちらです。](../documents/join.md#意図しないクロス結合)

### 内部結合と外部結合のパフォーマンス差

以下の2つのSQLを実行してください。返却されるレコードは同一です。  
これらのSQLを見て、どちらのSQLがパフォーマンスが優れているのか予想してください。また、その原因について考えてください。

```sql
select
    * 
from
    sample_parent as sp 
    inner join sample_child as sc 
        on sp.id = sc.parent_id 
where
    sp.id <= 100000
order by sp.id
;
```

```sql
select
    * 
from
    sample_parent as sp 
    left outer join sample_child as sc 
        on sp.id = sc.parent_id 
where
    sp.id <= 100000
order by sp.id
;
```

【ヒント】

- 1つ目のSQLではINNER JOIN(内部結合)が、2つ目のSQLではLEFT OUTER JOIN(左外部結合)が、それぞれ使用されています。これらの結合方法の違いは、どのようなものでしょうか。
- 実行計画から、何かわかることはないでしょうか。

### WHERE句の絞り込みタイミング

以下のSQLは、実行結果が同一です。ただし、WHERE句の条件を記述する位置が異なります。前者のSQLは結合後のテーブルに対してWHERE句の条件を記述しているのに対して、後者のSQLは結合前のテーブル(sample_child)に対してWHERE句を記述しています。  
これらのSQLについて、パフォーマンスが優れているのはどちらのSQLか予想してください。また、その原因について考えてください。

```sql
select
    * 
from
    sample_child as sc 
    inner join sample_parent as sp 
        on sc.parent_id = sp.id 
where
    sc.id >= 1 
    and sc.id < 10000
;
```

```sql
select
    * 
from
    ( 
        select
            * 
        from
            sample_child 
        where
            sample_child.id >= 1 
            and sample_child.id < 10000
    ) as sc 
    inner join sample_parent as sp 
        on sc.parent_id = sp.id
;
```

【ヒント】

- 実行計画から、何かわかることはないでしょうか。

### 結合条件列に対するインデックス

テキストの[結合#nested-loopsの性能改善](../documents/join.md#nested-loopsの性能改善)に関連したパフォーマンスチューニング手法です。[こちらの解説を読み、性能改善効果を確認してください。](./answer.md#結合条件列に対するインデックス)

## [サブクエリ](../documents/subquery.md)

サブクエリは、性能劣化の原因となるケースが多いです。そのため、以下の演習は「サブクエリを使用した性能改善」よりも「サブクエリを別の構文に書き換える」ことに重点を置いています。

### サブクエリの書き換え

**【注意】**  以下のSQLをA5M2で実行すると、実行に非常に時間がかかるため、DB接続が切断されます。一方、接続切断後もSQL自体は実行され続けるため、これが原因でシステムに不要な負荷がかかり続けることになります。これを避けるため、**以下の手順に従ってSQL実行後にDBを再起動して、SQLの実行を強制終了してください。**

1. Windowsの画面下部、タスクバーのテキストボックスに「サービス」と入力し、表示された「サービス」アプリをクリックします。
1. 表示されたウィンドウをスクロールし、「postgresql-x64-○○(○○はPostgreSQLのバージョン番号)」という名前のサービスを探します。
1. SQLを実行して動作を確認したら、「postgresql-x64-○○」を右クリックし、表示されたメニューで「再起動」をクリックします。
1. 再起動の進捗が表示されます。これが終われば、DBの再起動が完了しています。

**上記の【注意】を確認した上で**、以下のサブクエリを含むSQLを実行してください。

```sql
select
    * 
from
    sample_parent 
where
    id not in (select parent_id from sample_child)
;
```

上記のSQLは、sample_childに対応するレコードが存在しないsample_parentのレコードを取得することが目的です(この条件に該当するレコード数は9千万件です)。より現実的なケースで考えると、sample_parentを商品テーブル、sample_childを注文テーブルとすれば、上記のSQLで注文の入っていない商品一覧を取得する、といった状況です。

上記の目的を実現し、かつ実用的な実行時間で処理が完了するようにSQLを書き換えてください(2つの方法があります)。

【ヒント】

- INを使用したSQLは、性能がよくないケースが多いとされています。INを使用せずに実装する方法はないでしょうか。
  - この方法がうまくいったら、実行計画をよく確認してみてください。もう一つの解法に関するヒントが隠れています。
- いくつかの理由から、[サブクエリ自体に性能劣化の懸念があります](../documents/subquery.md#サブクエリの問題点)。サブクエリを使用せずに実装する方法はないでしょうか。

### サブクエリによるパフォーマンス改善

以下の条件を満たすSQLを作成してください。

- sample_childテーブルをcol_01列で集約し、集約関数COUNTでそれぞれの出現回数を取得してください。
- sample_parent_idテーブルとsample_childテーブルを内部結合してください。
  - 結合条件は`sample_parent.id = cast(sample_child.col_01 as int)`
- SELECT句で取得する列は、「sample_parent.id」と「sample_child.col_01列の集計結果」です。
- 取得したレコードは、sample_parent.idでソートしてください。

上記のSQLを **「結合を先に行うパターン(サブクエリを使用しない)」と「集約を先に行うパターン(サブクエリを使用する)」の2種類実装し、実行時間を比較してください。** また、なぜこのような結果となるのか、テキストの記述などを参考にして考えてください。

【ヒント】

- 以下のテキストを参照してください。[subquery.md#サブクエリの使用を検討すべきパターン](../documents/subquery.md#サブクエリの使用を検討すべきパターン)

## [更新系SQLのチューニング](../documents/update.md)

この項の演習では、sample_childテーブルを使用して更新系SQLのパフォーマンスを確認します。以下のSQLを実行し、初期投入データを削除してください。

```sql
truncate sample_child cascade;
```

### INSERT

以下のSQLを実行し、実行時間を比較してください。**片方のSQLを実行したら、`truncate sample_child cascade;`でレコードを削除してからもう片方のSQLを実行するようにしてください。**  
以下のSQLは、いずれもsample_childテーブルに1000件のレコードをINSERTします。

- 1件ずつINSERT: [insert_single.txt](resources/insert_single.txt)
- まとめてINSERT(バルクインサート): [insert_bulk.txt](resources/insert_bulk.txt)

### DELETE

以下の演習を実施する前に、sample_childテーブルのレコードをすべて削除します。

```sql
truncate sample_child cascade;
```

次に、初期データを投入します。以下のSQLを実行して、sample_childテーブルに100万件のレコードをINSERTします。

```sql
INSERT 
INTO public.sample_child(id, parent_id, col_01) 
SELECT
    i
    , i
    , i/100
FROM
    generate_series(1, 1000000) as i
;
```

上記の準備を行ったうえで、以下に示す全レコード削除のSQLを実行し、実行時間を比較してください。なお、**片方のSQLを実行したら、初期データ投入のSQLを再度実行して、sample_childテーブルに100万件のレコードを挿入してください。**

【DELETEを使用する方法】

```sql
delete from sample_child;
```

【TRUNCATEを使用する方法】

```sql
truncate sample_child cascade;
```

### 演習が終わったら

上記の演習が終わったら、以下のSQLを実行してsample_childのレコードを元に戻します。

```sql
truncate sample_child cascade;

INSERT 
INTO public.sample_child(id, parent_id, col_01) 
SELECT
    i
    , i
    , i/100
FROM
    generate_series(1, 1000000) as i
;
```

念のため、統計情報も更新します。

```sql
analyze sample_child;
```

## [インデックス](../documents/index.md)

### インデックスの有無によるパフォーマンス差

以下のSQLを実行し、実行時間を比較してください。また、それぞれの実行時間をメモしておいてください。  
なお、sample_parentテーブルのid列にはインデックスが作成されており(主キーインデックス)、id_noindex列にはインデックスが作成されていないものとします。すでに作成されている場合は、`drop index インデックス名`でインデックスを削除した上でSQLを実行してください。

【インデックスが作成されている列を使用したSQL】

```sql
select
    * 
from
    sample_parent 
where
    id <= 5000000
;
```

【インデックスが設定されていない列を使用したSQL】

```sql
select
    * 
from
    sample_parent 
where
    id_noindex <= 5000000
;
```

次に、id_noindex列にインデックスを作成し(念のため統計情報も更新)、再度SQLを実行してインデックスの作成前後のパフォーマンス差を確認してください。

【インデックスを作成するSQL】

```sql
create index idx_id_noindex on public.sample_parent(id_noindex);
analyze sample_child;
```

【インデックスを**作成した**列を使用したSQL】

```sql
select
    * 
from
    sample_parent 
where
    id_noindex <= 5000000
;
```

インデックスによる性能改善が確認できたら、以下のSQLを実行してインデックスを削除してください。

```sql
drop index idx_id_noindex;
```

### インデックスによる性能向上が難しいケース

ここでは、インデックスによる性能向上が難しいSQLについて見ていきます。以下に示すSQLを実行し、その実行計画も確認してください。

#### 絞り込み条件が存在しない

そもそもレコードを絞り込む条件が存在しないので、インデックスは使用できません。

```sql
select
    * 
from
    sample_parent
;
```

#### ほとんどレコードを絞り込めない

WHERE句の条件でインデックスが作成されているid列を使用しています。しかし、条件に合致するレコードが多すぎるため、インデックスは使用されません。  

```sql
select
    * 
from
    sample_parent
where
    id > 0 and id < 9000000
;
```

さらに、上記のSQLの条件を変更して(例えば`id > 0 and id < 5000000`)、どの程度絞り込めるときにインデックスが使用されるか確認してください。

#### 索引列で演算を行っている

索引列で演算を行うと、インデックスは使用されません。

```sql
select
    * 
from
    sample_parent
where
    id * 10 < 10000
;
```

一方、式変形を行って索引列で演算を行わない形にすると、インデックスが有効になります。もちろん、返却されるレコードは式変形を行う前と同一です。

```sql
select
    * 
from
    sample_parent
where
    id  < 1000
;
```

#### 索引列に対して関数を使用している

索引列に対して関数を使用している場合も、インデックスは使用されません。

```sql
select
    * 
from
    sample_parent
where
    abs(id) = 1
;
```

#### 否定形を使用している

索引列に対して否定形を使用する場合も、インデックスは使用されません。

```sql
select
    * 
from
    sample_parent
where
    id <> 1 and id < 10000
;
```

### インデックス更新のコスト

インデックスを作成した列が更新された場合(新規レコードの挿入も含む)、インデックスの更新処理が発生します。そのため、多くのインデックスが作成されている場合、更新や挿入のパフォーマンスが悪くなることがあります。  
以下のSQLを実行することで、インデックスの有無によるレコード挿入にかかる時間の変化を確認します。

まず、以下のSQLを実行して、id_noindex列とcol_01列にインデックスを作成してください(作成済みの場合はエラーとなりますが無視してください)。

```sql
create index idx_id_noindex on public.sample_parent(id_noindex);
create index idx_col_01 on public.sample_parent(col_01);
```

以下のSQLは、sample_parentテーブルに100万行を挿入するSQLです。これを実行し、実行時間をメモしておいてください。

```sql
INSERT 
INTO public.sample_parent(id, id_noindex, col_01) 
SELECT
    i
    , i 
    , CEIL(i / 1001) 
FROM
    generate_series(10000001, 11000000) as i
;
```

次に、上記のSQLで挿入したレコードを削除します。

```sql
delete 
from
    sample_parent 
where
    id > 10000000;
```

さらに、インデックスも削除し、念のため統計情報を更新します。

```sql
drop index idx_id_noindex;
drop index idx_col_01;
analyze sample_parent;
```

最後に、先ほどと同様にsample_parentテーブルに100万行を挿入します。実行時間をメモしておいてください。

```sql
INSERT 
INTO public.sample_parent(id, id_noindex, col_01) 
SELECT
    i
    , i 
    , CEIL(i / 1001) 
FROM
    generate_series(10000001, 11000000) as i
;
```

SQLの実行にかかった時間を比較し、インデックスの有無による実行時間の変化を確認してください。
