# はじめに

## 概要

- このドキュメントは、パフォーマンスを意識したSQLの作成方法について学習する目的で作成されました。
- このドキュメントの主な対象読者は、以下のとおりです。
  - SQLやDBの基礎知識を持っている方(新人研修の学習範囲、SQLの基本文法を理解できていればよい)
  - 案件などでパフォーマンスを意識したSQLを作成する必要がある方

## ドキュメントの構成

- [環境構築](documents/environment.md)
- [パフォーマンスチューニングの手順](documents/tuning_procedure.md)
- [実行計画と統計情報](documents/analyze_sql.md)
- [結合](documents/join.md)
- [サブクエリ](documents/subquery.md)
- [更新系SQLのチューニング](documents/update.md)
- [インデックス](documents/index.md)
- [その他のSQLチューニング手法](documents/etc.md)

## 使い方

- TODO

## お問い合わせ先

ご意見、ご感想などがございましたら、以下の問い合わせ先まで遠慮なくご連絡ください。

- デジタル企画推進部 技術教育チーム(柴田、加藤)
  - メールアドレス: si-kyoiku@dcs.co.jp
  - [デジタル企画推進部セミナーサイト](https://mridcs.sharepoint.com/sites/seminar2)
