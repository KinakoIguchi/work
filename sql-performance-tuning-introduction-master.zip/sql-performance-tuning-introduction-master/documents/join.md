# 結合

ここでは、結合の基本的知識と、結合のパフォーマンスチューニングの方法を解説します。  
結合を含むSQLは、その実行時間やリソース消費(特にメモリ消費)が問題となることが多いです。しかし、パフォーマンスチューニングの手段はかなり限定されます。したがって、「結合を使用しない」ことが解決への近道という場合もあります。  
結合を使用したSQLの性能改善の手段として、ヒント句を使用した実行計画の操作があります。この方法は有効な場合もある反面、かえって性能劣化の原因となることもあるので、注意が必要です。

---

- [結合](#結合)
	- [結合の種類](#結合の種類)
		- [クロス結合](#クロス結合)
			- [意図しないクロス結合](#意図しないクロス結合)
		- [内部結合](#内部結合)
			- [内部結合と相関サブクエリ](#内部結合と相関サブクエリ)
		- [外部結合](#外部結合)
			- [外部結合の種類](#外部結合の種類)
	- [結合のアルゴリズムとパフォーマンス](#結合のアルゴリズムとパフォーマンス)
		- [Nested Loops](#nested-loops)
			- [Nested Loopsの性能改善](#nested-loopsの性能改善)
			- [Nested Loopsの注意点](#nested-loopsの注意点)
		- [Hash](#hash)
			- [Hashの特徴](#hashの特徴)
			- [Hashが有効なケースと注意点](#hashが有効なケースと注意点)
		- [Sort Merge](#sort-merge)
			- [Sort Mergeの特徴](#sort-mergeの特徴)
			- [Sort Mergeの注意点](#sort-mergeの注意点)
		- [結合アルゴリズムのまとめ](#結合アルゴリズムのまとめ)
	- [結合が遅い場合の対処法](#結合が遅い場合の対処法)
		- [ケースごとの最適な結合アルゴリズム](#ケースごとの最適な結合アルゴリズム)
		- [実行計画の制御とその限界](#実行計画の制御とその限界)

---

## 結合の種類

機能別に分類した以下の結合について解説します。

- クロス結合
- 内部結合
- 外部結合

各結合について理解している方は、ここは飛ばして、次の「[結合のアルゴリズムとパフォーマンス](#結合のアルゴリズムとパフォーマンス)」からお読みください。

### クロス結合

クロス結合は、この後に説明する内部結合と外部結合の基準となっている結合の方法です。クロス結合を実務で使用することはまずありませんが、この後の説明の都合上、最初に解説します。

例として、以下の2つのテーブルのクロス結合について確認します。

booksテーブル

| book_no | title                            | author     | publisher            | price | stock |
| ------: | :------------------------------- | :--------- | :------------------- | ----: | ----: |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |
|       2 | Javaプログラミングサンプル１００ | 岡本　雅文 | 技術出版社           |  1560 |    20 |
|       4 | windowsＸＰ全機能徹底解説        | 渋谷　博善 | 瀬戸メディアワークス |  2200 |    20 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |
|       7 | WEBデザインの大原則              | 里見　陽子 | 瀬戸メディアワークス |  1520 |    20 |

ordersテーブル

| ord_no | cust_no | book_no | ord_qty |   ord_date |
| -----: | ------: | ------: | ------: | ---------: |
|      1 |       1 |       1 |       3 | 2020/06/16 |
|      2 |       2 |       1 |       2 | 2020/06/16 |
|      3 |       1 |       2 |       4 | 2020/06/16 |
|      4 |       2 |       6 |       5 | 2020/06/16 |
|      5 |       1 |       6 |       2 | 2020/06/16 |
|      6 |       3 |       4 |       1 | 2020/06/16 |
|      7 |       3 |       6 |       1 | 2020/06/16 |
|      8 |       5 |       1 |       1 | 2020/06/16 |
|      9 |       5 |       1 |       5 | 2020/06/16 |

この2つのテーブルをクロス結合するSQLは、以下のとおりです。

```sql
select
    * 
from
    books as b 
    cross join orders as o
;
```

SQLを実行すると、以下の結果が得られます。

| book_no | title                            | author     | publisher            | price | stock | ord_no | cust_no | book_no_1 | ord_qty |   ord_date |
| ------: | :------------------------------- | :--------- | :------------------- | ----: | ----: | -----: | ------: | --------: | ------: | ---------: |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      1 |       1 |         1 |       3 | 2020/06/16 |
|       2 | Javaプログラミングサンプル１００ | 岡本　雅文 | 技術出版社           |  1560 |    20 |      1 |       1 |         1 |       3 | 2020/06/16 |
|       4 | windowsＸＰ全機能徹底解説        | 渋谷　博善 | 瀬戸メディアワークス |  2200 |    20 |      1 |       1 |         1 |       3 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      1 |       1 |         1 |       3 | 2020/06/16 |
|       7 | WEBデザインの大原則              | 里見　陽子 | 瀬戸メディアワークス |  1520 |    20 |      1 |       1 |         1 |       3 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      2 |       2 |         1 |       2 | 2020/06/16 |
|       2 | Javaプログラミングサンプル１００ | 岡本　雅文 | 技術出版社           |  1560 |    20 |      2 |       2 |         1 |       2 | 2020/06/16 |
|       4 | windowsＸＰ全機能徹底解説        | 渋谷　博善 | 瀬戸メディアワークス |  2200 |    20 |      2 |       2 |         1 |       2 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      2 |       2 |         1 |       2 | 2020/06/16 |
|       7 | WEBデザインの大原則              | 里見　陽子 | 瀬戸メディアワークス |  1520 |    20 |      2 |       2 |         1 |       2 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      4 |       2 |         6 |       5 | 2020/06/16 |
|       2 | Javaプログラミングサンプル１００ | 岡本　雅文 | 技術出版社           |  1560 |    20 |      4 |       2 |         6 |       5 | 2020/06/16 |
|       4 | windowsＸＰ全機能徹底解説        | 渋谷　博善 | 瀬戸メディアワークス |  2200 |    20 |      4 |       2 |         6 |       5 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      4 |       2 |         6 |       5 | 2020/06/16 |
|       7 | WEBデザインの大原則              | 里見　陽子 | 瀬戸メディアワークス |  1520 |    20 |      4 |       2 |         6 |       5 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      3 |       1 |         2 |       4 | 2020/06/16 |
|       2 | Javaプログラミングサンプル１００ | 岡本　雅文 | 技術出版社           |  1560 |    20 |      3 |       1 |         2 |       4 | 2020/06/16 |
|       4 | windowsＸＰ全機能徹底解説        | 渋谷　博善 | 瀬戸メディアワークス |  2200 |    20 |      3 |       1 |         2 |       4 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      3 |       1 |         2 |       4 | 2020/06/16 |
|       7 | WEBデザインの大原則              | 里見　陽子 | 瀬戸メディアワークス |  1520 |    20 |      3 |       1 |         2 |       4 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      5 |       1 |         6 |       2 | 2020/06/16 |
|       2 | Javaプログラミングサンプル１００ | 岡本　雅文 | 技術出版社           |  1560 |    20 |      5 |       1 |         6 |       2 | 2020/06/16 |
|       4 | windowsＸＰ全機能徹底解説        | 渋谷　博善 | 瀬戸メディアワークス |  2200 |    20 |      5 |       1 |         6 |       2 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      5 |       1 |         6 |       2 | 2020/06/16 |
|       7 | WEBデザインの大原則              | 里見　陽子 | 瀬戸メディアワークス |  1520 |    20 |      5 |       1 |         6 |       2 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      6 |       3 |         4 |       1 | 2020/06/16 |
|       2 | Javaプログラミングサンプル１００ | 岡本　雅文 | 技術出版社           |  1560 |    20 |      6 |       3 |         4 |       1 | 2020/06/16 |
|       4 | windowsＸＰ全機能徹底解説        | 渋谷　博善 | 瀬戸メディアワークス |  2200 |    20 |      6 |       3 |         4 |       1 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      6 |       3 |         4 |       1 | 2020/06/16 |
|       7 | WEBデザインの大原則              | 里見　陽子 | 瀬戸メディアワークス |  1520 |    20 |      6 |       3 |         4 |       1 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      7 |       3 |         6 |       1 | 2020/06/16 |
|       2 | Javaプログラミングサンプル１００ | 岡本　雅文 | 技術出版社           |  1560 |    20 |      7 |       3 |         6 |       1 | 2020/06/16 |
|       4 | windowsＸＰ全機能徹底解説        | 渋谷　博善 | 瀬戸メディアワークス |  2200 |    20 |      7 |       3 |         6 |       1 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      7 |       3 |         6 |       1 | 2020/06/16 |
|       7 | WEBデザインの大原則              | 里見　陽子 | 瀬戸メディアワークス |  1520 |    20 |      7 |       3 |         6 |       1 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      8 |       5 |         1 |       1 | 2020/06/16 |
|       2 | Javaプログラミングサンプル１００ | 岡本　雅文 | 技術出版社           |  1560 |    20 |      8 |       5 |         1 |       1 | 2020/06/16 |
|       4 | windowsＸＰ全機能徹底解説        | 渋谷　博善 | 瀬戸メディアワークス |  2200 |    20 |      8 |       5 |         1 |       1 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      8 |       5 |         1 |       1 | 2020/06/16 |
|       7 | WEBデザインの大原則              | 里見　陽子 | 瀬戸メディアワークス |  1520 |    20 |      8 |       5 |         1 |       1 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      9 |       5 |         1 |       5 | 2020/06/16 |
|       2 | Javaプログラミングサンプル１００ | 岡本　雅文 | 技術出版社           |  1560 |    20 |      9 |       5 |         1 |       5 | 2020/06/16 |
|       4 | windowsＸＰ全機能徹底解説        | 渋谷　博善 | 瀬戸メディアワークス |  2200 |    20 |      9 |       5 |         1 |       5 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      9 |       5 |         1 |       5 | 2020/06/16 |
|       7 | WEBデザインの大原則              | 里見　陽子 | 瀬戸メディアワークス |  1520 |    20 |      9 |       5 |         1 |       5 | 2020/06/16 |

まず、結合前の各テーブルのレコード数よりもかなり多い件数が出力されていることがわかります。以下、上記の結果となった理由を説明します。  
クロス結合では、結合対象となる2つのテーブルの各レコードについて、すべての組み合わせを網羅するような演算が行われます。そのため、booksテーブルの5レコードとordersテーブルの9レコードのすべての組み合わせ、すなわち`5 × 9 = 45`レコードが結果として得られることになります。ちなみに、このような計算を数学的には「直積」や「デカルト積」と呼びます。

繰り返しになりますが、クロス結合は業務において使用されることがほとんどありません。その理由は大きく2つあります。

- 実業務において、このような結合が必要となる状況がないため
- 実行コストがかかる計算であるため

#### 意図しないクロス結合

ここまで述べてきたとおり、クロス結合を実務で使用することはありません。しかし、結合の仕方にミスがあると意図しないクロス結合が発生し、その結果として実行効率の悪いSQLとなることがあります。

意図しないクロス結合が発生する代表的なケースは、古い(そのため現在は非推奨の)SQL文法で結合を行う場合に、結合条件を書き忘れた場合です。

以下のSQLは、booksテーブルとordersテーブルが持つbook_no列を結合条件として、古いSQL文法を使用して結合を行うことを意図しています。しかし、結合条件を記述しておらず、結果的に意図しないクロス結合が発生します。

意図しないクロス結合が発生するSQL

```sql
select
    * 
from
    books as b
    , orders as o
-- 結合条件なし
;
```

もちろん、結合条件を正しく記述すれば、クロス結合は発生しません(実行計画上は後述の内部結合となります)。

クロス結合が発生しないSQL

```sql
select
    * 
from
    books as b
    , orders as o 
-- 以下が結合条件
where
    b.book_no = o.book_no
;
```

今回のSQL例は2つのテーブルのシンプルな結合のため、通常はミスが発生することはないと思います。しかし、実業務ではもっと多くのテーブルを一つのSQLで結合するケースが多く、その場合に結合条件を書き漏らしてしまうことは少なくありません。  
このようなミスを予防する方法として一番確実なのは、古いSQL文法(`表1, 表2 where 結合条件`)で結合するのではなく、`INNER JOIN`のような標準SQLに則った文法を使用することです。標準SQLであれば、結合条件がなかった場合はエラーとなり、SQL自体が実行できないため、意図しないクロス結合の実行を未然に防ぐことができます(意図的にクロス結合をしたい場合であっても`CROSS JOIN`を使用すべきです)。  
また、1つのSQLで複数のタスクを行うために長文のSQLを記述した場合にもクロス結合が発生しやすいため、1つのSQLをできるだけシンプルにすることも重要です。その上で、例えば1つの複雑なSQLをタスクごとにいくつかのSQLに分割して、これらの実行結果をアプリケーション側でまとめる、といった処理方式を検討することも一案です。また、どうしても1つのSQLにまとめる必要がある場合は、状況に応じてUNIONの使用も検討します。

### 内部結合

booksテーブルとordersテーブルを再び使用して、内部結合の例を見ていきます。いずれのテーブルにも「book_no」という列があり、この列には互いに対応する値が入っているので、これを結合条件として内部結合を実行します。

```sql
select
    * 
from
    books as b 
    inner join orders as o 
        on b.book_no = o.book_no                
-- 結合結果そのままだと読みづらいので、book_no列でソート
order by
    b.book_no
;
```

実行結果

| book_no | title                            | author     | publisher            | price | stock | ord_no | cust_no | book_no_1 | ord_qty |   ord_date |
| ------: | :------------------------------- | :--------- | :------------------- | ----: | ----: | -----: | ------: | --------: | ------: | ---------: |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      1 |       1 |         1 |       3 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      2 |       2 |         1 |       2 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      8 |       5 |         1 |       1 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      9 |       5 |         1 |       5 | 2020/06/16 |
|       2 | Javaプログラミングサンプル１００ | 岡本　雅文 | 技術出版社           |  1560 |    20 |      3 |       1 |         2 |       4 | 2020/06/16 |
|       4 | windowsＸＰ全機能徹底解説        | 渋谷　博善 | 瀬戸メディアワークス |  2200 |    20 |      6 |       3 |         4 |       1 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      5 |       1 |         6 |       2 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      7 |       3 |         6 |       1 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      4 |       2 |         6 |       5 | 2020/06/16 |

次に、この結果と先述のクロス結合の結果とを見比べます。そうすると、内部結合の結果は、クロス結合の結果の一部となっていることがわかります。言い換えると、「内部結合はクロス結合の部分集合である」ということです。

以下に、クロス結合の結果を再掲します。表のうち、網掛けになっている行は内部結合と同一の行です。この表で、内部結合はクロス結合の部分集合となっていることを確認してください。

<table>
	<tr>
		<th>book_no</th>
		<th>title</th>
		<th>author</th>
		<th>publisher</th>
		<th>price</th>
		<th>stock</th>
		<th>ord_no</th>
		<th>cust_no</th>
		<th>book_no_1</th>
		<th>ord_qty</th>
		<th>ord_date</th>
	</tr>
	<tr>
		<th style="text-align: right" nowrap>1</th>
		<th nowrap >Ｃプログラミング大辞典</th>
		<th nowrap>宮崎　満</th>
		<th nowrap>テクニカルブックス</th>
		<th style="text-align: right" nowrap>2200</th>
		<th style="text-align: right" nowrap>20</th>
		<th style="text-align: right" nowrap>9</th>
		<th style="text-align: right" nowrap>5</th>
		<th style="text-align: right" nowrap>1</th>
		<th style="text-align: right" nowrap>5</th>
		<th style="text-align: right" nowrap>2020/06/16</th>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>1</td>
		<td nowrap>Ｃプログラミング大辞典</td>
		<td nowrap>宮崎　満</td>
		<td nowrap>テクニカルブックス</td>
		<td style="text-align: right" nowrap>2200</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<th style="text-align: right" nowrap>1</th>
		<th nowrap>Ｃプログラミング大辞典</th>
		<th nowrap>宮崎　満</th>
		<th nowrap>テクニカルブックス</th>
		<th style="text-align: right" nowrap>2200</th>
		<th style="text-align: right" nowrap>20</th>
		<th style="text-align: right" nowrap>2</th>
		<th style="text-align: right" nowrap>2</th>
		<th style="text-align: right" nowrap>1</th>
		<th style="text-align: right" nowrap>2</th>
		<th style="text-align: right" nowrap>2020/06/16</th>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>1</td>
		<td nowrap>Ｃプログラミング大辞典</td>
		<td nowrap>宮崎　満</td>
		<td nowrap>テクニカルブックス</td>
		<td style="text-align: right" nowrap>2200</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>4</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<th style="text-align: right" nowrap>1</th>
		<th nowrap>Ｃプログラミング大辞典</th>
		<th nowrap>宮崎　満</th>
		<th nowrap>テクニカルブックス</th>
		<th style="text-align: right" nowrap>2200</th>
		<th style="text-align: right" nowrap>20</th>
		<th style="text-align: right" nowrap>8</th>
		<th style="text-align: right" nowrap>5</th>
		<th style="text-align: right" nowrap>1</th>
		<th style="text-align: right" nowrap>1</th>
		<th style="text-align: right" nowrap>2020/06/16</th>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>1</td>
		<td nowrap>Ｃプログラミング大辞典</td>
		<td nowrap>宮崎　満</td>
		<td nowrap>テクニカルブックス</td>
		<td style="text-align: right" nowrap>2200</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>4</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>1</td>
		<td nowrap>Ｃプログラミング大辞典</td>
		<td nowrap>宮崎　満</td>
		<td nowrap>テクニカルブックス</td>
		<td style="text-align: right" nowrap>2200</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>7</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>1</td>
		<td nowrap>Ｃプログラミング大辞典</td>
		<td nowrap>宮崎　満</td>
		<td nowrap>テクニカルブックス</td>
		<td style="text-align: right" nowrap>2200</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>4</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<th style="text-align: right" nowrap>1</th>
		<th nowrap>Ｃプログラミング大辞典</th>
		<th nowrap>宮崎　満</th>
		<th nowrap>テクニカルブックス</th>
		<th style="text-align: right" nowrap>2200</th>
		<th style="text-align: right" nowrap>20</th>
		<th style="text-align: right" nowrap>1</th>
		<th style="text-align: right" nowrap>1</th>
		<th style="text-align: right" nowrap>1</th>
		<th style="text-align: right" nowrap>3</th>
		<th style="text-align: right" nowrap>2020/06/16</th>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>2</td>
		<td nowrap>Javaプログラミングサンプル１００</td>
		<td nowrap>岡本　雅文</td>
		<td nowrap>技術出版社</td>
		<td style="text-align: right" nowrap>1560</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>7</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>2</td>
		<td nowrap>Javaプログラミングサンプル１００</td>
		<td nowrap>岡本　雅文</td>
		<td nowrap>技術出版社</td>
		<td style="text-align: right" nowrap>1560</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>4</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<th style="text-align: right" nowrap>2</th>
		<th nowrap>Javaプログラミングサンプル１００</th>
		<th nowrap>岡本　雅文</th>
		<th nowrap>技術出版社</th>
		<th style="text-align: right" nowrap>1560</th>
		<th style="text-align: right" nowrap>20</th>
		<th style="text-align: right" nowrap>3</th>
		<th style="text-align: right" nowrap>1</th>
		<th style="text-align: right" nowrap>2</th>
		<th style="text-align: right" nowrap>4</th>
		<th style="text-align: right" nowrap>2020/06/16</th>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>2</td>
		<td nowrap>Javaプログラミングサンプル１００</td>
		<td nowrap>岡本　雅文</td>
		<td nowrap>技術出版社</td>
		<td style="text-align: right" nowrap>1560</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>2</td>
		<td nowrap>Javaプログラミングサンプル１００</td>
		<td nowrap>岡本　雅文</td>
		<td nowrap>技術出版社</td>
		<td style="text-align: right" nowrap>1560</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>4</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>2</td>
		<td nowrap>Javaプログラミングサンプル１００</td>
		<td nowrap>岡本　雅文</td>
		<td nowrap>技術出版社</td>
		<td style="text-align: right" nowrap>1560</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>9</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>2</td>
		<td nowrap>Javaプログラミングサンプル１００</td>
		<td nowrap>岡本　雅文</td>
		<td nowrap>技術出版社</td>
		<td style="text-align: right" nowrap>1560</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>2</td>
		<td nowrap>Javaプログラミングサンプル１００</td>
		<td nowrap>岡本　雅文</td>
		<td nowrap>技術出版社</td>
		<td style="text-align: right" nowrap>1560</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>2</td>
		<td nowrap>Javaプログラミングサンプル１００</td>
		<td nowrap>岡本　雅文</td>
		<td nowrap>技術出版社</td>
		<td style="text-align: right" nowrap>1560</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>8</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<th style="text-align: right" nowrap>4</th>
		<th nowrap>windowsＸＰ全機能徹底解説</th>
		<th nowrap>渋谷　博善</th>
		<th nowrap>瀬戸メディアワークス</th>
		<th style="text-align: right" nowrap>2200</th>
		<th style="text-align: right" nowrap>20</th>
		<th style="text-align: right" nowrap>6</th>
		<th style="text-align: right" nowrap>3</th>
		<th style="text-align: right" nowrap>4</th>
		<th style="text-align: right" nowrap>1</th>
		<th style="text-align: right" nowrap>2020/06/16</th>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>4</td>
		<td nowrap>windowsＸＰ全機能徹底解説</td>
		<td nowrap>渋谷　博善</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>2200</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>4</td>
		<td nowrap>windowsＸＰ全機能徹底解説</td>
		<td nowrap>渋谷　博善</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>2200</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>4</td>
		<td nowrap>windowsＸＰ全機能徹底解説</td>
		<td nowrap>渋谷　博善</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>2200</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>4</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>4</td>
		<td nowrap>windowsＸＰ全機能徹底解説</td>
		<td nowrap>渋谷　博善</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>2200</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>4</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>4</td>
		<td nowrap>windowsＸＰ全機能徹底解説</td>
		<td nowrap>渋谷　博善</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>2200</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>4</td>
		<td nowrap>windowsＸＰ全機能徹底解説</td>
		<td nowrap>渋谷　博善</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>2200</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>7</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>4</td>
		<td nowrap>windowsＸＰ全機能徹底解説</td>
		<td nowrap>渋谷　博善</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>2200</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>8</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>4</td>
		<td nowrap>windowsＸＰ全機能徹底解説</td>
		<td nowrap>渋谷　博善</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>2200</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>9</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>6</td>
		<td nowrap>Word入門講座</td>
		<td nowrap>小島　基彦</td>
		<td nowrap>テクニカルブックス</td>
		<td style="text-align: right" nowrap>1100</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>4</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>6</td>
		<td nowrap>Word入門講座</td>
		<td nowrap>小島　基彦</td>
		<td nowrap>テクニカルブックス</td>
		<td style="text-align: right" nowrap>1100</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>4</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<th style="text-align: right" nowrap>6</th>
		<th nowrap>Word入門講座</th>
		<th nowrap>小島　基彦</th>
		<th nowrap>テクニカルブックス</th>
		<th style="text-align: right" nowrap>1100</th>
		<th style="text-align: right" nowrap>20</th>
		<th style="text-align: right" nowrap>4</th>
		<th style="text-align: right" nowrap>2</th>
		<th style="text-align: right" nowrap>6</th>
		<th style="text-align: right" nowrap>5</th>
		<th style="text-align: right" nowrap>2020/06/16</th>
	</tr>
	<tr>
		<th style="text-align: right" nowrap>6</th>
		<th nowrap>Word入門講座</th>
		<th nowrap>小島　基彦</th>
		<th nowrap>テクニカルブックス</th>
		<th style="text-align: right" nowrap>1100</th>
		<th style="text-align: right" nowrap>20</th>
		<th style="text-align: right" nowrap>7</th>
		<th style="text-align: right" nowrap>3</th>
		<th style="text-align: right" nowrap>6</th>
		<th style="text-align: right" nowrap>1</th>
		<th style="text-align: right" nowrap>2020/06/16</th>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>6</td>
		<td nowrap>Word入門講座</td>
		<td nowrap>小島　基彦</td>
		<td nowrap>テクニカルブックス</td>
		<td style="text-align: right" nowrap>1100</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>6</td>
		<td nowrap>Word入門講座</td>
		<td nowrap>小島　基彦</td>
		<td nowrap>テクニカルブックス</td>
		<td style="text-align: right" nowrap>1100</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>9</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>6</td>
		<td nowrap>Word入門講座</td>
		<td nowrap>小島　基彦</td>
		<td nowrap>テクニカルブックス</td>
		<td style="text-align: right" nowrap>1100</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>8</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>6</td>
		<td nowrap>Word入門講座</td>
		<td nowrap>小島　基彦</td>
		<td nowrap>テクニカルブックス</td>
		<td style="text-align: right" nowrap>1100</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<th style="text-align: right" nowrap>6</th>
		<th nowrap>Word入門講座</th>
		<th nowrap>小島　基彦</th>
		<th nowrap>テクニカルブックス</th>
		<th style="text-align: right" nowrap>1100</th>
		<th style="text-align: right" nowrap>20</th>
		<th style="text-align: right" nowrap>5</th>
		<th style="text-align: right" nowrap>1</th>
		<th style="text-align: right" nowrap>6</th>
		<th style="text-align: right" nowrap>2</th>
		<th style="text-align: right" nowrap>2020/06/16</th>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>7</td>
		<td nowrap>WEBデザインの大原則</td>
		<td nowrap>里見　陽子</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>1520</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>7</td>
		<td nowrap>WEBデザインの大原則</td>
		<td nowrap>里見　陽子</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>1520</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>4</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>7</td>
		<td nowrap>WEBデザインの大原則</td>
		<td nowrap>里見　陽子</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>1520</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>4</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>7</td>
		<td nowrap>WEBデザインの大原則</td>
		<td nowrap>里見　陽子</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>1520</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>4</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>7</td>
		<td nowrap>WEBデザインの大原則</td>
		<td nowrap>里見　陽子</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>1520</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>7</td>
		<td nowrap>WEBデザインの大原則</td>
		<td nowrap>里見　陽子</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>1520</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>9</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>7</td>
		<td nowrap>WEBデザインの大原則</td>
		<td nowrap>里見　陽子</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>1520</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>8</td>
		<td style="text-align: right" nowrap>5</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>7</td>
		<td nowrap>WEBデザインの大原則</td>
		<td nowrap>里見　陽子</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>1520</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>7</td>
		<td style="text-align: right" nowrap>3</td>
		<td style="text-align: right" nowrap>6</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
	<tr>
		<td style="text-align: right" nowrap>7</td>
		<td nowrap>WEBデザインの大原則</td>
		<td nowrap>里見　陽子</td>
		<td nowrap>瀬戸メディアワークス</td>
		<td style="text-align: right" nowrap>1520</td>
		<td style="text-align: right" nowrap>20</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>1</td>
		<td style="text-align: right" nowrap>2</td>
		<td style="text-align: right" nowrap>2020/06/16</td>
	</tr>
</table>

「内部結合」という言葉の語源は、この「クロス結合」との関係性にあります。つまり、内部結合の「内部」とは、直積(クロス結合)の部分集合(内部)である、ということです。

#### 内部結合と相関サブクエリ

内部結合は、相関サブクエリに書き換えることができるケースがあります。基本的に、内部結合で記述できる場合は内部結合で記述したほうが効率は良いですが、念のため書き換えの仕方について確認します。

例えば、以下に再掲する内部結合のSQLは、相関サブクエリに書き換えることができます。

内部結合のSQL(再掲)

```sql
select
    * 
from
    books as b 
    inner join orders as o 
        on b.book_no = o.book_no                
-- 結合結果そのままだと読みづらいので、book_no列でソート
order by
    b.book_no
;
```
相関サブクエリに書き換えたSQL

```sql
select
    ( 
        select
            book_no 
        from
            books as b 
        where
            b.book_no = o.book_no
    ) 
    , ( 
        select
            title 
        from
            books as b 
        where
            b.book_no = o.book_no
    ) 
    , ( 
        select
            author 
        from
            books as b 
        where
            b.book_no = o.book_no
    ) 
    , ( 
        select
            publisher 
        from
            books as b 
        where
            b.book_no = o.book_no
    ) 
    , ( 
        select
            price 
        from
            books as b 
        where
            b.book_no = o.book_no
    ) 
    , ( 
        select
            stock 
        from
            books as b 
        where
            b.book_no = o.book_no
    ) 
    , o.* 
from
    orders as o 
order by
    o.ord_no

```

実行結果

| book_no | title                            | author     | publisher            | price | stock | ord_no | cust_no | book_no_1 | ord_qty |   ord_date |
| ------: | :------------------------------- | :--------- | :------------------- | ----: | ----: | -----: | ------: | --------: | ------: | ---------: |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      1 |       1 |         1 |       3 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      2 |       2 |         1 |       2 | 2020/06/16 |
|       2 | Javaプログラミングサンプル１００ | 岡本　雅文 | 技術出版社           |  1560 |    20 |      3 |       1 |         2 |       4 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      4 |       2 |         6 |       5 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      5 |       1 |         6 |       2 | 2020/06/16 |
|       4 | windowsＸＰ全機能徹底解説        | 渋谷　博善 | 瀬戸メディアワークス |  2200 |    20 |      6 |       3 |         4 |       1 | 2020/06/16 |
|       6 | Word入門講座                     | 小島　基彦 | テクニカルブックス   |  1100 |    20 |      7 |       3 |         6 |       1 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      8 |       5 |         1 |       1 | 2020/06/16 |
|       1 | Ｃプログラミング大辞典           | 宮崎　満   | テクニカルブックス   |  2200 |    20 |      9 |       5 |         1 |       5 | 2020/06/16 |

実行結果のソート順こそordersテーブルのord_no昇順となっているものの、得られたレコードと列順は内部結合の場合と同じです。

このSQLのポイントは、SELECT句の相関サブクエリです。相関サブクエリ内のWHERE句で結合条件を指定していますが、ordersテーブルのレコードから見てbooksテーブルのレコードは一意(orders:books = 多:1の関係)なので、booksテーブルの主キーbook_noを条件に指定すれば一意に定まることが保証され、それぞれの相関サブクエリは必ず1つの戻り値を返却するサブクエリ(これをスカラサブクエリと呼ぶ)となります。ちなみに、相関サブクエリ内のFROM句をordersとして、booksテーブルとの結合条件を指定することはできません。なぜなら、booksテーブルのレコードから見てordersテーブルのレコードは一意ではなく複数(books:orders = 1:多の関係)のため、相関サブクエリの結果が一つに定まらないからです。

先述のとおり、内部結合と相関サブクエリで同じ結果が取得できる場合は、内部結合の方が効率よく実行できるケースがほとんどです。なぜなら、今回のように相関サブクエリをスカラサブクエリとして使用した場合、得られるレコード数だけ相関サブクエリが実行されることになり、一般に高コストな処理となるからです。よって、相関サブクエリでしか実装できないなどの理由がない限り、内部結合を使用して実装するようにしてください。

### 外部結合

外部結合も、内部結合と同様に実案件でよく使用する結合方法です。内部結合はクロス結合の結果(直積)の部分集合(内部)となっていましたが、外部結合はクロス結合の結果(直積)の部分集合(内部)にはならないことがあります。クロス結合の結果(直積)から外部にはみ出す、というイメージです。

#### 外部結合の種類

外部結合には、以下の種類があります。

- 左外部結合
- 右外部結合
- 完全外部結合

このうち、「左外部結合」と「右外部結合」は実質的に同じ動作を行うもので、単にマスタとなるテーブルがSQL上で左にあれば「左外部結合」、右にあれば「右外部結合」を使用する、という使い分けがあるだけです。

以下の例は左外部結合と右外部結合の実行例です(結合結果の一部列のみを取得しています)。実行結果はまったくの同一です。マスタのテーブルはいずれもbooksテーブルとしているため、左外部結合と右外部結合とで、booksテーブルとordersテーブルの位置が反対になっています。

左外部結合の例

```sql
select
    b.book_no
    , b.title
    , o.ord_no
    , o.ord_qty 
from
    books as b 
    left outer join orders as o 
        on b.book_no = o.book_no                
-- 結合結果そのままだと読みづらいので、book_no列でソート
order by
    b.book_no
;
```

右外部結合の例

```sql
select
    b.book_no
    , b.title
    , o.ord_no
    , o.ord_qty 
from
    orders as o 
    right outer join books as b 
        on o.book_no = b.book_no                
-- 結合結果そのままだと読みづらいので、book_no列でソート
order by
    b.book_no
;
```

実行結果(同一)

| book_no | title                            | ord_no | ord_qty |
| ------: | :------------------------------- | -----: | ------: |
|       1 | Ｃプログラミング大辞典           |      1 |       3 |
|       1 | Ｃプログラミング大辞典           |      2 |       2 |
|       1 | Ｃプログラミング大辞典           |      9 |       5 |
|       1 | Ｃプログラミング大辞典           |      8 |       1 |
|       2 | Javaプログラミングサンプル１００ |      3 |       4 |
|       4 | windowsＸＰ全機能徹底解説        |      6 |       1 |
|       6 | Word入門講座                     |      7 |       1 |
|       6 | Word入門講座                     |      5 |       2 |
|       6 | Word入門講座                     |      4 |       5 |
|       7 | WEBデザインの大原則              |        |         |

実行結果の最終行を見ると、ord_no列とord_qty列がNULLのレコードが出力されています。これは、クロス結合には含まれていなかったレコードです。この例からもわかるとおり、外部結合ではマスタテーブル側だけに存在するキーがあった場合、そのキーを削除せず、実行結果に保存するという挙動になります(`book_no = 7`の行)。そのため、マスタテーブル側のキーの値をすべて保持したい場合に使用されます。

上述の外部結合の結果のうち、book_noが1~6のものについては内部結合の結果と同一です(取得する列は省略していますが)。一方で、最終行については、内部結合はもちろん、その基準となるクロス結合でも取得しなかった行となります。この部分が、「外部」にはみ出しているようなイメージで、これが「外部結合」という名前の由来になっています。

## 結合のアルゴリズムとパフォーマンス

以下では、結合のアルゴリズムと、そのパフォーマンスについて解説します。  
オプティマイザがとりうる結合のアルゴリズムは、以下の3つです。なお、オプティマイザが選択するアルゴリズムは、データサイズや結合条件などによって決まります。

- Nested Loops
- Hash
- Sort Merge

これらのアルゴリズムの概要については、「[analyze_sql.md#結合のアルゴリズム](analyze_sql.md#結合のアルゴリズム)」を確認してください。以下では、それぞれのアルゴリズムについて、性能面に着目して解説します。

### Nested Loops

Nested Loopsの特徴は、以下のとおりです。

- 2つのテーブル(テーブルA、テーブルB)の結合対象となる行数をそれぞれR(A)、R(B)と置けば、アクセス対象の行数はR(A) × R(B)となる。Nested Loopsの実行時間は、この行数に比例する
- 1つのステップ(内部処理の単位)で処理する行数が少ないため、HashやSort Mergeと比べてメモリ消費が少ない
- どのDBMSでも必ずサポートしている

Nested Loopsの性能を考える上で重要なポイントは、結合するテーブルのどちらを駆動表とするかという点です。一見すると、どちらが駆動表でもアクセス対象の行数はR(A) × R(B)もしくはR(B) × R(A)なので、性能は変わらないように思えます。しかし、実際には駆動表が小さいほどNested Loopsの性能が向上することが知られています。

#### Nested Loopsの性能改善

Nested Loopsの性能を改善する手法として、駆動表に小さなテーブルを選ぶ(≒内部表に大きいテーブルを選ぶ)ということがあります。以下では、なぜこのような手法が有効なのか、その理由を解説します。

「駆動表を小さくする」という性能改善手法の前提条件は、**内部表の結合キー列にインデックスが設定されていること**です。内部表の結合キーの列にインデックスが存在する場合、そのインデックスを使用することで、駆動表の各行に対して内部表をすべてスキャンする必要がなくなります。このことで、内部表に対するループ処理を一部スキップすることができるので、性能が改善するということです。

理想的なケースとして、内部表の結合キー列にインデックスが存在し、かつ駆動表のレコードが内部表のレコードと1対1で紐付いている場合を考えます。この場合、内部表のインデックスにアクセスすることで内部表のループが不要となります。この場合のアクセス行数はR(A) × 2(インデックス→内部表のレコード)となります。  
次に、内部表の結合キー列にインデックスが存在し、かつ駆動表のレコードが内部表のレコードと1対多で紐付いている場合を考えます。この場合もインデックスは使用できるため、インデックスが存在しない場合と比べれば高速な実行が可能です。ただし、駆動表のレコードに対して内部表の複数レコードが対応するので、そのレコード数分のループは必要となります。

ここまで、「駆動表に小さなテーブルを選ぶ」ことが、なぜ性能改善につながるのかについて、簡単に解説しました。この「駆動表に小さなテーブルを選ぶ」ということは、言い換えると「内部表に大きなテーブルを選ぶ」と性能改善に有効である、ということでもあります。なぜなら、インデックスで内部表のループ回数を減らすことによる効果は、内部表が大きければ大きいほど顕著になるからです。

#### Nested Loopsの注意点

上述の性能改善手法は、テーブルの状態によってはうまく機能しないことがあります。特に、駆動表が小さく、内部表が大きい状態であっても、駆動表と内部表の各レコードの関係が1:多の関係にある場合、性能改善ができないことがあります。この原因は、駆動表のあるレコードに対する結合対象となる内部表のレコードが多くなる場合に、インデックスを使用してもループ回数を削減できないことがあるからです。  
この問題のやっかいなところは、結合条件が(ユーザが指定した検索条件などにより)変動する場合に、ある結合条件では性能に問題がないが、別の結合条件では性能が劣化することがある点です。例えば、店舗情報をまとめた店舗テーブルを駆動表、各店舗の注文状況をまとめた注文テーブルを内部表として、両者を結合するケースを考えます。それぞれのテーブルは、

- 店舗:注文は1:多の関係にある
- 店舗テーブルが相対的に小さく、注文テーブルは店舗テーブルよりも十分に大きい
- 注文テーブルにおいて結合条件に使用する列(店舗IDなど各店舗を識別する列を想定)には、インデックスが設定されている
- 各店舗の売上には差があり、ある店舗では非常に多くの注文を受ける(店舗に紐づく注文が多い)一方、別の店舗ではほとんど注文がない(店舗に紐づく注文が少ない)

という状況とします。  
結合の際には、注文が少ない店舗の場合はループ回数が少なくて済むため、性能に問題はありません。一方で、注文が多い店舗の場合は注文テーブルから多数のレコードを結合する必要があるため、その分ループ回数も多くなります。したがって、注文が多い店舗に対する注文テーブルの結合は、そのループ回数の多さから性能劣化の可能性が高いです。

この問題に対処する方法としては、以下の2つが考えられます。

- 結合順を入れ替え、大きな駆動表と小さな内部表にする
  - 問題の根本原因は駆動表:内部表が1:多の関係であることなので、これを逆転して駆動表:内部表を多:1の関係にします。こうすると、駆動表から見て内部表の結合対象のレコードが一意に定まり、内部表へのアクセスが常に主キーのインデックスで行われます。これにより駆動表の各レコード単位で発生していたループがなくなり、検索条件ごとの性能のばらつき減らすことができます。
  - 結合条件ごとの性能差は縮まるものの、Nested Loopsの性能改善の原則である「小さな駆動表と大きな内部表」からは外れるため、平均的な性能の低下は避けられません。
- 結合のアルゴリズムとしてHashを使用する
  - Hashについては、次の項で解説します。

### Hash

Hash(ハッシュ結合)は、Hashというアルゴリズムでテーブルを結合する手法です。ハッシュ結合の処理の流れとしては、まず相対的に小さいテーブルをスキャンし、結合キーに対してハッシュ関数(ある入力に対してできるだけ一意性と一様性を持った値を出力する関数)を適用することで、それぞれハッシュ値に変換します。この一連のハッシュ値をハッシュテーブルと呼びます。その後、大きなテーブルをスキャンして、結合キーがハッシュテーブルに存在するかを調べ、一致するものがあれば結合対象とする、という流れで結合を行います。

#### Hashの特徴

Hash(ハッシュ結合)の特徴は、以下のとおりです。

- 結合テーブルからハッシュテーブルを作成するため、Nested Loopsと比べてメモリを多く消費する
- メモリ内にハッシュテーブルが収まらない場合、ストレージを使用することになって遅延が発生する
- 出力となるハッシュ値は入力値の順序性を保証しないため、使用できるのは等値結合の場合だけ

#### Hashが有効なケースと注意点

以下の条件に当てはまる場合、Hashが有効である可能性が高いです。

- Nested Loopsで適切な駆動表が存在しない場合
  - 2つのテーブル間にサイズ差がなく、小さい駆動表を選べないケースが該当します。
- 相対的に小さいテーブルはあるが、内部表のヒット件数が多い場合
  - [Nested Loopsの注意点](#nested-loopsの注意点)で解説したケースが該当します。
- Nested Loopsの内部表にインデックスが存在しない場合
  - 何らかの事情でインデックスが作成できないケースが該当します。

ただし、Hashには注意すべき点もあります。

- ハッシュテーブルを作成するために消費するメモリ量が多く、ハッシュテーブルがメモリ内に収まらない場合に処理が遅延する
  - 特に注意が必要なのは、同時実行されるOLTP処理(ユーザの要求に対して結果を即時返却するような処理)でHashを使用する場合で、DBMSに割り当てられたメモリが枯渇する可能性が高まります。
  - DBMSの処理によってメモリ容量が枯渇した結果、ストレージを使用した処理が発生することを俗に「TEMP落ち」と呼ぶ。
- Hashでは必ず両方のテーブルを全件読み込むため、テーブルフルスキャンが発生することが多い
  - テーブルのサイズが大きい場合は、フルスキャンの時間も考慮が必要です。

### Sort Merge

#### Sort Mergeの特徴

- 結合対象のテーブルをどちらもソートする必要があるため、Nested Loopsよりも多くのメモリを消費する
  - Hashと比較してどちらが多くメモリを消費するかは状況による。Hashは片方のテーブルを見てハッシュテーブルを作成する一方、両方のテーブルを見てソートを行うSort Mergeのほうがより多くのメモリを消費するケースがある。
  - 「TEMP落ち」による処理遅延が発生する可能性がある(Hashと同様)。
- Hashとは異なり、結合条件に等号(`=`)だけではなく不等号(`<、>、<=、>=`)を使った結合にも使用できる。ただし、否定条件(`<>`)の結合には使用できない。
- テーブルをソートするため、片方のテーブルをすべてスキャンしたタイミングで結合を終了できる
  - ソート自体は両方のテーブルに対して実施するが、その後にNested Loopsのようなループ処理は不要。

#### Sort Mergeの注意点

Sort Mergeを使用した結合は、たとえ結合対象の列が多い場合であっても、結合にそれほど時間はかかりません。しかし、両テーブルのソートに多くのメモリを消費する可能性があります。よって、運用中にレコード数が増加した場合に、Sort Mergeを使用するSQLではTEMP落ちによる性能劣化が発生しうる点には注意が必要です。  
Sort Mergeでは結合列でレコードをソートする関係上、テーブルの各レコードが結合列でソート済みの場合に性能が良いケースがあります。逆に、結合列でソートされていない場合は、他のアルゴリズムと比べて性能が劣る可能性があります。　

### 結合アルゴリズムのまとめ

ここまでに解説した各結合アルゴリズムについて、その利点と欠点をまとめます。

| アルゴリズム | 利点                                                                                                                                               | 欠点                                                                                                                               |
| -----------: | :------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| Nested Loops | ・「小さな駆動表」と「インデックスのある大きな内部表」の組み合わせで高速<br>・メモリ消費が少ないのでOLTP処理に適する<br>・非等値結合でも使用できる | ・大きなテーブル同士の結合には不適<br>・内部表のインデックスが使えない、あるいは内部表の選択率が高いと低速                         |
|         Hash | ・大きなテーブル同士の結合に適している                                                                                                             | ・メモリ消費が多くOLTP処理には不適<br>・メモリ枯渇の場合にTEMP落ちで性能劣化<br>・等値結合でしか使用できない                       |
|   Sort Merge | ・大きなテーブル同士の結合に適している<br>・非等値結合でも使用できる                                                                               | ・メモリ消費が多くOLTP処理には不適<br>・メモリ枯渇の場合にTEMP落ちで性能劣化<br>・結合対象のテーブルがソート済みでないと効率が悪い |

## 結合が遅い場合の対処法

### ケースごとの最適な結合アルゴリズム

オプティマイザは、結合アルゴリズムそれぞれの利点と欠点を考慮し、どのアルゴリズムを使用するか決定しています。しかし、オプティマイザによって選択されたアルゴリズムが必ずしも最速というわけではありません(これはどのような実行計画にも言えることです)。

最適な結合アルゴリズムを「結合対象テーブルのレコード数」という観点からまとめると、以下のようになります。

- 小さいテーブル × 小さいテーブル
  - アルゴリズム間には差がほとんどないため、どれを選んでもさほど変わらない。
- 小さいテーブル × 大きいテーブル
  - 大きいテーブル側の結合キーにインデックスが存在することを前提に、小さいテーブルを駆動表、大きいテーブルを内部表としたNested Loopsが適する。
  - ただし、内部表の結合対象のレコード数が多い場合は駆動表を逆にする(大きいテーブルを駆動表、小さいテーブルを内部表)、もしくはHashを使用したほうが速い場合がある。
- 大きいテーブル × 大きいテーブル
  - Hashが適することが多い。
  - 結合キーがソート済みという前提があれば、HashよりもSort Mergeのほうが高速なケースがある。

### 実行計画の制御とその限界

ここまでに、結合アルゴリズムの利点・欠点や、結合対象テーブルの状態による向き・不向きを見てきました。理論上は、開発者がこれらの条件を考慮した上で、最適なアルゴリズムを選択することによって、効率の良いデータアクセスが可能になると考えられます。  
しかし、そもそも結合アルゴリズムを選択して実行計画を作成するのはオプティマイザの役割です。そのため、開発者がこの仕組み自体に介入することはできないように思えます。もちろん、例えばNested Loopsを使用すると効率的になる可能性がある場合に、内部表の結合キーにインデックスを設定する、といったレベルの介入はできます。それでも、どのアルゴリズムを使用するかはオプティマイザが判断することなので、必ずNested Loopsが使用されるとは限りません。

開発者が実行計画に直接的に介入する手段として、SQLに記述する「ヒント句」という機能があります。この機能は、PostgreSQLでは外部ツール(pg_hint_plan)を導入することで使用でき、Oracleでは組み込み機能として提供されています。ヒント句を記述することで、Nested Loopsの駆動表を指定したり、結合で使用するアルゴリズム自体を指定したりできます。  
ヒント句の詳細な説明は割愛しますが、SQLの改修やインデックスの設定では十分な性能が出ない場合に、最終手段としてヒント句を使用せざるを得ないケースがあることは理解してください。また、ヒント句は実行計画の変更も抑制してしまうので、テーブルのレコードの増減によって性能劣化が発生することがあるため、当該SQLの性能監視が必要になることにも注意してください。

結合アルゴリズムが複数ある関係上、オプティマイザが生成する実行計画も変動する可能性があります。例えば、ある状況下ではNested Loopsが使用され、別の状況下ではHashが選択される、といった具合です。結合の性能問題は、このアルゴリズム(実行計画)の変更時に発生しやすく、これが結合を含むSQLの性能予測を難しいものにしています。  
このような性能変動を未然に防ぐためには、究極的には「結合を使用しない」ことがベストです。もちろん、要求仕様的に結合を使用せざるを得ない場面があるため、すべてのSQLから結合を排除することは不可能です。ただし、場合によっては結合以外のSQLで求める結果が得られるケースもあります。よって、結合による性能問題が発生した場合は、一度は別のSQLに書き換えられないか検討してみてください。