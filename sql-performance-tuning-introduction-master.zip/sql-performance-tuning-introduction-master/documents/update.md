# 更新系SQLのチューニング

ここでは、更新系SQL(INSERT、UPDATE、DELETE)のチューニングについて解説します。  
更新系SQLにおいて発生する性能劣化は、データモデル(テーブル自体の構成など)が原因となっているケースが多いです。このような性能問題の原因は、主に設計時に排除しておくことが重要です。ただ、このテキストはSQLによる性能改善を主題としているため、SQLの修正で性能改善が見られるケースに限定して解説します。  
更新系SQLの修正によって性能改善が見込まれるケースは、多くの場合繰り返し実行される「ループ系SQL」です。これを「一括実行系SQL」に書き換えることによって、効率的に実行できることがあります。この点は「[その他のSQLチューニング手法](etc.md#ループ系のsqlを一括実行できるsqlに書き換える)」で紹介しているチューニング手法とよく似ています。「SQLからループ(繰り返し)実行を排除することで性能改善が見込まれる」という原則は、検索系・更新系いずれのSQLでも有効なことを理解してください。

---

- [更新系SQLのチューニング](#更新系sqlのチューニング)
  - [挿入(INSERT)におけるバルクインサート](#挿入insertにおけるバルクインサート)
      - [一行ずつのINSERT](#一行ずつのinsert)
      - [バルクインサート](#バルクインサート)
      - [COPYコマンドを使用したINSERT](#copyコマンドを使用したinsert)
  - [削除(DELETE)における一括削除](#削除deleteにおける一括削除)
      - [DELETEを使用する方法](#deleteを使用する方法)
      - [TRUNCATEを使用する方法](#truncateを使用する方法)
  - [更新(UPDATE)における一括実行](#更新updateにおける一括実行)
      - [ケース1: 相関サブクエリを使用する方法](#ケース1-相関サブクエリを使用する方法)
      - [ケース2: 行式を使用する方法](#ケース2-行式を使用する方法)
          - [1列ずつの更新](#1列ずつの更新)
          - [行式を使用して複数列を更新する方法](#行式を使用して複数列を更新する方法)
          - [【参考】INSERT SELECTを使用する方法](#参考insert-selectを使用する方法)

---

## 挿入(INSERT)におけるバルクインサート

挿入(INSERT)を行うSQLにおいて、INSERT文そのものに性能問題が出るケースは少ないです。もしINSERTを行うSQLに性能問題があるとすれば、INSERTする対象列を他のテーブルから検索(SELECT)するサブクエリなど、INSERT以外の箇所に問題がある可能性が高いです。  
ただ、大量データのINSERTについては、INSERT文の書き方次第で大幅な性能改善が見られる可能性があります。この方法が、以下で述べる「バルクインサート」と呼ばれる方法です。

### 一行ずつのINSERT

一行ずつ実行するINSERT文は、もっとも基本的な挿入のSQLです。このSQLで複数行をINSERTする場合、SQLが繰り返し実行されることになります。そのため、SQL実行のためのオーバーヘッド(SQL文のパースや実行計画生成・評価などにかかる時間)も、挿入する行数分発生します。ゆえに、このようなSQLの実行は遅いことが多いです。

以下のSQLは複数行を一行ずつINSERTする例です。`insert into ~~~ ;`が複数あることから、SQLが複数回実行されることが理解できると思います。  
一行ずつINSERTする方法であっても、挿入する行数が数百行程度であれば、多くの場合許容できる時間内に実行が完了します。しかし、数十万行単位の大量レコードをINSERTする場合、この方法だとかなりの時間を要するため、何らかの性能改善が必要となります。

```sql
insert 
into public.books(book_no, title, author, publisher, price, stock) 
values (
    1
    , 'Ｃプログラミング大辞典'
    , '宮崎　満'
    , 'テクニカルブックス'
    , 2200
    , 20
); 

insert 
into public.books(book_no, title, author, publisher, price, stock) 
values ( 
    2
    , 'Javaプログラミングサンプル１００'
    , '岡本　雅文'
    , '技術出版社'
    , 1560
    , 20
); 

insert 
into public.books(book_no, title, author, publisher, price, stock) 
values ( 
    4
    , 'windowsＸＰ全機能徹底解説'
    , '渋谷　博善'
    , '瀬戸メディアワークス'
    , 2200
    , 20
); 

insert 
into public.books(book_no, title, author, publisher, price, stock) 
values (
    6
    , 'Word入門講座'
    , '小島　基彦'
    , 'テクニカルブックス'
    , 1100
    , 20); 

insert 
into public.books(book_no, title, author, publisher, price, stock) 
values ( 
    7
    , 'WEBデザインの大原則'
    , '里見　陽子'
    , '瀬戸メディアワークス'
    , 1520
    , 20
);

```

### バルクインサート

1回のSQL実行で複数の行をINSERTする記法を、一般に「バルクインサート(Bulk Insert)」と呼びます。この記法を用いれば、一行ずつINSERTしていたSQLを1つにまとめて、1回のSQL実行で複数行を挿入することが可能です。

以下のSQLは、バルクインサートの例です。バルクインサートの記法では、`,`(カンマ)で複数の挿入行を連ねて書くことで、1つのSQLにまとめます。一見すると一行ずつINSERTするSQLとの違いはほとんどありませんが、このように書くだけでSQLの実行が1回で済みます。

```sql
insert 
into books(book_no, title, author, publisher, price, stock) 
values 
  (1
  , 'Ｃプログラミング大辞典'
  , '宮崎　満'
  , 'テクニカルブックス'
  , 2200
  , 20
)
, ( 
    2
    , 'Javaプログラミングサンプル１００'
    , '岡本　雅文'
    , '技術出版社'
    , 1560
    , 20
) 
, ( 
    4
    , 'windowsＸＰ全機能徹底解説'
    , '渋谷　博善'
    , '瀬戸メディアワークス'
    , 2200
    , 20
) 
, (
    6
    , 'Word入門講座'
    , '小島　基彦'
    , 'テクニカルブックス'
    , 1100
    , 20
)
, ( 
    7
    , 'WEBデザインの大原則'
    , '里見　陽子'
    , '瀬戸メディアワークス'
    , 1520
    , 20
);

```

### COPYコマンドを使用したINSERT

COPYコマンドはPostgreSQLで使用できる機能で(他のDB製品では使用できません)、一般にバルクインサートよりも高速な行挿入が可能です。ただし、このコマンドはSQLだけでは完結せず、挿入対象の行を何かしらのファイル(CSVファイルなど)にあらかじめ用意しておき、これを読み込む必要があります。  
COPYのように、特定DB製品で使用できる大量データINSERTの手段としては、Oracleの「SQL*Loader」やMySQLの「LOAD DATA」などがあります。いずれも、通常のSQLを使用したINSERTよりも高速な行挿入を謳っており、INSERT時の性能問題の解消に役立ちます。

COPYコマンドとバルクインサートの使い分けについて説明します。バルクインサートは多くのDB製品で使用できる一方、COPYコマンドよりも実行速度は遅い可能性が高いです。一方のCOPYコマンドは、多くの場合に最速で行挿入できる一方、PostgreSQL以外のDB製品で使用できない点、またあらかじめファイルを用意する必要がある点がネックです。したがって、性能を求める場合はCOPYコマンドを、処理方式の変更を最小限にとどめたい場合はバルクインサートを使用するとよいでしょう。

以下のSQLは、COPYコマンドを使用した行挿入の例です。「books」という名前のテーブルに対してtable.csvというCSVファイルに書かれた行のINSERTを実行します。

```sql
COPY books(book_no, title, author, publisher, price, stock) 
FROM
    'table.csv' WITH CSV
;
```

## 削除(DELETE)における一括削除

行削除(DELETE)を行うSQLも、INSERT文と同様に性能問題が出るケースは少ないです。また、性能問題の原因がDELETEそのものではなく、DELETE以外の箇所に存在する可能性が高いことも同様です。  
大量レコードを持つテーブルのレコードを削除する方法としては、DELETEを使用する方法とTRUNCATEを使用する方法があります。TRUNCATEのほうが高速に削除できますが、削除対象レコードの条件指定ができない(必ず全レコード削除)などの制約もあります。

### DELETEを使用する方法

DELETEを使用したレコードの削除は、最も基本的な方法です。WHERE句を使用して削除対象レコードを指定することもできます。

以下は、booksテーブルから`book_no = 1`に該当するレコードを削除するSQLです。

```sql
delete 
from
    books 
where
    book_no = 1
;
```

また、テーブルの全レコードを削除する場合は、WHERE句の条件なしで実行します。特定のレコードを削除する場合(どちらかというとDELETEはこの目的で使用します)、WHERE句の記述を忘れないように注意が必要です。

```sql
delete 
from
    books 
-- where句がないので全レコードが削除対象
;
```

DELETEによるレコードの削除は、COMMIT前であればROLLBACKできます(削除を取り消して元に戻せます)。一方、後述のTRUNCATEによる全レコード削除と比較すると低速であるという欠点があります。

### TRUNCATEを使用する方法

TRUNCATEは、テーブルから全レコードを削除する目的で使用します。WHERE句で条件を指定することはできず、必ず全レコードを削除します。  

TRUNCATEは、実際にはレコードを削除しているのではなく、テーブルを削除してから新たに空の(レコードが1つもない)テーブルを作り直す、という仕組みになっています(DELETEはテーブルを削除せずレコードだけを削除する)。このことにより、特定のレコードを削除することはできない一方、DELETEよりも高速な全レコード削除が可能になっています。  
TRUNCATEではテーブルをいったん削除してしまう都合上、基本的にレコード削除をROLLBACKすることができません(例外的にPostgreSQLではROLLBACKすることができますが、Oracleなどは不可能です)。そのため、誤って削除した場合に復旧が難しい点には注意が必要です。

以下は、TRUNCATEを使用してbooksテーブルからすべてのレコードを削除するSQLです。

```sql
truncate table books;
```

## 更新(UPDATE)における一括実行

更新(UPDATE)のSQLも、INSERTやDELETEと同様に、一括実行することでパフォーマンスを改善できるケースがあります。以下では2つの例を取り上げ、ループ系SQLから一括実行系SQLに書き換える方法について考えます。

### ケース1: 相関サブクエリを使用する方法

以下に示すsensor_logテーブルは、センサーの測定値を保存するためのテーブルです([ループ系SQLの改修例](etc.md#ループ系sqlの改修例)で使用したテーブル、レコードは一部変更)。id列がセンサーを識別するID、unixtimeが測定時刻、valueが測定値を表します。sign列については使用しないので、無視してください。

| id   | unixtime   | value | sign |
| :--- | :--------- | ----: | :--- |
| 1    | 1635724801 |    67 |      |
| 1    | 1635724802 |    95 |      |
| 1    | 1635724803 |    45 |      |
| 1    | 1635724804 |    31 |      |
| 1    | 1635724805 |       |      |
| 1    | 1635724806 |    18 |      |
| 1    | 1635724807 |    82 |      |
| 1    | 1635724808 |    57 |      |
| 1    | 1635724809 |    57 |      |
| 1    | 1635724810 |       |      |
| 2    | 1635724801 |    96 |      |
| 2    | 1635724802 |    32 |      |
| 2    | 1635724803 |       |      |
| 2    | 1635724804 |    95 |      |
| 2    | 1635724805 |    32 |      |
| 2    | 1635724806 |    32 |      |
| 2    | 1635724807 |       |      |
| 2    | 1635724808 |       |      |
| 2    | 1635724809 |    57 |      |
| 2    | 1635724810 |    86 |      |

ポイントは、value列がNULLとなっているレコードの存在です。このようなレコードは欠損値や欠測値と呼ばれ、統計処理などの際には取り扱いに注意が必要なデータです。統計処理の目的に応じて、このようなレコードは無視したり、あるいは欠損値に適当な値を代入したりする必要があります。

今回は、value列がNULLの場合には直近のレコードのvalue列の値で穴埋めすることにします。この処理を、UPDATEで実行することにします。

| id   | unixtime   |              value | sign |
| :--- | :--------- | -----------------: | :--- |
| 1    | 1635724801 |                 67 |      |
| 1    | 1635724802 |                 95 |      |
| 1    | 1635724803 |                 45 |      |
| 1    | 1635724804 |                 31 |      |
| 1    | 1635724805 | 31(欠損値を穴埋め) |      |
| 1    | 1635724806 |                 18 |      |
| 1    | 1635724807 |                 82 |      |
| 1    | 1635724808 |                 57 |      |
| 1    | 1635724809 |                 57 |      |
| 1    | 1635724810 | 57(欠損値を穴埋め) |      |
| 2    | 1635724801 |                 96 |      |
| 2    | 1635724802 |                 32 |      |
| 2    | 1635724803 | 32(欠損値を穴埋め) |      |
| 2    | 1635724804 |                 95 |      |
| 2    | 1635724805 |                 32 |      |
| 2    | 1635724806 |                 32 |      |
| 2    | 1635724807 | 32(欠損値を穴埋め) |      |
| 2    | 1635724808 | 32(欠損値を穴埋め) |      |
| 2    | 1635724809 |                 57 |      |
| 2    | 1635724810 |                 86 |      |

更新対象となるレコードは`value is null`が真となるレコードであることは明らかです。問題は、更新対象となるレコードについて、そのvalueをどのように選択するかです。テーブル全体を見れば直近のレコードのvalueは明らかですが、このルールをSQLに落とし込むことは簡単ではありません。特に、穴埋めに使用するvalueの値を決めるために、行間比較が必要となる点が難しいです。  
一つの実装手段として、ホスト側(SQLを発行するプログラム側)でUPDATEのSQLを複数回実行する方法が考えられます。処理の流れは、まずテーブル全体を取得し、value列がNULLであるレコードを取得、それらを順番に直前のレコードのvalueでUPDATEしていく、というイメージです。しかし、この方法では穴埋めするレコードの数だけSQLが実行されるため、パフォーマンスが悪いことは明らかです。  

行間比較が必要なSQLの実装には「相関サブクエリ」がよく使用されます。相関サブクエリはサブクエリの一種で、「外側のクエリの値をサブクエリ内で使用する」という実装パターンです。  
今回は、

- 同じidを持つ
- 自分(のレコード)より小さいunixtimeを持つ
- valueがNULLではない

という3つの条件に一致するレコードに絞り込み、その中で最大のunixtimeを持つレコードのvalueで穴埋めする、という考え方でSQLを実装していきます。特に「自分(のレコード)より小さいunixtimeを持つ」がポイントで、この条件によって自分自身よりも前のレコードへさかのぼってスキャンする動作を実現します。

上記のSQLを相関サブクエリで実装すると、以下のようになります。3つの条件がすべて含まれていることを確認してください。

```sql
update sensor_log 
set
    value = ( 
        select
            value 
        from
            sensor_log as s1 
        where
            s1.id = sensor_log.id -- 同じidを持つ
            and s1.unixtime = ( 
                select
                    max(unixtime) 
                from
                    sensor_log as s2 
                where
                    s2.id = sensor_log.id 
                    and s2.unixtime < sensor_log.unixtime -- 自分より小さいunixtimeを持つ 
                    and s2.value is not null -- valueがNULLではない
            )
    ) 
where
    value is null
;
```

実行計画は以下のようになります。表別名s2に対するテーブルフルスキャンの結果をMAX関数で集約し、それでs1テーブルの行を特定しています。

| QUERY PLAN                                                                                                                                                                                                                                                                                                               |
| :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Update on sensor_log  (cost=0.00..3.82 rows=1 width=27)                                                                                                                                                                                                                                                                  |
| &nbsp;&nbsp;-\>  Seq Scan on sensor_log  (cost=0.00..3.82 rows=1 width=27)                                                                                                                                                                                                                                               |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Filter: (value IS NULL)                                                                                                                                                                                                                                                  |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SubPlan 2                                                                                                                                                                                                                                                                |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Seq Scan on sensor_log s1  (cost=1.32..2.62 rows=1 width=4)                                                                                                                                                                           |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Filter: ((id = sensor_log.id) AND ((unixtime)::text = $2))                                                                                                                                                   |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;InitPlan 1 (returns $2)                                                                                                                                                                                      |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Aggregate  (cost=1.31..1.32 rows=1 width=11)                                                                                                                              |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Seq Scan on sensor_log s2  (cost=0.00..1.30 rows=3 width=11)                                                                                |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Filter: ((value IS NOT NULL) AND ((unixtime)::text \< (sensor_log.unixtime)::text) AND (id = sensor_log.id)) |

今回の例ではテーブルのレコード数が少ないため、テーブルフルスキャンが実行されています。仮にレコード数が増えた場合でもidとunixtimeの複合主キーのインデックスが使用できる可能性が高いため、パフォーマンスはループ系SQLの複数回実行よりも優れているといえます。

### ケース2: 行式を使用する方法

**【注意】 以下で紹介する[行式を使用して複数列を更新する方法](#行式を使用して複数列を更新する方法)は、PostgreSQLでは使用できません(エラーとなります)。** これは、PostgreSQLは右辺がスカラとなる単純な行式(例えば`update ex_table set (col1, col2, col3) = (1, 2, 3)`)だけに対応しているためです。  
行式とサブクエリの組み合わせは、OracleやDB2などで使用できます。

次に、ケース1で取り上げた相関サブクエリと行式を組み合わせた実装例を見ていきます。

以下のテーブルは、ある株式銘柄の株価(終値)を、日ごとに記録するテーブルです。id列が株式銘柄を表すid、dateが年月日、priceが株価を表しています。このようなテーブルは、1つの要素(今回はid)に対して1つのデータ(今回はprice、dateはデータの属性と考えるので含めない)を持っていることから、「行持ち」のテーブルと呼びます。また、複数のレコードを縦に積むことで1つの要素に対するデータ全体を表現する様子から「縦持ち」のテーブルと呼ぶこともあります。

| id   | date     | price |
| :--- | :------- | ----: |
| 1    | 20211104 |  1000 |
| 1    | 20211105 |  1100 |
| 2    | 20211104 |  2000 |
| 2    | 20211105 |  2200 |
| 3    | 20211104 |  3000 |
| 3    | 20211105 |  3100 |
| 3    | 20211106 |  3300 |

上記の行持ちテーブルに基づいて、以下の「列持ち」テーブルを更新することを考えます。id列は行持ちテーブルと同様ですが、dateとpriceを組み合わせて表現した列があり、例えば「price_20211104」には、行持ちテーブルのdateが20211104のpriceが入ります。言い換えると、行持ちのテーブルの複数行(id列が同一のレコード)を1行に集約するということです。このようなテーブルは、1つの要素に対するすべてのデータを1行(横方向)で持っていることから「横持ち」のテーブルと呼ぶこともあります。

| id   | price_20211104 | price_20211105 | price_20211106 |
| :--- | -------------: | -------------: | -------------: |
| 1    |                |                |                |
| 2    |                |                |                |
| 3    |                |                |                |
| 4    |                |                |                |

ここで問題になるのは、日ごとのpriceを各列に対して移す方法です。更新後の列持ちテーブルは以下のようになります。

| id   | price_20211104 | price_20211105 | price_20211106 |
| :--- | -------------: | -------------: | -------------: |
| 1    |           1000 |           1100 |                |
| 2    |           2000 |           2200 |                |
| 3    |           3000 |           3100 |           3300 |
| 4    |                |                |                |

id = 1,2の銘柄については2021年11月6日のレコードがないため(取引所が休みの日)、NULLとなります。また、id = 4の銘柄は存在しないため、id列以外はすべてNULLになります。

行持ちテーブルに基づいて列持ちテーブルを更新する際のSQLですが、ケース1と同様に相関サブクエリを使用します。同じid(銘柄)の行を更新するので、更新対象の条件はid列になることは容易に想像できます。

#### 1列ずつの更新

まず、列持ちテーブルを1列ずつ更新する方法を考えます。SQLの動作は理解しやすいですが、3つの相関サブクエリが実行されるため、パフォーマンスが悪いことが予想されます。

```sql
update stocks_column 
set
    price_20211104 = ( 
        select
            price 
        from
            stocks_row as sr 
        where
            sr.id = stocks_column.id 
            and sr.date = '20211104'
    ) 
    , price_20211105 = ( 
        select
            price 
        from
            stocks_row as sr 
        where
            sr.id = stocks_column.id 
            and sr.date = '20211105'
    ) 
    , price_20211106 = ( 
        select
            price 
        from
            stocks_row as sr 
        where
            sr.id = stocks_column.id 
            and sr.date = '20211106'
    )
;
```

実行計画からも、3つのサブクエリが実行されることがわかります。

| QUERY PLAN                                                                                                                                            |
| :---------------------------------------------------------------------------------------------------------------------------------------------------- |
| Update on stocks_column  (cost=0.00..14.30 rows=4 width=8)                                                                                            |
| &nbsp;&nbsp;-\>  Seq Scan on stocks_column  (cost=0.00..14.30 rows=4 width=8)                                                                         |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SubPlan 1                                                                                             |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Seq Scan on stocks_row sr  (cost=0.00..1.11 rows=1 width=4)                                      |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Filter: ((id = stocks_column.id) AND ((date)::text = '20211104'::text)) |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SubPlan 2                                                                                             |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Seq Scan on stocks_row sr_1  (cost=0.00..1.11 rows=1 width=4)                                    |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Filter: ((id = stocks_column.id) AND ((date)::text = '20211105'::text)) |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SubPlan 3                                                                                             |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Seq Scan on stocks_row sr_2  (cost=0.00..1.11 rows=1 width=4)                                    |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Filter: ((id = stocks_column.id) AND ((date)::text = '20211106'::text)) |

SQLや実行計画から、この方法では更新対象の列が増えるたびにサブクエリが増えることがわかります。このサブクエリが増えれば増えるほど、性能は悪化することが予想されます。

#### 行式を使用して複数列を更新する方法

**【注意】 以下で紹介する行式とサブクエリを組み合わせる方法は、PostgreSQLでは使用できません(エラーとなります)。**

今回のように複数列を条件に応じて更新する場合は、「行式」という機能を使用すると効率のよい実行が可能となります。

以下のSQLは、行式を使用して書き換えたものです。

```sql
update stocks_column 
set
    (price_20211104, price_20211105, price_20211106) = ( 
        select
            max( 
                case 
                    when date = '20211104' 
                        then price 
                    else null 
                    end
            ) as price_20211104
            , max( 
                case 
                    when date = '20211105' 
                        then price 
                    else null 
                    end
            ) as price_20211105
            , max( 
                case 
                    when date = '20211106' 
                        then price 
                    else null 
                    end
            ) as price_20211106 
        from
            stocks_row as sr 
        where
            sr.id = stocks_column.id
    )
;
```

行式を使用することでサブクエリの実行が1回で済むため、パフォーマンスの改善が見込まれます。さらに、更新対象の行が増加した場合であっても、相関サブクエリの実行は1回で変わらないため、性能劣化も防ぐことができます。

#### 【参考】INSERT SELECTを使用する方法

「列持ちのテーブルにレコードが存在しない」という条件付きではありますが、以下のSQLで行持ちテーブルから列持ちテーブルに変換することができます。

```sql
insert 
into stocks_column 
select
    id
    , max(case date when '20211104' then price end) as price_20211104
    , max(case date when '20211105' then price end) as price_20211105
    , max(case date when '20211106' then price end) as price_20211106 
from
    stocks_row 
group by
    id
;
```

| QUERY PLAN                                                                                               |
| :------------------------------------------------------------------------------------------------------- |
| Insert on stocks_column  (cost=1.19..1.25 rows=3 width=14)                                               |
| &nbsp;&nbsp;-\>  HashAggregate  (cost=1.19..1.22 rows=3 width=15)                                        |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Group Key: stocks_row.id                                       |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Seq Scan on stocks_row  (cost=0.00..1.07 rows=7 width=15) |

UPDATEではなく、いわゆるINSERT SELECTを使用して、空のテーブルにレコードを挿入する方法です。実行計画を見ると、テーブルフルスキャンとINSERTはいずれも1回だけ実行されており、パフォーマンスは良いことが予想されます。

INSERT SELECTには、以下のメリットがあります。

- 一般的に、UPDATEに比べてINSERT SELECTのほうがパフォーマンスが良い
- PostgreSQLのように行式とサブクエリの組み合わせが使用できない場合でも実行可能

「既存のレコードをUPDATEする」という当初の想定からは外れてしまいますが、設計上問題がない場合はINSERT SELECTの使用も検討すべきです。
