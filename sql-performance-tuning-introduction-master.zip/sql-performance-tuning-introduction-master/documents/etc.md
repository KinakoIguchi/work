# その他のSQLチューニング手法

ここでは、結合やインデックスに関係しないパフォーマンスチューニングの手法を解説します。

---

- [その他のSQLチューニング手法](#その他のsqlチューニング手法)
  - [SELECT句では必要な列だけを取得する](#select句では必要な列だけを取得する)
      - [インデックスオンリースキャン](#インデックスオンリースキャン)
  - [UNIONを使用した条件分岐をCASE式にする](#unionを使用した条件分岐をcase式にする)
      - [ケース1: SELECTする列の条件分岐](#ケース1-selectする列の条件分岐)
          - [UNIONを使用した条件分岐](#unionを使用した条件分岐)
          - [CASE式を使用した条件分岐](#case式を使用した条件分岐)
      - [ケース2: 集計における条件分岐](#ケース2-集計における条件分岐)
          - [UNIONを使用した条件分岐](#unionを使用した条件分岐-1)
          - [CASE式を使用した条件分岐](#case式を使用した条件分岐-1)
      - [ケース3: 集約の結果に対する条件分岐](#ケース3-集約の結果に対する条件分岐)
          - [UNIONを使用した条件分岐](#unionを使用した条件分岐-2)
          - [CASE式を使用した条件分岐](#case式を使用した条件分岐-2)
      - [まとめ](#まとめ)
  - [UNIONの使用が妥当なケース](#unionの使用が妥当なケース)
      - [UNIONを使用せざるを得ないケース](#unionを使用せざるを得ないケース)
      - [UNIONの使用を検討するケース](#unionの使用を検討するケース)
          - [UNIONによる実装](#unionによる実装)
          - [OR句による実装](#or句による実装)
  - [ループ系のSQLを一括実行できるSQLに書き換える](#ループ系のsqlを一括実行できるsqlに書き換える)
      - [ループ系SQLの改修例](#ループ系sqlの改修例)
          - [ループ系SQLの実装例とデメリット](#ループ系sqlの実装例とデメリット)
          - [一括実行系SQLの実装例](#一括実行系sqlの実装例)

---

## SELECT句では必要な列だけを取得する

SELECT句には、取得する列名や列番号を記述できるほか、`*`(アスタリスク)を記述してすべての列を取得することもできます。この`*`を使用した記法は「ワイルドカード」と呼ばれます。ワイルドカードを使用すれば、SELECT文に列名を記述する必要がないため、SQLは簡潔になって実装時の手間が省けます。  
その一方で、本来は取得する必要のない列を取得してしまう可能性もあります(例えば画面表示に必要ないレコード作成/更新時刻の列まで取得してしまうなど)。不必要な列の取得によるデメリットとしては、

- 不要な列を取得することによる実行時間の増加、ネットワークトラフィックやI/O負荷の増大
- インデックスオンリースキャン(後述)が使用できない可能性がある

といったものがあります。よって、SELECTの際には、必要な場合を除いてワイルドカード`*`は使用せず、列名を指定するようにしてください。

### インデックスオンリースキャン

以下では、インデックスオンリースキャンの例について簡単に説明します。インデックスオンリースキャンはSQLの性能を改善する手段の一つですが、ワイルドカードを使用した場合には基本的に使用できません。そのため、インデックスオンリースキャンが使用できるということも、ワイルドカードではなく列名を指定することのメリットです。  
インデックスオンリースキャンの詳細は、[index.md#インデックスオンリースキャンを使用する方法](index.md#インデックスオンリースキャンを使用する方法)を参照してください。

インデックスが設定された列のみを使用したSQLを実行する場合、インデックスオンリースキャンが使用できるケースがあります。インデックスオンリースキャンは、その名のとおりテーブルではなくインデックスだけを見て検索する方法であり、一般にI/O負荷が低くかつ高速な検索が可能です。

インデックスオンリースキャンを実行するための条件は、以下の2点です。

- インデックスに格納されている列だけを参照するSQLであること
  - ここで話題にしているのは、こちらの条件です。
- インデックスの種類がインデックスオンリースキャンに対応した形式であること
  - Bツリーインデックスなどが該当します。一般的なインデックスであれば、対応していると考えてよいです。

このうち、「インデックスに格納されている列だけを参照するSQLであること」というルールが、ワイルドカードの使用や余計な列指定がある場合に守られず、結果としてテーブルフルスキャンやインデックススキャンとなってしまうことがあります。

以下で例を見ていきます。sensorテーブルのid列にはインデックスが設定されています。このとき、以下のSQLを実行し、実行計画を取得します(意味のあるSQLではありませんが、インデックスオンリースキャンの実行例として確認してください)。

```sql
select
    id
from
    sensor 
where
    id = '1'
```

実行計画

| QUERY PLAN                                                                    |
| :---------------------------------------------------------------------------- |
| Index Only Scan using sensor_pkey on sensor  (cost=0.42..8.44 rows=1 width=9) |
| &nbsp;&nbsp;Index Cond: (id = '1'::bpchar)                                    |

実行計画に`Index Only Scan using sensor_pkey on sensor`とあり、インデックスオンリースキャンが実行されていることがわかります。

次に、SELECT句の列をidから`*`に変更します。

```sql
select
    *
from
    sensor 
where
    id = '1'
```

実行計画

| QUERY PLAN                                                                |
| :------------------------------------------------------------------------ |
| Index Scan using sensor_pkey on sensor  (cost=0.42..8.44 rows=1 width=63) |
| &nbsp;&nbsp;Index Cond: (id = '1'::bpchar)                                |

実行計画は`Index Scan using sensor_pkey on sensor`となり、テーブルを見に行く通常のインデックススキャンに変化しました。この原因は、SELECT句で`*`を指定しており、これによってid列以外の列も取得する必要があるので、インデックスオンリースキャンが実行できないためです。

インデックスオンリースキャンは、一般に高速かつI/O負荷も低いです。しかし、常にインデックススキャンよりも優れているとは言い切れません。なおかつ、使用できる場面も限られます。よって、使えるときには使用を検討する、という考え方でよいと思います。それぞれのスキャン方法の優劣以上に、「不要な列は取得しない」という原則のほうが重要です。

次に、複数列インデックス(2つ以上の列を使用したインデックス)の挙動について確認します。sensorテーブルの2つの列(startdate_a、operation_flag_a)を使用した複数列インデックスが存在するとき、以下のSQLを実行します。

```sql
select
    startdate_a
from
    sensor 
where
    operation_flag_a = 'T'
```

実行計画

| QUERY PLAN                                                                  |
| :-------------------------------------------------------------------------- |
| Index Only Scan using idx_a on sensor  (cost=0.42..19380.75 rows=1 width=4) |
| &nbsp;&nbsp;Index Cond: (operation_flag_a = 'T'::bpchar)                    |

SELECT句でstartdate_a、WHERE句でoperation_flag_aを使用するSQLですが、これでもインデックスオンリースキャンが実行されます。このように、複数列インデックスの場合は、SELECT句とWHERE句を併せて、インデックスに使用したすべての列を使用している場合、インデックスオンリースキャンが実行される可能性があります。

なお、複数列インデックスに対するインデックスオンリースキャンの場合も、単一列インデックスの場合と同様に、SELECT句にインデックスに使用した列以外の列が含まれる場合はインデックスオンリースキャンが実行されません。

```sql
select
    startdate_a
    , id  -- id列にインデックスは設定されているが、複数列インデックスには含まれていない
from
    sensor 
where
    operation_flag_a = 'T'
```

| QUERY PLAN                                                              |
| :---------------------------------------------------------------------- |
| Index Scan using idx_a on sensor  (cost=0.42..19380.75 rows=1 width=13) |
| &nbsp;&nbsp;Index Cond: (operation_flag_a = 'T'::bpchar)                |

【参考】

ところで、SELECT句でCOUNT関数を使用する際のインデックスオンリースキャンは、COUNT関数の引数に指定する列が`*`、または特定の列(例えばid列)のいずれの場合も実行されます。

```sql
select
    count(*)
from
    sensor 
where
    id = '1'
```

```sql
select
    count(id)
from
    sensor 
where
    id = '1'
```

実行計画(上記2つのSQLで同一)

| QUERY PLAN                                                                                     |
| :--------------------------------------------------------------------------------------------- |
| Aggregate  (cost=8.45..8.46 rows=1 width=9)                                                    |
| &nbsp;&nbsp;-\>  Index Only Scan using sensor_pkey on sensor  (cost=0.42..8.44 rows=1 width=9) |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Index Cond: (id = '1'::bpchar)                 |

「COUNT関数の引数には`*`よりも特定の列を指定したほうが高速である」とする解説も見られますが、手元の環境では実行計画上の違いがありませんでした(実行時間にも差はありません)。ただし、DB製品やそのバージョンによっては、特定列を指定したほうが速い可能性もあります。よって、念のためCOUNT関数の場合も特定列を指定するとよいでしょう(COUNT関数の列指定に関するルールは、各案件のコーディング規約に記載されていることもあります)。

【インデックスオンリースキャンに関する参考資料】

- [11.11. インデックスオンリースキャン](https://www.postgresql.jp/document/10/html/indexes-index-only-scans.html)

## UNIONを使用した条件分岐をCASE式にする

UNIONを使用したSQLは可読性が悪く、かつ非効率な実行計画となることが多いため、性能劣化の原因になりえます。特に、UNIONを使用した条件分岐をCASE式に書き換えることで、性能を改善できる場合があります。  

### ケース1: SELECTする列の条件分岐

#### UNIONを使用した条件分岐

まずは、UNIONを使用した条件分岐の例を見ていきます。

以下のテーブルは、シンプルな社員テーブルです。列は社員IDのid、社員名のname、月給を表すsalary、年一回のボーナスを表すbonusの各列です。なお、bonus列がNULLの社員はボーナスが支給されないことを意味します。

|   id | name   | salary |  bonus |
| ---: | :----- | -----: | -----: |
|    1 | tanaka | 400000 | 300000 |
|    2 | yamada | 250000 | 100000 |
|    3 | suzuki | 300000 |        |
|    4 | saitoh | 200000 |        |

ここで、各社員の年収を計算し、社員名とともに表示することを考えます。年収の計算式は「salaly(月給) * 12(ヶ月) + bonus(ボーナス)」とします。

年収の計算式を単純に全社員に適用し、結果をSQLで取得すると以下のようになります。

```sql
select
    name as "名前"
    , salary * 12 + bonus as "年収" 
from
    employee
;
```

実行結果

| 名前   |    年収 |
| :----- | ------: |
| tanaka | 5100000 |
| yamada | 3100000 |
| suzuki |         |
| saitoh |         |

以上のように、一部の社員の年収が表示されません。この理由は、bonus列がNULLの社員が存在し、salary * 12とNULLの足し算がNULLとなってしまうことが原因です。  
(参考) テーブル定義の時点でbonus列に初期値0を入れるなどの工夫をすればNULLは入らないので、後述のSQLによる条件分岐は不要となります。この例のように、そもそもの設計不備がSQLの記述や性能に影響する点について注意が必要なのは確かですが、今回は設計変更ができないものと考えて読み進めてください。

計算結果がNULLとなってしまうことを防ぐためには、以下のような条件分岐が必要です。

- bonus列がNULLの社員
  - bonusを計算式に含めず、salary * 12で年収を計算する
- bonus列がNULLではない(ボーナスを支給されている)社員
  - bonusを計算式に含めて、salary * 12 + bonusで年収を計算する

この条件分岐をUNIONを使用して実装すると、以下のようになります。今回の例ではUNION前後のSELECTの結果が重複することはないため(ボーナス支給、非支給がの社員が排他)、UNION ALLを使用します。仮にUNIONを使用しても、同じ結果となります。

```sql
select
    name as "名前"
    , salary * 12 as "年収" 
from
    employee 
where
    bonus is null 
union all 
select
    name as "名前"
    , salary * 12 + bonus as "年収" 
from
    employee 
where
    bonus is not null
;
```

実行結果

| 名前   |    年収 |
| :----- | ------: |
| suzuki | 3600000 |
| saitoh | 2400000 |
| tanaka | 5100000 |
| yamada | 3100000 |

このSQLには2つの問題があります。

- SQLの記述が冗長
  - 同じようなSQL(違いはSELECTに記述した計算式とWHERE句の条件式のみ)が2つ書かれていて冗長です。今回は条件が少ないので簡単に読み解けますが、もっと多くの条件について分岐を行う場合は更に冗長かつ読みづらいSQLとなってしまいます。
- パフォーマンスの悪化
  - 後述しますが、この冗長さが原因となって非効率な実行計画が作成され、SQLの実行も遅くなる可能性があります。

次に、実行計画を見ていきます。

| QUERY PLAN                                                                          |
| :---------------------------------------------------------------------------------- |
| Append  (cost=0.00..2.13 rows=4 width=11)                                           |
| &nbsp;&nbsp;-\>  Seq Scan on employee  (cost=0.00..1.04 rows=2 width=11)            |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Filter: (bonus IS NULL)             |
| &nbsp;&nbsp;-\>  Seq Scan on employee employee_1  (cost=0.00..1.05 rows=2 width=15) |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Filter: (bonus IS NOT NULL)         |

実行計画から、テーブルに対して2回のアクセスが発生していることがわかります。その際にはテーブルへのフルスキャンが発生しており、読み取りのコストはデータ量に対して線形に(データ量が増えれば増えるほど)大きくなることが予想されます。

以上のことから、UNION(UNION ALLも含む)を使用するとテーブルへの無駄なアクセスが発生し、パフォーマンス劣化の原因となりうることがわかります。さらに、データをストレージ(ディスク)から取得する回数が増えるため、物理的なリソースも無駄に消費してしまいます。  

UNION自体は便利な機能ですが、条件分岐に使用することは適当ではないと言えます。

#### CASE式を使用した条件分岐

UNIONを使用した条件分岐のSQLをCASE式を使用したものに書き換えると、以下のようになります。

```sql
select
    name as "名前"
    , case 
        when bonus is null 
            then salary * 12 
        when bonus is not null 
            then salary * 12 + bonus 
        end as "年収" 
from
    employee
;
```

実行結果

| 名前   |    年収 |
| :----- | ------: |
| tanaka | 5100000 |
| yamada | 3100000 |
| suzuki | 3600000 |
| saitoh | 2400000 |

UNIONを使用したSQLと比べて、可読性が向上しました。実行結果は、UNIONを使用した場合と同様です。

次に、実行計画を取得します。

| QUERY PLAN                                              |
| :------------------------------------------------------ |
| Seq Scan on employee  (cost=0.00..1.07 rows=4 width=15) |

実行計画から、テーブルへのアクセスが2回から1回になったことがわかります。おおざっぱに考えると、テーブルへのアクセス回数が半分になったため、半分の時間でSQLが実行できます(キャッシュなどの要因も関係するため一概に言い切ることはできませんが)。  
筆者の環境でemplpyeeテーブルに約100万レコードを挿入して上記のSQLを実行したところ、CASE式を使用する方がUNIONを使用するよりも0.1秒程度高速でした。わずかな差に見えますが、レコード数がもっと多くなればより大きな差異となることが予想されます。

### ケース2: 集計における条件分岐

次に、表の集計における条件分岐について考えます。

先ほどのemployeeテーブルを拡張し、役職としてclass列、所属部門としてdebt列を追加します。また、レコードも追加します。

|   id | name      | salary |  bonus | class  | dept   |
| ---: | :-------- | -----: | -----: | :----- | :----- |
|    1 | tanaka    | 400000 | 300000 | 課長   | 経理部 |
|    2 | yamada    | 250000 | 100000 | 担当者 | 経理部 |
|    3 | suzuki    | 300000 |        | 課長   | 総務部 |
|    4 | saitoh    | 200000 |        | 担当者 | 総務部 |
|    5 | satoh     | 300000 |        | 課長   | 経理部 |
|    6 | takahashi | 200000 |        | 担当者 | 経理部 |
|    7 | yamamoto  | 400000 |        | 課長   | 総務部 |
|    8 | nakamura  | 300000 |        | 担当者 | 総務部 |

ここで、部門ごとのsalaryの合計値を、課長と担当者に分けて集計することを考えます。つまり、それぞれの部門の課長と担当者に対して、どれくらいの給与を支払っているのか知りたい、ということです。  
求める結果を模式的に表すと、以下のようになります。

| 部門   |        担当者の月給合計 |        課長の月給合計 |
| :----- | ----------------------: | --------------------: |
| 経理部 | 経理部×担当者の月給合計 | 経理部×課長の月給合計 |
| 総務部 | 総務部×担当者の月給合計 | 総務部×課長の月給合計 |

#### UNIONを使用した条件分岐

ここで、UNIONを使用して上記の集計を行う方法を考えます。考え方としては、

- 担当者の月給合計を部門別に求める。
- 課長の月給合計を部門別に求める。
- 上記を集計する

という風になります。

SQLと実行結果は、以下のとおりです。

```sql
select
    dept
    , sum(associate_sum) as associate_sum
    , sum(manager_sum) as manager_sum 
from
    ( 
        select
            dept
            , salary as associate_sum
            , null as manager_sum 
        from
            employee 
        where
            class = '担当者' 
        union 
        select
            dept
            , null as associate_sum
            , salary as manager_sum 
        from
            employee 
        where
            class = '課長'
    ) tmp 
group by
    dept
;
```

実行結果

| dept   | associate_sum | manager_sum |
| :----- | ------------: | ----------: |
| 経理部 |        450000 |      700000 |
| 総務部 |        500000 |      700000 |

なお、中間テーブルtmpは以下のようになります。

| dept   | associate_sum | manager_sum |
| :----- | ------------: | ----------: |
| 経理部 |        200000 |             |
| 経理部 |        250000 |             |
| 経理部 |               |      300000 |
| 経理部 |               |      400000 |
| 総務部 |        200000 |             |
| 総務部 |        300000 |             |
| 総務部 |               |      300000 |
| 総務部 |               |      400000 |

確かに、求める結果が得られていることがわかります。しかし、WHERE句で条件分岐を行った上で、その結果をUNIONでマージしている点が冗長という問題があります。また、SQLの可読性もあまり良くないので、一見して何を行っているSQLか判断しづらいという問題もあります。

次に、実行計画を確認します。

| QUERY PLAN                                                                                                                                                                                                                               |
| :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| GroupAggregate  (cost=27.28..27.36 rows=2 width=86)                                                                                                                                                                                      |
| &nbsp;&nbsp;Group Key: employee.dept                                                                                                                                                                                                     |
| &nbsp;&nbsp;-\>  Unique  (cost=27.28..27.30 rows=2 width=82)                                                                                                                                                                             |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Sort  (cost=27.28..27.29 rows=2 width=82)                                                                                                                                           |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sort Key: employee.dept, employee.salary, (NULL::integer)                                                                                |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Append  (cost=0.00..27.27 rows=2 width=82)                                                                                          |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Seq Scan on employee  (cost=0.00..13.63 rows=1 width=82)                            |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Filter: ((class)::text = '担当者'::text) |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Seq Scan on employee employee_1  (cost=0.00..13.63 rows=1 width=82)                 |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Filter: ((class)::text = '課長'::text)   |

やや複雑な実行計画となっていますが、注目すべきは`Seq Scan on employee`が2回現れている点です。このことから、テーブルフルスキャンが2回発生しており、データアクセスの効率が悪いことが予想されます。

#### CASE式を使用した条件分岐

次に、CASE式を使用する方法について解説します。CASE式は「式」なので、SQLの中で値が入る可能性がある箇所ならどこでも使用することができます。今回は、集約関数の内部で使用することで、求める結果を得ることができます。

```sql
select
    dept
    , sum(case when class = '担当者' then salary else 0 end) as associate_sum
    , sum(case when class = '課長' then salary else 0 end) as manager_sum 
from
    employee 
group by
    dept
;
```

実行結果

| dept   | associate_sum | manager_sum |
| :----- | ------------: | ----------: |
| 総務部 |        500000 |      700000 |
| 経理部 |        450000 |      700000 |


CASE式にclassに応じた条件分岐を記述しており、条件に一致すればsalaryの値を、そうでなければ0とするように条件を記述しています。これらを集計関数SUMで足し合わせることで、それぞれのclassごとのsalaryを、GROUP BY句で指定したdept別に集計することができます。  
上記のSQLから分かる通り、UNIONで記述したSQLよりも、CASE式で記述したほうがSQLの可読性が向上しています(もちろん、CASE式の使い方を熟知していることが前提です)。

次に、実行計画を確認します。

| QUERY PLAN                                                               |
| :----------------------------------------------------------------------- |
| HashAggregate  (cost=1.18..1.20 rows=2 width=22)                         |
| &nbsp;&nbsp;Group Key: dept                                              |
| &nbsp;&nbsp;-\>  Seq Scan on employee  (cost=0.00..1.08 rows=8 width=22) |

ひと目で、実行計画もSQLと同様にシンプルになっていることがわかります。さらに、`Seq Scan on employee`の回数が1回に減っており、UNIONを使用したSQLよりも高速に実行できることが予想されます。

以上のことから、集計における条件分岐においても、CASE式が活用できることがわかります。集計の場合も「ケース1: SELECTする列の条件分岐」と同様に、UNIONではなくCASE式が使用できないか考えることが大切です。

### ケース3: 集約の結果に対する条件分岐

最後に、集約の結果で条件分岐を行うケースを見ていきます。

以下のケースの想定は、ここまで使用してきたemployeeテーブルの運用が変更となったというものです。employeeテーブルのclass列には一つの部門しか保持できないのですが、ここにきて複数名の社員が部門を兼任する場合があるとわかりました。

対応方針としては、大きく以下の2つがあります。

- テーブル定義を変更する
  - 例えば、所属部門テーブルを新規に作成し、所属部門はこちらで管理する。これにより、employeeテーブルのdept列は不要となるため削除する(所属部門を取得したい場合はemployeeテーブルと所属部門テーブルを結合)。
  - システム全体への影響が大きいため、今回はこの方法を採用しないことにします。ただし、設計としてのあるべき姿や、根本的な対応策として正しいのはこちらの方法ということには留意してください。
- 部門兼任の場合は、その部門数分のレコードを追加し、追加したレコードのdept列に兼任している部門を保持する。
  - 追加したレコードのsalaryとbonusはNULLとします。
  - 場当たり的な対応となっていますが、今回はこちらを採用したと仮定します。

上記の対応を取った結果、テーブルの各レコードの状態は以下のようになりました。

|   id | name      | salary |  bonus | class  | dept   |
| ---: | :-------- | -----: | -----: | :----- | :----- |
|    1 | tanaka    | 400000 | 300000 | 課長   | 経理部 |
|    2 | yamada    | 250000 | 100000 | 担当者 | 経理部 |
|    3 | suzuki    | 300000 |        | 課長   | 総務部 |
|    4 | saitoh    | 200000 |        | 担当者 | 総務部 |
|    5 | satoh     | 300000 |        | 課長   | 経理部 |
|    6 | takahashi | 200000 |        | 担当者 | 経理部 |
|    7 | yamamoto  | 400000 |        | 課長   | 総務部 |
|    8 | nakamura  | 300000 |        | 担当者 | 総務部 |
|    9 | tanaka    |        |        | 課長   | 総務部 |
|   10 | tanaka    |        |        | 課長   | 人事部 |
|   11 | yamada    |        |        | 担当者 | 総務部 |

tanakaが3部門を兼務、yamadaが2部門を兼務している状態です。

ここで、以下の集約を行うことを考えます。

- deptが1つの場合は、所属部門名を表示
- deptが2つの場合は、「2部門を兼務」と表示
- deptが3つ以上の場合は、「3部門以上を兼務」を表示

想定する結果は、以下のとおりです。

|       name | dept            |
| ---------: | :-------------- |
|     tanaka | 3部門以上を兼務 |
|     yamada | 2部門を兼務     |
|     suzuki | 総務部          |
| (以下省略) |                 |

#### UNIONを使用した条件分岐

では、UNIONを使用して集約を行う方法を考えます。

```sql
select
    name
    , max(dept) as dept 
from
    employee 
group by
    name 
having
    count(*) = 1 
union 
select
    name
    , '2部門を兼務' as dept 
from
    employee 
group by
    name 
having
    count(*) = 2 
union 
select
    name
    , '3部門以上を兼務' as dept 
from
    employee 
group by
    name 
having
    count(*) >= 3
;
```

実行結果

| name   | dept            |
| :----- | :-------------- |
| satoh  | 経理部          |
| (中略) |                 |
| yamada | 2部門を兼務     |
| tanaka | 3部門以上を兼務 |

SQLの見た目はそこまで複雑ではありませんが、細かいテクニックが含まれるので、以下で簡単に解説します。

- max(dept)について
  - 兼務ではない(1つの部門に所属する)場合はdept列の値をそのまま出力すれば良いですが、そのような記述はエラーとなります。なぜなら、GROUP BY句を使用した場合、SELECT句に記述できるのは「GROUP BY句に含まれる列」か、さもなくば「集約関数内で使用」する必要があるためです。今回は後者のルールに該当するよう、集約関数MAX内にdept列を記述することで、deptの値を取得・表示しています。  
  - 集約関数MAXは最大値を求める関数ですが、今回のように列値をそのまま表示する目的で便宜上使用される場合があります。なお、MIN関数でも同様の結果となります。
- count(*)について
  - 集計関数countは、ある集合内の要素数(レコード数)を返却する関数です。この関数は、テーブル内のレコード数を取得する目的で`select count(*) from テーブル名`の形でよく使用されます。この場合、テーブル全体を1つの集合と考え、その集合内のレコード数を取得しています。
  - 集計関数countをGROUP BY句を伴って使用した場合は、GROUP BY句によって分割された各集合内の要素数を取得することになります。今回はGROUP BY句でname列を指定して分割しているため、count(*)が返却する値としては、1件のレコードを持つ社員(一つの部門に所属)は1、2件の場合は2、3件の場合は3、となります。この返却値によって、所属部門の数を取得しています。

以下で、実行計画を確認します。

| QUERY PLAN                                                                                                                                                              |
| :---------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| HashAggregate  (cost=4.18..4.42 rows=24 width=10)                                                                                                                       |
| &nbsp;&nbsp;Group Key: employee.name, (max((employee.dept)::text))                                                                                                      |
| &nbsp;&nbsp;-\>  Append  (cost=1.19..4.06 rows=24 width=10)                                                                                                             |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  HashAggregate  (cost=1.19..1.29 rows=8 width=17)                                                                   |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Group Key: employee.name                                                |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Filter: (count(*) = 1)                                                  |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Seq Scan on employee  (cost=0.00..1.11 rows=11 width=17)           |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  HashAggregate  (cost=1.17..1.27 rows=8 width=7)                                                                    |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Group Key: employee_1.name                                              |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Filter: (count(*) = 2)                                                  |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Seq Scan on employee employee_1  (cost=0.00..1.11 rows=11 width=7) |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  HashAggregate  (cost=1.17..1.27 rows=8 width=7)                                                                    |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Group Key: employee_2.name                                              |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Filter: (count(*) \>= 3)                                                |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Seq Scan on employee employee_2  (cost=0.00..1.11 rows=11 width=7) |

これまでの例で見た実行計画と同様に、UNIONでテーブルを3回マージしているため、テーブルに対するアクセスも3回発生しており、非効率な実行計画となっています。

#### CASE式を使用した条件分岐

CASE式を使用してUNIONの場合と同様の結果を得るためのSQLは、以下のとおりです。

```sql
select
    name
    , case 
        when count(*) = 1 
            then max(dept) 
        when count(*) = 2 
            then '2部門を兼務' 
        when count(*) >= 3 
            then '3部門以上を兼務' 
        end as dept 
from
    employee 
group by
    name
;
```

UNIONを使用したSQLと比べて、可読性が向上していることがわかります。

実行計画は、以下のとおりです。

| QUERY PLAN                                                                |
| :------------------------------------------------------------------------ |
| HashAggregate  (cost=1.25..1.39 rows=8 width=17)                          |
| &nbsp;&nbsp;Group Key: name                                               |
| &nbsp;&nbsp;-\>  Seq Scan on employee  (cost=0.00..1.11 rows=11 width=17) |

CASE式を使用することで、SELECT句のレベルで条件分岐を実現した結果、テーブルへのアクセス回数は1回となりました。さらに、GROUP BYの実行回数が1回に減った結果として、`HashAggregate`(Hash演算)の回数も1回となっています。

### まとめ

ここまで、UNIONとCASE式を使用した条件分岐の例を紹介しました。そのいずれの場合においても、CASE式を使用したほうがSQLの可読性が高く、また実行計画も効率的で、高速に動作することがわかりました。

ここまでの説明を一般化すると、以下のようにまとめることができます。

- 条件分岐が必要な場合は、まずCASE式の使用を検討する
  - UNIONによる条件分岐は、考え方自体は理解しやすいのですが、実装したSQLや実行計画は非効率となりがちです。そのため、まずはCASE式の使用を検討してください。
- 条件分岐(場合分け)は、WHERE句やHAVING句の単位で行うのではなく、SELECT句の中で行うようにする
  - やや抽象的な表現となっていますが、例えば「ケース1: SELECTする列の条件分岐」においては、UNIONの場合は条件分岐(場合分け)の条件をWHERE句で指定していたのに対して、CASE式の場合はSELECT句の中で指定していました。このように、SELECT句の中で条件を指定できないか検討すると、自然とCASE式が使用できるようになると考えられます。

## UNIONの使用が妥当なケース

「UNIONを使用した条件分岐をCASE式にする」では、UNIONを使用したSQLをCASE式に書き換え、その有用性について解説しました。一方で、UNIONの使用が妥当なケースもあります。以下では、このようなケースについて確認していきます。

### UNIONを使用せざるを得ないケース

まず、UNION以外では実装できないケースを確認します。それは、別々のテーブルをマージする場合です。  
以下の例で別々のテーブルをマージするケースを考えます。操作ログを保存するテーブルなどのレコード数が多いテーブルでは、1つのテーブルですべてのレコードを管理するのではなく、それが(頻繁に)検索される条件に応じてテーブルをあらかじめ分割(パーティショニング)することがあります。例えば、あるログが月単位で検索されることが多い場合、ログテーブルをログが発生した月単位に分割して、2021_01_log、2021_02_log...というように別々のテーブルに分割します。こうすることで、1つのテーブルですべてのログを管理する場合よりも高速な検索が可能です。

ここで、月単位でlog_2021_01、log_2021_02...とテーブルを分割している状況において、「年単位」のログを一度のSQL実行で取得するケースを考えます。テーブル分割の単位が「月単位」なので、1つのテーブルに対する検索だけでは1年分のレコードを参照することはできません。この場合は、どうしても複数テーブル(log_2021_01、log_2021_02...、log_2021_12)に対する検索が必要です。

以下に、1年分のログを全量取得するSQLを示します。

```sql
-- 重複がない想定なので、UNIONではなくUNION ALLを使用
select
    * 
from
    log_2021_01 
union all
select
    * 
from
    log_2021_02 
-- (中略)
union all
select
    * 
from
    log_2021_12
;
```

上記のSQLで、1年分のログ全量を取得できます。このように、複数テーブルの検索結果をマージする必要がある場合は、UNION(UNION ALL)を使用する必要があります。特に条件分岐はないため、CASE式への書き換えはできません。

### UNIONの使用を検討するケース

次に、UNIONを使用するSQLとそうでないSQLを比較・検討すべきケースを見ていきます。インデックスを使用した検索が行えるケースでは、他の記法よりもUNIONのほうがメモリを節約できたり、処理が高速となったりする場合があります。

以下の想定のもと、UNIONを使用するSQLとそうでないSQLを比較します。sensorテーブルは、各工場に配置されているセンサーの情報を管理するテーブルです。startdateはセンサーの稼働開始日、operation_flagは稼働しているか否かをT(True)/F(False)で記録します。また、それぞれの列名の末尾のアルファベットは工場名(A工場、B工場、C工場)です。

sensorテーブル

| id                                                  | name       | startdate_a | operation_flag_a | startdate_b | operation_flag_b | startdate_c | operation_flag_c |
| :--------------------------------------------------- | :--------- | ----------: | :--------------- | ----------: | :--------------- | ----------: | :--------------- |
| 1                                                    | センサー01 |  2021/11/01 | T                |             |                  |             |                  |
| 2                                                    | センサー02 |             |                  |  2021/11/01 | T                |             |                  |
| 3                                                    | センサー03 |             |                  |  2021/11/01 | F                |             |                  |
| 4                                                    | センサー04 |             |                  |  2021/12/31 | T                |             |                  |
| 5                                                    | センサー05 |             |                  |             |                  |  2021/11/01 | T                |
| 6                                                    | センサー06 |             |                  |             |                  |  2021/12/01 | F                |
| 7                                                    | センサー07 |             |                  |             |                  |             |                  |
| (後略、残りのレコードはid列とname列以外がすべてNULL) |            |             |                  |             |                  |             |                  |

業務ルールとして、センサーが配置されている拠点以外の各列はNULLとなっていることにします。例えば、センサー01はA工場に配置しているためstartdate_aとoperation_flag_aには値が入っていますが、その他はNULLです。また、工場への配置が済んでいないセンサーについては、startdateとoperation_flagはすべてNULLです(センサー07以降のレコードが該当)。

このsensorテーブルから、稼働開始日が特定日付(startdateが2021/11/01)であり、かつ稼働中(operation_flagがT)であるレコードを取得するSQLを考えます。

#### UNIONによる実装

SQLは冗長になりますが、UNIONで実装した場合は以下のようになります。UNIONでマージしている3つのSELECT文で異なる点は、WHERE句で指定する列だけです。

```sql
explain 
select
    id
    , name
    , startdate_a
    , operation_flag_a
    , startdate_b
    , operation_flag_b
    , startdate_c
    , operation_flag_c 
from
    sensor 
where
    startdate_a = '2021/11/01' 
    and operation_flag_a = 'T' 
union 
select
    id
    , name
    , startdate_a
    , operation_flag_a
    , startdate_b
    , operation_flag_b
    , startdate_c
    , operation_flag_c 
from
    sensor 
where
    startdate_b = '2021/11/01' 
    and operation_flag_b = 'T' 
union 
select
    id
    , name
    , startdate_a
    , operation_flag_a
    , startdate_b
    , operation_flag_b
    , startdate_c
    , operation_flag_c 
from
    sensor 
where
    startdate_c = '2021/11/01' 
    and operation_flag_c = 'T'
;
```

実行結果

| id   | name       | startdate_a | operation_flag_a | startdate_b | operation_flag_b | startdate_c | operation_flag_c |
| :--- | :--------- | ----------: | :--------------- | ----------: | :--------------- | ----------: | :--------------- |
| 1    | センサー01 |  2021/11/01 | T                |             |                  |             |                  |
| 2    | センサー02 |             |                  |  2021/11/01 | T                |             |                  |
| 5    | センサー05 |             |                  |             |                  |  2021/11/01 | T                |


ここで、このSQLの実行速度を改善するため、以下のインデックスを作成します(インデックスに関しては[インデックスのセクション](index.md)で詳しく解説しています。ここでは、インデックスに指定した列を使用する検索(例えばWHERE句の条件にstartdate_aとoperation_flag_aがある場合)が高速化できる、と理解してください)。

```sql
create index idx_a on public.sensor(startdate_a,operation_flag_a)
create index idx_b on public.sensor(startdate_b,operation_flag_b)
create index idx_c on public.sensor(startdate_c,operation_flag_c)
```

上記のインデックスが作成された状況下で、SQLの実行計画を確認します。

| QUERY PLAN                                                                                                                                                                            |
| :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| HashAggregate  (cost=24.97..25.00 rows=3 width=42)                                                                                                                                    |
| &nbsp;&nbsp;Group Key: sensor.id, sensor.name, sensor.startdate_a, sensor.operation_flag_a, sensor.startdate_b, sensor.operation_flag_b, sensor.startdate_c, sensor.operation_flag_c  |
| &nbsp;&nbsp;-\>  Append  (cost=0.28..24.91 rows=3 width=42)                                                                                                                           |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Index Scan using idx_a on sensor  (cost=0.28..8.29 rows=1 width=42)                                                              |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Index Cond: ((startdate_a = '2021-11-01'::date) AND (operation_flag_a = 'T'::bpchar)) |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Index Scan using idx_b on sensor sensor_1  (cost=0.28..8.29 rows=1 width=42)                                                     |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Index Cond: ((startdate_b = '2021-11-01'::date) AND (operation_flag_b = 'T'::bpchar)) |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Index Scan using idx_c on sensor sensor_2  (cost=0.28..8.29 rows=1 width=42)                                                     |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Index Cond: ((startdate_c = '2021-11-01'::date) AND (operation_flag_c = 'T'::bpchar)) |

`Index Scan using idx_* on sensor`とあるように、全てのSELECT文に対してインデックスが使用されています。このインデックスによって、sensorテーブルのレコード数が多く、かつそれぞれのWHERE句の検索条件によってレコード件数が絞り込める場合に、テーブルフルスキャンと比べて高速にアクセスが可能です。

(参考) sensorテーブルのレコード数が少ない場合(100レコード程度)、インデックスが使用されずにテーブルフルスキャンが実行されることがあります。これは、インデックスを使用するよりもフルスキャンのほうが高速であるとDBMSが判断したためです。  
今回のケースのように、インデックスが存在しても使用されないケースがあることには注意が必要です。性能調査の際には、SQLの実装のみでインデックス使用の有無を判断するのではなく、必ず統計情報を更新した後に実行計画を取得して、インデックスが使用されているかどうか確認してください。

#### OR句による実装

次に、UNIONではなくOR句を使用する実装例を見ていきます。  
UNIONを使用する場合と比べて、SQLの可読性はやや改善されます。一方で、この実装ではインデックスが使用できないケースもあるため、実行計画を確認すべきです(筆者の環境ではビットマップインデックスを使用した検索となりました)。

```sql
select
    id
    , name
    , startdate_a
    , operation_flag_a
    , startdate_b
    , operation_flag_b
    , startdate_c
    , operation_flag_c 
from
    sensor 
where
    ( 
        startdate_a = '2021/11/01' 
        and operation_flag_a = 'T'
    ) 
    or ( 
        startdate_b = '2021/11/01' 
        and operation_flag_b = 'T'
    ) 
    or ( 
        startdate_c = '2021/11/01' 
        and operation_flag_c = 'T'
    )
;
```

## ループ系のSQLを一括実行できるSQLに書き換える

実案件における業務処理の実装で、以下のような処理を見かけることがあります。

- 検索条件に該当するレコードを1件ずつ取得することを繰り返し、得られたレコード群を明細として画面上に表示する
- レコードを1件ずつ取得し、ホスト側(Javaなどのプログラムで)で処理して、処理結果をテーブルに挿入することを繰り返す

上記の各処理は、いずれも「SQLを繰り返し実行する」という要素を含む処理です。このように、SQLを繰り返し発行するような処理を、以下ではループ系SQLと呼びます。  
ループ系SQLは効率の悪い処理となることが多いです(どうしてもこの実装が必要な場合もありますが)。一方で、ループ系SQLを書き換えることで、効率よくデータを処理することができる場合があります。

### ループ系SQLの改修例

以下のケースで、ループ系SQLの改修について考えます。sensor_logテーブルは、センサーの測定値を保存するためのテーブルです。id列はセンサーのID、unixtimeはデータの取得時刻、valueはセンサーの測定値(0~100の数値)をそれぞれ表しています。

sensor_logテーブル

| id                                     | unixtime   | value |
| :------------------------------------- | :--------- | ----: |
| 1                                      | 1635724801 |    67 |
| 1                                      | 1635724802 |    95 |
| 1                                      | 1635724803 |    45 |
| 1                                      | 1635724804 |    31 |
| 1                                      | 1635724805 |    99 |
| 1                                      | 1635724806 |    18 |
| 1                                      | 1635724807 |    82 |
| 1                                      | 1635724808 |    57 |
| 1                                      | 1635724809 |    57 |
| 1                                      | 1635724810 |    40 |
| 2                                      | 1635724801 |    96 |
| 2                                      | 1635724802 |    32 |
| 2                                      | 1635724803 |    12 |
| 2                                      | 1635724804 |    95 |
| 2                                      | 1635724805 |    32 |
| 2                                      | 1635724806 |    32 |
| 2                                      | 1635724807 |    12 |
| 2                                      | 1635724808 |    31 |
| 2                                      | 1635724809 |    57 |
| 2                                      | 1635724810 |    86 |
| (以下、大量のレコードが存在すると仮定) |            |       |

このテーブルに格納されたデータから、ある取得時刻の測定値とその前の測定値の変化を調べます。そして、この結果をsensor_summaryテーブルに格納することにします。  

sensor_summaryテーブルには、測定値の変化を格納するためのsign列が存在します。他の列については、sensor_logテーブルと同様です。  
sign列には、以下のルールで値を入れます。

- 前の測定値が存在しない場合: NULL
- 前の測定値よりも増加した場合: +
- 前の測定値よりも減少した場合: -
- 前の測定値よりと同じ値の場合: =

上記のルールに則ってレコードを挿入したsensor_summaryテーブルは、以下のようになります。

sensor_summaryテーブル

| id                                     | unixtime   | value | sign |
| :------------------------------------- | :--------- | ----: | :--- |
| 1                                      | 1635724801 |    67 |      |
| 1                                      | 1635724802 |    95 | +    |
| 1                                      | 1635724803 |    45 | -    |
| 1                                      | 1635724804 |    31 | -    |
| 1                                      | 1635724805 |    99 | +    |
| 1                                      | 1635724806 |    18 | -    |
| 1                                      | 1635724807 |    82 | +    |
| 1                                      | 1635724808 |    57 | -    |
| 1                                      | 1635724809 |    57 | =    |
| 1                                      | 1635724810 |    40 | -    |
| 2                                      | 1635724801 |    96 |      |
| 2                                      | 1635724802 |    32 | -    |
| 2                                      | 1635724803 |    12 | -    |
| 2                                      | 1635724804 |    95 | +    |
| 2                                      | 1635724805 |    32 | -    |
| 2                                      | 1635724806 |    32 | =    |
| 2                                      | 1635724807 |    12 | -    |
| 2                                      | 1635724808 |    31 | +    |
| 2                                      | 1635724809 |    57 | +    |
| 2                                      | 1635724810 |    86 | +    |
| (以下、大量のレコードが存在すると仮定) |            |       |      |

ここで、上記のsensor_summaryテーブルに対して、sensorテーブルに基づいたレコードを挿入する方法について考えます。

#### ループ系SQLの実装例とデメリット

まずは、ループ処理の中でSQLを複数発行してレコードを挿入するパターンを考えます。この場合は、ホスト側(SQLを発行するプログラム)で、以下のような処理を実行することになります。

- sensor_logテーブルの全レコードを取得
- ループ処理の内部で、あるレコードとその直前に記録されたレコードのvalue列どうしを比較し、sign列の符号を決定する
- その後、同じくループ処理の中でsensor_summaryテーブルへの挿入を実行する

(以下、疑似的なプログラミング言語で上記処理を記述しました。読み飛ばしてもこの後の解説に特に支障はありません)。

```
sensor_logテーブルの全レコード <= (select * from sensor_log; の取得結果)

# 以下、ループ処理
loop (sensor_logテーブルの全レコード)の要素数分だけ繰り返し

    sensor_logテーブルのレコード <= sensor_logテーブルの全レコード.1レコードを取得

    if sensor_logテーブルのレコードのid != sensor_logテーブルのレコードの1つ前のレコードのid then
        sign列の値 = NULL
    else
        if sensor_logテーブルのレコードのvalue > sensor_logテーブルのレコードの1つ前のレコードのvalue then
            sign列の値 = '+'
        else if sensor_logテーブルのレコードのvalue < sensor_logテーブルのレコードの1つ前のレコードのvalue then
            sign列の値 = '-'
        else
            sign列の値 = '='
    
    sensor_summaryテーブルへのINSERT  # 上記if文で生成したsign列の値を使用
    sensor_logテーブルのレコードの1つ前のレコード <= sensor_logテーブルのレコード

end # ループの終端
```

ループ系SQLのメリットは、処理内で実行するSQLが単純になることです。今回の例で実行しているSQLは以下の2本だけで、それぞれ簡単なSQLです。

- sensor_logテーブルの全レコードを取得(`select * from sensor_log`)
- sensor_summaryテーブルへの挿入(`insert into sensor_summary (...)`)

しかし、ループ系SQLの実行には、以下のデメリットがあります。

- SQL実行のオーバーヘッドにより遅くなる
  - SQLの実行時には様々な処理が発生します。その中でも、特にSQL文のパース(DBMSが処理しやすい形式への変換)と実行計画生成・評価には相応の時間がかかります。これらはSQLの実行のたびに処理が発生します(パース結果や実行計画はあらかじめキャッシュされたものが使用される場合もあります)。そのため、ループ系の処理で大量のSQLを繰り返し実行する場合には、繰り返しの回数だけオーバーヘッドが発生するため、処理全体で相当な時間がかかります。
- 並列分散に向かない
  - 一つ一つのSQLが単純なため、データベースサーバのCPUレベルの並列分散処理や、データが格納されたディスクレベルでのI/O分散など、並列分散処理ができない可能性があります。
- チューニングの余地が少ない
  - 単純なSQLを実行している以上、SQLレベルのチューニング余地がほとんどありません。一方、より複雑なSQLであれば、SQL自体を書き換えることによるチューニングに加えて、DB製品のバージョンアップによる性能向上(オプティマイザの改善など)の恩恵も受けられる可能性があります。

上記のループ系SQLの実行にかなりの時間がかかると仮定して、どのような改善策が考えられるでしょうか。

- ループを排除するために、処理とSQL自体を書き換える
  - この方法については、後ほど解説します。ただ、この方法はアプリケーション自体の改修を意味するため、改修のコストは高くなることが多いです。そのため、できるだけ設計段階で効率的なSQLを準備しておくことが重要です。
- ループはそのままにして、個々のSQLをチューニングする
  - 先述のとおり、個々のSQLは単純なため、チューニングの余地はほとんどありません。それでも、場合によっては改善可能なこともあります(インデックス追加など)。
- ループはそのままにして、処理を多重化する
  - 本テキストの学習範囲を超えるため詳しくは説明しませんが、アプリケーションレベルの改修でループ処理を多重化(並行実行)することで、性能が改善できる可能性があります。

#### 一括実行系SQLの実装例

では、上記のループ系処理を、一括実行できるようにSQLを書き換えます。

SQLでループを代替するために重要な要素は、CASE式とウィンドウ関数です。実際にループに対応しているのはウィンドウ関数であり、ループ内のif文に対応するのがCASE式です。(プログラミングにおけるfor文とif文と同様に)これらの要素はセットで使用することが多いため、「ループ処理にはCASE式とウィンドウ関数を使う」と覚えてしまってもよいでしょう。

では、以下に書き換え後のSQLを示します。以下のSQLを一回実行するだけで、ループ系SQLと同様の処理(sensor_summaryテーブルへの挿入)が行えます。

```sql
insert 
into sensor_summary 
select
    id
    , unixtime
    , value
    , case sign( 
            value - max(value) over ( 
                partition by
                    id 
                order by
                    unixtime rows between 1 preceding and 1 preceding
            )
        ) 
        when 0 then '=' 
        when 1 then '+' 
        when -1 then '-' 
        else null 
        end as sign 
from
    sensor_log
;
```

上記SQLを理解するためのポイントは、以下のとおりです。

- SIGN関数は数値型を引数に取り、0の場合は0を、符号がプラスなら1を、マイナスなら-1を返却します。この関数とCASE式で、直前に取得した測定値との差異の符号を生成しています。
- `unixtime rows between 1 preceding and 1 preceding`で`rows between n preceding and m preceding`の記法を使用しています。これは、「現在取得しているレコードのn行前からm行前までのレコード(群)」を表しています。この`rows between~`によって、max関数で比較するレコード群を「現在取得しているレコードの1行前から1行前までのレコード(群)」に絞り込んでいます。「1行前から1行前までのレコード(群)」とは、つまり「現在取得しているレコードの1行前の1レコード」なので、このレコードのvalueがmax関数の戻り値です。この戻り値が、(ORDER BY句を使用してunixtime順に並び替えているので)直前に取得したレコードを意味します。

次に、実行計画を確認します。

| QUERY PLAN                                                                                                      |
| :-------------------------------------------------------------------------------------------------------------- |
| WindowAgg  (cost=1.63..2.33 rows=20 width=17)                                                                   |
| &nbsp;&nbsp;-\>  Sort  (cost=1.63..1.68 rows=20 width=17)                                                       |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sort Key: id, unixtime                                          |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Seq Scan on sensor_log  (cost=0.00..1.20 rows=20 width=17) |

最初にsensor_logテーブルをテーブルフルスキャンして、次にウィンドウ関数でソートしています(partition byとorder byによるソート)。結合などの処理もないため、テーブルの状況によって実行計画が変動する恐れが少なく、性能自体の予測可能性も高いと言えます。

(参考)

以下では、より現実にありそうなケースについても考えてみます。ただし、「一括実行系への書き換え」という議論の本筋からは外れますので、参考情報として紹介します。

上記の例では、直近の測定値との差異を符号で出力しました。ただ、より現実的な状況としては、測定値が大きく変動したタイミングを別テーブルに記録しておくことで、そのデータを何らかの異常検知に役立てるといったシチュエーションが想定できます。  

以上のデータ抽出を実現するためには、SQLに以下の記述が必要です。

- ある取得時刻の測定値とその前の測定値との間の変化を調べる。
  - すでにsign列を作成する箇所で実装済みです。
- 測定値に大きな変化(例えば±50以上)があったレコードを抽出する。
  - こちらを新規実装します。

ただ、このSQLを実装する場合は、以下の点に注意する必要があります。

- WHERE句に列別名を使用することはできない
  - [一括実行系SQLの実装例](#一括実行系sqlの実装例)で紹介したSQLの「sign」列のように、直近の測定値との差異をSELECT句の中で計算して列別名(仮にdiffと置く)を付けた上で、この列別名diffを使ってWHERE句に条件式を書くことはできません(例えば`where abs(diff) >= 50`)。
- WHERE句にウィンドウ関数を書くことはできない
  - 列別名が使用できないなら、直接WHERE句の中にウィンドウ関数を使用した式を書くという考え方もありますが、こちらも不可能です。

結論としては、FROM句にサブクエリ(副問合せ)としてSELECT文を記述し、この内部でsign列やdiff列の計算を行います。そして、これらの列をSELECT句に記述し、WHERE句の条件式(`abs(diff) >= 50`)に使用することで、求める結果が取得できます。

```sql
-- sensor_summaryテーブルへのINSERTは省略
select
    id
    , unixtime
    , value
    , sign
    , diff 
from
    ( 
        select
            id
            , unixtime
            , value
            , case sign( 
                    value - max(value) over ( 
                        partition by
                            id 
                        order by
                            unixtime rows between 1 preceding and 1 preceding
                    )
                ) 
                when 0 then '=' 
                when 1 then '+' 
                when - 1 then '-' 
                else null 
                end as sign
            , value - max(value) over ( 
                partition by
                    id 
                order by
                    unixtime rows between 1 preceding and 1 preceding
            ) as diff 
        from
            sensor_log
    ) tmp 
where
    abs(diff) >= 50
;
```

実行結果

| id   | unixtime   | value | sign | diff |
| :--- | :--------- | ----: | :--- | ---: |
| 1    | 1635724803 |    45 | -    |  -50 |
| 1    | 1635724805 |    99 | +    |   68 |
| 1    | 1635724806 |    18 | -    |  -81 |
| 1    | 1635724807 |    82 | +    |   64 |
| 2    | 1635724802 |    32 | -    |  -64 |
| 2    | 1635724804 |    95 | +    |   83 |
| 2    | 1635724805 |    32 | -    |  -63 |

実行計画についても、sign列のみを求めるSQLと比べて大きな変化はありません。

| QUERY PLAN                                                                                                                                    |
| :-------------------------------------------------------------------------------------------------------------------------------------------- |
| Subquery Scan on tmp  (cost=1.63..2.73 rows=7 width=126)                                                                                      |
| &nbsp;&nbsp;Filter: (abs(tmp.diff) \>= 50)                                                                                                    |
| &nbsp;&nbsp;-\>  WindowAgg  (cost=1.63..2.43 rows=20 width=90)                                                                                |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Sort  (cost=1.63..1.68 rows=20 width=90)                                                 |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sort Key: sensor_log.id, sensor_log.unixtime                    |
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-\>  Seq Scan on sensor_log  (cost=0.00..1.20 rows=20 width=90) |
