# 参考資料

- このドキュメントは、[Python学習ガイド](./python_learning_guide.md)で取り上げなかった有用な参考資料を紹介するものです。
- 各資料のターゲットは、どちらかといえば[Python学習ガイド](./python_learning_guide.md)を使用した学習を一通り終えた方です。そのため、やや発展的な内容も含まれています。

---

目次

- [参考資料](#参考資料)
  - [List of Free Learning Resources In Many Languages(Pythonの学習資料集)](#list-of-free-learning-resources-in-many-languagespythonの学習資料集)
  - [The Algorithms - Python(代表的なアルゴリズムのPythonによる実装例)](#the-algorithms---python代表的なアルゴリズムのpythonによる実装例)
  - [build-your-own-x(様々なアプリケーションの実装チュートリアル)](#build-your-own-x様々なアプリケーションの実装チュートリアル)

---

## [List of Free Learning Resources In Many Languages(Pythonの学習資料集)](https://github.com/EbookFoundation/free-programming-books/blob/master/books/free-programming-books-ja.md#python)

- 無料公開されている学習資料のリンク集です。
- [Python学習ガイド](./python_learning_guide.md)で紹介したテキストと同等の内容を扱っている学習資料も多いですが、説明の仕方やサンプルコードが異なるため、ある単元を多角的に理解する用途に活用できます。
- 古いPythonバージョンの知識に基づいているテキストがあるため、よく確認した上で使用してください。
- Python以外のプログラミング言語に関する学習資料もまとめられています。

## [The Algorithms - Python(代表的なアルゴリズムのPythonによる実装例)](https://github.com/TheAlgorithms/Python/blob/master/DIRECTORY.md)

- 代表的な各種アルゴリズム(例: ソート、検索、暗号化)のサンプルコード集です。
- コードをコピーして動作を確認(いわゆる写経)するほか、他者の書いたコードを読み取るトレーニングにも活用できます。

## [build-your-own-x(様々なアプリケーションの実装チュートリアル)](https://github.com/danistefanovic/build-your-own-x#table-of-contents)

- アプリケーション(例: ボット、データベース、検索エンジン)の実装チュートリアルのリンク集です。
- Python以外のプログラミング言語を使用したチュートリアルもまとめられています。