# 環境構築ガイド

目次

- [環境構築ガイド](#環境構築ガイド)
  - [前提条件](#前提条件)
  - [pyenv](#pyenv)
  - [venv](#venv)
  - [Jupyter、Linter、Formatterのインストール](#jupyterlinterformatterのインストール)
  - [Visual Studio Code](#visual-studio-code)
  - [Visual Studio Code上でのプログラム実行](#visual-studio-code上でのプログラム実行)

---

## 前提条件

本ガイドを使用した環境構築は、以下の環境で実施することを想定している。

- 社内標準端末のOS(Windows 10)
- 社内ネットワークからインターネットにアクセスできること
- インストールするPythonは3系(3.x.x)

## pyenv

1. pyenvをダウンロードし、ローカルに配置する。
   - 右のURLにアクセス: [GitHub - pyenv-win/pyenv-win](https://github.com/pyenv-win/pyenv-win)
   - ページ中段の「Download link: pyenv-win」をクリックし、zipファイルをダウンロードする。
   	- `C:\Users\ユーザ名`の直下に「.pyenv」フォルダを手動で作成する。
	- ダウンロードしたzipファイルを解凍し、中身の **pyenv-winフォルダのみ** を`C:\Users\ユーザ名\.pyenv`フォルダに移動する。  
	  解凍したその他のフォルダ・ファイルは不要なので削除する。

1. 環境変数を以下の通り変更する。
   - Windowsキー+ Rキー を押して「ファイル名を指定して実行」を開き、`rundll32 sysdm.cpl,EditEnvironmentVariables`と入力して「OK」ボタンをクリックして環境変数の設定画面を表示する。
     - 上記の方法で表示できない場合は、右のURLの手順を参考に、環境変数の設定画面を表示する: [Windows 10でPath環境変数を設定／編集する：Tech TIPS - ＠IT](https://atmarkit.itmedia.co.jp/ait/articles/1805/11/news035.html)
   - ユーザー環境変数のPathに、以下の設定を追加する。  
     すでにインストーラなどでPythonをインストール済みの場合は、以下で設定する環境変数の値が既存のPythonのパスや`%USERPROFILE%\AppData\Local\Microsoft\WindowsApps`よりも前に設定されるよう記述すること(不明な場合は以下の設定を先頭に記述する)。
     - `%USERPROFILE%\.pyenv\pyenv-win\bin`
     - `%USERPROFILE%\.pyenv\pyenv-win\shims`

1. コマンドプロンプトを起動し、以下のコマンドを実行する。
   - 以下のコマンドを実行し、環境変数を(一時的に)設定する。これにより、pyenvはプロキシサーバを経由した通信が可能となる(プロキシサーバを経由しないと社内FWによって通信が拒否されてしまう)。

        ```console
        set http_proxy=gienah.in.dcs.co.jp:8080
        set https_proxy=gienah.in.dcs.co.jp:8080
        ```
   - インストール可能なPythonのバージョン一覧を表示する。このコマンドが正しく実行されない場合、pyenvの配置、または環境変数の設定を失敗している可能性がある。前の手順を見直して、ミスがないか確認すること。

        ```console
        pyenv install -l
        ```
   - インストール可能なPythonのバージョンから、任意のバージョンを指定してインストール(ダウンロード)する。  
   特に指定がない場合は、`a`や`rc`や`win32`といった文字列を含まない最新のバージョンを使用するとよい(以下のコマンドはバージョン3.9.4を指定する例)。また、ダウンロードには10分程度かかる。

        ```console
        pyenv install 3.9.4
        ```
   - インストール(ダウンロード)済みのPythonのバージョン一覧を表示する。  
   インストールしたPythonのバージョンが表示されない場合、インストールに失敗している可能性がある。一つ前の手順を再度実施すること。

        ```console
        pyenv versions
        ```
   - pyenvの設定フォルダを再作成する。  
   このコマンドを実行すると、C:\Users\ユーザ名\.pyenvフォルダ以下に設定フォルダが生成する。今後、pyenvがうまく動作しない場合は、念のため`pyenv rehash`を実行すること。
    
        ```console
        pyenv rehash
        ```

1. ここまでの手順でpyenvの初期設定が完了した。  
以下のコマンドは、新規にPythonプロジェクトを作成する際に、そのつど実行すること。
   - 任意の場所にプロジェクトフォルダを作成する。
   - コマンドプロンプトを起動し、任意のプロジェクトフォルダに移動する。

        ```console
        (例) cd C:\Users\dcs\workspace
        ```
   - プロジェクト内で使用するPythonのバージョンを指定する。

        ```console
        (例) pyenv local 3.9.4
        ```
   - 上記のコマンドによりプロジェクトフォルダ内に生成する`.python-version`ファイルをテキストエディタで表示すると、指定したバージョン番号が記述されている。
   - プロジェクト内で使用するPythonのバージョンを確認する。

        ```console
        pyenv version
        ```

## venv

1. PowerShellを管理者権限で起動し、以下のコマンドを実行する。  
**このコマンドは、今回の一度だけ実行すればよく、これ以降に仮想環境を新規作成・使用する際の実行は不要である。**

    ```powershell
    Set-ExecutionPolicy RemoteSigned
    (コマンド実行後に表示される選択肢ではyを入力し、Enterキーを押すこと)
    ```

1. コマンドプロンプトを起動し、以下のコマンドを実行する。以下のコマンドを実行すると、仮想環境の初期設定が完了する。
   - 任意のプロジェクトフォルダに移動する。

        ```console
        (例) cd C:\Users\dcs\workspace
        ```
   - venvの仮想環境を生成する。  
   仮想環境名には「.venv」がよく用いられる。このコマンドによりプロジェクトフォルダ内に仮想環境名と同名のフォルダが生成する。

        ```console
        python -m venv [作成する仮想環境名]
        (例) python -m venv .venv
        ```

1. コマンドプロンプトを起動し、以下のコマンドを実行する。以下のコマンドは、仮想環境の操作をする際にそのつど実行する。
    - 任意のプロジェクトフォルダに移動する。

        ```console
        (例) cd C:\Users\dcs\workspace
        ```
    - 以下のコマンドを実行して仮想環境に入る。

        ```console
        .venv\Scripts\activate
        ```
    - 上記のコマンドで仮想環境に入った(activateした)状態でPythonのコマンドを実行した場合、コマンドは仮想環境内で実行される。  
    例えば、仮想環境に入った状態で`pip install ~~~`コマンドを実行すると、パッケージは仮想環境下にインストールされる。そのため、仮にインストーラなどを使用してホスト環境(Windows)にPythonがインストールされていても、**ホスト環境は改変されない。**
    - 以下のコマンドを実行すると、仮想環境から抜ける。

        ```console
        deactivate
        ```

## Jupyter、Linter、Formatterのインストール

1. `.venv\Scripts\activate`でvenvの仮想環境に入り、以下のコマンドで各種パッケージをインストールする。

    ```python
    pip install jupyter flake8 black --trusted-host pypi.python.org --trusted-host files.pythonhosted.org --trusted-host pypi.org --proxy=http://gienah.in.dcs.co.jp:8080
    ```

1. 各パッケージの役割は以下の通り。
    - jupyter: Jupyter Notebookを表示・実行するためのパッケージ
    - flake8: Pythonのコードをチェックし、問題点を指摘するツール(静的検証ツール、Linter)
    - black:  Pythonのコードを自動で整形(フォーマット)するツール(コード整形ツール、Formatter)

## Visual Studio Code

1. 右のURLにアクセスし、手順通りに「インストールの実施（VSCode）」~「文字コード、改行コードの設定」までを実施する: [javascript-introduction · GitLab](http://gitlab.in.dcs.co.jp/education/javascript-introduction/blob/master/docs/environment.md#%E3%82%A4%E3%83%B3%E3%82%B9%E3%83%88%E3%83%BC%E3%83%AB%E3%81%AE%E5%AE%9F%E6%96%BDvscode)
1. [エクステンションのインストール](http://gitlab.in.dcs.co.jp/education/javascript-introduction/blob/master/docs/environment.md#%E3%82%A8%E3%82%AF%E3%82%B9%E3%83%86%E3%83%B3%E3%82%B7%E3%83%A7%E3%83%B3%E3%81%AE%E3%82%A4%E3%83%B3%E3%82%B9%E3%83%88%E3%83%BC%E3%83%AB)の手順に従って、以下のエクステンション(拡張機能)をインストールする(手順内にあるPrettierなどはインストール不要)。
    - Japanese Language Pack for Visual Studio Code
    - Python
    - Pylance(Python拡張機能をインストールする際に同時にインストールされる)
    - Jupyter(Python拡張機能をインストールする際に同時にインストールされる)
1. Visual Studio Code上で`Ctrl + ,`キーを押し、設定画面を開く。画面上部の検索バーに以下を入力し、それぞれ設定する。
    - `python.linting.flake8Enabled`: チェックを入れる
    - `python.linting.pylintEnabled`: チェックを **外す**
    - `python.formatting.provider`: blackを選択
    - `editor.formatOnSave`: チェックを入れる

## Visual Studio Code上でのプログラム実行

1. 任意のプロジェクトフォルダ(venvの仮想環境名のフォルダが存在するフォルダ)直下に、Pythonプログラム(.pyファイル)を配置する。
1. プロジェクトフォルダをVisual Studio Codeで開く。  
フォルダを開く方法は複数あるが、以下のいずれかの方法で開くと簡単である。
     - エクスプローラ上でフォルダを右クリックし、右クリックメニューから「Codeで開く」を選択する
     - Visual Studio Codeを起動して画面左上の「ファイル」から「フォルダーを開く」を選択する
1. 画面左側のペイン(表示領域)にプロジェクトフォルダ内のフォルダ・ファイルが表示されるので、配置した.pyファイルをクリックして開く。
1. Visual Studio Code上で.pyファイルを開いた状態で、画面左下のPython x.y.z(バージョン番号)と書かれた箇所をクリックし、画面上部にPythonインタープリターのリストを表示する。  
![interpreter_list](./images/environment/interpreter_list.png)
1. リストの中に`.\仮想環境名\Scripts\python.exe`と書かれたものがあれば、それをクリックする(例: `.\.venv\Scripts\python.exe`)。  
ない場合は、`+ Enter interpreter path...`と書かれた箇所をクリックし、`Find...`をクリックする。ダイアログボックスが表示されるので、`プロジェクトフォルダ\仮想環境名\Scripts\python.exe`を選択する。
1. プロジェクトフォルダ内に.vscodeフォルダとsetting.jsonファイルが自動生成する。setting.jsonファイルには、前の手順で設定したPythonインタープリターのパスが記録される。
1. 画面左下のPython x.y.z(バージョン番号)と書かれた箇所に`Python x.y.z 64-bit ('仮想環境名': venv)`と表示されていることを確認する(例: `Python 3.9.4 64-bit ('.venv': venv)`)。
1. Visual Studio Code上で,pyファイルを開いた状態でF5キーを押す。
1. 画面上部にDebug Configurationのリストが表示されるので、「Python File」をクリックする。  
![debug_configuration](./images/environment/debug_configuration.png)
1. 画面下部で自動的にターミナル(PowerShell)が開き、`プロジェクトフォルダ/仮想環境名/Scripts/Activate.ps1`が実行され、仮想環境に入った状態でPythonプログラムが実行される。実行結果(`print()`によるターミナル出力やエラーの情報)は、このターミナル上に表示される。
1. .pyファイルを開いた状態で、画面左側にある虫と▷が組み合わさったアイコン(実行とデバッグ)をクリックする。  
1. 開いたペイン(表示領域) の「launch.jsonファイルを作成します」と書かれたリンクをクリックする。
1. プログラム実行時と同様にDebug Configurationのリストが表示されるので、「Python File」をクリックする。
1. プロジェクトフォルダ直下の.vscodeフォルダ内にlaunch.jsonファイルが自動生成し、Visual Studio Code上にlaunch.jsonファイルが表示される。  
表示されたlaunch.jsonファイルは、特に変更せずに閉じてよい。
1. 再度、Visual Studio Code上で.pyファイルを開き、F5キーを押す。
1. 前の手順でF5キーを押したときと異なり、
     - Debug Configurationのリストが表示されないこと
     - 画面左側に表示される実行とデバッグのペインに、「launch.jsonファイルを作成します」と書かれたリンクが存在しないこと

     をそれぞれ確認する。
1. これ以降、プロジェクトフォルダ内に作成した.pyファイルを実行する際は、Visual Studio Codeで.pyファイルを開いた上でF5キーを押すだけでよい。
1. 別のプロジェクトフォルダで.pyファイルを実行する場合は、上記の手順を再び実行すること。  
特に、**Pythonインタープリターの設定が以前のプロジェクトフォルダ(仮想環境)の設定のまま残っている場合があるので、必ず確認すること。**
