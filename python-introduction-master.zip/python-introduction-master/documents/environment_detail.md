# 環境構築ガイド_詳説

- このドキュメントは、[環境構築ガイド](./environment.md)で構築した開発環境について、以下の情報を補足するものです。
  - 各ツールの役割と導入のメリット
  - 各ツールの設定に関する解説

---

目次

- [環境構築ガイド_詳説](#環境構築ガイド_詳説)
  - [開発環境の概説](#開発環境の概説)
  - [各ツールの詳細](#各ツールの詳細)
        - [pyenv](#pyenv)
          - [動作の仕組み](#動作の仕組み)
        - [venv](#venv)
          - [動作の仕組み](#動作の仕組み-1)
          - [参考資料](#参考資料)
        - [各種パッケージ](#各種パッケージ)
          - [flake8(Linter)](#flake8linter)
          - [black(Formatter)](#blackformatter)
          - [Jupyter](#jupyter)
          - [(参考) その他のツール](#参考-その他のツール)
        - [Visual Studio Code](#visual-studio-code) 

---

## 開発環境の概説

以下で、[環境構築ガイド](./environment.md)にて構築する環境と、その必要性について解説します。

(Windows上での)Pythonのプログラム開発に最低限必要となる要素は、以下の2点です。

- Pythonインタープリター
  - Pythonプログラムをコンピュータが解釈し、実行するために必要です。
- テキストエディタ
  - Pythonプログラム(コード)を記述するために必要です。

このうち、Pythonインタープリターについては[Python公式サイト](https://www.python.org/)からWindows用のインストーラをダウンロードして実行すればインストールできます。また、テキストエディタとしては、Windowsに付属する「メモ帳」や、別途インストールした任意のテキストエディタを使用できます。

一方で、インタープリターとテキストエディタだけを使用してプログラムを開発すると、特に実案件におけるプログラム開発においては以下の問題が発生することがあります。

- Pythonのバージョンを変更することが難しい
  - 案件によっては、使用するPythonのバージョンを状況に応じて変更する場合があります。例えば、「現行システムのPythonをバージョンアップする」という案件において、ローカル上に現行システムのPythonバージョンと新システムのPythonバージョンの開発環境を作成し、それぞれの環境下でプログラムのテストを実施するといったケースが考えられます。別のケースとしては、配布されているプログラムの動作するPythonバージョンが指定されている場合に、特定のバージョンをインストールして使用することがあります。
  - Windows上に直接インストールしたPythonのバージョンを変更する場合、Pythonをアンインストールした上で別のバージョンを再度インストールする必要があり、手順が煩雑で時間もかかります。
- Pythonのパッケージ構成を変更することが難しい
  - Pythonには`pip`コマンドを使用してパッケージ(例: 数値解析ツール、Webアプリケーションフレームワークなど)をインストールする仕組みがあります。インストールするパッケージは(各パッケージのバージョンも含めて)案件で要求されるものだけを使用する必要があります。そのため、複数の案件を掛け持ちする場合は、それぞれの案件で別々のパッケージ構成が必要となることがほとんどです。
  - Windows上に直接インストールしたPythonでは、パッケージ構成を切り替えることはできません。そのため、パッケージ構成を変更する場合はそのつどパッケージをインストール・アンインストールする必要があり、手順が煩雑で時間もかかります。
- コーディング規約を守ってプログラムを記述することが難しい
  - 保守性が高くバグの少ないプログラムを作成するためには、コーディング規約を遵守することが重要です。また、プログラムの生産性を向上するためには、開発者が意識しなくても自動的にコーディング規約に合ったコードを記述できる仕組みが求められます。
  - Pythonインタープリター自体に、コーディング規約を遵守しているかチェックし、プログラムを自動的にコーディング規約に合ったものに修正する機能はありません。
- テキストエディタにプログラム開発支援機能がない
  - プログラム開発の生産性を向上するためには、テキストエディタにシンタックスハイライトやプログラムをエディタ上で実行できるといった開発支援機能があることが望ましいです。
  - 「メモ帳」などのテキストエディタには、プログラムの開発支援機能はありません。

上記の問題を解説するために、[環境構築ガイド](./environment.md)では以下のツールを導入・使用しています。

- [pyenv](https://github.com/pyenv/pyenv)
  - 複数のPythonバージョンを管理するためのツールです。異なるバージョンのPythonをインストールし、必要に応じて使用するPythonのバージョンを切り替えるなどの機能があります。
- [venv](https://docs.python.org/ja/3/library/venv.html)
  - 仮想環境(**V**irtual **Env**ironment)を作成し、この内部でパッケージ構成を管理するためのツールです。仮想環境はホストOS(Windows)や他の仮想環境から独立しているため、互いの環境に影響を与えずにパッケージをインストール・アンインストールすることができます。
- 各種パッケージ
  - [flake8](https://pypi.org/project/flake8/)(Linter)
     - Pythonプログラムの解析を行い、Python公式のコーディング規約([PEP 8](https://pep8-ja.readthedocs.io/ja/latest/))などに従っているかチェックします。また潜在的なバグが発生しうるコードの有無をチェックし、プログラムの問題点を指摘します。
     - 一般に、プログラムの静的解析を行うこと(プログラムを実行せずに解析すること)をLint、静的解析を行うツールをLinterと呼びます。静的解析ツールはプログラムの問題点を指摘しますが、自動修正までは行いません(ツールによっては自動修正まで行うことができます)。参考: [lintとは - IT用語辞典 e-Words](https://e-words.jp/w/lint.html)
  - [black](https://github.com/psf/black)(Formatter)
     - Pythonプログラムの解析を行い、コーディング規約([PEP 8](https://pep8-ja.readthedocs.io/ja/latest/))などのルールに合わせてプログラムを整形(format)するツールです。  
     PEP 8に準拠しているかチェックする点はflake8と似ていますが、コードを規約に合わせて整形する機能を持っている点が異なります(flake8などのLinterは基本的にチェックのみ)。
     - 一般に、任意のコードスタイルへプログラムを整形するツールをFormatterと呼びます。
  - [Jupyter](https://pypi.org/project/jupyter/)
     - [Jupyter Notebook](https://jupyter.org/)(MarkdownテキストやPythonなどのプログラムを含むことができるドキュメント形式)を表示するためのパッケージです。
     - プログラム開発に必須のパッケージではないため、インストールしなくても問題ありません。ただし、[Python学習ガイド](./python_learning_guide.md)で紹介しているテキストや講座の一部でJupyter Notebook形式の学習資料が提供されるケースがあるため、ここで導入しています。
- [Visual Studio Code](https://code.visualstudio.com/)
  - Microsoftが開発しているソースコードエディタで、プログラム開発をサポートする様々な機能(シンタックスハイライト、プログラムの実行とデバッグ、LinterやFormatterとの連携など)を提供します。
  - 拡張機能をインストールすることで、様々な機能を追加することもできます。

## 各ツールの詳細

以下で、各ツールの機能と[環境構築ガイド](./environment.md)にて紹介した一部の手順について、その詳細や実行結果について補足します。

### pyenv

#### 動作の仕組み

pyenvは、以下の流れでPythonのバージョンを切り替え、実行しています。

1. Pythonのコマンド(`python`や`pip`)をコマンドプロンプトなどで実行すると、Windowsは環境変数のPathに設定された文字列の先頭から各フォルダ内を検索し、同名のファイルの存在をチェックする。
1. WindowsはPathに記述されている`C:\Users\ユーザ名\.pyenv\pyenv-win\shims`直下の.batファイルを実行する(例えば`python`コマンドを実行した場合は`python.bat`)。  
なお、1.と2.に示した動作の都合上、Pathに追記する`C:\Users\ユーザ名\.pyenv\pyenv-win\shims`はWindowsに直接インストールしたPythonのパス(存在する場合)よりも前に記述する必要がある(後に記述した場合は直接インストールしたPythonが優先で実行されてしまいpyenvが使用されないため)。
1. (以下がpyenv本体の動作) 実行された.batファイルは以下の設定を順番に確認し、設定されていれば該当するバージョンのPythonを実行する(太字は環境構築で設定したもの)。
   1. 環境変数の`PYENV_VERSION`
   1. **カレントディレクトリにある`python-version`ファイル(バージョンは`pyenv local`コマンドで設定可能)**
   1. カレントディレクトリの親ディレクトリの`python-version`ファイル
   1. グローバルな `C:\Users\ユーザ名\.pyenv\pyenv-win\version`ファイル(バージョンは`pyenv global`コマンドで設定可能)
   1. 上記の設定がすべて存在しない場合、Windows上に直接インストールしたPythonを実行

`pyenv install x.y.z`でインストールしたPythonは`C:\Users\ユーザ名\.pyenv\pyenv-win\versions`直下のx.y.zという名前のフォルダにインストールされています。そのため、`pyenv local`コマンドでPythonバージョンを指定した状態で`python`コマンドを実行した場合は、指定したバージョン名のフォルダ直下の`Python.exe`が実行されます。

### venv

#### 動作の仕組み

venvは、以下の流れで仮想環境を作成し、その内部で実行された各種パッケージのインストールなどを外部(WindowsなどのホストOSや他の仮想環境)から分離しています。

1. プロジェクトフォルダ内で`python -m venv [作成する仮想環境名]`コマンドを実行すると、プロジェクトフォルダ直下に仮想環境名のフォルダが生成します。この際、フォルダ内にはPythonの実行に必要な各種実行ファイル(Python.exeなど)が生成します。なお、ここで生成する各種実行ファイルは、インストール済みのPythonの各種実行ファイルがコピーされたものです。  
今回はpyenvを使用してPythonをインストールした上で、`pyenv local`コマンドを実行することでプロジェクトフォルダ内で使用するPythonバージョンを指定しています。そのため、結果的に`C:\Users\ユーザ名\.pyenv\pyenv-win\versions`直下の`x.y.z`(バージョン番号)フォルダ内の実行ファイルを仮想環境名のフォルダにコピーする、という挙動になります。これと同様に、pyenvを使用せずホストOSに直接Pythonをインストールしている場合は、その実行ファイルがコピーされます。  
仮想環境を作成する際には、`pip`や`setuptools`といったPythonの環境構築に必要なパッケージも自動でインストールされます。
1. `仮想環境名\Scripts\activate`を実行すると、以下の設定が適用されます。
     - 環境変数Pathの文字列の先頭に仮想環境配下のフォルダ(`仮想環境\Scripts`)を追記する。これにより、仮想環境に入った状態で`python`コマンドや`pip`コマンドを実行すると`仮想環境名\Scripts\python.exe(pip.exe)`が実行されます。  
     - 環境変数VIRTUAL_ENVに仮想環境のフォルダのパスを追記する。

        上記の環境変数の設定は、`仮想環境名\Scripts\activate`を実行した後に以下のコマンドを実行すると確認できます。  

        ```powershell
        # PowerShellの場合
        > (.venv) Get-ChildItem env:
        Name                           Value
        ----                           -----
        ...
        Path                           C:\~~~\仮想環境名\Scripts;...
        ...
        VIRTUAL_ENV                    C:\~~~\仮想環境名
        ...
        ```
        
        ```powershell
        # コマンドプロンプトの場合(実行結果はPowerShellと同様)
        > (.venv) set
        ```
     - Pythonのsysモジュールが持つ変数を仮想環境のパスに応じて書き換える。

1. 上記の設定により、`pip install`コマンド実行時のインストール先が`仮想環境名\Lib\site-packages`となります。この結果として、仮想環境内で実行するPythonプログラムが使用するパッケージやパッケージのインストールを外部(WindowsなどのホストOSや他の仮想環境)から分離することができます。

#### 参考資料

- [venv --- 仮想環境の作成 — Python 3.9.4 ドキュメント](https://docs.python.org/ja/3/library/venv.html)
- [venvが動作する仕組みを調べてみた - えんでぃの技術ブログ](https://endy-tech.hatenablog.jp/entry/how_venv_works_in_python)

### 各種パッケージ

それぞれのPythonパッケージについて、以下で簡単に説明します。なお、動作の仕組みについての詳しい説明は省略します。

#### flake8(Linter)

flake8は以下の静的解析ツールをまとめて実行することができるツールです。

- [PyFlakes](https://github.com/PyCQA/pyflakes): コードの文法上のエラーをチェック
- [pycodestyle](https://github.com/PyCQA/pycodestyle): コードが[PEP 8](https://pep8-ja.readthedocs.io/ja/latest/)に準拠しているかチェック
- [McCabe complexity checker](https://github.com/PyCQA/mccabe): [McCabeのコードの循環的複雑度](https://ja.wikipedia.org/wiki/%E5%BE%AA%E7%92%B0%E7%9A%84%E8%A4%87%E9%9B%91%E5%BA%A6)のチェック。ただし、デフォルト設定では無効化されている(環境構築ガイドでも無効のままとした)

PythonのLinterとしては、flake8のほかに[Pylint](https://github.com/PyCQA/pylint)があります。Pylintはflake8と比較すると、より幅広くチェックを行う傾向にあります。一方で、チェックにやや時間がかかり、Pylintを初期設定のまま使用するとミスではないコードも指摘してしまうといった弱点もあります。また、2021年時点ではflake8のほうがよく採用されているようです。  
(参考資料)
- [Pythonのコード改善のためのツール5つを試してみた - minus9d's diary](https://minus9d.hatenablog.com/entry/2018/10/22/235604)
- [Flake8プラグイン&フォーマットツールまとめ | DevelopersIO](https://dev.classmethod.jp/articles/flake8-plugins-and-format-tools/)

以上のことから、環境構築ガイドではflake8を使用することにしました。

#### black(Formatter)

PythonのFormatterにはblackのほかに[autopep8](https://github.com/hhatto/autopep8)や[yapf](https://github.com/google/yapf)があります。いずれのFormatterも、コード整形のルールやカスタマイズできる範囲が異なる程度で、機能や使用感は互いによく似ています。  
このうち、autopep8はflake8の項で紹介した[pycodestyle](https://github.com/PyCQA/pycodestyle)がチェックする一部指摘は[修正しません](https://github.com/hhatto/autopep8#features)。また、yapfはカスタマイズ性が高いため、初めてPythonに触れる方にとっては設定がやや難しく感じられる可能性があります。  
blackは、基本的にpycodestyleの指摘をすべて修正します。また、PEP 8には定義されていないものの可読性を下げる記法についても修正します。一方で、カスタマイズできる項目はほとんどありません。それゆえ、初期設定のまま簡単に使用できるというメリットがあります。

以上のことから、環境構築ガイドではblackを使用することにしました。

#### Jupyter

Jupyter Notebook(MarkdownテキストやPythonなどのプログラムを含むことができるドキュメント形式)を表示するためのパッケージです。

#### (参考) その他のツール

以下では、環境構築ガイドでは導入しなかったLinter・Formatterを紹介します。  
環境構築ガイドは初学者にもわかりやすい開発環境を構築するために、ツールの導入は必要最小限にしています。そのため、以下に挙げるツールは導入しませんでした。  
以下で列挙するツールは、正しく使用することでコードの保守性や可読性を向上することができます。必要に応じて導入を検討してください。もちろん、環境構築ガイドで構築した環境に追加で導入してもかまいません。

- [mypy](https://github.com/python/mypy)
  - 静的型チェックを行うツール(Linter)です。
  - Pythonは[動的型付け](https://ja.wikipedia.org/wiki/%E5%8B%95%E7%9A%84%E5%9E%8B%E4%BB%98%E3%81%91)言語です。つまり、ある変数に格納するデータ型を指定する必要はなく、変数に代入するデータ型にも制限はありません。  
  動的型付けには、プログラムの変更への対応が容易であるといったメリットがあります。一方で、例えば関数の引数のデータ型を(実装の段階で)指定できないといったデメリットもあります。
  - mypyの主な機能は、Pythonの[型ヒント](https://docs.python.org/ja/3/library/typing.html)の仕組みと対応して、型ヒントと異なる値が変数に代入されるコードをエラーとして指摘することです。これにより、想定外の型の値が使用されることによるバグを未然に防止できます。
  - (使用例) 以下のサンプルコードにおけるdivide関数の引数と戻り値には型ヒントが記述されており、int型の引数を2つ取り(`x: int, y: int`の部分)、int型の値を返却することを意図しています(`-> int`の部分)。
    
        ```python
        def divide(x: int, y: int) -> int:
          return x / y
    
    
        print(divide(1.0, "2"))
        ```  
        このコードをmypyでチェックすると、以下のエラーが指摘されます。指摘内容は、関数の戻り値の型ヒントとしてintが指定されているが、実装の戻り値はfloat型(`x / y`の除算結果はfloat型)である点と、引数の型ヒントがint型であるのにfloat型とstr型を渡して関数を実行している点です。
    
        ```python
        ~~~.py:2: error: Incompatible return value type (got "float", expected "int")
        ~~~.py:5: error: Argument 1 to "divide" has incompatible type "float"; expected "int"
        ~~~.py:5: error: Argument 2 to "divide" has incompatible type "str"; expected "int"
        ```  
        上記のコードを以下のように変更することで、mypyによる指摘は解消されます。  
        ただし、基本的にmypyの指摘は機械的に修正できるものではない点に注意が必要です(例えばサンプルコードの引数の型ヒントをfloatとする修正も考えられる)。ゆえに、修正する際はプログラムの設計仕様に基づいて判断する必要があります。
        ```python
        def divide(x: int, y: int) -> float:
          return x / y
    
    
        print(divide(1, 2))
        ```
- [autoflake](https://github.com/myint/autoflake)
  - 未使用のインポートと変数を削除するツール(Formatter)です。未使用のインポートと変数はflake8に含まれている[PyFlakes](https://github.com/PyCQA/pyflakes)でチェック(Lint)できますが、これをさらに一歩進めて自動削除まで実施するツールとなります。
  - (使用例) 以下のサンプルコードではmathモジュールがインポートされていますが、プログラム内で使用されていません。また、divide関数内で変数answerが定義されていますが、こちらも使用されていません。
    
        ```python
        import math
    
    
        def divide(x, y):
            answer = x / y
            return x / y
        ```  
        このコードをautoflakeでフォーマットすると、未使用のインポートと変数が削除されます。ただし、`x / y`は無意味なコードとして残ってしまいます。
    
        ```python
        def divide(x, y):
            x / y
            return x / y
        ``` 
- [isort](https://github.com/PyCQA/isort)
  - インポートされているライブラリの順序をチェックし、並び替えるツール(Linter兼Formatter)です。
  - インポートの順序や記法は[PEP 8に規約があり](https://pep8-ja.readthedocs.io/ja/latest/#import)、これに従って並び替えを行います。

### Visual Studio Code

Visual Studio Codeはそのままでも高機能のテキストエディタとして使用できますが、拡張機能(エクステンション)を導入することで機能を追加し、より効率的なプログラム開発を行うことができます。  
環境構築ガイドでは、Visual Studio Codeにいくつかの拡張機能をインストールしました。これらの役割を、以下で簡単に説明します。

- [Japanese Language Pack for Visual Studio Code](https://marketplace.visualstudio.com/items?itemName=MS-CEINTL.vscode-language-pack-ja)
  - Visual Studio CodeのUIを日本語化する拡張機能です。
- [Python](https://marketplace.visualstudio.com/items?itemName=ms-python.python)
  - Pythonのプログラム開発に有用な各種機能(IntelliSense(コード補完)、デバッグ、シンタックスハイライト、Lint、Formatなど)を追加する拡張機能です。
- [Pylance](https://marketplace.visualstudio.com/items?itemName=ms-python.vscode-pylance)
  - IntelliSenseや自動インポートなどの機能を持つ[言語サーバ](https://docs.microsoft.com/ja-jp/visualstudio/extensibility/language-server-protocol?view=vs-2019)を使用するための拡張機能です。
- [Jupyter](https://marketplace.visualstudio.com/items?itemName=ms-toolsai.jupyter)
  - Jupyter Notebook形式のドキュメントをVisual Studio Code上で表示するための拡張機能です。
