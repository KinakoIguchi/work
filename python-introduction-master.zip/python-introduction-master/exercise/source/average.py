num1 = 10
num2 = 20
num3 = 30
average = (num1 + num2 + num3) / 3

print(average)
