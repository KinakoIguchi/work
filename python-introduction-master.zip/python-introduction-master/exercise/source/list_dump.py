list = [1, 2, 3, 4, 5]

for elem in list:
    print(elem)
