def sum(a=0, b=0):
    return a + b


print(sum(1, 2))

# 第2引数には何も指定していないので0がデフォルト値として代入される
print(1)

# (参考) Noneを引数とした場合であっても、None自体は値なのでデフォルト値は使用されない
print(None, 2)
