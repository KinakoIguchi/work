a = "A"
b = "B"

print("aの値:" + a + "、bの値:" + b)

print("入れ替えます")
temp = a
a = b
b = temp

print("aの値:" + a + "、bの値:" + b)

# 別解(カンマ(,)を使用した複数変数への代入: こちらのほうが可読性が高く適切)
print("*****別解*****")
a = "A"
b = "B"

print("aの値:" + a + "、bの値:" + b)

print("入れ替えます")
a, b = b, a

print("aの値:" + a + "、bの値:" + b)
