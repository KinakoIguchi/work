keys = ["alpha", "beta", "gumma"]
values = ["アルファ", "ベータ", "ガンマ"]

# zip関数を使用して2つのリストから辞書を生成するもっとも簡潔な記述方法
dictionary1 = dict(zip(keys, values))
print(dictionary1)

# for文とzip関数を使用する方法
dictionary2 = {}
for key, value in zip(keys, values):
    dictionary2[key] = value

print(dictionary2)
