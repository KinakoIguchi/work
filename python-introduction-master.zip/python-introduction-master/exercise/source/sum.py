x = 10
sum = 0

for num in range(1, x + 1):
    sum += num

print(sum)
