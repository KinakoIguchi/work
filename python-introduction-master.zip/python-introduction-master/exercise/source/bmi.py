import math

height = 1.7
weight = 60
bmi = weight / (height * height)

print(bmi)

# 別解1(累乗の演算子を使用)
bmi = weight / height ** 2
print(bmi)

# 別解2(math.powで累乗を計算)
bmi = weight / math.pow(height, 2)
print(bmi)
