for i in range(1, 10):
    for j in range(1, 10):
        # f-stringの:2dで「2桁で表示(1桁の場合は十の位をスペースで埋める)」と指定
        print(f"|{i*j:2d}", end="")
    else:
        # 末尾の"|"と改行
        print("|")
