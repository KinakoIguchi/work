class Person:
    def __init__(self, name="", age=0):
        self.__name = name
        self.__age = age

    def set_name(self, name):
        self.__name = name
        print(f"名前を{name}に設定しました")

    def set_age(self, age):
        self.__age = age
        print(f"年齢を{age}に設定しました")

    def show(self):
        print(f"名前: {self.__name}\n年齢: {self.__age}")


# コンストラクタ引数を指定しなかった場合
person = Person()
person.show()

# コンストラクタ引数を正しく指定した場合
person2 = Person(name="suzuki", age=30)
person2.show()
