str = "大崎-品川-高輪ゲートウェイ"

if "品川" in str:
    print("品川が含まれています")
else:
    print("品川が含まれていません")

str = "青物横丁-鮫洲-立会川"

if "品川" in str:
    print("品川が含まれています")
else:
    print("品川が含まれていません")
