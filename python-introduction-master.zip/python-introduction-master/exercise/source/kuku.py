for i in range(1, 10):
    for j in range(1, 10):
        print("|", i * j, end="")
    else:
        # 末尾の"|"と改行
        print("|")

# 別解(結果の表示にf-stringを使用し、数値を文字列に埋め込む)
for i in range(1, 10):
    for j in range(1, 10):
        print(f"|{i*j}", end="")
    else:
        # 末尾の"|"と改行
        print("|")
