def func_kwargs(**kwargs):
    return kwargs["width"] * kwargs["height"]


print(func_kwargs(width=2, height=6))


# (参考) キーワード引数よりも個別の引数を指定するほうがバグが起きにくい関数になる
def func_args(width, height):
    return width * height


print(func_args(2, 6))
