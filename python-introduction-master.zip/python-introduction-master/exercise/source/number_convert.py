century = 21

# 数値を組み込み関数str()で文字列に変換し、文字列と結合・出力
print("今は" + str(century) + "世紀です")

# (参考) f-stringを使用すると、数値を文字列に変換しなくとも文字列と結合・出力できる
# 可読性が高いため、通常はこの記法を推奨
print(f"今は{century}世紀です")

# 数値を文字列に変換しないで文字列と結合しようとするとエラー
# TypeError: can only concatenate str (not "int") to str
print("今は" + century + "世紀です")
