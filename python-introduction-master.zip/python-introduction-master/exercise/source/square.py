def square(height, width):
    print(f"高さ:{height}　幅:{width}")

    # 使用しない値を代入する変数名には_(アンダースコア)を使用することが一般的
    for _ in range(height):
        for _ in range(width):
            print("*", end="")
        else:
            # 改行
            print("")


square(5, 12)
