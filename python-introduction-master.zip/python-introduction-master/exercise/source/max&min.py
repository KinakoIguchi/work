a = 10
b = 20
c = 30

# 最大値maxと最小値maxはaと仮置きする
max = a
min = a

# 最大値の判定: maxの値とb, cをそれぞれ比較
if b > max:
    max = b
if c > max:
    max = c

# 最小値の判定: minの値とb, cをそれぞれ比較
if b < min:
    min = b
if c < min:
    min = c

print("最大値、最小値の順に")
print(max)
print(min)

# 別解(結果の表示にf-stringを使用し、数値の変数を文字列に埋め込む)
print("*****別解*****")
str = f"最大値: {max}, 最小値: {min}"
print(str)
