list = [5, 3, 8, 1, 2]

# ソートの処理を実行(以下はバブルソート)
for i in range(len(list)):
    for j in range(len(list) - 1, i, -1):
        if list[j] < list[j - 1]:
            list[j], list[j - 1] = list[j - 1], list[j]

# ソート結果の表示
print(list)

# 検算(sort, sortedの結果との見比べ)
list.sort()
print(list)
print(sorted(list))
