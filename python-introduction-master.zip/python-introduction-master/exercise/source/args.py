def args(*args):
    sum = 0
    for num in args:
        sum += num

    return sum


print(args(1, 2, 3))
print(args(1, 2, 3, 4, 5))
