def show():
    print("これは引数なし、戻り値なしの関数です。")


show()
