class Person:
    def __init__(self):
        self.__name = ""
        self.__age = 0

    def set_name(self, name):
        self.__name = name
        print(f"名前を{name}に設定しました")

    def set_age(self, age):
        self.__age = age
        print(f"年齢を{age}に設定しました")

    def show(self):
        print(f"名前: {self.__name}\n年齢: {self.__age}")


person = Person()
person.set_name("tanaka")
person.set_age(25)
person.show()

print("*****参考: プライベート変数を直接操作した場合の挙動*****")
person.__name = "suzuki"
person.__age = 30
# プライベート変数を直接操作してもエラーにはならないが、値は変更されない
person.show()
