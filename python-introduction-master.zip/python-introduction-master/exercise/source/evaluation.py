def evaluate(scores):
    average = 0
    for score in scores:
        average += score / len(scores)
    if 0 <= average <= 59:
        print("不可")
    if 60 <= average <= 69:
        print("可")
    if 70 <= average <= 79:
        print("良")
    if 80 <= average <= 89:
        print("優")
    if 90 <= average <= 100:
        print("秀")


scores = [60, 70, 80]
evaluate(scores)
