# 環境構築(基本版)

## インストール

### IDEのセットアップ

[DCS-FWのEclipse ide installation guide](http://gitlab.in.dcs.co.jp/dcs-framework/framework/wikis/Eclipse%20IDE%20Installation%20Guide)を参照し、Eclipse／JBossEAPをインストール・設定してください。

### ソースコードの取得

#### ソースコードのクローン  

まず、Git上に存在するリモートリポジトリ(ソースコードやその編集履歴一式などを含むデータのまとまりのこと)をローカルに保存します。  
Gitでは、これをクローンと言います。  

まず、リポジトリを保管する場所(フォルダ)を決めてください。既存のフォルダでも、新規作成したフォルダでも構いません。  
以下で示す例では、`C:\Users\ユーザー名`に「git」というフォルダを新規作成し、そこにクローンすることにします。  
  
<img src="./image/MakeGitFolder.png" width="750px">
  
コマンドプロンプトを起動し、リポジトリをクローンするフォルダに移動します(例では`C:\Users\ユーザー名\git`)。  
その後、以下のコマンドを実行することにより、リポジトリがクローンされます。  
  
```console
git clone リモートリポジトリのURL
```
  
リモートリポジトリのURLは、プロジェクト画面トップのボタンをクリックすることでコピーできます(以下のスクリーンショットを参照)。  

<img src="./image/CopyURL.png" width="750px">

コマンドの実行に成功すると、以下のように表示されます。  

<img src="./image/CommandExecution.png" width="750px">  

フォルダ内を確認し、クローンが成功していることを確認して下さい。  

<img src="./image/SuccessClone.png" width="750px">  

ここで、リポジトリの内容を確認します。  
「javaee-basic」内の「source」フォルダを表示してください。「booking」がハンズオンで編集するプロジェクト、「view」がサンプルアプリケーションです。  

#### プロジェクトのインポート

次に、クローンしたリポジトリ内のプロジェクトをEclipseにインポートします。  

Eclipseを起動し、画面上部のメニューバーの「ファイル」 > 「インポート」を選択して、表示されたダイアログボックスから「既存Mavenプロジェクト」を選択(「既存Mavenプロジェクト」が表示されていない場合は一般をダブルクリック)し、次へをクリックします。  

<img src="./image/Import.png" width="750px">  

<img src="./image/ExistingMavenProject.png" width="750px">  

Mavenプロジェクトの選択ダイアログボックスが表示されるので、「参照」をクリックし、クローンした「booking」フォルダを選択します。  
最後に「完了」をクリックします。

<img src="./image/Browse.png" width="750px">  

<img src="./image/SelectBooking.png" width="750px">  

<img src="./image/Complete.png" width="750px">  

「booking」が「booking-javaee-7.0」という名前でインポートされたことを確認します。  

<img src="./image/ImportConfirmation.png" width="750px">  

同様の手順で、「view」もインポートします。  
「view」は「samplesite-javaee-7.0」という名前でインポートされます。  

<img src="./image/SamplesiteImport.png" width="750px">  

#### Eclipseの設定

Eclipseの設定を変更し、HTMLエディターの行の幅を調整します。  

Eclipse画面上部のメニューバーより、「ウィンドウ」 > 「設定」を選択します。  

<img src="./image/edit.png" width="750px">  

ダイアログボックスの左側より、「Web」 > 「HTMLファイル」 > 「エディター」を選択し、行の幅を100に設定し、適用をクリックします。  

<img src="./image/editer.png" width="750px">  

## 稼働確認

### JBossの設定

アプリケーションの稼働にはアプリケーションサーバーが必要となります。今回は、JBoss EAPを使用します。  
  
先ほどクローンした「javaee-basic」内の「jboss」フォルダ内にある「jboss-eap-7.1.0.zip」を任意の場所に解凍します。解凍されたものは、以下に配置してください。  
`C:\eclipse_DcsFramework\jboss-eap-7.1`  

次に、解凍されたJBoss EAP7をEclipseに登録します。  

Eclipseの画面下部にあるタブから「サーバー」を選択し、赤枠内をクリックして下さい(以下スクリーンショットを参照)。  

<img src="./image/selectServer.png" width="750px">  

「新規サーバーの定義」というダイアログボックスが表示されるので、サーバーのタイプ選択で「JBoss AS, WildFly, & EAP Server Tools」を選択し、次へをクリックします。なお、ここで「JBoss AS, WildFly, & EAP Server Tools」が表示されていない場合は、後述の **(注意)** を確認してください。  
その後のフィーチャーライセンス画面では、同意しますを選択し、完了をクリックします。  

<img src="./image/selectJBoss.png" width="750px">  

<img src="./image/agree.png" width="750px">  

**(注意) 上記の手順を実施すると、「JBoss AS, WildFly, & EAP Server Tools」が表示されず、代わりに「Red Hat JBoss ミドルウェア」などが表示される場合があります。**  
この場合は、「Red Hat JBoss ミドルウェア」をクリックして表示される「Red Hat JBoss Enterprise Application Platform 7.1」を選択し、次へを押して下さい。
この場合、この手順の直後の手順(インストール完了後 ~ 「Red Hat JBoss EAP 7.1」に変更し、次へをクリックします。 まで)は実施不要です。引き続き、「以下の画面が表示された場合、設定を変更せずに次へをクリックします。」の手順から実施してください。

<img src="./image/selectJBoss7.1.png" width="750px">  

インストール完了後、再び「サーバー」タブ内の新規サーバー作成リンクをクリックします。  
JBoosのサーバータイプが以下のスクリーンショットのように追加されます。「7.1」を選択し、サーバー名を「Red Hat JBoss EAP 7.1」に変更し、次へをクリックします。  

<img src="./image/selectJBoss7.1.png" width="750px">  

以下の画面が表示された場合、設定を変更せずに次へをクリックします。

<img src="./image/NewJbossServer.png" width="750px">  

以降の手順では、以下のスクリーンショットの赤枠内と同様の設定になるよう、各種設定を実施します。  

<img src="./image/eap5.png" width="750px">  

ダイアログボックスに表示されている各設定項目について、以下のとおり設定します。

- 名前
  - 空欄の場合、「JBoss EAP 7.1 Runtime」と入力
- ホーム・ディレクトリー
  - 入力されていない場合、入力欄右側の参照ボタンをクリックし、表示されるダイアログボックスで`C:\eclipse_DcsFramework\jboss-eap-7.1`を指定
- 代替JRE
  - 代替JREのラジオボタンが選択されていない場合はクリックして選択。代替JREにjdk1.8.0_\*\*\*(\*\*\*はバージョン番号)が指定されていない場合、以下の手順を実施
    1. 代替JREを選択するドロップダウンリストの右側にあるインストール済みのJREボタンをクリックし、表示されたダイアログボックスの追加ボタンをクリック  
    <img src="./image/InstalledJRE.png" width="750px">
    1. 標準VMを選択し、次へをクリック  
    <img src="./image/JREType.png" width="750px">
    1. 表示されたダイアログボックス右上のディレクトリーボタンをクリックし、`C:\eclipse_DcsFramework\jdk1.8.0_***`を指定。その後、完了ボタンをクリック  
    <img src="./image/JREDefinition.png" width="750px">
    1. jdk1.8.0...をクリックしてチェックが入っていることを確認した後、適用して閉じるボタンをクリック  
    <img src="./image/InstalledJRE2.png" width="750px">

以上の手順を実施して、以下のスクリーンショットの赤枠内の設定となったら(代替JREの`_`以降のバージョンは異なる場合あり)、完了ボタンをクリックします。  

<img src="./image/eap5.png" width="750px">  

サーバータブ内にサーバーが追加されていれば、設定は完了です。  

<img src="./image/finishJBoss.png" width="750px">  

### ログイン画面アクセス・ログイン

最後に、アプリケーションの稼働確認を行います。  
  
「booking-javaee-7.0」を右クリック、「実行」から「サーバーで実行」を選択します。  

<img src="./image/RunOnServer.png" width="750px">  

ダイアログボックスが表示されるので、「完了」をクリックします。  

<img src="./image/CompleteServer.png" width="750px">  

このとき、コンソールタブ内に`Error occurred during initialization of VM Could not reserve enough space for ~~~KB object heap`というメッセージが表示されてサーバーが起動しない場合、以下の設定を実施します。

1. サーバータブ内のサーバー(Red Hat JBoss EAP 7.1)をダブルクリック
1. 表示された設定画面の左側の起動構成を開くリンクをクリック
1. 表示されたダイアログボックスのVM引数欄の`-Xms1303m -Xmx1303m`を`-Xms1024m -Xmx1024m`に書き換える(書き換えても同様の事象が発生する場合は、`-Xms512m -Xmx512m`に書き換え)
1. 書き換え後、ダイアログボックスのOKボタンをクリック
1. 「booking-javaee-7.0」を右クリックし、「実行」から「サーバーで実行」をクリックしてサーバーを起動

サーバーが正常に起動すると、以下のような404エラー画面が出力されます。  

<img src="./image/404.png" width="750px">  

このエラーは、デフォルトで表示されるURLが間違っているために発生したものです。  
正しいURLは<http://localhost:8080/booking>です。このURLをWEBブラウザで表示してください。  
以下のログイン画面が表示されれば、アプリケーションは正常に稼働しています。  

<img src="./image/Login.png" width="750px">  

user id、password共に「admin」でログインできますので、ログインしてTOP画面を表示してください。  
TOP画面に「システムエラー画面」と表示される場合がありますが、この場合でもアプリケーションは正常に動作しています(仕様です)。再度ログインすると、正しく画面が表示されます。  

<img src="./image/TOP.png" width="750px">