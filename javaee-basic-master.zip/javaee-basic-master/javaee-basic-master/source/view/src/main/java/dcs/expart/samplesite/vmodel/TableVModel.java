package dcs.expart.samplesite.vmodel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.slf4j.Logger;

import dcs.expart.samplesite.layer.SampleSiteGenericVModel;
import dcs.expart.samplesite.sampleHotel.Hotel;
import dcs.expart.samplesite.util.Constant;
import dcs.fw.context.ExpartContext;
import dcs.fw.context.ViewModel;

/**
 * コンポーネントVModel
 *
 * @version 1.0
 */
@Named("tableVModel")
@SessionScoped
@ViewModel
public class TableVModel extends SampleSiteGenericVModel implements
		Serializable {

	/** ログインスタンス */
	protected Logger log = ExpartContext.getLogger(getClass());

	/** ID */
	private static final long serialVersionUID = 1L;

	/** タイトル（コンポーネント名） */
	private final String title = Constant.L_TABLE;

	/** ホテルリスト */
	private List<Hotel> allHotels = new ArrayList<Hotel>();

	/** 初期化処理 */
	@PostConstruct
	public void init() {
		// 属性のセット
		getComponentDataFromXML(title);
		// ホテルリストに追加
		for (int i = 1; i <= 50; i++) {
			if (i < 10) {
				getAllHotels().add(
						new Hotel("100" + i, "サンプルホテル" + i, "サンプル県" + i + "-"
								+ i, 51 - i));
			} else {
				getAllHotels().add(
						new Hotel("10" + i, "サンプルホテル" + i, "サンプル県" + i + "-"
								+ i, 51 - i));
			}
		}
	}

	/*
	 * --------------------------以下、getter、setter--------------------------------
	 */

	public String getTitle() {
		return title;
	}

	public List<Hotel> getAllHotels() {
		return allHotels;
	}

	public void setAllHotels(List<Hotel> allHotels) {
		this.allHotels = allHotels;
	}

}