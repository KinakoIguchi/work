package dcs.expart.samplesite.sampleHotel;

import java.io.Serializable;

/**
 * サンプルホテルクラス
 *
 * @author DCS ykitagawa
 * @version 1.0
 */
public class Hotel implements Serializable {

	/** */
	private static final long serialVersionUID = 1L;
	/** ホテルコード */
	private String code;
	/** ホテル名 */
	private String name;
	/** 住所 */
	private String address;
	/** ランク */
	private int rank;

	/** コンストラクタ */
	public Hotel(String code, String name, String address, int rank) {
		this.setCode(code);
		this.setName(name);
		this.setAddress(address);
		this.setRank(rank);
	}

	/**
	 * ホテルコードを取得します。
	 *
	 * @return ホテルコード
	 */
	public String getCode() {
		return code;
	}

	/**
	 * ホテルコードを設定します。
	 *
	 * @param code
	 *            ホテルコード
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * ホテル名を取得します。
	 *
	 * @return ホテル名
	 */
	public String getName() {
		return name;
	}

	/**
	 * ホテル名を設定します。
	 *
	 * @param name
	 *            ホテル名
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 住所を取得します。
	 *
	 * @return 住所
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * 住所を設定します。
	 *
	 * @param address
	 *            住所
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * ランクを取得します。
	 *
	 * @return ランク
	 */
	public int getRank() {
		return rank;
	}

	/**
	 * ランクを設定します。
	 *
	 * @param rank
	 *            ランク
	 */
	public void setRank(int rank) {
		this.rank = rank;
	}

}
