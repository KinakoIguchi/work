package dcs.expart.samplesite.initializer;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;

import dcs.fw.jpa.LazyEntityManager;

/**
 * データベースに初期データ投入をする為のイニシャライザ<br/>
 * ログイン画面のJSFイベントによって動作する想定。<br/>
 * （イニシャライザはコンポーネント生成時の一度のみ動作する想定）<br/>
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Named
@Stateful
@ApplicationScoped
public class BookingInitializer implements Serializable {

	/** */
	private static final long serialVersionUID = 1L;

	/** */
	@Inject
	LazyEntityManager lazyEntityManager;

	/**
	 * 初回アクセス時にしか動かない
	 */

	@PostConstruct
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void init() {
	}

}
