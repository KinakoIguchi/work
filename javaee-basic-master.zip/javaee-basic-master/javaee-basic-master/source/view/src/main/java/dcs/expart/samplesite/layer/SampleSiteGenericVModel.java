package dcs.expart.samplesite.layer;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Semaphore;

import javax.enterprise.context.ApplicationScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.ServletContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import dcs.fw.auth.AuthProvider;
import dcs.fw.context.ExpartContext;
import dcs.fw.context.ExpartContext.MessageSeverity;
import dcs.fw.exception.BusinessInvalidException;
import dcs.fw.util.CDI;

/**
 * Exampleサイト用汎用ViweModel
 * 
 * @author DCS ykitagawa
 * @version 1.0
 */
public abstract class SampleSiteGenericVModel implements Serializable {

	/** */
	private static final long serialVersionUID = 1L;
	/** */
	@Inject
	protected ExpartContext context;

	// -------------------拡張部分--------------------//
	/** タイトルとビューIDの対応MAP */
	private HashMap<String, HashMap<String, String>> pageMapMap = new HashMap<String, HashMap<String, String>>();

	/** ページタイトルマップ */
	private HashMap<String, List<String>> pageTitleMap = new HashMap<String, List<String>>();

	/** タグ名 */
	private String tagName;

	/** コンポーネントの説明文 */
	protected String description;

	/** 属性（プロパティ） */
	protected List<String> properties = new ArrayList<String>();

	/** 属性の説明 */
	protected HashMap<String, String> descriptionsOfProperties = new HashMap<String, String>();

	/** 入力値 */
	protected String inputValue;

	/** disableフラグ */
	private boolean isDisabled;

	/** 入力値 */
	private String inputDisabledValue;

	/**
	 * 引数のカテゴリに属するメニュー関連のデータをXMLより取得し、セットする。
	 */
	public void getMenuDataFromXML(String category) {

		HashMap<String, String> pageMap = new HashMap<String, String>();
		List<String> pageTitle = new ArrayList<String>();

		// XMLファイルよりページ情報（タイトル・パス）を取得
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			// component.xmlファイルを取得
			ServletContext servletContext = (ServletContext) FacesContext
					.getCurrentInstance().getExternalContext().getContext();
			File f = new File(
					servletContext.getRealPath("/WEB-INF/components.xml"));
			Document doc = builder.parse(f);
			// ルートを取得
			Element root = doc.getDocumentElement();
			// <page>を全て取得
			NodeList pages = root.getChildNodes();
			for (int i = 0; i < pages.getLength(); i++) {
				// 1つの<page>を取得
				Node page = pages.item(i);
				if (page instanceof Element) {
					Element pageElement = (Element) page;
					String categoryName = pageElement
							.getElementsByTagName("category").item(0)
							.getFirstChild().getNodeValue();
					if (category.equals(categoryName)) {
						String title = pageElement
								.getElementsByTagName("title").item(0)
								.getFirstChild().getNodeValue();
						String viewid = pageElement
								.getElementsByTagName("viewid").item(0)
								.getFirstChild().getNodeValue();
						// <title>を設定
						pageTitle.add(title);
						// <viewid>を設定
						pageMap.put(title, viewid);
					}
				}
			}

			pageTitleMap.put(category, pageTitle);
			pageMapMap.put(category, pageMap);

		} catch (ParserConfigurationException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

	}

	/**
	 * 引数のタイトル名よりコンポーネント関連のデータをXMLより取得し、セットする。
	 */
	public void getComponentDataFromXML(String title) {

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			// component.xmlファイルを取得
			ServletContext servletContext = (ServletContext) FacesContext
					.getCurrentInstance().getExternalContext().getContext();
			File f = new File(
					servletContext.getRealPath("/WEB-INF/components.xml"));
			Document doc = builder.parse(f);
			// ルートを取得
			Element root = doc.getDocumentElement();
			// <page>を全て取得
			NodeList pages = root.getChildNodes();
			for (int i = 0; i < pages.getLength(); i++) {
				// 1つの<page>を取得
				Node page = pages.item(i);
				if (page instanceof Element) {
					Element pageElement = (Element) page;
					String pageTitle = pageElement
							.getElementsByTagName("title").item(0)
							.getFirstChild().getNodeValue();
					// タイトルが一致するものを取得
					if (title.equals(pageTitle)) {
						// <tagName>を設定
						setTagName(pageElement.getElementsByTagName("tagName")
								.item(0).getFirstChild().getNodeValue());
						// <description>を設定
						description = pageElement
								.getElementsByTagName("description").item(0)
								.getFirstChild().getNodeValue();
						// <property>を設定
						Node propertiesNode = pageElement.getElementsByTagName(
								"properties").item(0);
						NodeList propertyNodeList = propertiesNode
								.getChildNodes();
						for (int j = 0; j < propertyNodeList.getLength(); j++) {
							Node propertyNode = propertyNodeList.item(j);
							if (propertyNode instanceof Element) {
								Element propertyElement = (Element) propertyNode;
								properties.add(propertyElement.getFirstChild()
										.getNodeValue());
							}
						}
						// <descriptionsOfProperty>を設定
						Node descriptionsOfpropertiesNode = pageElement
								.getElementsByTagName(
										"descriptionsOfProperties").item(0);
						NodeList descriptionsOfpropertiesNodeList = descriptionsOfpropertiesNode
								.getChildNodes();
						int count = 0;
						for (int j = 0; j < descriptionsOfpropertiesNodeList
								.getLength(); j++) {
							Node descriptionOfpropertyNode = descriptionsOfpropertiesNodeList
									.item(j);
							if (descriptionOfpropertyNode instanceof Element) {
								Element descriptionOfpropertyElement = (Element) descriptionOfpropertyNode;
								descriptionsOfProperties
										.put(properties.get(count),
												descriptionOfpropertyElement
														.getFirstChild()
														.getNodeValue());
								count++;
							}

						}

					}
				}

			}

		} catch (ParserConfigurationException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

	}

	/**
	 * [送信]ボタン押下時処理
	 */
	public String sendButton() {
		context.addMessage(MessageSeverity.INFO, null,
				"格納された値は[" + this.getInputValue() + "]です。");
		return context.getRedirectCurrentPage();
	}

	/**
	 * [無効化]ボタン押下時処理
	 */
	public String pushDisabledButton() {
		setDisabled(true);
		return context.getRedirectCurrentPage();
	}

	/**
	 * [有効化]ボタン押下時処理
	 */
	public String pushAbledButton() {
		setDisabled(false);
		return context.getRedirectCurrentPage();
	}

	public String getInputValue() {
		return inputValue;
	}

	public void setInputValue(String inputValue) {
		this.inputValue = inputValue;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	public List<String> getProperties() {
		return properties;
	}

	public void setProperties(List<String> properties) {
		this.properties = properties;
	}

	public HashMap<String, String> getDescriptionsOfProperties() {
		return descriptionsOfProperties;
	}

	public void setDescriptionsOfProperties(HashMap<String, String> descriptions) {
		this.descriptionsOfProperties = descriptions;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public HashMap<String, HashMap<String, String>> getPageMapMap() {
		return pageMapMap;
	}

	public void setPageMapMap(
			HashMap<String, HashMap<String, String>> pageMapMap) {
		this.pageMapMap = pageMapMap;
	}

	public HashMap<String, List<String>> getPageTitleMap() {
		return pageTitleMap;
	}

	public void setPageTitleMap(HashMap<String, List<String>> pageTitleMap) {
		this.pageTitleMap = pageTitleMap;
	}

	public boolean isDisabled() {
		return isDisabled;
	}

	public void setDisabled(boolean isDisabled) {
		this.isDisabled = isDisabled;
	}

	public String getInputDisabledValue() {
		return inputDisabledValue;
	}

	public void setInputDisabledValue(String inputDisabledValue) {
		this.inputDisabledValue = inputDisabledValue;
	}

	// ----------------拡張部分ここまで--------------//

	/**
	 * キャンセル処理用のアクションメソッド
	 * 
	 * @param endConversation
	 *            カンバセーションを終了する
	 * @return 認証成功画面
	 */
	public String cancel(boolean endConversation) {
		// カンバセーションの終了が指定されている場合endConversationを行う
		if (endConversation)
			context.endConversation();
		AuthProvider authProvider = CDI.getBeanInstance(AuthProvider.class,
				ApplicationScoped.class);
		return context.getRedirectPage(authProvider.getPageLoginSuccess());
	}

	/**
	 * セマポアによる同時実行数チェック<br/>
	 * 引数で渡されたセマポアオブジェクトの同時実行可能数を確認し、<br/>
	 * 実行不可ならエラーを発生させる。<br/>
	 * 正常の場合は、セマポアオブジェクトの同時実行可能数を減らし、<br/>
	 * 他のエラーがなければ、次の段階に実行させる。<br/>
	 * 
	 * @param semaphore
	 *            Semaphore
	 */
	protected void acquire(Semaphore semaphore) {
		// 実行可能なプロセスが超えたら今の処理は行わず、ユーザに再処理を求める旨のメッセージをリターン
		if (semaphore.availablePermits() < 1) {
			// TODO
			// メッセージが修正されたり、プロパティーに移されたりしたら「AsyncFileUploadCDIHelperServlet,commonScripts」も確認
			throw new BusinessInvalidException("同時実行数制限のため拒否されました。再度実行してください。");
		}

		try {
			semaphore.acquire();
		} catch (InterruptedException e) {
			e.printStackTrace();
			throw new BusinessInvalidException("同時実行数制限中、エラーが発生しました");
		}
	}

	/**
	 * semaphore.acquire()で減った資源を戻す。<br/>
	 * 同時実行可能数を増やす。
	 * 
	 * @param semaphore
	 *            Semaphore
	 */
	protected void release(Semaphore semaphore) {
		semaphore.release();
	}

}
