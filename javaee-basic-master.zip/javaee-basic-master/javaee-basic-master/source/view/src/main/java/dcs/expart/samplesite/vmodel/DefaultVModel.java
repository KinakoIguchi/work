package dcs.expart.samplesite.vmodel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import dcs.expart.samplesite.layer.SampleSiteGenericVModel;
import dcs.expart.samplesite.util.Constant;
import dcs.fw.context.ViewModel;

/**
 * メニューVModel
 *
 * @version 1.0
 */
@Named("defaultVModel")
@SessionScoped
@ViewModel
public class DefaultVModel extends SampleSiteGenericVModel implements
		Serializable {

	/** ID */
	private static final long serialVersionUID = 1L;

	/** カテゴリリスト */
	private List<String> categoryList = new ArrayList<String>();

	/** 説明の表示フラグ */
	private boolean displayFlg;

	/** 初期化処理 */
	@PostConstruct
	public void init() {
		// メニュータイトル（カテゴリ名）を追加
		getCategoryList().add(Constant.INPUT_COMPONENTS);
		getCategoryList().add(Constant.OUTPUT_COMPONENTS);
		getCategoryList().add(Constant.LAYOUT_COMPONENTS);
		getCategoryList().add(Constant.OTHERS_COMPONENTS);

		// メニューの情報をcomponents.xmlより取得する。
		for (String menuTitle : getCategoryList()) {
			getMenuDataFromXML(menuTitle);
		}

		// 説明ブロックの表示
		setDisplayFlg(true);
	}

	public void hideDescription() {
		this.setDisplayFlg(isDisplayFlg() ? false : true);
	}

	public List<String> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<String> categoryList) {
		this.categoryList = categoryList;
	}

	public boolean isDisplayFlg() {
		return displayFlg;
	}

	public void setDisplayFlg(boolean displayFlg) {
		this.displayFlg = displayFlg;
	}

}
