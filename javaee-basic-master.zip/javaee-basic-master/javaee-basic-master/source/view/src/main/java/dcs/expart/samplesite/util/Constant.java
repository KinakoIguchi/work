package dcs.expart.samplesite.util;

/**
 * Exampleサイト用定数
 *
 * @author DCS ykitagawa
 * @version 1.0
 *
 */
public final class Constant {

	/** 入力系コンポーネント */
	public static final String INPUT_COMPONENTS = "入力系コンポーネント";
	public static final String S_TEXT_INPUT_PLAIN = "テキストインプット（プレーンテキスト）";
	public static final String S_TEXT_INPUT_PASSWORD = "テキストインプット（パスワード）";
	public static final String S_TEXT_AREA = "テキストエリア";
	public static final String S_RADIO_BUTTON = "ラジオボタン";
	public static final String S_PULLDOWN_LIST = "プルダウンリスト";
	public static final String S_CHECK_BOX = "チェックボックス";
	public static final String S_LINK = "リンク";
	public static final String S_IMAGE = "イメージ";
	public static final String S_BADGE = "バッジ";
	public static final String S_BUTTON = "ボタン";
	public static final String S_ICON = "アイコン";

	/** 出力系コンポーネント */
	public static final String OUTPUT_COMPONENTS = "出力系コンポーネント";
	public static final String S_OUTPUT_TEXT = "アウトプットテキスト";
	public static final String M_CALENDAR = "カレンダー";
	public static final String M_FILE_UPLOAD = "ファイルアップロード";
	public static final String M_NAVIGATION_BAR = "ナビゲーションバー";
	public static final String M_PROGRESS_BAR = "プログレスバー";
	public static final String M_TAB = "タブ";

	/** レイアウト系コンポーネント */
	public static final String LAYOUT_COMPONENTS = "レイアウト系コンポーネント";
	public static final String L_TABLE = "テーブル";
	public static final String L_GRID = "グリッド";
	public static final String L_RESPONSIVE_DESIGN = "レスポンシブデザイン";

	/** その他コンポーネント */
	public static final String OTHERS_COMPONENTS = "その他コンポーネント";
	public static final String L_VALIDATION = "バリデーション";
	public static final String L_CONVERTER = "コンバータ";
	public static final String L_AJAX = "Ajax";
	public static final String OTHERS_MODAL_DIALOG = "モーダルダイアログ";
}
