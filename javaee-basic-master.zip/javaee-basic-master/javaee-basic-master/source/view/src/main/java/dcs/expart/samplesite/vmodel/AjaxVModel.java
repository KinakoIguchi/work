package dcs.expart.samplesite.vmodel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.slf4j.Logger;

import dcs.expart.samplesite.layer.SampleSiteGenericVModel;
import dcs.expart.samplesite.util.Constant;
import dcs.fw.context.ExpartContext;
import dcs.fw.context.ViewModel;
import dcs.fw.validator.AllowCharType;

/**
 * コンポーネントVModel
 *
 * @version 1.0
 */
@Named("ajaxVModel")
@SessionScoped
@ViewModel
public class AjaxVModel extends SampleSiteGenericVModel implements Serializable {

	/** ログインスタンス */
	protected Logger log = ExpartContext.getLogger(getClass());

	/** ID */
	private static final long serialVersionUID = 1L;

	/** タイトル（コンポーネント名） */
	private final String title = Constant.L_AJAX;

	/** 選択肢（コンボボックス - 大分類） */
	private Map<String, String> optionLarge = new LinkedHashMap<String, String>();
	/** 選択肢（コンボボックス - 小分類） */
	private List<String> optionSmall = new ArrayList<String>();
	/** 入力値（コンボボックス） */
	private String inputValueCombo;

	/** 選択肢（リストボックス） */
	private List<String> option = new ArrayList<String>();
	/** 選択値（リストボックス） */
	private List<String> choosedValue = new ArrayList<String>();
	/** 選択肢1の描画フラグ */
	private boolean renderOption1 = false;
	/** 選択肢2の描画フラグ */
	private boolean renderOption2 = false;

	/** 半角数字（動的バリデーション） */
	@AllowCharType(hanNum = true, msgParam = AllowCharType.HALF_NUMBER)
	private String hanNum;

	/**
	 * 初期化処理
	 */
	@PostConstruct
	public void init() {
		// 説明、タグ名、属性のセット
		getComponentDataFromXML(title);
		// コンボボックスの選択肢の生成
		getOptionLarge().put("1", "-- 大分類① --");
		getOptionLarge().put("2", "-- 大分類② --");
		getOptionLarge().put("3", "-- 大分類③ --");
		// リストボックスの選択肢の生成
		getOption().add("選択肢①");
		getOption().add("選択肢②");
		getOption().add("選択肢③");
	}

	/**
	 * コンボボックスの値の入替を行う。
	 */
	public void changeOptionSmall() {
		if (inputValueCombo != null) {
			switch (inputValueCombo) {
			case "1":
				getOptionSmall().clear();
				getOptionSmall().add("-- 小分類① --");
				getOptionSmall().add("-- 小分類② --");
				getOptionSmall().add("-- 小分類③ --");
				break;
			case "2":
				getOptionSmall().clear();
				getOptionSmall().add("-- 小分類④ --");
				getOptionSmall().add("-- 小分類⑤ --");
				getOptionSmall().add("-- 小分類⑥ --");
				break;
			case "3":
				getOptionSmall().clear();
				getOptionSmall().add("-- 小分類⑦ --");
				getOptionSmall().add("-- 小分類⑧ --");
				getOptionSmall().add("-- 小分類⑨ --");
				break;
			}
		} else {
			getOptionSmall().clear();
		}
	}

	/**
	 * [追加]ボタン押下時処理
	 */
	public void addButton() {
		if (getInputValue() != null && !getInputValue().isEmpty()) {
			getChoosedValue().add(getInputValue());
			getOption().remove(getInputValue());
		}
	}

	/**
	 * [削除]ボタン押下時処理
	 */
	public void removeButton() {
		if (getInputValue() != null && !getInputValue().isEmpty()) {
			getChoosedValue().remove(getInputValue());
			getOption().add(getInputValue());
		}
	}

	/**
	 * [選択肢1]ラジオボタン押下時処理
	 */
	public void renderOption1() {
		setRenderOption1(true);
		setRenderOption2(false);
	}

	/**
	 * [選択肢2]ラジオボタン押下時処理
	 */
	public void renderOption2() {
		setRenderOption1(false);
		setRenderOption2(true);
	}

	/*
	 * --------------------------以下、getter、setter--------------------------------
	 */
	public String getTitle() {
		return title;
	}

	public List<String> getOption() {
		return option;
	}

	public void setOption(List<String> option) {
		this.option = option;
	}

	public List<String> getChoosedValue() {
		return choosedValue;
	}

	public void setChoosedValue(List<String> choosedValue) {
		this.choosedValue = choosedValue;
	}

	public boolean isRenderOption1() {
		return renderOption1;
	}

	public void setRenderOption1(boolean renderOption1) {
		this.renderOption1 = renderOption1;
	}

	public boolean isRenderOption2() {
		return renderOption2;
	}

	public void setRenderOption2(boolean renderOption2) {
		this.renderOption2 = renderOption2;
	}

	public String getHanNum() {
		return hanNum;
	}

	public void setHanNum(String hanNum) {
		this.hanNum = hanNum;
	}

	public List<String> getOptionSmall() {
		return optionSmall;
	}

	public void setOptionSmall(List<String> optionSmall) {
		this.optionSmall = optionSmall;
	}

	public Map<String, String> getOptionLarge() {
		return optionLarge;
	}

	public void setOptionLarge(Map<String, String> optionLarge) {
		this.optionLarge = optionLarge;
	}

	public String getInputValueCombo() {
		return inputValueCombo;
	}

	public void setInputValueCombo(String inputValueCombo) {
		this.inputValueCombo = inputValueCombo;
	}

}
