package dcs.expart.samplesite.vmodel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.slf4j.Logger;

import dcs.expart.samplesite.layer.SampleSiteGenericVModel;
import dcs.expart.samplesite.util.Constant;
import dcs.fw.context.ExpartContext;
import dcs.fw.context.ExpartContext.MessageSeverity;
import dcs.fw.context.ViewModel;

/**
 * コンポーネントVModel
 *
 * @version 1.0
 */
@Named("pullDownListVModel")
@SessionScoped
@ViewModel
public class PullDownListVModel extends SampleSiteGenericVModel implements
		Serializable {

	/** ログインスタンス */
	protected Logger log = ExpartContext.getLogger(getClass());

	/** ID */
	private static final long serialVersionUID = 1L;

	/** タイトル（コンポーネント名） */
	private final String title = Constant.S_PULLDOWN_LIST;

	/** 入力値（月） */
	private String month;

	/** プルダウンリスト（月） */
	private List<String> pullDownList = new ArrayList<String>();

	/** 初期化処理 */
	@PostConstruct
	public void init() {
		// 属性のセット
		getComponentDataFromXML(title);
		// ラジオボタンの選択肢を生成
		for (int i = 1; i <= 12; i++) {
			getPullDownList().add(i + "月");
		}
	}

	/** [送信]ボタン押下時処理 */
	@Override
	public String sendButton() {
		context.addMessage(MessageSeverity.INFO, null,
				"格納された値は[" + this.getInputValue() + "][" + this.getMonth()
						+ "]です。");
		return context.getRedirectCurrentPage();
	}

	/*
	 * --------------------------以下、getter、setter--------------------------------
	 */

	public String getTitle() {
		return title;
	}

	public List<String> getPullDownList() {
		return pullDownList;
	}

	public void setPullDownList(List<String> pullDownList) {
		this.pullDownList = pullDownList;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

}
