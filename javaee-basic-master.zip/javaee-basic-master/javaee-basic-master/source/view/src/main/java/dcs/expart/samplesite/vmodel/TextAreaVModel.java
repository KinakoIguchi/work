package dcs.expart.samplesite.vmodel;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.slf4j.Logger;

import dcs.expart.samplesite.layer.SampleSiteGenericVModel;
import dcs.expart.samplesite.util.Constant;
import dcs.fw.context.ExpartContext;
import dcs.fw.context.ViewModel;

/**
 * コンポーネントVModel
 *
 * @version 1.0
 */
@Named("textAreaVModel")
@SessionScoped
@ViewModel
public class TextAreaVModel extends SampleSiteGenericVModel implements
		Serializable {

	/** ログインスタンス */
	protected Logger log = ExpartContext.getLogger(getClass());

	/** ID */
	private static final long serialVersionUID = 1L;

	/** タイトル（コンポーネント名） */
	private final String title = Constant.S_TEXT_AREA;

	/** 初期化処理 */
	@PostConstruct
	public void init() {
		// 属性のセット
		getComponentDataFromXML(title);
	}

	/*
	 * --------------------------以下、getter、setter--------------------------------
	 */
	public String getTitle() {
		return title;
	}

}
