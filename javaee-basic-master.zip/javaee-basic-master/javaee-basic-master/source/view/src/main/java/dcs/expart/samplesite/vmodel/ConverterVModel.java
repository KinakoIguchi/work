package dcs.expart.samplesite.vmodel;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.slf4j.Logger;

import dcs.expart.samplesite.layer.SampleSiteGenericVModel;
import dcs.expart.samplesite.util.Constant;
import dcs.fw.context.ExpartContext;
import dcs.fw.context.ViewModel;
import dcs.fw.validator.Post;

/**
 * コンポーネントVModel
 * @author 
 * @version 1.0
 */
@Named("converterVModel")
@SessionScoped
@ViewModel
public class ConverterVModel extends SampleSiteGenericVModel implements
        Serializable {

    /** ログインスタンス */
    protected Logger log = ExpartContext.getLogger(getClass());

    /** ID */
    private static final long serialVersionUID = 1L;

    /** タイトル（コンポーネント名） */
    private final String title = Constant.L_CONVERTER;

    /** カンマ編集(1) */
    private Integer comma1;
    /** カンマ編集(2) */
    private BigDecimal comma2;
    /** 日付型 */
    private Date date;
    /** 郵便番号 */
    @Post
    private String postalCode;
    /** 半角カナ */
    private String hanKana;
    /** 全角カナ */
    private String zenKana;
    /** 半角文字 */
    private String hanMoji;
    /** 全角文字 */
    private String zenMoji;

    /** 初期化処理 */
    @PostConstruct
    public void init() {
        // 属性のセット
        getComponentDataFromXML(title);
    }

    @Override
    public String sendButton() {
        return context.getRedirectCurrentPage();
    }

    /**
     * クラス名を返却
     * 
     * @param obj obj
     * @return クラス名
     */
    public String getClassName(Object obj) {
        if (obj == null) {
            return null;
        }
        return obj.getClass().getCanonicalName();
    }

    /*
     * --------------------------以下、getter、setter--------------------------------
     */

    /**
     * @return the comma1
     */
    public Integer getComma1() {
        return comma1;
    }

    /**
     * @param comma1 the comma1 to set
     */
    public void setComma1(Integer comma1) {
        this.comma1 = comma1;
    }

    /**
     * @return the comma2
     */
    public BigDecimal getComma2() {
        return comma2;
    }

    /**
     * @param comma2 the comma2 to set
     */
    public void setComma2(BigDecimal comma2) {
        this.comma2 = comma2;
    }

    /**
     * @return the date
     */
    public Date getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * @return the postalCode
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * @param postalCode the postalCode to set
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    /**
     * @return the hanKana
     */
    public String getHanKana() {
        return hanKana;
    }

    /**
     * @param hanKana the hanKana to set
     */
    public void setHanKana(String hanKana) {
        this.hanKana = hanKana;
    }

    /**
     * @return the zenKana
     */
    public String getZenKana() {
        return zenKana;
    }

    /**
     * @param zenKana the zenKana to set
     */
    public void setZenKana(String zenKana) {
        this.zenKana = zenKana;
    }

    /**
     * @return the hanMoji
     */
    public String getHanMoji() {
        return hanMoji;
    }

    /**
     * @param hanMoji the hanMoji to set
     */
    public void setHanMoji(String hanMoji) {
        this.hanMoji = hanMoji;
    }

    /**
     * @return the zenMoji
     */
    public String getZenMoji() {
        return zenMoji;
    }

    /**
     * @param zenMoji the zenMoji to set
     */
    public void setZenMoji(String zenMoji) {
        this.zenMoji = zenMoji;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

}