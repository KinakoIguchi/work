package dcs.expart.samplesite.vmodel;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Semaphore;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.http.Part;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;

import dcs.expart.samplesite.layer.SampleSiteGenericVModel;
import dcs.expart.samplesite.util.Constant;
import dcs.fw.context.ExpartContext;
import dcs.fw.context.ExpartContext.MessageSeverity;
import dcs.fw.context.ViewModel;
import dcs.fw.jsf.JsfHelper;
//import dcs.fw.tag.upload.FileInfo;
import dcs.fw.tag.upload.UploadUtil;

/**
 * コンポーネントVModel
 *
 * @version 1.0
 */
@Named("fileUploadVModel")
@SessionScoped
@ViewModel
public class FileUploadVModel extends SampleSiteGenericVModel implements
		Serializable {

	/** ログインスタンス */
	protected Logger log = ExpartContext.getLogger(getClass());

	/** ID */
	private static final long serialVersionUID = 1L;

	/** タイトル（コンポーネント名） */
	private final String title = Constant.M_FILE_UPLOAD;

	/** アップロードファイル */
	@NotNull
	private Part uploadFile;

	/** アップロードファイル一覧 */
//	private List<FileInfo> attachmentFiles = Collections
//			.synchronizedList(new ArrayList<FileInfo>());

	/** セマフォ・インスタンス */
	private static Semaphore semaphore;

	/**
	 * 初期化処理
	 */
	@PostConstruct
	public void init() {
		// セマフォ変数が存在しない場合のみ生成
		if (semaphore == null) {
			semaphore = new Semaphore(1);
		}
		// 初期化処理
		getComponentDataFromXML(title);
	}

	/**
	 * [アップロード]ボタン押下時処理
	 */
	public String upload() {
		context.addMessage(MessageSeverity.INFO, null, "アップロードが完了しました。");
		log.info("ファイル名：" + this.getUploadFile().getSubmittedFileName());
		return context.getRedirectCurrentPage();
	}

	/**
	 * 非同期アップロードボタン押下時処理
	 *
	 * @param fileItem
	 *            fileItem
	 * @throws Exception 
	 */
	public void onAsyncUpload() throws Exception {
		acquire(semaphore);

        //uploadFileのリストをattachmentFilesに追加
//        try {
//            attachmentFiles.addAll(UploadUtil.getFileInfoList(uploadFile));
//        } catch (IOException | ServletException e) {
//            throw e;
//        } finally {
//            release(semaphore);
//        }
	}

	/**
	 * 指定されたインデックス番号の添付ファイルをダウンロードする
	 *
	 * @param index
	 *            インデックス番号
	 * @throws IOException
	 *             予期せぬ理由によりServletOutputStreamの書き出しに失敗した場合に発生
	 */
	public void download(int index) throws IOException {
//        FileInfo item = attachmentFiles.get(index);
//
//        File file = new File(item.getTempFileName());
//        FileInputStream fis = new FileInputStream(file);
//        
//        JsfHelper.download(item.getFileName(), item.getFileSize(), fis);
	}

	/**
	 * 指定されたインデックス番号の添付ファイルを削除する
	 *
	 * @param index
	 *            削除対象のインデックス番号
	 */
	public void removeUploadFile(int index) {
	    System.out.println("【確認】removeUploadFile");
//		attachmentFiles.remove(index);
	}

	/*
	 * --------------------------以下、getter、setter--------------------------------
	 */

	public String getTitle() {
		return title;
	}

	/**
	 * アップロードファイルを取得します。
	 *
	 * @return アップロードファイル
	 */
	public Part getUploadFile() {
		return uploadFile;
	}

	/**
	 * アップロードファイルを設定します。
	 *
	 * @param uploadFile
	 *            アップロードファイル
	 */
	public void setUploadFile(Part uploadFile) {
		this.uploadFile = uploadFile;
	}

	/**
	 * アップロードファイル一覧を取得します。
	 *
	 * @return アップロードファイル一覧
	 */
//	public List<FileInfo> getAttachmentFiles() {
//		return attachmentFiles;
//	}

	/**
	 * アップロードファイル一覧を設定します。
	 *
	 * @param attachmentFiles
	 *            アップロードファイル一覧
	 */
//	public void setAttachmentFiles(List<FileInfo> attachmentFiles) {
//		this.attachmentFiles = attachmentFiles;
//	}

}
