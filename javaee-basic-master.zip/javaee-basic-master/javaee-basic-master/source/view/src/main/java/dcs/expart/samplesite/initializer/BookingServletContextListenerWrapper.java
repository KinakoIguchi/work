package dcs.expart.samplesite.initializer;

import javax.enterprise.inject.Alternative;
import javax.persistence.EntityManager;

import org.slf4j.Logger;

import dcs.fw.context.ExpartContext;
import dcs.fw.initialize.ServletContextListenerWrapper;

/**
 * ServletContextListenerWrapperの実装クラス<br/>
 * サーバ起動及び停止時に処理を差し込む際のサンプル<br/>
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Alternative
public class BookingServletContextListenerWrapper implements
		ServletContextListenerWrapper {

	/** ロガー */
	private Logger log = ExpartContext.getLogger(getClass());

	@Override
	public void initialized(EntityManager entityManager) {
		log.info("初期化処理がコールされました。");
		// DateUtilのプロパティをBookingカスタマイズのものに変更
		// DateUtil.getInstance().setDateProperty(
		// new BookingDatePropertyImpl(entityManager));
		// CDI.getBeanInstance(BookingInitializer.class,
		// ApplicationScoped.class);
	}

	@Override
	public void destroyed() {
		log.info("終了処理がコールされました。");
	}
}
