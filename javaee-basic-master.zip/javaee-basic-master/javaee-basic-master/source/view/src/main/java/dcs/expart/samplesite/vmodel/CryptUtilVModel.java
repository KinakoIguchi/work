package dcs.expart.samplesite.vmodel;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.slf4j.Logger;
import org.apache.commons.codec.binary.Hex;

import dcs.expart.samplesite.layer.SampleSiteGenericVModel;
import dcs.fw.context.ExpartContext;
import dcs.fw.context.ViewModel;
import dcs.fw.context.ExpartContext.MessageSeverity;
import dcs.fw.util.CryptUtil;

/**
 * 暗号化復号化UtilityのViewModel
 * 
 * @version 1.0
 */
@Named("cryptutilVModel")
@SessionScoped
@ViewModel
public class CryptUtilVModel extends SampleSiteGenericVModel implements Serializable {

    /** ログインスタンス */
    protected Logger log = ExpartContext.getLogger(getClass());

    /** ID*/
    private static final long serialVersionUID = 1L;

    /** タイトル（コンポーネント名） */
    private final String title = "暗号化復号化Utility";

    /** 元データ*/
    private String plainString;

    /** 暗号データ*/
    private String cipherString;


    /** 元データ*/
    private byte[] plainData;

    /** 暗号データ*/
    private byte[] cipherData;

    /** IV*/
    private byte[] CryIv;

    /** IVString*/
    private String cryIvString;

    /**
     * 初期化処理
     */
    @PostConstruct
    public void init() {
        // 説明、タグ名、属性のセット
        getComponentDataFromXML(title);
        setIV();
    }

    /**
     * iv生成処理
     */
    public void setIV(){
        this.CryIv = CryptUtil.createIv();
        this.cryIvString = Hex.encodeHexString(this.CryIv);
    }

    /**
     * 暗号化処理
     */
    public String encrypt(){
        this.CryIv = hexStringToByte(this.cryIvString);
        if (this.CryIv == null) {
            setIV();
        } else if (this.CryIv.length < 16) {
            context.addMessage(MessageSeverity.INFO,null,
                    "iv値の桁数をご確認ください。");
            return context.getRedirectCurrentPage();
        }
        try{
            this.cipherData = CryptUtil.encrypt(this.CryIv, this.plainString.getBytes());
        } catch (Exception e) {
            context.addMessage(MessageSeverity.INFO,null,
                    "異常が発生しました。入力値をご確認ください。");
            return context.getRedirectCurrentPage();
        }
        this.cipherString = Hex.encodeHexString(this.cipherData);
        this.plainString = null;
        return null;
    }

    /**
     * 復号化処理
     */
    public String decrypt(){
        this.CryIv = hexStringToByte(this.cryIvString);
        if (this.CryIv == null) {
            setIV();
        } else if (this.CryIv.length < 16) {
            context.addMessage(MessageSeverity.INFO,null,
                    "iv値の桁数をご確認ください。");
            return context.getRedirectCurrentPage();
        }
        this.cipherData = hexStringToByte(this.cipherString);
        if (this.cipherData == null) {
            context.addMessage(MessageSeverity.INFO,null,
                    "異常が発生しました。暗号値をご確認ください。");
            return context.getRedirectCurrentPage();
        }
        try{
            this.plainData = CryptUtil.decrypt(this.CryIv, this.cipherData);
        } catch (Exception e) {
            context.addMessage(MessageSeverity.INFO,null,
                    "異常が発生しました。暗号と複合間にiv値が変更されていないかをご確認ください。");
            return context.getRedirectCurrentPage();
        }
        this.plainString = new String(this.plainData);
        this.cipherString = null;
        return null;
    }

    /**
     * バイト型の文字列を復元する処理
     */
    private byte[] hexStringToByte(String inVal){
        try {
            return Hex.decodeHex(inVal.toCharArray());
        } catch (Exception e) {
            return null;
        }
    }


    /*
     * --------------------------以下、getter、setter--------------------------------
     */
    public String getTitle() {
        return title;
    }

    /**
     * @return plainString
     */
    public String getPlainString() {
        return plainString;
    }

    /**
     * @param plainString セットする plainString
     */
    public void setPlainString(String plainString) {
        this.plainString = plainString;
    }

    /**
     * @return cipherString
     */
    public String getCipherString() {
        return cipherString;
    }

    /**
     * @param cipherString セットする cipherString
     */
    public void setCipherString(String cipherString) {
        this.cipherString = cipherString;
    }

    /**
     * @return cryIvString
     */
    public String getCryIvString() {
        return cryIvString;
    }

    /**
     * @param cryIvString セットする cryIvString
     */
    public void setCryIvString(String cryIvString) {
        this.cryIvString = cryIvString;
    }
}
