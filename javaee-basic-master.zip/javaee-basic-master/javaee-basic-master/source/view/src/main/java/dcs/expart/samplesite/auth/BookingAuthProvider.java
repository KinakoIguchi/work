package dcs.expart.samplesite.auth;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.inject.Inject;
import javax.inject.Named;

import dcs.fw.auth.AuthProvider;
import dcs.fw.auth.Identity;

/**
 * 認証処理のプロバイダー<br/>
 * FWのAuthProviderを継承し、業務のログイン処理のみ実装するようにしています。<br/>
 * サンプルでは、データベースの認証処理を実装しています。
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Named("authProvider")
@Alternative
@Stateless
public class BookingAuthProvider extends AuthProvider implements Serializable {
	/** シリアルID */
	private static final long serialVersionUID = 1L;

	/** 認証情報 */
	@Inject
	Identity identity;

	/** アカウント情報サービス */
	// @Inject
	// private AccountService accountService;
	// /** ログ出力サービス */
	// @Inject
	// private AuditService auditService;

	/**
	 * 初期化処理
	 */
	@PostConstruct
	@Override
	public void init() {
		// 自動制御用のページを設定
		setPageLogin("/login");
		setPageLoginSuccess("/index");

	}

	/**
	 * ログイン実処理<br/>
	 * DBに問い合わせを行い、認証を行う
	 *
	 * @return ログイン処理結果
	 */
	@Override
	public boolean login() {
		// 入力値を取得
		String userId = context.getParameter("userId");
		String password = getHashedPwd(context.getParameter("password"));

		// /** クライテリアクエリの確認(意図はそれだけ) */
		// CriteriaBuilder cb = context.getEntityManager().getCriteriaBuilder();
		// CriteriaQuery<Account> cq = cb.createQuery(Account.class);
		// Root<Account> r = cq.from(Account.class);
		// cq.select(r).where(cb.equal(r.get("accountId"), userId));
		// List<Account> loginAccount =
		// context.getEntityManager().createQuery(cq).getResultList();
		// Account loginAccount = accountService.find(userId);

		// if (loginAccount != null) {
		// if (password.equals(loginAccount.getPassword())) {
		// // Account account = loginAccount;
		// identity.setUserId(account.getAccountId());
		// identity.setEmail(account.getEmail());
		// identity.setUserName(account.getFirstName() + " " +
		// account.getSecondName());
		// this.setRoles(account.getAccountId());
		//
		// // AuthProviderでの更新処理確認
		// account.updateDate();
		// accountService.update(account);
		//
		// //AuthProviderでの更新処理確認
		// auditService.outputLoginLog(userId, true);
		//
		// // ログイン前のURLを残しておきたくない場合
		// // ((HttpSession)
		// FacesContext.getCurrentInstance().getExternalContext().getSession(false)).removeAttribute(AuthPhaseListener.LOGIN_REQUEST_URI);
		// return true;
		// }
		// }
		//
		// //AuthProviderでの更新処理確認 - 別トランログ書込み
		// auditService.outputLoginLog(userId, false);
		return false;
	}

	/**
	 * ロール情報を設定します。
	 * 
	 * @param accountId
	 *            アカウントID
	 */
	private void setRoles(String accountId) {
		if ("admin".equals(accountId)) {
			identity.setRoles(new String[] { "admin" });
		} else {
			identity.setRoles(new String[] { "user" });
		}
	}
}
