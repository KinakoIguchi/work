package dcs.expart.samplesite.vmodel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.slf4j.Logger;

import dcs.expart.samplesite.layer.SampleSiteGenericVModel;
import dcs.expart.samplesite.util.Constant;
import dcs.fw.context.ExpartContext;
import dcs.fw.context.ExpartContext.MessageSeverity;
import dcs.fw.context.ViewModel;

/**
 * コンポーネントVModel
 *
 * @version 1.0
 */
@Named("checkBoxVModel")
@SessionScoped
@ViewModel
public class CheckBoxVModel extends SampleSiteGenericVModel implements Serializable {

    /** ログインスタンス */
    protected Logger log = ExpartContext.getLogger(getClass());

    /** ID */
    private static final long serialVersionUID = 1L;

    /** タイトル（コンポーネント名） */
    private final String title = Constant.S_CHECK_BOX;

    /** 入力値 */
    private ArrayList<String> inputListValue = new ArrayList<String>();

    /** 入力値（スポーツ） */
    private ArrayList<String> inputValueSports = new ArrayList<String>();

    /** チェックボックス（スポーツ） */
    private List<String> checkBoxSports = new ArrayList<String>();

    /** チェックボックス（無効化サンプル） */
    private List<String> checkBoxDisabledSample = new ArrayList<String>();

    /** 初期化処理 */
    @PostConstruct
    public void init() {
        // 初期化処理
        getComponentDataFromXML(title);
        // チェックボックスの選択肢を生成
        getCheckBoxSports().add("サッカー");
        getCheckBoxSports().add("野球");
        getCheckBoxSports().add("バスケットボール");
    }

    @Override
    /** [送信]ボタン押下時処理 */
    public String sendButton() {
        if (!inputListValue.isEmpty() || !inputValueSports.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            if (!inputListValue.isEmpty()) {
                for (String temp : getInputListValue()) {
                    sb.append(temp + ",");
                }
            }
            if (!inputValueSports.isEmpty()) {
                for (String temp : getInputValueSports()) {
                    sb.append(temp + ",");
                }
            }
            sb.replace(sb.lastIndexOf(","), sb.lastIndexOf(",") + 1, "");

            context.addMessage(MessageSeverity.INFO, null, "格納された値は[" + sb + "]です。");
        } else {
            context.addMessage(MessageSeverity.ERROR, null, "チェックボックスをチェックしてください。");
        }
        return context.getRedirectCurrentPage();

    }

    /*
     * --------------------------以下、getter、setter--------------------------------
     */

    public String getTitle() {
        return title;
    }

    public ArrayList<String> getInputListValue() {
        return inputListValue;
    }

    public void setInputListValue(ArrayList<String> inputListValue) {
        this.inputListValue = inputListValue;
    }

    public ArrayList<String> getInputValueSports() {
        return inputValueSports;
    }

    public void setInputValueSports(ArrayList<String> inputValueSports) {
        this.inputValueSports = inputValueSports;
    }

    public List<String> getCheckBoxSports() {
        return checkBoxSports;
    }

    public void setCheckBoxSports(List<String> checkBoxSports) {
        this.checkBoxSports = checkBoxSports;
    }

    public List<String> getCheckBoxDisabledSample() {
        return checkBoxDisabledSample;
    }

    public void setCheckBoxDisabledSample(List<String> checkBoxDisabledSample) {
        this.checkBoxDisabledSample = checkBoxDisabledSample;
    }

}
