package dcs.expart.samplesite.auth;

import java.io.Serializable;

import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.context.SessionScoped;
import javax.enterprise.inject.Alternative;
import javax.inject.Named;

import dcs.fw.auth.Identity;

/**
 * 認証アカウントを管理するクラス
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Named("identity")
@SessionScoped
@Alternative
@Stateful
//！重要 - AuthProviderで更新を行う場合、identityのログイン確認でEJBのrockが発生する。
// そのため、本EJBはトランザクションを必要としていないことを明示する指定を行う。
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class BookingIdentity extends Identity implements Serializable {

    /** シリアルID */
    private static final long serialVersionUID = 1L;
}
