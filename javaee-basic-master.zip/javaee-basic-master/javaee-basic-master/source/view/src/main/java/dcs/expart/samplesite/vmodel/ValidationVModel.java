package dcs.expart.samplesite.vmodel;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;
import org.slf4j.Logger;

import dcs.expart.samplesite.layer.SampleSiteGenericVModel;
import dcs.expart.samplesite.util.Constant;
import dcs.fw.context.ExpartContext;
import dcs.fw.context.ExpartContext.MessageSeverity;
import dcs.fw.context.ViewModel;
import dcs.fw.validator.AllowCharType;
import dcs.fw.validator.Email;
import dcs.fw.validator.Hizuke;
import dcs.fw.validator.Nengetsu;
import dcs.fw.validator.Post;
import dcs.fw.validator.Time;

/**
 * コンポーネントVModel
 *
 * @version 1.0
 */
@Named("validationVModel")
@SessionScoped
@ViewModel
public class ValidationVModel extends SampleSiteGenericVModel implements Serializable {

    /** ログインスタンス */
    protected Logger log = ExpartContext.getLogger(getClass());

    /** ID */
    private static final long serialVersionUID = 1L;

    /** タイトル（コンポーネント名） */
    private final String title = Constant.L_VALIDATION;

    // バリデーション項目
    /** 必須項目 */
    @NotNull
    private String notNull;

    /** 文字数（最小） */
    @Size(min = 2, message = "{javax.validation.constraints.Size.Min.message}")
    private String lengthMin;
    /** 文字数（最大） */
    @Size(max = 5, message = "{javax.validation.constraints.Size.Max.message}")
    private String lengthMax;
    /** 文字数（最小・最大） */
    @Size(min = 2, max = 5)
    private String length;
    

    /** 半角数字 */
    @AllowCharType(hanNum = true, msgParam = AllowCharType.HALF_NUMBER)
    private String hanNum;
    /** 半角英字 */
    @AllowCharType(hanEng = true, msgParam = AllowCharType.HALF_ALPHA)
    private String hanEng;
    /** 半角記号 */
    @AllowCharType(hanSign = true, msgParam = AllowCharType.HALF_SYMBOL)
    private String hanSign;
    /** 半角カナ */
    @AllowCharType(hanKana = true, msgParam = AllowCharType.HALF_KANA)
    private String hanKana;
    /** 半角 */
    @AllowCharType(hanEng = true, hanKana = true, hanNum = true, hanSign = true, msgParam = AllowCharType.HALF_CHARACTER)
    private String han;
    /** 全角数字 */
    @AllowCharType(zenNum = true, msgParam = AllowCharType.FULL_NUMBER)
    private String zenNum;
    /** 全角英字 */
    @AllowCharType(zenEng = true, msgParam = AllowCharType.FULL_ALPHA)
    private String zenEng;
    /** 全角記号 */
    @AllowCharType(zenSign = true, msgParam = AllowCharType.FULL_SYMBOL)
    private String zenSign;
    /** 全角カナ */
    @AllowCharType(zenKana = true, msgParam = AllowCharType.FULL_KATAKANA)
    private String zenKana;
    /** 全角かな */
    @AllowCharType(zenHiragana = true, msgParam = AllowCharType.FULL_HIRAGANA)
    private String zenHiragana;
    /** 全角漢字 */
    @AllowCharType(zenKanji = true, msgParam = AllowCharType.FULL_KANZI)
    private String zenKanji;
    /** 全角 */
    @AllowCharType(zenEng = true, zenHiragana = true, zenKana = true, zenKanji = true, zenNum = true, zenSign = true, msgParam = AllowCharType.FULL_CHARACTER)
    private String zen;

    /** 許可値（最小） */
    @Min(value = 10)
    private Integer enableValMin;
    @Max(value = 100)
    /** 許可値（最大） */
    private Integer enableValMax;
    /** 許可値（最小・最大） */
    @Range(min = 10, max = 100)
    private Integer enableVal;
    /** 数値桁数 */
    @Digits(integer = 2, fraction = 2)
    private BigDecimal enableValDigits;

    /** その他チェック **/
    /** メールアドレス */
    @Email
    private String email;
    /** 日付 */
    @Hizuke
    private String hizuke;
    /** 年月 */
    @Nengetsu
    private String nengetsu;
    /** 時間 */
    @Time
    private String time;
    /** 郵便番号 */
    @Post
    private String post;

    /** 初期化処理 */
    @PostConstruct
    public void init() {
        // 属性のセット
        getComponentDataFromXML(title);
    }

    /**
     * [送信]ボタン押下時処理
     */
    @Override
    public String sendButton() {
        context.addMessage(MessageSeverity.INFO, null, "チェック対象の入力値は、全て正常です。");
        return context.getRedirectCurrentPage();
    }

    public String getNotNull() {
        return notNull;
    }

    public void setNotNull(String notNull) {
        this.notNull = notNull;
    }

    public String getLengthMin() {
        return lengthMin;
    }

    public void setLengthMin(String lengthMin) {
        this.lengthMin = lengthMin;
    }

    public String getLengthMax() {
        return lengthMax;
    }

    public void setLengthMax(String lengthMax) {
        this.lengthMax = lengthMax;
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public String getHanNum() {
        return hanNum;
    }

    public void setHanNum(String hanNum) {
        this.hanNum = hanNum;
    }

    public String getHanEng() {
        return hanEng;
    }

    public void setHanEng(String hanEng) {
        this.hanEng = hanEng;
    }

    public String getHanSign() {
        return hanSign;
    }

    public void setHanSign(String hanSign) {
        this.hanSign = hanSign;
    }

    public String getHanKana() {
        return hanKana;
    }

    public void setHanKana(String hanKana) {
        this.hanKana = hanKana;
    }

    public String getHan() {
        return han;
    }

    public void setHan(String han) {
        this.han = han;
    }

    public String getZenNum() {
        return zenNum;
    }

    public void setZenNum(String zenNum) {
        this.zenNum = zenNum;
    }

    public String getZenEng() {
        return zenEng;
    }

    public void setZenEng(String zenEng) {
        this.zenEng = zenEng;
    }

    public String getZenSign() {
        return zenSign;
    }

    public void setZenSign(String zenSign) {
        this.zenSign = zenSign;
    }

    public String getZenKana() {
        return zenKana;
    }

    public void setZenKana(String zenKana) {
        this.zenKana = zenKana;
    }

    public String getZenHiragana() {
        return zenHiragana;
    }

    public void setZenHiragana(String zenHiragana) {
        this.zenHiragana = zenHiragana;
    }

    public String getZenKanji() {
        return zenKanji;
    }

    public void setZenKanji(String zenKanji) {
        this.zenKanji = zenKanji;
    }

    public String getZen() {
        return zen;
    }

    public void setZen(String zen) {
        this.zen = zen;
    }

    public Integer getEnableValMin() {
        return enableValMin;
    }

    public void setEnableValMin(Integer enableValMin) {
        this.enableValMin = enableValMin;
    }

    public Integer getEnableValMax() {
        return enableValMax;
    }

    public void setEnableValMax(Integer enableValMax) {
        this.enableValMax = enableValMax;
    }

    public Integer getEnableVal() {
        return enableVal;
    }

    public void setEnableVal(Integer enableVal) {
        this.enableVal = enableVal;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getHizuke() {
        return hizuke;
    }

    public void setHizuke(String hizuke) {
        this.hizuke = hizuke;
    }

    public String getNengetsu() {
        return nengetsu;
    }

    public void setNengetsu(String nengetsu) {
        this.nengetsu = nengetsu;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getTitle() {
        return title;
    }

    public BigDecimal getEnableValDigits() {
        return enableValDigits;
    }

    public void setEnableValDigits(BigDecimal enableValDigits) {
        this.enableValDigits = enableValDigits;
    }

    
    /*
     * --------------------------以下、getter、setter--------------------------------
     */

}
