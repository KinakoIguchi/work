select r 
from Reservation r where r.room.roomNo = :roomNo 
and (r.reserveDate is null or r.reserveDate = :reserveDate) 
and r.room.hotel.code = :code