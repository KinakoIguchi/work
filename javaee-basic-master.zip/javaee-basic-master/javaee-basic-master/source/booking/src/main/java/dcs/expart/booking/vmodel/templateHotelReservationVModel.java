package dcs.expart.booking.vmodel;


import java.io.Serializable;


import javax.annotation.PostConstruct;
import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.inject.Named;


import dcs.expart.booking.entity.Hotel;

import dcs.expart.booking.service.HotelService;

import dcs.expart.booking.service.RoomService;

import dcs.fw.auth.AuthProvider;
import dcs.fw.auth.Identity;

import dcs.fw.context.ViewModel;

import dcs.fw.layer.GenericVModel;


/**
 * ホテル予約画面用のViewModel
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Named
@ConversationScoped
@ViewModel
public class templateHotelReservationVModel extends GenericVModel implements Serializable {

  /** シリアルID */
  private static final long serialVersionUID = 1L;

  /** 予約対象のホテル */
  private Hotel hotel;

  /** ホテル管理用サービス */
  @Inject
  private HotelService hotelService;

  /** ホテルの部屋情報サービス */
  @Inject
  private RoomService roomService;

  /** アカウント管理用サービス */
  /** */
  @Inject
  private AuthProvider authProvider;

  /** 認証情報 */
  @Inject
  private Identity identity;

  /**
   * 初期化処理 予約対象のホテルをセット
   */
  @PostConstruct
  public void init() {}



  /**
   * 選択されているホテルについて予約可能な部屋一覧を返します
   *
   * @return 予約可能な部屋一覧
   */

  /**
   * 予約対象のホテルを取得します。
   *
   * @return 予約対象のホテル
   */
  public Hotel getHotel() {
    return hotel;
  }

  /**
   * 予約対象のホテルを設定します。
   *
   * @param hotel 予約対象のホテル
   */
  public void setHotel(Hotel hotel) {
    this.hotel = hotel;
  }

}
