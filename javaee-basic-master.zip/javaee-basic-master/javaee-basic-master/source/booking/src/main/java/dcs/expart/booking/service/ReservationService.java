package dcs.expart.booking.service;



import javax.inject.Inject;
import javax.ws.rs.Path;
import dcs.fw.context.ExpartContext;


/**
 * 予約操作サービス
 * 
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Path("/reservation")
public class ReservationService {

  /** */
  @Inject
  private ExpartContext context;

  /**
   * 予約情報と部屋番号、ホテルコードから予約レコードを生成し登録
   * 
   * @param reservation 予約情報
   * @param roomNo 部屋番号
   * @param hotelCode ホテルコード
   * @throws RuntimeException 重複登録時の例外
   */

}
