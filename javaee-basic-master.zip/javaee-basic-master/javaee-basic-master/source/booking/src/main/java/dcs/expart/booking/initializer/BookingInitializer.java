package dcs.expart.booking.initializer;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.Set;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;
import dcs.expart.booking.entity.Account;
import dcs.expart.booking.entity.GroupRole;
import dcs.expart.booking.entity.Holiday;
import dcs.expart.booking.entity.Hotel;
import dcs.expart.booking.entity.Room;
import dcs.fw.auth.AuthProvider;
import dcs.fw.jpa.LazyEntityManager;
import dcs.fw.util.DateUtil;

/**
 * データベースに初期データ投入をする為のイニシャライザ<br/>
 * ログイン画面のJSFイベントによって動作する想定。<br/>
 * （イニシャライザはコンポーネント生成時の一度のみ動作する想定）<br/>
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@ApplicationScoped
@Transactional(value = TxType.REQUIRES_NEW)
public class BookingInitializer implements Serializable {

  /** シリアルID */
  private static final long serialVersionUID = 1L;

  /** エンティティマネージャ */
  @Inject
  LazyEntityManager lazyEntityManager;

  /**
   * 初期データを登録します
   */
  public void load() {
    // Adminユーザがすでに登録済みの場合、初期データ投入は実行しない
    Long count = lazyEntityManager.getEntityManager()
        .createQuery("SELECT COUNT(a) FROM Account a Where accountId = :accountId", Long.class)
        .setParameter("accountId", "admin").getSingleResult();
    if (count == 0) {
      Account account = new Account();
      account.setAccountId("admin");
      account.setFirstName("DCS");
      account.setSecondName("太郎");
      account.setPassword(AuthProvider.getHashedPwd("admin"));
      account.setEmail("dcstaro@dcs.co.jp");
      lazyEntityManager.getEntityManager().persist(account);

      for (Integer i : DateUtil.getInstance().getDateProperty().getHolidays()) {
        Holiday holiday = new Holiday();
        holiday.setDate(i);
        lazyEntityManager.getEntityManager().persist(holiday);
      }

      for (int i = 0; i < 30; i++) {
        Account account2 = new Account();
        account2.setAccountId("admin" + i);
        account2.setFirstName("DCS" + i);
        account2.setSecondName("太郎");
        account2.setPassword(AuthProvider.getHashedPwd("admin" + i));
        account2.setEmail("dcstaro" + i + "@dcs.co.jp");
        lazyEntityManager.getEntityManager().persist(account2);
      }

      /**
       * groupRoleデータ初期化<br/>
       * <br/>
       * 例1）admin0は、1グループ＆ロール1<br/>
       * 例2）admin1は、1グループ＆ロール2(admin0のグループの上長)<br/>
       * 例1）admin2は、1グループ＆ロール3(admin1のグループの上長)<br/>
       */
      for (int i = 0; i < 15; i++) {
        GroupRole groupRole = new GroupRole();
        int r = i % 5 + 1;
        int g = Math.floorDiv(i, 10) + 1;
        groupRole.setUserId("admin" + i);
        groupRole.setGroupCode(g + "G");
        groupRole.setRoleCode(r);
        lazyEntityManager.getEntityManager().persist(groupRole);
      }

      Hotel hotel = new Hotel();
      hotel.setAddress("東京都");
      hotel.setCode("11111111");
      hotel.setName("テストホテルA");
      hotel.setRank(5);

      Hotel hotel2 = new Hotel();
      hotel2.setAddress("東京都");
      hotel2.setCode("11111112");
      hotel2.setName("テストホテルB");
      hotel2.setRank(5);

      Hotel hotel3 = new Hotel();
      hotel3.setAddress("東京都");
      hotel3.setCode("11111113");
      hotel3.setName("テストホテルC");
      hotel3.setRank(3);

      lazyEntityManager.getEntityManager().persist(hotel);
      lazyEntityManager.getEntityManager().persist(hotel2);
      lazyEntityManager.getEntityManager().persist(hotel3);


      Set<Room> rooms = new LinkedHashSet<Room>();
      for (int i = 1; i < 10; i++) {
        for (int j = 1; j < 6; j++) {
          Room room = new Room();
          room.setRoomNo(j + "0" + i);
          room.setHotel(hotel);
          lazyEntityManager.getEntityManager().persist(room);
          rooms.add(room);
        }
      }

      Set<Room> rooms2 = new LinkedHashSet<Room>();
      for (int i = 1; i < 5; i++) {
        for (int j = 1; j < 4; j++) {
          Room room2 = new Room();
          room2.setRoomNo(j + "0" + i);
          room2.setHotel(hotel2);
          lazyEntityManager.getEntityManager().persist(room2);
          rooms2.add(room2);
        }
      }

      Set<Room> rooms3 = new LinkedHashSet<Room>();
      for (int i = 1; i < 3; i++) {
        for (int j = 1; j < 3; j++) {
          Room room3 = new Room();
          room3.setRoomNo(j + "0" + i);
          room3.setHotel(hotel3);
          lazyEntityManager.getEntityManager().persist(room3);
          rooms3.add(room3);
        }
      }

      hotel.setRooms(rooms);
      hotel2.setRooms(rooms2);
      hotel3.setRooms(rooms3);
      lazyEntityManager.getEntityManager().merge(hotel);
      lazyEntityManager.getEntityManager().merge(hotel2);
      lazyEntityManager.getEntityManager().merge(hotel3);
    }
  }
}
