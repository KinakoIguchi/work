package dcs.expart.booking.service;

import javax.ejb.Asynchronous;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import dcs.expart.booking.entity.Audit;
import dcs.expart.booking.entity.LogCategory;
import dcs.fw.auth.UserForAsync;
import dcs.fw.context.ExpartContext;
import dcs.fw.util.StringUtil;

/**
 *
 * ログデータの操作用サービス
 *
 * @author u071501
 * @version 1.0
 */
@RequestScoped
public class AuditService {

  /** Expartコンテキスト */
  @Inject
  private ExpartContext expartContext;

  /** 別トランザクション実行用にEntityManagerを直接インジェクション */
  // @Inject
  // private LazyEntityManager lazyEntityManager;

  /** ユーザ名を保つ非同期処理用object */
  @Inject
  private UserForAsync identityForAsync;

  /**
   * ログインログの書き込みサービス
   * 
   * @param userName ユーザ名
   * @param userId ユーザID
   * @param result ログイン処理結果
   */
  @Asynchronous
  // @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
  public void outputLoginLog(String userName, String userId, boolean result) {
    // ログインユーザIDを渡す
    identityForAsync.setUserId(userId);
    Audit audit;
    if (result) {
      audit = new Audit(LogCategory.LOGIN, StringUtil.join(userId, "：", "SUCCESS"));
    } else {
      audit = new Audit(LogCategory.LOGIN, StringUtil.join(userId, "：", "FAILD"));
    }
    expartContext.getEntityManager().persist(audit);
  }

  /**
   * ログインログの書き込みサービス
   * 
   * @param result ログイン処理結果
   */
  @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
  // @Asynchronous
  public void outputReserveInsertLog(boolean result) {
    Audit audit;
    if (result) {
      audit = new Audit(LogCategory.DB, "ホテル予約完了");
    } else {
      audit = new Audit(LogCategory.LOGIN, "ホテル予約失敗");
    }
    expartContext.getEntityManager().persist(audit);
  }
}
