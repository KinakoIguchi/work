package dcs.expart.booking.vmodel;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.inject.Named;

import dcs.expart.booking.entity.Account;
import dcs.expart.booking.service.AccountService;
import dcs.fw.context.ViewModel;
import dcs.fw.layer.GenericVModel;

/**
 * アカウント一覧用ViweModel
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Named
@ConversationScoped
@ViewModel
public class AccountSearchVModel extends GenericVModel implements Serializable {

  /** シリアルID */
  private static final long serialVersionUID = 1L;

  /** アカウント管理用のサービス */
  @Inject
  private transient AccountService accoutnService;

  /** アカウント一覧 */
  private List<Account> allAccounts;

  /**
   * 初期処理<br/>
   * アカウント一覧を取得し、設定する
   */
  public void init() {

    allAccounts = accoutnService.getAllAccounts();
  }

  /**
   * 選択されたアカウントIDをパラメータとして付与し、更新画面へ遷移する
   *
   * @param account 選択されたアカウント
   * @return 次画面ID
   */
  public String update(Account account) {
    Map<String, String> params = new HashMap<String, String>();
    params.put("accountId", account.getAccountId());
    return context.getRedirectPageWithParam("/mst/accountUpdate", params);
  }

  /**
   * @return アカウント一覧
   */
  public List<Account> getAllAccounts() {
    return allAccounts;
  }

}
