package dcs.expart.booking.context;

import javax.enterprise.context.RequestScoped;

/**
 * Booking用のContext<br/>
 * プロジェクト用に拡張したい場合は、ExpartContextを継承し、
 * 
 * <pre>
 * &#64;Named("expartContext")
 * </pre>
 * 
 * を付与すること
 *
 * @author u071501
 * @version 1.0
 *
 */
// @Alternative
// @Named("expartContext")
@RequestScoped
public class BookingContext {

}
