package dcs.expart.booking.interceptor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import javax.inject.Inject;
import javax.interceptor.InvocationContext;
import dcs.expart.booking.entity.Hotel;
import dcs.expart.booking.entity.Review;
import dcs.expart.booking.service.ReviewService;
import dcs.fw.interceptor.BaseUpdateInterceptor;
import dcs.fw.jpa.entity.UpdateHistory;
import dcs.fw.util.JsonUtil;
import dcs.fw.websocket.endpoint.DbUpdateEndpoint;

/**
 * DB更新を自動で検知するためのインターセプターの実装クラス
 * 
 * @author d530964
 * @version 1.0
 */
public class BookingUpdateInterceptor extends BaseUpdateInterceptor {

  /**
   * シリアルバージョンUID
   */
  private static final long serialVersionUID = 1L;

  /**
   * レビューサービスクラス
   */
  @Inject
  ReviewService reviewService;


  /*
   * 抽象メソッドのオーバーライド 独自の送信処理を実装
   * 
   */
  @Override
  protected void send(InvocationContext context, UpdateHistory updateHistory, String jsonData) {

    String className = updateHistory.getClassName();

    if (className.equals(Review.class.getName())) {

      // 一覧の取得
      Review para = (Review) context.getParameters()[0];
      String hotelCode = para.getHotel().getCode();
      Hotel hotel = reviewService.findHotelIncludeReviews(hotelCode);

      List<Review> reviewList = hotel.getReviewsList();

      // 平均値の取得
      double points = 0;

      // JSONへの変換
      List<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();

      for (Review review : reviewList) {

        HashMap<String, String> map = new LinkedHashMap<String, String>();

        map.put("reviewDate", review.getReviewDate().toString());
        map.put("userName", review.getUserName());
        map.put("comment", review.getComment());
        map.put("point", review.getPoint());

        list.add(map);
        points += Double.parseDouble(review.getPoint());
      }

      HashMap<String, Object> listMap = new LinkedHashMap<String, Object>();
      listMap.put("list", list);

      // 平均値の設定
      String average = String.format("%.1f", (points / hotel.getReviews().size()));
      listMap.put("average", average);

      // レビュー件数の設定
      listMap.put("count", list.size());

      String exJsonData = JsonUtil.createJsonData(listMap);

      // WebSocketの送信メソッドの呼び出し
      DbUpdateEndpoint.send("reviewlist" + hotel.getCode(), exJsonData);
    }
  }
}
