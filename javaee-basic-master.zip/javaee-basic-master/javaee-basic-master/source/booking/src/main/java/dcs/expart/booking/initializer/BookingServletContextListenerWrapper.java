package dcs.expart.booking.initializer;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Alternative;
import javax.persistence.EntityManager;
import org.slf4j.Logger;
import dcs.expart.booking.util.BookingDatePropertyImpl;
import dcs.fw.context.ExpartContext;
import dcs.fw.initialize.ServletContextListenerWrapper;
import dcs.fw.util.CDI;
import dcs.fw.util.DateUtil;

/**
 * ServletContextListenerWrapperの実装クラス<br/>
 * サーバ起動及び停止時に処理を差し込む際のサンプル<br/>
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@ApplicationScoped
@Alternative
public class BookingServletContextListenerWrapper implements ServletContextListenerWrapper {

  /** ロガー */
  private Logger log = ExpartContext.getLogger(getClass());

  @Override
  public void initialized(EntityManager entityManager) {
    log.info("初期化処理がコールされました。");
    // 初期データ投入
    BookingInitializer bi = CDI.getBeanInstance(BookingInitializer.class, ApplicationScoped.class);
    bi.load();
    // 日付処理のカスタマイズ
    DateUtil.getInstance().setDateProperty(new BookingDatePropertyImpl(entityManager));
  }

  @Override
  public void destroyed() {
    log.info("終了処理がコールされました。");
  }
}
