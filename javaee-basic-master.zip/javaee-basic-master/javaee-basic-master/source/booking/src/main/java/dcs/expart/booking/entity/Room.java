package dcs.expart.booking.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlTransient;

import dcs.fw.jpa.entity.SurrogateKeyEntity;

/**
 * ルームテーブルのエンティティ
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Entity
@Table
public class Room extends SurrogateKeyEntity implements Serializable {

  /***/
  private static final long serialVersionUID = 1L;

  /** */
  @ManyToOne
  private Hotel hotel;

  /** 部屋番号 */
  private String roomNo;

  /**
   * hotelを取得します。
   *
   * @return hotel
   */
  @XmlTransient
  public Hotel getHotel() {
    return hotel;
  }

  /**
   * hotelを設定します。
   *
   * @param hotel hotel
   */
  @XmlTransient
  public void setHotel(Hotel hotel) {
    this.hotel = hotel;
  }

  /**
   * 部屋番号を取得します。
   *
   * @return 部屋番号
   */
  public String getRoomNo() {
    return roomNo;
  }

  /**
   * 部屋番号を設定します。
   *
   * @param roomNo 部屋番号
   */
  public void setRoomNo(String roomNo) {
    this.roomNo = roomNo;
  }
}
