package dcs.expart.booking.entity;

import java.io.Serializable;

import javax.persistence.Entity;

import org.hibernate.validator.constraints.Range;

import dcs.fw.jpa.entity.SurrogateKeyEntity;

/**
 * パスワードテーブルのエンティティ
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Entity
public class PasswordPolicy extends SurrogateKeyEntity implements Serializable {

  /** */
  private static final long serialVersionUID = 1L;
  /** パスワードの最小長 */
  @Range(min = 0, max = 32)
  private int lengthMin;

  /** パスワードの最大長 */
  @Range(min = 0, max = 32)
  private int lengthMax;

  /** 強制文字種有無フラグ（英字） */
  private boolean forceCharAlph;

  /** 強制文字種有無フラグ（数字） */
  private boolean forceCharNum;

  /** 強制文字種有無フラグ（記号） */
  private boolean forceCharSymbol;

  /** 有効期限有無フラグ */
  private boolean expireAvailableFlg;

  /** 有効期限 */
  @Range(min = 0, max = 3650)
  private int untilExpireTerm;

  /** ロック有無フラグ */
  private boolean lockAvailableFlg;

  /** ロックまでの回数 */
  @Range(min = 0, max = 10)
  private int untilLockCount;

  /** 前回と同じパスワード許可フラグ */
  private boolean allowSamePass;

  /** 初回パスワード強制変更フラグ */
  private boolean forceFirstPassChg;

  /**
   * パスワードの最小長を取得します。
   *
   * @return パスワードの最小長
   */
  public int getLengthMin() {
    return lengthMin;
  }

  /**
   * パスワードの最小長を設定します。
   *
   * @param lengthMin パスワードの最小長
   */
  public void setLengthMin(int lengthMin) {
    this.lengthMin = lengthMin;
  }

  /**
   * パスワードの最大長を取得します。
   *
   * @return パスワードの最大長
   */
  public int getLengthMax() {
    return lengthMax;
  }

  /**
   * パスワードの最大長を設定します。
   *
   * @param lengthMax パスワードの最大長
   */
  public void setLengthMax(int lengthMax) {
    this.lengthMax = lengthMax;
  }

  /**
   * 強制文字種有無フラグ（英字）を取得します。
   *
   * @return 強制文字種有無フラグ（英字）
   */
  public boolean isForceCharAlph() {
    return forceCharAlph;
  }

  /**
   * 強制文字種有無フラグ（英字）を設定します。
   *
   * @param forceCharAlph 強制文字種有無フラグ（英字）
   */
  public void setForceCharAlph(boolean forceCharAlph) {
    this.forceCharAlph = forceCharAlph;
  }

  /**
   * 強制文字種有無フラグ（数字）を取得します。
   *
   * @return 強制文字種有無フラグ（数字）
   */
  public boolean isForceCharNum() {
    return forceCharNum;
  }

  /**
   * 強制文字種有無フラグ（数字）を設定します。
   *
   * @param forceCharNum 強制文字種有無フラグ（数字）
   */
  public void setForceCharNum(boolean forceCharNum) {
    this.forceCharNum = forceCharNum;
  }

  /**
   * 強制文字種有無フラグ（記号）を取得します。
   *
   * @return 強制文字種有無フラグ（記号）
   */
  public boolean isForceCharSymbol() {
    return forceCharSymbol;
  }

  /**
   * 強制文字種有無フラグ（記号）を設定します。
   *
   * @param forceCharSymbol 強制文字種有無フラグ（記号）
   */
  public void setForceCharSymbol(boolean forceCharSymbol) {
    this.forceCharSymbol = forceCharSymbol;
  }

  /**
   * 有効期限有無フラグを取得します。
   *
   * @return 有効期限有無フラグ
   */
  public boolean isExpireAvailableFlg() {
    return expireAvailableFlg;
  }

  /**
   * 有効期限有無フラグを設定します。
   *
   * @param expireAvailableFlg 有効期限有無フラグ
   */
  public void setExpireAvailableFlg(boolean expireAvailableFlg) {
    this.expireAvailableFlg = expireAvailableFlg;
  }

  /**
   * 有効期限を取得します。
   *
   * @return 有効期限
   */
  public int getUntilExpireTerm() {
    return untilExpireTerm;
  }

  /**
   * 有効期限を設定します。
   *
   * @param untilExpireTerm 有効期限
   */
  public void setUntilExpireTerm(int untilExpireTerm) {
    this.untilExpireTerm = untilExpireTerm;
  }

  /**
   * ロック有無フラグを取得します。
   *
   * @return ロック有無フラグ
   */
  public boolean isLockAvailableFlg() {
    return lockAvailableFlg;
  }

  /**
   * ロック有無フラグを設定します。
   *
   * @param lockAvailableFlg ロック有無フラグ
   */
  public void setLockAvailableFlg(boolean lockAvailableFlg) {
    this.lockAvailableFlg = lockAvailableFlg;
  }

  /**
   * ロックまでの回数を取得します。
   *
   * @return ロックまでの回数
   */
  public int getUntilLockCount() {
    return untilLockCount;
  }

  /**
   * ロックまでの回数を設定します。
   *
   * @param untilLockCount ロックまでの回数
   */
  public void setUntilLockCount(int untilLockCount) {
    this.untilLockCount = untilLockCount;
  }

  /**
   * 前回と同じパスワード許可フラグを取得します。
   *
   * @return 前回と同じパスワード許可フラグ
   */
  public boolean isAllowSamePass() {
    return allowSamePass;
  }

  /**
   * 前回と同じパスワード許可フラグを設定します。
   *
   * @param allowSamePass 前回と同じパスワード許可フラグ
   */
  public void setAllowSamePass(boolean allowSamePass) {
    this.allowSamePass = allowSamePass;
  }

  /**
   * 初回パスワード強制変更フラグを取得します。
   *
   * @return 初回パスワード強制変更フラグ
   */
  public boolean isForceFirstPassChg() {
    return forceFirstPassChg;
  }

  /**
   * 初回パスワード強制変更フラグを設定します。
   *
   * @param forceFirstPassChg 初回パスワード強制変更フラグ
   */
  public void setForceFirstPassChg(boolean forceFirstPassChg) {
    this.forceFirstPassChg = forceFirstPassChg;
  }
}
