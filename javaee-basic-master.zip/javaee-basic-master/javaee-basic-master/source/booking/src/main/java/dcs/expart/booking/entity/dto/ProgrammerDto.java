package dcs.expart.booking.entity.dto;

/**
 * Programmerオブジェクトの@SqlResultSetMapping対応用ＤＴＯオブジェクト
 * 
 * @author DCS.黄
 * @version 1.0
 */
public class ProgrammerDto {

  /** プログラム言語 */
  private String name;

  /** 登場時間 */
  private Integer appeared;

  /**
   * マッピング用コンストラクタ構成
   * 
   * @param name プログラム言語
   * @param appeared 登場時間
   */
  public ProgrammerDto(String name, Integer appeared) {
    this.name = name;
    this.appeared = appeared;
  }

  /**
   * プログラム言語を取得します。
   * 
   * @return プログラム言語
   */
  public String getName() {
    return name;
  }

  /**
   * プログラム言語を設定します。
   * 
   * @param name プログラム言語
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * 登場時間を取得します。
   * 
   * @return 登場時間
   */
  public Integer getAppeared() {
    return appeared;
  }

  /**
   * 登場時間を設定します。
   * 
   * @param appeared 登場時間
   */
  public void setAppeared(Integer appeared) {
    this.appeared = appeared;
  }

}
