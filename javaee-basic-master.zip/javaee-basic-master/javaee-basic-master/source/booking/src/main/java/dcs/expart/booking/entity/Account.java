package dcs.expart.booking.entity;


import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import dcs.fw.auth.common.AuthAccount;
import dcs.fw.jpa.entity.LogicalName;
import dcs.fw.validator.Email;

/**
 * ユーザテーブルのエンティティ
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Entity
// REST向け定義
@XmlRootElement
public class Account extends AuthAccount {

  /***/
  private static final long serialVersionUID = 1L;

  /** 苗字 */
  @LogicalName("苗字")
  @Size(min = 0, max = 10)
  @NotNull
  private String firstName;

  /** 名前 */
  @LogicalName("名前")
  @Size(min = 0, max = 10)
  @NotNull
  private String secondName;

  /**
   * 苗字を取得します。
   *
   * @return 苗字
   */
  public String getFirstName() {
    return firstName;
  }

  /**
   * 苗字を設定します。
   *
   * @param firstName 苗字
   */
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  /**
   * 名前を取得します。
   *
   * @return 名前
   */
  public String getSecondName() {
    return secondName;
  }

  /**
   * 名前を設定します。
   *
   * @param secondName 名前
   */
  public void setSecondName(String secondName) {
    this.secondName = secondName;
  }

  /**
   * メールアドレスを取得します。<br/>
   * 既存のバリデーションに追加要素を設けたい場合は、getterに付与することでバリデーションを追加できます。
   *
   * @return メールアドレス
   */
  @Email
  public String getEmail() {
    return super.getEmail();
  }

  @Override
  public String getUserName() {
    return getFirstName().concat(" ").concat(getSecondName());
  }

}
