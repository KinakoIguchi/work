package dcs.expart.booking.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import dcs.fw.jpa.entity.SurrogateKeyEntity;

/**
 * 予約テーブルのエンティティ
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Entity
@Table(uniqueConstraints = {@UniqueConstraint(columnNames = {"room_id", "reserveDate"})})
public class Reservation extends SurrogateKeyEntity implements Serializable {

  /** シリアルID */
  private static final long serialVersionUID = 1L;

  /** 予約対象の客室 */
  @OneToOne
  private Room room;

  /** 予約者 */
  @OneToOne
  private Account account;

  /** 宿泊予定日 */
  @NotNull
  private Date reserveDate;

  /**
   * 予約対象の客室を取得します。
   *
   * @return 予約対象の客室
   */
  public Room getRoom() {
    return room;
  }

  /**
   * 予約対象の客室を設定します。
   *
   * @param room 予約対象の客室
   */
  public void setRoom(Room room) {
    this.room = room;
  }

  /**
   * 予約者を取得します。
   *
   * @return 予約者
   */
  public Account getAccount() {
    return account;
  }

  /**
   * 予約者を設定します。
   *
   * @param account 予約者
   */
  public void setAccount(Account account) {
    this.account = account;
  }

  /**
   * 宿泊予定日を取得します。
   *
   * @return 宿泊予定日
   */
  public Date getReserveDate() {
    return reserveDate;
  }

  /**
   * 宿泊予定日を設定します。
   *
   * @param reserveDate 宿泊予定日
   */
  public void setReserveDate(Date reserveDate) {
    this.reserveDate = reserveDate;
  }

}
