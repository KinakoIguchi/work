package dcs.expart.booking.service;

import javax.inject.Inject;
import javax.ws.rs.Path;
import dcs.fw.context.ExpartContext;

/**
 * 客室操作サービス
 * 
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Path("/room")
public class RoomService {

  /** Expartコンテキスト */
  @Inject
  private ExpartContext context;

  /**
   * 引数のホテルコードをもとに対象のホテルの客室一覧を取得
   * 
   * @param hotelCode 検索対象のホテルコード
   * @return 対象ホテルの客室一覧
   */

}
