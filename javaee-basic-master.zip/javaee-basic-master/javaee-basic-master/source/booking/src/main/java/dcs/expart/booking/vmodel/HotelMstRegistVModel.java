package dcs.expart.booking.vmodel;


/**
 * ホテル更新画面用のViewModel
 *
 * @author DCS tmikami
 * @version 1.0
 */

public class HotelMstRegistVModel {

  /** シリアスID */
  private static final long serialVersionUID = 1L;

}
