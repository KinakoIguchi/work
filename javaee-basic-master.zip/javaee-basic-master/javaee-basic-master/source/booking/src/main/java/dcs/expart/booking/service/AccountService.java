package dcs.expart.booking.service;

import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import dcs.expart.booking.entity.Account;
import dcs.fw.context.ExpartContext;

/**
 * アカウントのマスタメンテナンス用サービス<br/>
 * 検証のため、各クエリをCriteriaBuilderを利用して実装
 * 
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Path("/accounts")
@RequestScoped
public class AccountService {

  /** Expartコンテキスト */
  @Inject
  private ExpartContext context;

  /**
   * ユーザIDを指定してユーザを取得
   * 
   * @param accountId ユーザID
   * @return 検索対象のユーザ
   */
  @GET
  @Path("/{accountId}")
  @Produces("application/json; charset=UTF-8")
  public Account find(@PathParam("accountId") String accountId) {
    CriteriaBuilder cb = context.getEntityManager().getCriteriaBuilder();
    CriteriaQuery<Account> cq = cb.createQuery(Account.class);
    Root<Account> r = cq.from(Account.class);
    cq.select(r).where(cb.equal(r.get("accountId"), accountId));
    List<Account> accountList = context.getEntityManager().createQuery(cq).getResultList();

    return accountList.size() > 0 ? accountList.get(0) : null;
  }

  /**
   * ユーザ一覧を取得するメソッド
   * 
   * @return ユーザ一覧
   */
  @GET
  @Produces("application/json; charset=UTF-8")
  public List<Account> getAllAccounts() {
    CriteriaBuilder cb = context.getEntityManager().getCriteriaBuilder();
    CriteriaQuery<Account> cq = cb.createQuery(Account.class);
    Root<Account> r = cq.from(Account.class);
    cq.select(r).orderBy(cb.asc(r.get("accountId")));

    return context.getEntityManager().createQuery(cq).getResultList();
  }

  /**
   * 引数のアカウント情報を更新するメソッド
   * 
   * @param account 更新対象のアカウント
   */
  public void update(Account account) {
    // TODO パスワード更新処理が未実装
  }

  /**
   * 引数のアカウント情報を更新するメソッド
   * 
   * @param account 更新対象のアカウント
   */
  public void insert(Account account) {
    context.getEntityManager().persist(account);
  }
}
