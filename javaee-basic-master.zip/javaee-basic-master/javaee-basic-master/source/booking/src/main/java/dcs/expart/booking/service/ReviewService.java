package dcs.expart.booking.service;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import dcs.expart.booking.entity.Hotel;
import dcs.expart.booking.entity.Review;
import dcs.fw.context.ExpartContext;

/**
 * レビューサービス
 * 
 * @author DCS yohsato
 * @version 1.0
 */
@RequestScoped
public class ReviewService {

  /**
   * ExpartContextをインジェクション
   */
  @Inject
  private ExpartContext context;

  /**
   * レビューエンティティの登録
   * 
   * @param review レビュー
   */
  public void registReview(Review review) {
    context.getEntityManager().persist(review);
  }

  /**
   * ホテルに紐付くレビューの一覧を保持したホテルエンティティを取得します。
   * 
   * @param code コード
   * @return hotel
   */
  public Hotel findHotelIncludeReviews(String code) {
    Hotel hotel = context.getEntityManager()
        .createQuery("from Hotel h left join fetch h.reviews where h.code = :code", Hotel.class)
        .setParameter("code", code).getSingleResult();
    return hotel;
  }

}
