package dcs.expart.booking.vmodel;


import java.io.Serializable;

import java.util.List;


import javax.annotation.PostConstruct;
import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.inject.Named;

import dcs.expart.booking.entity.Hotel;

import dcs.expart.booking.service.HotelService;

import dcs.fw.context.ViewModel;

import dcs.fw.layer.GenericVModel;


/**
 * ホテル予約用のViewModel
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Named
@ConversationScoped
@ViewModel
public class HotelSearchVModel extends GenericVModel implements Serializable {

  /** シリアルID */
  private static final long serialVersionUID = 1L;

  /** ホテル一覧 */
  private List<Hotel> allHotels;

  /** ホテル操作サービス */
  @Inject
  private HotelService hotelService;

  /** コンストラクター */
  @PostConstruct
  public void init() {
    allHotels = hotelService.getAllHotels();
  }

  /**
   * 選択されたホテル予約画面へ遷移
   *
   * @param hotel Hotel
   * @return 遷移先
   */

  /**
   *
   * @return List<Hotel>
   */
  public List<Hotel> getAllHotels() {
    return allHotels;
  }
  
}
