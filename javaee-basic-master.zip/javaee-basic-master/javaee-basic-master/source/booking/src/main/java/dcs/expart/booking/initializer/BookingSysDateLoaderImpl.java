package dcs.expart.booking.initializer;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import dcs.fw.exception.CodingException;
import dcs.fw.initialize.MBeanLoaderImpl;

/**
 * bookingアプリのシステム日付MBeanLoader
 * 
 * @author DCS 曺
 * @version 1.0
 */
@Singleton
@Startup
public class BookingSysDateLoaderImpl extends MBeanLoaderImpl {

  /** シリアルＩＤ */
  private static final long serialVersionUID = 1L;

  /** MBeanServerに登録するシステム日付MBeanのオブジェクトネーム */
  private static ObjectName objectName;

  static {
    try {
      // objectNameの初期化
      objectName =
          new ObjectName(BookingSysDateLoaderImpl.class.getPackage().getName(), KEY, VALUE);
    } catch (MalformedObjectNameException e) {
      throw new CodingException(e.getMessage());
    }
  }

  @Override
  @PostConstruct
  public void registMXBean() {
    registMXBean(objectName);
  }

  @Override
  @PreDestroy
  public void unregistMXBean() {
    unregistMXBean(objectName);
  }

  /**
   * システム日付MBeanの値を取得
   * 
   * @return システム日付
   */
  public static Date getSysDate() {
    return getSysDate(objectName);
  }

}
