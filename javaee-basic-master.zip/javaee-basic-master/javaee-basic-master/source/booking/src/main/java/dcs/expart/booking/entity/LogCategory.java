package dcs.expart.booking.entity;

/**
 * ログ種類を示すENUM
 *
 * @author DCS.kfukuda
 * @version 1.0
 */
public enum LogCategory {
  /** ログインログ */
  LOGIN,
  /** DBログ */
  DB;
}
