package dcs.expart.booking.vmodel;

import java.io.Serializable;
import java.util.concurrent.Semaphore;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.hibernate.validator.constraints.NotBlank;

import dcs.expart.booking.entity.Account;
import dcs.expart.booking.service.AccountService;
import dcs.fw.context.ViewModel;
import dcs.fw.layer.GenericVModel;
import dcs.fw.util.MDUtil;

/**
 * パスワード変更画面用のViewModel
 * 
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Named("passwordChangeVModel")
@ConversationScoped
@ViewModel
public class PasswordChangeVModel extends GenericVModel implements Serializable {

  /** シリアルバージョンUID */
  private static final long serialVersionUID = 1L;

  /** 新しいパスワード */
  @NotBlank
  private String newPassword;

  /** 新しいパスワード（確認用） */
  @NotBlank
  private String confirmationNewPassword;

  /** */
  @Inject
  private AccountService accountService;

  /**
   * セマポア・インスタンス
   */
  private static Semaphore semaphore;

  /**
   * 初期化処理
   */
  @PostConstruct
  public void init() {
    // セマポア変数が存在しない場合のみ生成
    if (semaphore == null) {
      semaphore = new Semaphore(2);
    }
  }

  /**
   * ログインユーザのパスワードを入力された ものに変更するアクション
   * 
   * @return ホーム画面
   */
  public String change() {
    if (newPassword.equals(confirmationNewPassword)) {
      // 同時実行数確認の後実行
      acquire(semaphore);

      // TODO ログインユーザのIDを取得し、AccountService.findの引数とする
      Account account = accountService.find("ログインユーザのID");
      account.setPassword(MDUtil.digestAsHex(newPassword));

      // TODO AccountService.updateは空実装
      accountService.update(account);

      context.endConversation();
      // 使った資源は必ず返却する。
      release(semaphore);
      return "/index";
    } else {
      throw new RuntimeException("パスワードが一致しません");
    }
  }

  /**
   * 新しいパスワードを取得します。
   * 
   * @return 新しいパスワード
   */
  public String getNewPassword() {
    return newPassword;
  }

  /**
   * 新しいパスワードを設定します。
   * 
   * @param newPassword 新しいパスワード
   */
  public void setNewPassword(String newPassword) {
    this.newPassword = newPassword;
  }

  /**
   * 新しいパスワード（確認用）を取得します。
   * 
   * @return 新しいパスワード（確認用）
   */
  public String getConfirmationNewPassword() {
    return confirmationNewPassword;
  }

  /**
   * 新しいパスワード（確認用）を設定します。
   * 
   * @param confirmationNewPassword 新しいパスワード（確認用）
   */
  public void setConfirmationNewPassword(String confirmationNewPassword) {
    this.confirmationNewPassword = confirmationNewPassword;
  }
}
