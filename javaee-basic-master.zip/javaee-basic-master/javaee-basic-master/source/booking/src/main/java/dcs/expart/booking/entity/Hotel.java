package dcs.expart.booking.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.NamedSubgraph;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.validator.constraints.Range;

import dcs.fw.jpa.entity.SurrogateKeyEntity;
import dcs.fw.validator.AllowCharType;

/**
 * ホテルテーブルのエンティティ
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Entity
@NamedStoredProcedureQuery(name = "calc", procedureName = "test_function",
    parameters = {
        @StoredProcedureParameter(name = "x", type = Integer.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "y", type = Integer.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "result", type = Integer.class, mode = ParameterMode.OUT)})
@NamedEntityGraph(name = "hotel.graph",
    attributeNodes = {@NamedAttributeNode("name"),
        @NamedAttributeNode(value = "reviews", subgraph = "reviews")},
    subgraphs = {@NamedSubgraph(name = "reviews",
        attributeNodes = {@NamedAttributeNode("point"), @NamedAttributeNode("comment")})})
@XmlRootElement
@Table
public class Hotel extends SurrogateKeyEntity implements Serializable {

  /** */
  private static final long serialVersionUID = 1L;
  /** ホテルコード */
  @Size(min = 8, max = 8)
  @Column(unique = true)
  @AllowCharType(hanNum = true, msgParam = AllowCharType.HALF_NUMBER)
  private String code;
  /** ホテル名 */
  @Size(min = 0, max = 30)
  @NotNull
  private String name;
  /** 住所 */
  @Size(min = 0, max = 100)
  @NotNull
  private String address;
  /** ランク */
  @Range(min = 1, max = 5)
  private int rank;
  /** ホテルの客室 */
  @OneToMany(cascade = CascadeType.REMOVE)
  @OrderBy("roomNo")
  private Set<Room> rooms;

  /** レビュー */
  @OneToMany(mappedBy = "hotel", cascade = CascadeType.REMOVE)
  @OrderBy("reviewDate DESC")
  private Set<Review> reviews;

  /**
   * ホテルコードを取得します。
   *
   * @return ホテルコード
   */
  public String getCode() {
    return code;
  }

  /**
   * ホテルコードを設定します。
   *
   * @param code ホテルコード
   */
  public void setCode(String code) {
    this.code = code;
  }

  /**
   * ホテル名を取得します。
   *
   * @return ホテル名
   */
  public String getName() {
    return name;
  }

  /**
   * ホテル名を設定します。
   *
   * @param name ホテル名
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * 住所を取得します。
   *
   * @return 住所
   */
  public String getAddress() {
    return address;
  }

  /**
   * 住所を設定します。
   *
   * @param address 住所
   */
  public void setAddress(String address) {
    this.address = address;
  }

  /**
   * ランクを取得します。
   *
   * @return ランク
   */
  public int getRank() {
    return rank;
  }

  /**
   * ランクを設定します。
   *
   * @param rank ランク
   */
  public void setRank(int rank) {
    this.rank = rank;
  }

  /**
   * ホテルの客室を取得します。
   *
   * @return ホテルの客室
   */
  public Set<Room> getRooms() {
    return rooms;
  }

  /**
   * ホテルの客室を設定します。
   *
   * @param rooms ホテルの客室
   */
  public void setRooms(Set<Room> rooms) {
    this.rooms = rooms;
  }

  /**
   * レビューを取得します。
   *
   * @return レビュー
   */
  public Set<Review> getReviews() {
    return reviews;
  }

  /**
   * レビューを設定します。
   *
   * @param reviews レビュー
   */
  public void setReviews(Set<Review> reviews) {
    this.reviews = reviews;
  }

  /**
   * レビューをListで取得します。
   *
   * @return レビューのList
   */
  public List<Review> getReviewsList() {
    return new ArrayList<Review>(reviews);
  }
}
