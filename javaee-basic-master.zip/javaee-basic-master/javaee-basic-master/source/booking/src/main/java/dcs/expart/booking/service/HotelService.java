package dcs.expart.booking.service;

import java.util.List;
import javax.inject.Inject;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import dcs.expart.booking.entity.Hotel;
import dcs.expart.booking.entity.Reservation;
import dcs.fw.context.ExpartContext;

/**
 * ホテル操作サービス
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
/**
 * @author d530964
 * @version 1.0
 */
@Path("/hotels")
public class HotelService {

  /** Expartコンテキスト */
  @Inject
  private ExpartContext context;

  /**
   * コードを指定してホテルを取得（検索対象がない場合はnullを返却）
   *
   * @param code ホテルコード
   * @return 検索対象のホテル
   */

  /**
   * @return ホテル一覧
   */
  @GET
  @Produces("application/json; charset=UTF-8")
  public List<Hotel> getAllHotels() {

    /** ホテルを全件検索 */
    List<Hotel> allHotels = context.getEntityManager()
        .createQuery("select distinct h from Hotel h join fetch h.rooms", Hotel.class)
        .getResultList();

    return allHotels;
  }

  /**
   * 予約の一覧を取得する
   *
   * @param searchoDate
   * @return 予約リスト
   */
  public List<Reservation> getReservationList() {

    CriteriaBuilder cb = context.getEntityManager().getCriteriaBuilder();
    CriteriaQuery<Reservation> cq = cb.createQuery(Reservation.class);
    Root<Reservation> r = cq.from(Reservation.class);

    cq.select(r);

    List<Reservation> resultList = context.getEntityManager().createQuery(cq).getResultList();

    return resultList;
  }

}
