package dcs.expart.booking.entity;

import java.io.Serializable;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;

import dcs.expart.booking.entity.dto.EventDto;
import dcs.expart.booking.entity.dto.ProgrammerDto;
import dcs.fw.jpa.entity.SurrogateKeyEntity;

/**
 * 祝日を管理するためのテーブル
 *
 * @author DCS 黄
 * @version 1.0
 */
@Entity
@SqlResultSetMappings({
    @SqlResultSetMapping(name = "HolidayMultipleMapping",
        classes = {@ConstructorResult(targetClass = EventDto.class,
            columns = {@ColumnResult(name = "insertuser", type = String.class),
                @ColumnResult(name = "rowversion", type = Integer.class),
                @ColumnResult(name = "event", type = String.class)})}),
    @SqlResultSetMapping(name = "ProgrammerMapping",
        classes = {@ConstructorResult(targetClass = ProgrammerDto.class,
            columns = {@ColumnResult(name = "name", type = String.class),
                @ColumnResult(name = "appeared", type = Integer.class)})})})
public class Holiday extends SurrogateKeyEntity implements Serializable {

  /** シリアルバージョンUID */
  private static final long serialVersionUID = 1L;

  /** 日付 */
  private Integer date;

  /** イベント */
  private String event;

  /**
   * 日付を取得します。
   *
   * @return 日付
   */
  public Integer getDate() {
    return date;
  }

  /**
   * 日付を設定します。
   *
   * @param date 日付
   */
  public void setDate(Integer date) {
    this.date = date;
  }

  /**
   * イベント を取得します。
   *
   * @return イベント
   */
  public String getEvent() {
    return event;
  }

  /**
   * イベントを設定します。
   * 
   * @param event イベント
   */
  public void setEvent(String event) {
    this.event = event;
  }

}
