package dcs.expart.booking.auth;

import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Alternative;
import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;
import dcs.expart.booking.entity.Account;
import dcs.expart.booking.service.AccountService;
import dcs.expart.booking.service.AuditService;
import dcs.fw.auth.AuthProvider;
import dcs.fw.auth.Identity;
import dcs.fw.websocket.endpoint.SendAlertEndpoint;
import dcs.fw.websocket.endpoint.SendMessageEndpoint;
import dcs.fw.websocket.endpoint.SendProgressEndpoint;
import dcs.fw.websocket.endpoint.SendReloadAlertEndpoint;

/**
 * 認証処理のプロバイダー<br/>
 * FWのAuthProviderを継承し、業務のログイン処理のみ実装するようにしています。<br/>
 * サンプルでは、データベースの認証処理を実装しています。
 * 
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Named("authProvider")
@Alternative
@RequestScoped
@Transactional
public class BookingAuthProvider extends AuthProvider implements Serializable {
  /** シリアルID */
  private static final long serialVersionUID = 1L;

  /** 認証情報 */
  @Inject
  Identity identity;
  /** アカウント情報サービス */
  @Inject
  private AccountService accountService;
  /** ログ出力サービス */
  @Inject
  private AuditService auditService;

  /**
   * 初期化処理
   */
  @PostConstruct
  @Override
  public void init() {
    // 自動制御用のページを設定
    setPageLogin("/login");
    setPageLoginSuccess("/index");

  }

  /**
   * ログイン実処理<br/>
   * DBに問い合わせを行い、認証を行う
   * 
   * @return ログイン処理結果
   */
  @Override
  public boolean login() {
    // 入力値を取得
    String userId = context.getParameter("userId");
    String password = getHashedPwd(context.getParameter("password"));

    // 認証失敗時のユーザIDのロギングのために事前に保持
    // (AuthProviderでは認証失敗時にidentity.userIdをロギングするたｍ
    identity.setUserId(userId);

    Account loginAccount = accountService.find(userId);

    if (loginAccount != null) {
      if (password.equals(loginAccount.getPassword())) {

        // データの更新はauthorization()メソッドにて

        // AuthProviderでの更新処理確認（非同期：セッションを無視）
        auditService.outputLoginLog(identity.getUserName(), userId, true);

        // ログイン前のURLを残しておきたくない場合
        // ((HttpSession)
        // FacesContext.getCurrentInstance().getExternalContext().getSession(false)).removeAttribute(AuthPhaseListener.LOGIN_REQUEST_URI);
        return true;
      }
    }

    // AuthProviderでの更新処理確認 - 別トランログ書込み
    auditService.outputLoginLog(null, userId, false);
    return false;
  }

  /*
   * 親の認証処理の事後作業はここに。
   */
  @Override
  public String authorization() {

    // 親のを先に行い、結果を渡す。
    String resultStr = super.authorization();

    // ログインに成功したら
    if (identity.getIsLoggedIn()) {
      Account account = accountService.find(identity.getUserId());
      identity.setUserId(account.getAccountId());
      identity.setEmail(account.getEmail());
      identity.setUserName(account.getFirstName() + " " + account.getSecondName());
      this.setRoles(account.getAccountId());

      // HttpSessionにユーザＩＤを格納
      SendMessageEndpoint.setKey(SendMessageEndpoint.SEARCH_KEY, account.getAccountId());
      SendAlertEndpoint.setKey(SendAlertEndpoint.SEARCH_KEY, account.getAccountId());
      SendReloadAlertEndpoint.setKey(SendReloadAlertEndpoint.SEARCH_KEY, account.getAccountId());
      SendProgressEndpoint.setKey(SendProgressEndpoint.SEARCH_KEY, account.getAccountId());

      // AuthProviderでの更新処理確認
      account.updateDate();
      accountService.update(account);
    }

    return resultStr;
  }

  /**
   * ロール情報を設定します。
   * 
   * @param accountId アカウントID
   */
  private void setRoles(String accountId) {
    if ("admin".equals(accountId)) {
      identity.setRoles(new String[] {"admin"});
    } else {
      identity.setRoles(new String[] {"user"});
    }
  }
}
