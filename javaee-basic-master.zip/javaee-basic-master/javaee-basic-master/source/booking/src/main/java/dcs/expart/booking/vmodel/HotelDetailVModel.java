package dcs.expart.booking.vmodel;

import java.io.IOException;
import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.Part;
import javax.validation.constraints.NotNull;

import dcs.expart.booking.entity.Hotel;
import dcs.expart.booking.service.HotelService;
import dcs.fw.context.ViewModel;
import dcs.fw.jsf.JsfHelper;
import dcs.fw.layer.GenericVModel;
import dcs.fw.tag.upload.UploadFileHolder;
import dcs.fw.tag.upload.UploadUtil;

/**
 * ホテル詳細画面用のViewModel
 * 
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Named
@ConversationScoped
@ViewModel
public class HotelDetailVModel extends GenericVModel implements Serializable {

  /** シリアルバージョンUID */
  private static final long serialVersionUID = 1L;

  /** ホテルエンティティクラス */
  private Hotel hotel;

  /** ホテルサービスクラス */
  @Inject
  private HotelService hotelService;

  /** アップロードを管理するためのフィールド */
  @NotNull
  private Part uploadFile;

  /** ダウンロードファイル */
  UploadFileHolder downloadFile;

  /** 初期化処理 */
  @PostConstruct
  public void init() {
    // this.hotel = hotelService.find(context.getParameter("hotelCode"));
  }

  /**
   * ファイルをアップロードし、自画面遷移するメソッド
   * 
   * @return String 自画面遷移
   * @throws IOException 入出力例外
   */
  public String upload() throws IOException {
    downloadFile = UploadUtil.createUploadFileHolder(uploadFile);
    return context.getRedirectCurrentPage();
  }

  /**
   * ファイルダウンロード時のメソッド
   * 
   * @throws IOException 出力処理時にエラーが発生した際にスロー
   */
  public void download() throws IOException {
    JsfHelper.download(downloadFile.getFileName(), downloadFile.getFileSize(),
        downloadFile.getInputStream());
  }

  /**
   * ファイルを削除し、自画面遷移するメソッド
   * 
   * @return String 自画面遷移
   * @throws IOException 入出力例外
   */
  public String delete() throws IOException {
    downloadFile.deleteTempFile();
    downloadFile = null;
    return context.getRedirectCurrentPage();
  }

  /**
   * hotelを取得します。
   * 
   * @return hotel
   */
  public Hotel getHotel() {
    return hotel;
  }

  /**
   * hotelを設定します。
   * 
   * @param hotel hotel
   */
  public void setHotel(Hotel hotel) {
    this.hotel = hotel;
  }

  /**
   * 参考資料用のアップロードファイルを取得します。
   *
   * @return 参考資料用のアップロードファイル
   */
  public Part getUploadFile() {
    return uploadFile;
  }

  /**
   * 参考資料用のアップロードファイルを設定します。
   *
   * @param uploadFile 参考資料用のアップロードファイル
   */
  public void setUploadFile(Part uploadFile) {
    this.uploadFile = uploadFile;
  }

  /**
   * 参考資料用のアップロードファイル情報を取得します。
   * 
   * @return 参考資料用のアップロードファイル情報
   */
  public UploadFileHolder getDownloadFile() {
    return downloadFile;
  }

  /**
   * 参考資料用のアップロードファイル情報を設定します。
   * 
   * @param downloadFile 参考資料用のアップロードファイル情報
   */
  public void setDownloadFile(UploadFileHolder downloadFile) {
    this.downloadFile = downloadFile;
  }

}
