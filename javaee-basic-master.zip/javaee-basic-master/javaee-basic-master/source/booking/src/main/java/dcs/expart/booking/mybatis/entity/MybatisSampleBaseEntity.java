package dcs.expart.booking.mybatis.entity;

import java.util.Date;

/**
 * ユーザテーブルのエンティティ
 *
 * @author DCS Kwon
 * @version 1.0
 */
public class MybatisSampleBaseEntity {

  /** 登録者名 */
  private String insertUser;

  /** 登録日時 */
  private Date insertDate;

  /** 更新者名 */
  private String updateUser;

  /** 更新日時 */
  private Date updateDate;

  /**
   * 登録者名を取得します。
   *
   * @return 登録者名
   */
  public String getInsertUser() {
    return insertUser;
  }

  /**
   * 登録者名を設定します。
   *
   * @param insertUser 登録者名
   */
  public void setInsertUser(String insertUser) {
    this.insertUser = insertUser;
  }

  /**
   * 登録日時を取得します。
   *
   * @return 登録日時
   */
  public Date getInsertDate() {
    return insertDate;
  }

  /**
   * 登録日時を設定します。
   *
   * @param insertDate 登録日時
   */
  public void setInsertDate(Date insertDate) {
    this.insertDate = insertDate;
  }

  /**
   * 更新者名を取得します。
   *
   * @return 更新者名
   */
  public String getUpdateUser() {
    return updateUser;
  }

  /**
   * 更新者名を設定します。
   *
   * @param updateUser 更新者名
   */
  public void setUpdateUser(String updateUser) {
    this.updateUser = updateUser;
  }

  /**
   * 更新日時を取得します。
   *
   * @return 更新日時
   */
  public Date getUpdateDate() {
    return updateDate;
  }

  /**
   * 更新日時を設定します。
   *
   * @param updateDate 更新日時
   */
  public void setUpdateDate(Date updateDate) {
    this.updateDate = updateDate;
  }
}
