package dcs.expart.booking.vmodel;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.inject.Named;

import dcs.expart.booking.entity.Account;
import dcs.expart.booking.service.AccountService;
import dcs.fw.context.ExpartContext.MessageSeverity;
import dcs.fw.context.ViewModel;
import dcs.fw.layer.GenericVModel;
import dcs.fw.security.csrf.CheckToken;
import dcs.fw.util.StringUtil;

/**
 * アカウントのマスタメンテナンス用ViweModel
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Named
@ConversationScoped
@ViewModel
public class AccountUpdateVModel extends GenericVModel implements Serializable {

  /** シリアルID */
  private static final long serialVersionUID = 1L;

  /** アカウント管理用のサービス */
  @Inject
  private AccountService accountService;


  /**
   * 更新対象のアカウント
   */
  private Account account;

  /**
   * 初期化処理 更新対象のアカウントをセット
   */
  @PostConstruct
  public void init() {
    this.account = accountService.find(String.valueOf(context.getParameter("accountId")));
  }


  /**
   * 入力された情報でアカウントを更新
   *
   * @return 次画面ID
   */
  @CheckToken
  public String update() {
    accountService.update(account);
    context.endConversation();
    context.addMessage(MessageSeverity.INFO, null, "M000000075",
        StringUtil.join("アカウントID：", account.getAccountId()));
    return context.getRedirectPage("/mst/accountSearch");
  }

  @Override
  public String cancel(boolean endConversation) {
    super.cancel(endConversation);
    return context.getRedirectPage("/mst/accountSearch");
  }

  /**
   * 更新対象のアカウントを取得します。
   *
   * @return 更新対象のアカウント
   */
  public Account getAccount() {
    return account;
  }

  /**
   * 更新対象のアカウントを設定します。
   *
   * @param account 更新対象のアカウント
   */
  public void setAccount(Account account) {
    this.account = account;
  }

}
