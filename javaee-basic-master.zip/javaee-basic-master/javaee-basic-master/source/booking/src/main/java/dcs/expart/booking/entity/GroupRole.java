package dcs.expart.booking.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;

import dcs.fw.jpa.entity.SurrogateKeyEntity;

/**
 * <pre>
 * ワークフローのアサイン実装のため
 * ユーザにグループとロールを指定するテーブル
 * 
 * データ初期入力は
 * {@link dcs.expart.booking.initializer.BookingInitializer}を参照
 * 
 * -userid-+-group-+-role-+
 *  admin0 | 1G    | 1    |
 *  admin1 | 1G    | 2    |
 *  admin2 | 1G    | 3    |
 *  admin3 | 1G    | 4    |
 *  admin4 | 1G    | 5    |
 *  admin5 | 2G    | 1    |
 *  admin6 | 2G    | 2    |
 *  admin7 | 2G    | 3    |
 *  admin8 | 2G    | 4    |
 *  admin9 | 2G    | 5    |
 *  admin10| 3G    | 1    |
 *  admin11| 3G    | 2    |
 *  admin12| 3G    | 3    |
 *  admin13| 3G    | 4    |
 *  admin14| 3G    | 5    |
 * -userid-+-group-+-role-+
 * 
 * </pre>
 * 
 * @author scho
 * @version 1.0
 */
@Entity
@Table
public class GroupRole extends SurrogateKeyEntity implements Serializable {

  /** シリアルバージョンID */
  private static final long serialVersionUID = 1L;

  /** ユーザID */
  private String userId;

  /** グループコード */
  private String groupCode;

  /** ロールコード */
  private int roleCode;

  /**
   * @return groupCode
   */
  public String getGroupCode() {
    return groupCode;
  }

  /**
   * @param groupCode セットする groupCode
   */
  public void setGroupCode(String groupCode) {
    this.groupCode = groupCode;
  }

  /**
   * @return roleCode
   */
  public int getRoleCode() {
    return roleCode;
  }

  /**
   * @param roleCode セットする roleCode
   */
  public void setRoleCode(int roleCode) {
    this.roleCode = roleCode;
  }

  /**
   * @return userId
   */
  public String getUserId() {
    return userId;
  }

  /**
   * @param userId セットする userId
   */
  public void setUserId(String userId) {
    this.userId = userId;
  }

}
