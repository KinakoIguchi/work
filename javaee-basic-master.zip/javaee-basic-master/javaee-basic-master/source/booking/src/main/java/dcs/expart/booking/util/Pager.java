package dcs.expart.booking.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.slf4j.Logger;

import dcs.fw.security.csrf.CheckToken;
import dcs.fw.util.CDI;

/**
 * VModelで保持するListのページングを管理するためのクラス<br/>
 * ページング対象が複数ある場合については、未検証のため、1VModelに対して、1Listで利用するようにしてください。<br/>
 * 1ページの最大表示数は、デフォルトで10としています。<br/>
 * デフォルト値を変更したい場合は、web.xmlの環境変数max.page.sizeで指定してください。<br/>
 * 個別画面ごとに設定したい場合は、初期化後に個別で設定してください。
 * 
 * @author kfukuda
 * @version 1.0
 * 
 */
@Named
public class Pager implements Serializable {
  /** シリアルID */
  private static final long serialVersionUID = 1L;
  /** 1ページの最大表示数(設定値) */
  private Integer maxPageSize;
  /** 1ページの最大表示数(デフォルト値) */
  private static final Integer DEFAULT_MAX_PAGE_SIZE = 10;
  /** ログ */
  Logger log = CDI.getLogger(Pager.class);

  /** 対象とするリスト */
  @SuppressWarnings("rawtypes")
  List list;

  /**
   * リストを設定する。<br/>
   * リストがNULLの場合、長さ0のリストで保持する。
   * 
   * @param list 対象とするリスト
   */
  @SuppressWarnings("rawtypes")
  public void setList(List list) {
    if (list != null) {
      this.list = list;
    } else {
      this.list = new ArrayList();
    }
  }

  /**
   * 初期化処理<br/>
   * 1ページあたりの最大表示件数の設定を行います。
   */
  @PostConstruct
  public void initialize() {
    try {
      InitialContext initialContext = new InitialContext();
      Context context = (Context) initialContext.lookup("java:comp/env");
      Object obj = context.lookup("max.page.size");
      if (obj instanceof Integer) {
        maxPageSize = (Integer) obj;
      } else {
        maxPageSize = obj != null ? Integer.parseInt(obj.toString()) : null;
      }
    } catch (NamingException e) {
      // 設定されていない場合
      maxPageSize = DEFAULT_MAX_PAGE_SIZE;
    } catch (NumberFormatException e) {
      // 指定が誤っている場合もデフォルト値を設定
      maxPageSize = DEFAULT_MAX_PAGE_SIZE;
    }
  }

  /** ページ番号 */
  private Integer pageNumber = 0;

  /**
   * @return ページ番号
   */
  public Integer getPageNumber() {
    return pageNumber;
  }

  /**
   * 表示対象の先頭行のインデックスを返却します。<br/>
   * リストが空の場合、-1を返却します。
   * 
   * @return ページ番号
   */
  public Integer getPageFirstIndex() {
    if (list.size() == 0)
      return -1;
    return pageNumber * maxPageSize; // インデックス
  }

  /**
   * 表示対象の最終行のインデックスを返却します。<br/>
   * リストが空の場合、-1を返却します。
   * 
   * @return ページ番号
   */
  public Integer getPageLastIndex() {
    if (isHasNext()) {
      return this.getPageFirstIndex() + maxPageSize - 1;
    } else {
      return list.size() - 1;
    }
  }

  /**
   * 対象のリストのサイズを返却します。<br/>
   * リストが空の場合、0を返却します。
   * 
   * @return 対象のリストのサイズ
   */
  public Integer getListSize() {
    return list.size();
  }

  /**
   * 1ページの最大表示数の設定<br/>
   * 個別設定しない場合は、システムのデフォルト値が設定されています。
   * 
   * @param maxPageSize 1ページの最大表示数
   */
  public void setMaxPageSize(Integer maxPageSize) {
    this.maxPageSize = maxPageSize;
  }

  /**
   * 次のページに移動します。
   */
  @CheckToken
  public void next() {
    ++pageNumber;
  }

  /**
   * 前のページに移動します。
   */
  @CheckToken
  public void previous() {
    --pageNumber;
  }

  /**
   * 最終ページに移動します。
   */
  @CheckToken
  public void last() {
    pageNumber = (list.size() - 1) / maxPageSize; // 切り捨て
  }

  /**
   * 先頭ページに移動します。
   */
  @CheckToken
  public void first() {
    pageNumber = 0;
  }

  /**
   * 次のページにデータが存在するか確認し、 存在する場合は、trueを返します。
   * 
   * @return boolean 次ページデータ有無
   */
  public boolean isHasNext() {
    return list.size() > this.getPageFirstIndex() + maxPageSize;
  }

  /**
   * 前のページにデータが存在するか確認し、 存在する場合は、trueを返します。
   * 
   * @return boolean 次ページデータ有無
   */
  public boolean isHasPrevious() {
    return pageNumber != 0 ? true : false;
  }

}
