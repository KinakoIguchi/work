package dcs.expart.booking.service;


import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.Path;


import dcs.fw.context.ExpartContext;

/**
 * ホテル操作サービス
 *
 * @author DCS tmikami
 * @version 1.0
 */
@Path("/hotelmst")
@Stateless
public class HotelMstService {

  /** */
  @Inject
  private ExpartContext context;


}
