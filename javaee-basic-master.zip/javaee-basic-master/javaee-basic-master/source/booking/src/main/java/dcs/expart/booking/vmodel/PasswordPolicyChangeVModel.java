package dcs.expart.booking.vmodel;

import java.io.Serializable;

import javax.enterprise.context.ConversationScoped;
import javax.inject.Named;

import dcs.fw.context.ViewModel;

/**
 * パスワードポリシー変更画面用のViewModel
 * 
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Named("passwordPolicyChangeVModel")
@ConversationScoped
@ViewModel
public class PasswordPolicyChangeVModel implements Serializable {

  /***/
  private static final long serialVersionUID = 1L;

}
