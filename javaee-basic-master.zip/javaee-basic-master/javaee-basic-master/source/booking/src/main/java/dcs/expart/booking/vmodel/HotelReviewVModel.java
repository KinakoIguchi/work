package dcs.expart.booking.vmodel;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.interceptor.Interceptors;

import dcs.expart.booking.entity.Hotel;
import dcs.expart.booking.entity.Review;
import dcs.expart.booking.interceptor.BookingUpdateInterceptor;
import dcs.expart.booking.service.ReviewService;
import dcs.fw.auth.Identity;
import dcs.fw.context.ExpartContext.MessageSeverity;
import dcs.fw.jpa.service.UpdateHistoryService;
import dcs.fw.context.ViewModel;
import dcs.fw.layer.GenericVModel;

/**
 * ホテルレビュー画面用のViewModel
 * 
 * @author DCS yohsato
 * @version 1.0
 */
@Named
@ConversationScoped
@ViewModel
public class HotelReviewVModel extends GenericVModel {

  /** シリアルID */
  private static final long serialVersionUID = 1L;

  /** ホテル */
  private Hotel hotel;

  /** レビュー */
  private Review review = new Review();

  /** レビューサービス */
  @Inject
  private ReviewService reviewService;

  /** 認証情報 */
  @Inject
  private Identity identity;

  /** 更新履歴サービス */
  @Inject
  private UpdateHistoryService updateHistoryService;

  /** 初期処理 */
  @PostConstruct
  public void init() {
    this.hotel = reviewService.findHotelIncludeReviews(context.getParameter("hotelCode"));
  }

  /**
   * 評価平均を取得します。 少数第一位まで表示します
   * 
   * @return 評価平均
   */
  public String culcAveragePoint() {
    double points = 0;
    for (Review review : hotel.getReviews()) {
      points += Double.parseDouble(review.getPoint());
    }
    return String.format("%.1f", (points / hotel.getReviews().size()));
  }

  /**
   * hotelを取得します。
   * 
   * @return hotel
   */
  public Hotel getHotel() {
    return hotel;
  }

  /**
   * hotelを設定します。
   * 
   * @param hotel hotel
   */
  public void setHotel(Hotel hotel) {
    this.hotel = hotel;
  }

  /**
   * @param review レビュー
   * @return リダイレクトパス
   */
  @Interceptors({BookingUpdateInterceptor.class})
  public String review(Review review) {
    review.setHotel(hotel);
    review.setUserName(identity.getUserName());
    review.setReviewDate(new Date());
    reviewService.registReview(review);

    /**
     * クラス名をキーに更新履歴テーブルを作成・更新する。 （更新対象テーブルと同一トランザクション内に配置）
     */
    updateHistoryService.insertUpdate(Review.class.getName());

    context.addMessage(MessageSeverity.INFO, null, "レビューの登録に成功しました。");
    context.endConversation();
    return "/book/hotelSearch";
  }

  /**
   * @return the review
   */
  public Review getReview() {
    return review;
  }

  /**
   * @param review the review to set
   */
  public void setReview(Review review) {
    this.review = review;
  }

}
