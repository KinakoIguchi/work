package dcs.expart.booking.mybatis.entity;

/**
 * ユーザテーブルのエンティティ
 *
 * @author DCS Kwon
 * @version 1.0
 */
public class MybatisSampleEntity extends MybatisSampleBaseEntity {

  /** 主キー */
  private Long id;

  /** 苗字 */
  private String firstName;

  /** 名前 */
  private String secondName;

  /** ユーザID */
  private String accountId;

  /** メールアドレス */
  private String email;

  /** パスワード */
  private String password;

  /** バージョン */
  private Integer rowVersion;

  /**
   * idを取得します。
   *
   * @return id
   */
  public Long getId() {
    return id;
  }

  /**
   * idを設定します。
   *
   * @param id id
   */
  void setId(Long id) {
    this.id = id;
  }

  /**
   * バージョンを取得します。
   *
   * @return バージョン
   */
  public Integer getRowVersion() {
    return rowVersion;
  }

  /**
   * バージョンを設定します。
   *
   * @param rowVersion バージョン
   */
  public void setRowVersion(Integer rowVersion) {
    this.rowVersion = rowVersion;
  }

  /**
   * ユーザIDを取得します。
   * 
   * @return ユーザID
   */
  public String getAccountId() {
    return accountId;
  }

  /**
   * ユーザIDを設定します。
   * 
   * @param accountId ユーザID
   */
  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  /**
   * メールアドレスを取得します。
   * 
   * @return メールアドレス
   */
  public String getEmail() {
    return email;
  }

  /**
   * メールアドレスを設定します。
   * 
   * @param email メールアドレス
   */
  public void setEmail(String email) {
    this.email = email;
  }

  /**
   * パスワードを取得します。
   * 
   * @return パスワード
   */
  public String getPassword() {
    return password;
  }

  /**
   * パスワードを設定します。
   * 
   * @param password パスワード
   */
  public void setPassword(String password) {
    this.password = password;
  }

  /**
   * 苗字を取得します。
   *
   * @return 苗字
   */
  public String getFirstName() {
    return firstName;
  }

  /**
   * 苗字を設定します。
   *
   * @param firstName 苗字
   */
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  /**
   * 名前を取得します。
   *
   * @return 名前
   */
  public String getSecondName() {
    return secondName;
  }

  /**
   * 名前を設定します。
   *
   * @param secondName 名前
   */
  public void setSecondName(String secondName) {
    this.secondName = secondName;
  }
}
