package dcs.expart.booking.auth;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.enterprise.inject.Alternative;
import javax.inject.Named;
import dcs.fw.auth.Identity;

/**
 * 認証アカウントを管理するクラス
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Named("identity")
@SessionScoped
@Alternative
public class BookingIdentity extends Identity implements Serializable {

  /** シリアルID */
  private static final long serialVersionUID = 1L;
}
