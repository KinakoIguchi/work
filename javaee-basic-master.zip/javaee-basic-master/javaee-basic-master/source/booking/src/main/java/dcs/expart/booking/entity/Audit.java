package dcs.expart.booking.entity;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import dcs.fw.jpa.entity.SurrogateKeyEntity;

/**
 * ログテーブルのエンティティ
 *
 * @author DCS.kfukuda
 * @version 1.0
 */
@Entity
public class Audit extends SurrogateKeyEntity {

  /** シリアルID */
  private static final long serialVersionUID = 1L;

  /** ログカテゴリ */
  @Enumerated(EnumType.STRING)
  private LogCategory logCategory;

  /** ログ */
  private String logMessage;

  /**
   * デフォルトコンストラクタ
   */
  public Audit() {}

  /**
   * @param logCategory ログカテゴリ
   * @param logMessage ログメッセージ
   */
  public Audit(LogCategory logCategory, String logMessage) {
    super();
    this.logCategory = logCategory;
    this.logMessage = logMessage;
  }

  /**
   * @return logCategory
   */
  public LogCategory getLogCategory() {
    return logCategory;
  }

  /**
   * @param logCategory セットする logCategory
   */
  public void setLogCategory(LogCategory logCategory) {
    this.logCategory = logCategory;
  }

  /**
   * @return logMessage
   */
  public String getLogMessage() {
    return logMessage;
  }

  /**
   * @param logMessage セットする logMessage
   */
  public void setLogMessage(String logMessage) {
    this.logMessage = logMessage;
  }
}
