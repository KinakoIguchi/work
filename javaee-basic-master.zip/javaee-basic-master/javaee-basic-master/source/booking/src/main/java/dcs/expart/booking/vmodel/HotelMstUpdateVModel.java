package dcs.expart.booking.vmodel;


import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.inject.Named;

import dcs.expart.booking.entity.Hotel;
import dcs.expart.booking.service.HotelMstService;
import dcs.fw.context.ViewModel;
import dcs.fw.layer.GenericVModel;

/**
 * ホテル更新画面用のViewModel
 *
 * @author DCS tmikami
 * @version 1.0
 */
@Named
@ConversationScoped
@ViewModel
public class HotelMstUpdateVModel extends GenericVModel {

  /** */
  private static final long serialVersionUID = 1L;

  /** */
  private Hotel hotel;

  /** */
  @Inject
  private HotelMstService hotelMstService;

  /**
   * hotelを取得します。
   *
   * @return hotel
   */
  public Hotel getHotel() {
    return hotel;
  }

  /**
   * hotelを設定します。
   *
   * @param hotel hotel
   */
  public void setHotel(Hotel hotel) {
    this.hotel = hotel;
  }

}
