package dcs.expart.booking.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * JAX-RSを有効化にするだけのクラス.<br/>
 * /context-root/rest/*はJAX-RS用のアドレスですと宣言しているだけです。<br/>
 * Restへのアクセスは頭に/restをつける必要があります。
 * 
 * @author DCS tmatsuoka
 * @version 1.0
 */
@ApplicationPath("/rest")
public class JaxRsActivator extends Application {
}
