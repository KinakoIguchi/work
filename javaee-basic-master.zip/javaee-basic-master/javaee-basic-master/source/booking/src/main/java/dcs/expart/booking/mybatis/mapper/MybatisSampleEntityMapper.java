package dcs.expart.booking.mybatis.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.UpdateProvider;

import dcs.expart.booking.mybatis.entity.MybatisSampleEntity;
import dcs.expart.booking.mybatis.utils.SQLBuilder;

/**
 * データベースを操作するためのインターフェース<br/>
 *
 * @author DCS Kwon
 * @version 1.0
 */
public interface MybatisSampleEntityMapper {

  /**
   * ユーザテーブルの全件を取得する
   * 
   * @param sqlId 実行するSQL文のID
   * @return ユーザデータリスト
   */
  @SelectProvider(type = SQLBuilder.class, method = "getSql")
  List<MybatisSampleEntity> selectAll(@Param("sqlId") String sqlId);

  /**
   * ユーザテーブルで指定したユーザIDのデータを取得する
   * 
   * @param sqlId 実行するSQL文のID
   * @param accountId ユーザID
   * @return ユーザデータ
   */
  @SelectProvider(type = SQLBuilder.class, method = "getSql")
  @ResultMap("mybatisSampleResultMap")
  MybatisSampleEntity select(@Param("sqlId") String sqlId, @Param("accountId") String accountId);

  /**
   * ユーザテーブルで指定したユーザIDのデータを取得する<br>
   * (実行するSQL文をmapper.xmlに定義)
   * 
   * @param accountId ユーザID
   * @return ユーザデータ
   */
  MybatisSampleEntity selectWithMapperXML(String accountId);

  /**
   * ユーザテーブルへデータを登録する
   * 
   * @param sqlId 実行するSQL文のID
   * @param firstName 苗字
   * @param secondName 名前
   * @param email メールアドレス
   * @param password パスワード
   * @param accountId ユーザID
   * @param rowVersion ROWバージョン
   * @param insertDate 登録日時
   * @param insertUser 登録者名
   * @return 処理件数
   */
  @InsertProvider(type = SQLBuilder.class, method = "getModifiedSql")
  @SelectKey(statement = "select COALESCE(max(id) + 1, 1) from account", keyProperty = "id",
      before = true, resultType = long.class)
  int insertWithParams(@Param("sqlId") String sqlId, @Param("firstName") String firstName,
      @Param("secondName") String secondName, @Param("email") String email,
      @Param("password") String password, @Param("accountId") String accountId,
      @Param("rowVersion") int rowVersion, @Param("insertDate") Date insertDate,
      @Param("insertUser") String insertUser);

  /**
   * ユーザテーブルへデータを登録する
   * 
   * @param mse サンプルエンティティ
   * @return 処理件数
   */
  @Insert("insert into Account (insertDate, insertUser, rowVersion, accountId, email, password, firstName, secondName, id) values (CURRENT_TIMESTAMP(), #{insertUser}, #{rowVersion}, #{accountId}, #{email}, #{password}, #{firstName}, #{secondName}, #{id})")
  @SelectKey(statement = "select COALESCE(max(id) + 1, 1) from account", keyProperty = "id",
      before = true, resultType = long.class)
  int insert(MybatisSampleEntity mse);

  /**
   * ユーザテーブルへデータを登録する<br>
   * (実行するSQL文をmapper.xmlに定義)
   * 
   * @param mse サンプルエンティティ
   * 
   * @return 処理件数
   */
  int insertWithMapperXML(MybatisSampleEntity mse);

  /**
   * ユーザテーブルを更新する
   * 
   * @param sqlId 実行するSQL文のID
   * @param accountId ユーザID
   * @param firstName 苗字
   * @param secondName 名前
   * @param password パスワード
   * @param email メールアドレス
   * @param rowVersion ROWバージョン
   * @param updateUser 更新者名
   * @param updateDate 更新日時
   * @return 処理件数
   */
  @UpdateProvider(type = SQLBuilder.class, method = "getSql")
  int update(@Param("sqlId") String sqlId, @Param("accountId") String accountId,
      @Param("firstName") String firstName, @Param("secondName") String secondName,
      @Param("password") String password, @Param("email") String email,
      @Param("rowVersion") Integer rowVersion, @Param("updateUser") String updateUser,
      @Param("updateDate") Date updateDate);

  /**
   * ユーザテーブルを更新する<br>
   * (実行するSQL文をmapper.xmlに定義)
   * 
   * @param mse サンプルエンティティ
   * 
   * @return 処理件数
   */
  int updateWithMapperXML(MybatisSampleEntity mse);

  /**
   * ユーザテーブルで指定したユーザIDデータを削除する
   * 
   * @param sqlId 実行するSQL文のID
   * @param accountId ユーザID
   * @return 処理件数
   */
  @DeleteProvider(type = SQLBuilder.class, method = "getSql")
  int delete(@Param("sqlId") String sqlId, @Param("accountId") String accountId);

  /**
   * ユーザテーブルで指定したユーザIDデータを削除する<br>
   * (実行するSQL文をmapper.xmlに定義)
   * 
   * @param accountId ユーザID
   * 
   * @return 処理件数
   */
  int deleteWithMapperXML(String accountId);
}

