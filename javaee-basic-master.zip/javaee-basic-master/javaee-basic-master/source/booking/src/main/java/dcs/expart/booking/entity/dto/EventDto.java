package dcs.expart.booking.entity.dto;

/**
 * Holidayオブジェクトの@SqlResultSetMapping対応用ＤＴＯオブジェクト
 * 
 * @author DCS.黄
 * @version 1.0
 */
public class EventDto {
  /** イベント */
  private String event;

  /** 日付 */
  private Integer date;

  /** 登録者名 */
  private String insertuser;

  /** バージョン */
  private Integer rowversion;

  /**
   * マッピング用コンストラクタ構成
   * 
   * @param insertuser 登録者名
   * @param rowversion バージョン
   * @param event イベント
   */
  public EventDto(String insertuser, Integer rowversion, String event) {
    this.insertuser = insertuser;
    this.rowversion = rowversion;
    this.event = event;
  }

  /**
   * イベント を取得します。
   *
   * @return イベント
   */
  public String getEvent() {
    return event;
  }

  /**
   * イベントを設定します。
   * 
   * @param event イベント
   */
  public void setEvent(String event) {
    this.event = event;
  }

  /**
   * 日付を取得します。
   *
   * @return 日付
   */
  public Integer getDate() {
    return date;
  }

  /**
   * 日付を設定します。
   *
   * @param date 日付
   */
  public void setDate(Integer date) {
    this.date = date;
  }

  /**
   * 登録者名を取得します。
   *
   * @return 登録者名
   */
  public String getInsertuser() {
    return insertuser;
  }

  /**
   * 登録者名を設定します。
   *
   * @param insertuser 登録者名
   */
  public void setInsertuser(String insertuser) {
    this.insertuser = insertuser;
  }

  /**
   * バージョンを取得します。
   *
   * @return バージョン
   */
  public Integer getRowversion() {
    return rowversion;
  }

  /**
   * バージョンを設定します。
   *
   * @param rowversion バージョン
   */
  public void setRowversion(Integer rowversion) {
    this.rowversion = rowversion;
  }

}
