package dcs.expart.booking.mybatis.utils;

import java.util.Map;
import java.util.ResourceBundle;

import dcs.fw.util.PropertiesLoader;

/**
 * 外部propertiesファイルからSQL文を取得するクラス。
 * 
 * @author DCS Kwon
 * @version 1.0
 */
public class SQLBuilder {

  /** mybatis-sqlプロパティファイルのリソースバンドル (resource/mybatis-sql.properties) */
  private static final ResourceBundle RESOURCE_BUNDLE = PropertiesLoader.getBundle("mybatis-sql");

  /**
   * プロパーティファイルからSQL文を取得する
   * 
   * @param parameters パラメータ
   * @return SQL文
   */
  public String getSql(Map<String, Object> parameters) {
    String sqlId = (String) parameters.get("sqlId");
    String sql = RESOURCE_BUNDLE.getString(sqlId);
    return sql;
  }

  /**
   * プロパーティファイルからSQL文を取得してパラメータ値を埋め込む
   * 
   * @param parameters パラメータ
   * @return SQL文
   */
  public String getModifiedSql(Map<String, Object> parameters) {
    String sqlId = (String) parameters.get("sqlId");
    String sql = RESOURCE_BUNDLE.getString(sqlId);
    for (String key : parameters.keySet()) {
      sql = sql.replace("#{" + key + "}", "'" + parameters.get(key) + "'");
    }
    return sql;
  }
}
