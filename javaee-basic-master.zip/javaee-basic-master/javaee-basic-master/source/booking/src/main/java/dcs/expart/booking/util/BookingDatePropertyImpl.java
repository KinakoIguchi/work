package dcs.expart.booking.util;

import java.util.Calendar;
import java.util.Date;
import javax.persistence.EntityManager;
import dcs.fw.util.DateProperty;
import dcs.fw.util.DayType;

/**
 * Bookingアプリ独自のDateProperty<br/>
 * 開発時にはサーバ起動時は常にDBが空なので<br/>
 * HOLIDAYSフィールドは固定で設定。<br/>
 * 実際の開発時にはDBから祝日情報を取得しセット<br/>
 * することも可能。
 * 
 * @author DCS tmatsuoka
 * @version 1.0
 */
public class BookingDatePropertyImpl implements DateProperty {

  /** 日付書式 "yyyy/MM/dd" */
  public static final String DATE_PATTERN = "yyyy/MM/dd";

  /** 休日として扱う曜日 */
  public static final DayType[] DAY_OFF_TYPE = {DayType.SATURDAY, DayType.SUNDAY};

  /**
   * 祝日として扱う曜日 ex){20140211, 20140113}
   */
  public static Integer[] holydays = {};

  /**
   * 初期化時にHOLIDAYSフィールドをセット
   * 
   * @param entityManager エンティティマネージャ
   */
  public BookingDatePropertyImpl(EntityManager entityManager) {
    // DBに祝日情報が格納されている場合はここでアクセスして取得しセットする
    // @SuppressWarnings("unchecked")
    // List<Integer> list = ((List<Integer>)entityManager.createQuery("select h.date from Holiday
    // h").getResultList());
    // HOLIDAYS = list.toArray(new Integer[0]);
    holydays = new Integer[] {20140101, 20140202, 20140303};
  }

  @Override
  public String getDatePattern() {
    return DATE_PATTERN;
  }

  @Override
  public DayType[] getDayOffType() {
    return DAY_OFF_TYPE;
  }

  @Override
  public Integer[] getHolidays() {
    return holydays;
  }

  @Override
  public Date getDate() {
    return new Date();
  }

  @Override
  public Date getMaxDate() {
    Calendar cal = Calendar.getInstance();
    cal.set(9999, 12, 31);
    return cal.getTime();
  }
}
