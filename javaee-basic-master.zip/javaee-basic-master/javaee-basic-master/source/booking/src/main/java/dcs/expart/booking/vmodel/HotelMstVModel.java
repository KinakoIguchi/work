package dcs.expart.booking.vmodel;

import java.io.Serializable;
import java.util.List;


import javax.annotation.PostConstruct;
import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.inject.Named;

import dcs.expart.booking.entity.Hotel;
import dcs.expart.booking.service.HotelService;
import dcs.fw.context.ViewModel;
import dcs.fw.layer.GenericVModel;

/**
 * ホテルマスタメンテナンス用のViewModel
 *
 * @author DCS tmatsuoka
 * @version 1.0
 */
@Named("hotelMstVModel")
@ConversationScoped
@ViewModel
public class HotelMstVModel extends GenericVModel implements Serializable {

  /** */
  private static final long serialVersionUID = 1L;

  /** ホテル一覧 */
  private List<Hotel> allHotels;

  /** サービス */
  @Inject
  private HotelService hotelService;

  /** 初期化 */
  @PostConstruct
  private void init() {
    allHotels = hotelService.getAllHotels();
  }

  /**
   * ホテル一覧を取得します。
   * 
   * @return ホテル一覧
   */
  public List<Hotel> getAllHotels() {
    return allHotels;
  }

  /**
   * ホテル一覧をセットします。
   * 
   * @param allHotels ホテル一覧
   */
  public void setAllHotels(List<Hotel> allHotels) {
    this.allHotels = allHotels;
  }

}
