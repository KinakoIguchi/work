package dcs.expart.booking.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.validation.constraints.NotNull;

import dcs.fw.jpa.entity.SurrogateKeyEntity;

/**
 * オンラインバッチ処理結果を管理するためのテーブル
 * 
 * @author DCS 高坂
 * @version 1.0
 */
@Entity
public class BatchStatus extends SurrogateKeyEntity implements Serializable {

  /** シリアルID */
  private static final long serialVersionUID = 1L;

  /** バッチID */
  @NotNull
  private String batchId;

  /** バッチ引数 */
  @Column(length = 4096)
  private String batchArgs;

  /** バッチ起動要求サーバ */
  @NotNull
  @Column(length = 256)
  private String requestHostname;

  /** バッチ起動ユーザ */
  @NotNull
  @Column(length = 256)
  private String requestUserId;

  /** 起動日時 */
  @NotNull
  private Date startDate;

  /** 終了日時 */
  private Date endDate;

  /** バッチ実行サーバ */
  @Column(length = 256)
  private String execHostname;

  /** 処理結果 */
  private Integer exitCode;

  /** メッセージ */
  @Column(columnDefinition = "TEXT")
  private String messages;

  /**
   * バッチIDを取得する。
   * 
   * @return バッチID
   */
  public String getBatchId() {
    return batchId;
  }

  /**
   * バッチIDを設定する。
   * 
   * @param batchId バッチID
   */
  public void setBatchId(String batchId) {
    this.batchId = batchId;
  }

  /**
   * @return the batchArgs
   */
  public String getBatchArgs() {
    return batchArgs;
  }

  /**
   * @param batchArgs the batchArgs to set
   */
  public void setBatchArgs(String batchArgs) {
    this.batchArgs = batchArgs;
  }

  /**
   * 要求ホスト名を取得する。
   * 
   * @return 要求ホスト名
   */
  public String getRequestHostname() {
    return requestHostname;
  }

  /**
   * 要求ホスト名を設定する。
   * 
   * @param requestHostname 要求ホスト名
   */
  public void setRequestHostname(String requestHostname) {
    this.requestHostname = requestHostname;
  }

  /**
   * 要求ユーザIDを取得する。
   * 
   * @return 要求ユーザID
   */
  public String getRequestUserId() {
    return requestUserId;
  }

  /**
   * 要求ユーザIDを設定する。
   * 
   * @param requestUserId 要求ユーザID
   */
  public void setRequestUserId(String requestUserId) {
    this.requestUserId = requestUserId;
  }

  /**
   * 開始日時を取得する。
   * 
   * @return 開始日時
   */
  public Date getStartDate() {
    return startDate;
  }

  /**
   * 開始日時を設定する。
   * 
   * @param startDate 開始日時
   */
  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  /**
   * 終了日時を設定する。
   * 
   * @return 終了日時
   */
  public Date getEndDate() {
    return endDate;
  }

  /**
   * 終了日時を設定する。
   * 
   * @param endDate 終了日時
   */
  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }

  /**
   * 実行ホスト名を取得する。
   * 
   * @return 実行ホスト名
   */
  public String getExecHostname() {
    return execHostname;
  }

  /**
   * 実行ホスト名を設定する。
   * 
   * @param execHostname 実行ホスト名
   */
  public void setExecHostname(String execHostname) {
    this.execHostname = execHostname;
  }

  /**
   * 終了コードを取得する。
   * 
   * @return 終了コード
   */
  public Integer getExitCode() {
    return exitCode;
  }

  /**
   * 終了コードを設定する。
   * 
   * @param exitCode 終了コード
   */
  public void setExitCode(Integer exitCode) {
    this.exitCode = exitCode;
  }

  /**
   * メッセージを取得します。
   * 
   * @return メッセージ
   */
  public String getMessages() {
    return messages;
  }

  /**
   * メッセージを設定します。
   * 
   * @param messages メッセージ
   */
  public void setMessages(String messages) {
    this.messages = messages;
  }

}
