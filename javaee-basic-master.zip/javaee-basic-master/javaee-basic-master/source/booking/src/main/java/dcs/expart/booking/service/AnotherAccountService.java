package dcs.expart.booking.service;

import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import dcs.expart.booking.entity.Account;

/**
 * 
 * <pre>
 * 追加したDatasourceの稼働確認をするためのサービスクラス
 *　画面にアカウント情報を出力する。
 * </pre>
 * 
 * @author DCS asugiyama
 * @version 1.0
 */
@Path("/anotherAccount")
@RequestScoped
public class AnotherAccountService implements Serializable {

  /** シリアルバージョンUID */
  private static final long serialVersionUID = 1L;

  /**
   * 追加データソース検証用のエンティティマネージャーファクトリ 追加したデータソースの検証時は、defaultをpersistence.xmlで定義したユニット名に変更すること
   */
  @PersistenceUnit(unitName = "default")
  private EntityManagerFactory emf;

  /**
   * ユーザ一覧を取得するメソッド
   * 
   * @return ユーザ一覧
   */
  @GET
  @Produces("application/json; charset=UTF-8")
  @Path("/allAccounts")
  public List<Account> getAllAccounts() {
    CriteriaBuilder cb = emf.createEntityManager().getCriteriaBuilder();
    CriteriaQuery<Account> cq = cb.createQuery(Account.class);
    Root<Account> r = cq.from(Account.class);
    cq.select(r).orderBy(cb.asc(r.get("accountId")));

    return emf.createEntityManager().createQuery(cq).getResultList();
  }
}
