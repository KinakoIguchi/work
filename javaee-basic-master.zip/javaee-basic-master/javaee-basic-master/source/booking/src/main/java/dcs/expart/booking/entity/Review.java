package dcs.expart.booking.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import dcs.fw.jpa.entity.SurrogateKeyEntity;

/**
 * レビューテーブルのエンティティ
 * 
 * @author DCS yohsato
 * @version 1.0
 */
@Entity
@Table
public class Review extends SurrogateKeyEntity implements Serializable {

  /** シリアルID */
  private static final long serialVersionUID = 1L;

  /** ユーザ名 */
  private String userName;

  /** ホテル */
  @ManyToOne
  private Hotel hotel;

  /** 評価 */
  @NotNull
  private String point;

  /** コメント */
  @NotNull
  @Size(min = 1, max = 200)
  private String comment;

  /** 投稿日付 */
  @NotNull
  private Date reviewDate;

  /**
   * @return the reviewDate
   */
  public Date getReviewDate() {
    return reviewDate;
  }

  /**
   * @param reviewDate the reviewDate to set
   */
  public void setReviewDate(Date reviewDate) {
    this.reviewDate = reviewDate;
  }

  /**
   * ユーザ名を取得します。
   * 
   * @return ユーザ名
   */
  public String getUserName() {
    return userName;
  }

  /**
   * ユーザ名を設定します。
   * 
   * @param userName ユーザ名
   */
  public void setUserName(String userName) {
    this.userName = userName;
  }

  /**
   * ホテルを取得します。
   * 
   * @return ホテル
   */
  public Hotel getHotel() {
    return hotel;
  }

  /**
   * ホテルを設定します。
   * 
   * @param hotel ホテル
   */
  public void setHotel(Hotel hotel) {
    this.hotel = hotel;
  }

  /**
   * 評価を取得します。
   * 
   * @return 評価
   */
  public String getPoint() {
    return point;
  }

  /**
   * 評価を設定します。
   * 
   * @param point 評価
   */
  public void setPoint(String point) {
    this.point = point;
  }

  /**
   * コメントを取得します。
   * 
   * @return コメント
   */
  public String getComment() {
    return comment;
  }

  /**
   * コメントを設定します。
   * 
   * @param comment コメント
   */
  public void setComment(String comment) {
    this.comment = comment;
  }

}
