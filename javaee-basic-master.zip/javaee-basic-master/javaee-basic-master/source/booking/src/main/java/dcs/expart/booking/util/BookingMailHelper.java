package dcs.expart.booking.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Bookingアプリからメールを送信する際のパラメータ設定を補助するためのクラス
 * 
 * @author DCS tmatsuoka
 * @version 1.0
 */
public final class BookingMailHelper {

  /** コンストラクタ */
  private BookingMailHelper() {}

  /** タイムアウト値（ミリ秒） */
  public static final String PROP_TIMEOUT = "mail.smtp.timeout";
  /** 認証要否 */
  public static final String PROP_AUTH = "mail.smtp.auth";
  /** ユーザ名 */
  public static final String PROP_USER = "mail.smtp.user";
  /** パスワード */
  public static final String PROP_PASSWORD = "mail.smtp.password";
  /** デバッグ */
  public static final String PROP_DEBUG = "mail.debug";
  /** STARTTLSの有効/無効 */
  public static final String PROP_STARTTLS = "mail.smtp.starttls.enable";

  /**
   * デフォルトのパラメータを取得するためのメソッド アプリケーションが利用するSMTPサーバの仕様にあわせカスタマイズを行う
   * 
   * @return デフォルトのパラメータ
   */
  public static Map<String, String> getDefaultMailParams() {
    Map<String, String> params = new HashMap<String, String>();
    params.put(PROP_TIMEOUT, "30000");
    params.put(PROP_DEBUG, "true");
    return params;
  }

}
