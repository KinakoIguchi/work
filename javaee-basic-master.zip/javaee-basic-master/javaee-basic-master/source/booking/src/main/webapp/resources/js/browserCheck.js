//------------------------------------------------------------------------------
//! 対応ブラウザチェック
//!
//! @param	コンテキストパス
//! @return   無し
//------------------------------------------------------------------------------
function browsediscrimination(contextpath){

	var userAgent = window.navigator.userAgent;
	var setdata=Object;
	var bflag=false;
	var alertMessage = "非推奨ブラウザのため、正常に動作しない可能性があります。推奨ブラウザの使用を推奨します。";

//	jsondataを同期で取得
	$.ajax({
		type: "GET",
		url: contextpath+"/resources/json/browserCheck.json",
		async: false,
		dataType: "json",
		mimeType: "application/json",
		success: function(data){
			setdata = eval(data);
		}
	});

//useragentから必要事項のみを抽出
	var ua = getbrowserproperty(userAgent);
	for(var i in setdata){

		if (ua[0] == setdata[i].browser) {

			for(var j in setdata[i].version){
				// alert(setdata[i].version.length);
				var ver = setdata[i].version[j];
				if(ver == "*"){
					//バージョンの指定が*(アスタリスク)の場合は無条件でtrueを返す
					bflag=true;
					break;
				}else{
					//JSONのバージョン指定から先頭一致
					var uareg = new RegExp("^" + ver); // "^*"の場合はブラウザによって例外発生
					if(ua[1].match(uareg)){
						bflag=true;
						break;
					};
				}
			}
		}
	}

	//	flagによってアラートを表示
	if(bflag==false){
		alert(alertMessage);
	}

	//------------------------------------------------------------------------------
	//!クロージャ
	//! ブラウザバージョン取得
	//! @param[in]    browsername
	//! @return   useragentのブラウザ
	//------------------------------------------------------------------------------
	function getbrowserproperty(useragent){
		thisAgent = useragent + ";";
		thisAgent = thisAgent.replace( / /g, ";" );
		var Ver=new Array();

		// Mozilla/5.0 (Windows NT 6.0; rv:19.0) Gecko/20100101 Firefox/19.0
		if ( Searchtxt( "Firefox" ) ) Ver = ["firefox" , getver( "Firefox/" )];

		// Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.99 Safari/537.22
		else if ( Searchtxt( "Chrome" ) ) Ver = ["chrome" , getver( "Chrome/" )];

		// Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_3) AppleWebKit/536.28.10 (KHTML, like Gecko) Version/6.0.3 Safari/536.28.10
		else if ( Searchtxt( "Safari" ) && Searchtxt( "Version" ) ) Ver = ["safari", getver( "Version/" )];

		// Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0; Touch; MAFSJS)
		else if ( Searchtxt( "MSIE;" ) ) Ver = ["ie" , getver( "MSIE;" )];

		//Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko
		else if ( Searchtxt( "Trident/7.0" ) ) Ver = ["ie" , getver( "rv:" )];

		else Ver = navigator.appName;
		return Ver;

		//------------------------------------------------------------------------------
		//!クロージャ
		//! ブラウザバージョン取得
		//! @param[in]    browsername
		//! @return   バージョンを返す(string)
		//------------------------------------------------------------------------------
		function getver(browsername){
			var start = thisAgent.indexOf( browsername ) + browsername.length;
			var end = thisAgent.indexOf( ";", start );
			return thisAgent.substring ( start, end );
		};

		//------------------------------------------------------------------------------
		//!クロージャ
		//! 文字列一致
		//! @param[in]    key
		//! @return   true/false
		//------------------------------------------------------------------------------

		function Searchtxt( key ){
			return (thisAgent.indexOf( key )>=0) ? true : false;
		};
	};
}