# 環境構築(簡易版)

## Eclipseのダウンロード

1. 以下のURLからEclipseをダウンロードします。ファイルサイズが大きいため、時間のあるときにダウンロードすることを推奨します。  
<https://mridcs.sharepoint.com/:u:/s/msteams_1ba558/EVon9-ctrOtMjAD1W351QmgBPFTEhXQe8zbNTPFMa4U1Fw?e=iS2hHW>

## zipファイルの解凍と配置

1. ダウンロードしたzipファイルを解凍します。解凍の際は、以下のスクリーンショットのように直接Cドライブ直下に解凍してください(デスクトップに解凍してからCドライブに移動などはNG)。  
    <img src="./image/installation_simple/decompress.png" width="750px">
1. Cドライブ直下にeclipse_DcsFrameworkフォルダが作成されていることを確認します。

## Eclipseの初回起動

1. eclipse_DcsFrameworkフォルダ直下のeclipse.exe -clean.cmdを実行し、Eclipseを起動します。
1. Eclipseの起動時、ワークスペースをどこにするか確認された場合は、eclipse_DcsFrameworkフォルダ直下のworkspaceフォルダを選択します。

## Mavenのsetting.xmlの更新

1. <http://gitlab.in.dcs.co.jp/dcs-framework/framework/blob/master/tools/maven/settings.xml>にWEBブラウザでアクセスし、Editボタンの左側のボタン(Open raw)を右クリック→名前をつけてリンク先を保存で「settings.xml」をダウンロードします。
2. `C:\Users\(ログオンユーザ名)\.m2`フォルダを開き(.m2フォルダは隠しフォルダになっている場合あり。.m2フォルダがなければ作成)、そこにsettings.xmlを配置します。  
settings.xmlがすでに存在する場合は、もともと存在したsettings.xmlをコピーして別名保存した上で、ダウンロードしたsettings.xmlで上書きしてください。

## Eclipseの再起動

1. Eclipseをいったん終了し、再度eclipse_DcsFrameworkフォルダ直下のeclipse.exe -clean.cmdを実行し、Eclipseを起動してください。  
これ以降、Eclipseを起動する場合はeclipse_DcsFrameworkフォルダ直下のEclipse.exeを実行します。

## プロジェクトのインポート

1. 以下URLの手順を参照してプロジェクトをインポートしてください。**「プロジェクトのインポート」のセクションのみを実施します。**  
手順の中で「booking」フォルダを指定する箇所がありますが、こちらはC:\eclipse_DcsFramework\workspace\bookingを指定します(viewもbookingと同様にインポートしてください)。インポート後のプロジェクト名は「booking」、「view」となって手順と異なりますが、ハンズオン実施自体に影響はありません。  
[環境構築(基本編)#プロジェクトのインポート](installation_basic.md#プロジェクトのインポート)

## プロジェクトのMavenビルド

1. Eclipse上でbookingプロジェクトを右クリックし、Maven→プロジェクトの更新をクリックします。
    <img src="./image/installation_simple/update_project.png" width="750px">
1. bookingとviewにチェックを入れ、画面下部のスナップショット/リリースの更新を強制にチェックを入れてOKボタンをクリックします。
    <img src="./image/installation_simple/update_maven_project.png" width="750px">
1. 更新が完了するまで、数分かかります。更新状況は、Eclipseの画面下部に表示されます。  
更新が完了したら、プロジェクトのアイコン上から赤い×マークが消えたことを確認します。消えなかった場合は、上記のプロジェクト更新を何度か試してみてください。

## JBossの設定と初回起動

1. 以下URLの手順に沿って実施してください。「JBossの設定」と「ログイン画面アクセス・ログイン」のセクションを実施します。なお、`C:\eclipse_DcsFramework\jboss-eap-7.1`は解凍したeclipse_DcsFrameworkの直下に同梱しているので、**zipを解凍・配置する手順は無視してください。**  
[環境構築(基本編)#稼働確認](installation_basic.md#稼働確認)

2. この手順が終わった段階でサンプルアプリのURL<http://localhost:8080/booking>にブラウザからアクセスできれば、ハンズオンの実施が可能です。

## 自動ビルド設定の確認

1. Eclipseの画面上部のメニューバーからプロジェクトをクリックし、表示されるメニューの「自動的にビルド」にチェックが入っていることを確認してください(入っていない場合はクリック)。  
    <img src="./image/installation_simple/autobuild.png" width="750px">  
**演習中に変更したプログラムがアプリケーションに反映されない場合、上記「自動的にビルド」にチェックが入っているかどうかを確認してください。** 同様に、サーバの再起動を実施し忘れていないかも確認してください。

## ハンズオンサイト

以上で環境構築が完了しました。続いて、以下のハンズオンサイトにて学習を開始してください。  
<http://172.31.93.59/javaee-basic-hands-on/>
