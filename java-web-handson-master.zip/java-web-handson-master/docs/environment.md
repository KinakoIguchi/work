# 開発環境の構築

## Eclipseのインストール

### インストーラのダウンロードとインストール

1. [Pleiades All in One ダウンロード](https://mergedoc.osdn.jp/)にアクセスし、Eclipseをダウンロードします。ここでは、「Eclipse 4.5 Mars」を使用します。<br clear="all" />
![Eclipseのダウンロード](../img/environment/eclipse-download1.png)
2. ダウンロードしたファイル「pleiades-java-4.5.2-sfx.exe」を右クリックし、「管理者として実行」を選択します。下記画面が表示されたら「はい」を選択します。<br clear="all" />
![Eclipseのダウンロード](../img/environment/eclipse-download2.png)
3. 下記画面が表示されたら、解凍先はデフォルト設定のまま「C:\pleiades」と指定して、「解凍」を選択します。<br clear="all" />
![Eclipseのダウンロード](../img/environment/eclipse-download3.png)
4. 以下の画面が表示されるので、解凍が終るまでしばらくお待ちください。<br clear="all" />
![Eclipseのダウンロード](../img/environment/eclipse-download4.png)
5. 解凍が完了したら、Cドライブ直下にpleiadesフォルダが作成されたことを確認してください。<br clear="all" />
![Eclipseのダウンロード](../img/environment/eclipse-download5.png)



### Eclipseを起動する

1. 「eclipse.exe」を実行します。
	- C:\pleiades\eclipse\eclipse.exe
2. 以下が表示されます。しばらくお待ちください。<br clear="all" />
![Eclipseのダウンロード](../img/environment/eclipse-download6.png)
3. 下記画面が表示されます。ワークスペースはデフォルトのまま「../workspace」と指定します。
＊ワークスペースとは、作成したソースファイル等が置かれる場所のことです。<br clear="all" />
![Eclipseのダウンロード](../img/environment/eclipse-download7.png)
4. 下記画面が表示されることを確認します。<br clear="all" />
![Eclipseのダウンロード](../img/environment/eclipse-download8.png)



### Eclipseを設定する：行番号の表示

1. Eclipse画面上部にあるメニューバーの「ウィンドウ」⇒「設定」を押下して設定画面を表示します。

2. 「一般」⇒「エディター」⇒「テキストエディター」を選択します。右側の設定項目「行番号の表示」にチェックがついていることを確認して「OK」ボタンを選択してください。<br clear="all" />
![Eclipseのダウンロード](../img/environment/eclipse-download9.png)



### Eclipseを設定する：ファイルエンコードの設定

1. Eclipse画面上部にあるメニューバーの「ウィンドウ」⇒「設定」を押下して設定画面を表示します。

2. 「一般」⇒「ワークスペース」を選択します。右側の設定項目「テキスト・ファイルのエンコード」のラジオボタンで「その他」、プルダウンで「UTF-8」が選択されていることを確認して「OK」ボタンを選択してください。<br clear="all" />
![Eclipseのダウンロード](../img/environment/eclipse-download10.png)



### その他：ショートカットの作成

- 「C:\pleiades\eclipse」フォルダ内の「eclipse.exe」を右クリックして「送る」⇒「デスクトップ(ショートカットを作成)」を選択します。デスクトップにショートカットが作成されていることを確認してください。<br clear="all" />
![Eclipseのダウンロード](../img/environment/eclipse-download12.png)

