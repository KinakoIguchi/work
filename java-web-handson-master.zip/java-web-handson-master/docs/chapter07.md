# 第7章 リクエストスコープ

## リクエストスコープを使ったプログラムを作成する

スコープは、インスタンス（オブジェクト）を保存する領域のことです。スコープにより、サーブレットとJSP間で任意のインスタンスを共有・受け渡しすることができます。このうち、リクエストスコープは、一つのリクエストが開始してレスポンスが完了するまでの期間、インスタンスの保持が有効なスコープです。

- リクエストスコープのイメージ

    ![構成1](../img/chapter07/chapter07-00.png)

### 作成するプログラムの画面遷移イメージ

ユーザーが身長と体重の各値を入力・送信すると、診断情報として、BMI値を算出するだけでなくBMI値にもとづく体型を知らせるアプリケーションを作成します。

1. フォームを含む入力画面を用意します。（情報入力画面）

    ![手順1](../img/chapter07/chapter07-01.png)

2. 項目を正しく入力して送信（「診断」ボタンをクリック）した場合の画面です。（診断結果画面）

    ![手順2](../img/chapter07/chapter07-02.png)



### プログラムを作成する

1. 健康についての情報（身長、体重、BMI、体型）をひとまとめに保持するモデルクラスを作成します。  
＊新たに「model」パッケージを用意して、この配下に作ってください。パッケージの作成方法は以下の通り。  

    Eclipse上でexampleプロジェクトを右クリックし、新規>パッケージをクリック→開いたダイアログ上のテキストボックスに「model」と入力→exampleプロジェクトのJavaリソース>src配下にmodelパッケージが生成する。  

    ![手順1](../img/chapter07/chapter07-03.png)  
    ![手順2](../img/chapter07/chapter07-04.png)  
    ![手順3](../img/chapter07/chapter07-05.png)  

    modelパッケージ配下に.javaファイルを作成する方法は、modelパッケージを右クリック>新規>クラスをクリック(今回作成する.javaファイルはサーブレットではないので単なるJavaクラスでよい)→開いたダイアログ上のテキストボックスの名前欄にファイル名を入力して「完了」ボタンをクリックし、クラスを作成する。
   - **Health.java** (modelパッケージ)

       ```java
       package model;
    
       import java.io.Serializable;
    
       public class Health  implements Serializable{
           // 身長
           private double height;
           // 体重
           private double weight;
           // BMI値
           private double bmi;
           // 体型
           private String bodyType;
    
           // 身長を取得する
           public double getHeight() {
               return height;
           }
           // 身長を設定する
           public void setHeight(double height) {
               this.height = height;
           }
           // 体重を取得する
           public double getWeight() {
               return weight;
           }
           // 身長を体重する
           public void setWeight(double weight) {
               this.weight = weight;
           }
           // BMI値を取得する
           public double getBmi() {
               return bmi;
           }
           // BMI値を設定する
           public void setBmi(double bml) {
               this.bmi = bml;
           }
           // 体型を取得する
           public String getBodyType() {
               return bodyType;
           }
           // 体型を設定する
           public void setBodyType(String bodyType) {
               this.bodyType = bodyType;
           }
       }
       ```

2. BMI値を算出して、体型を判定する処理をもつモデルを作成します。
   - **HealthCheckLogic.java** (modelパッケージ)

       ```java
       package model;
    
       public class HealthCheckLogic {
    
           // BMI値を計算する
           public void execute(Health health){
               double height = health.getHeight();
               double weight = health.getWeight();
               double bmi = weight / (height / 100.0 * height / 100.0);
               health.setBmi(bmi);
    
               String bodyType;
               if(bmi < 18.5){
                   bodyType = "痩せ型";
               } else if(bmi < 25.0) {
                   bodyType = "標準";
               } else {
                   bodyType = "肥満";
               }
               health.setBodyType(bodyType);
           }
       }
       ```

3. 身長と体重を入力する画面を実現するJSPファイルを作成します。
   - **healthCheck.jsp** (WEB-INF/jspフォルダ)

       ```jsp
       <%@ page language="java" contentType="text/html; charset=UTF-8"
           pageEncoding="UTF-8"%>
       <!DOCTYPE html >
       <html>
       <head>
       <meta charset="UTF-8">
       <title>スッキリ健康診断</title>
       </head>
       <body>
       <h1>スッキリ健康診断</h1>
       <form action="/example/HealthCheck" method="post">
       身長：<input type="text" name="height"><br />
       体重：<input type="text" name="weight"><br />
       <input type="submit" value="診断">
       </form>
       </body>
       </html>
       ```

4. 診断結果を出力する画面を実現するJSPファイルを作成します。
   - **healthCheckResult.jsp** (WEB-INF/jspフォルダ)

       ```jsp
       <%@ page language="java" contentType="text/html; charset=UTF-8"
           pageEncoding="UTF-8"%>
       <%@ page import="model.Health" %>
       <%
           Health health = (Health)request.getAttribute("health");
       %>
       <!DOCTYPE html >
       <html>
       <head>
       <meta charset="UTF-8">
       <title>スッキリ健康診断</title>
       </head>
       <body>
       <h1>スッキリ健康診断の結果</h1>
       <p>
       身長：<%= health.getHeight() %><br />
       体重：<%= health.getWeight() %><br />
       BMI：<%= health.getBmi() %><br />
       体型：<%= health.getBodyType() %><br />
       </p>
       <a href="HealthCheck">戻る</a>
       </body>
       </html>
       ```

5. 各処理の制御を実行するサーブレットを作成します。
   - **HealthCheck.java** (servletパッケージ)
    
       ```java
       package servlet;
    
       import java.io.IOException;
       import javax.servlet.RequestDispatcher;
       import javax.servlet.ServletException;
       import javax.servlet.annotation.WebServlet;
       import javax.servlet.http.HttpServlet;
       import javax.servlet.http.HttpServletRequest;
       import javax.servlet.http.HttpServletResponse;
       import model.Health;
       import model.HealthCheckLogic;
    
       @WebServlet("/HealthCheck")
       public class HealthCheck extends HttpServlet {
           private static final long serialVersionUID = 1L;
    
           protected void doGet(HttpServletRequest request,
               HttpServletResponse response)
               throws ServletException, IOException {
               // ビューに画面表示の処理を依頼する。（情報入力画面）
               RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/healthCheck.jsp");
               dispatcher.forward(request, response);
           }
    
           protected void doPost(HttpServletRequest request, 
               HttpServletResponse response)
               throws ServletException, IOException {
    
               //リクエストスコープに保持されている身長・体重のデータを取得する。
               String height = request.getParameter("height");
               String weight = request.getParameter("weight");
               // 健康情報のインスタンスを生成し、身長・体重を格納する。
               Health health = new Health();
               health.setHeight(Double.parseDouble(height));
               health.setWeight(Double.parseDouble(weight));
               // 健康診断を実行するモデル（ビジネスロジック）を呼び出す。
               HealthCheckLogic logic = new HealthCheckLogic();
               logic.execute(health);
               // 診断結果をリクエストスコープに保管する。
               request.setAttribute("health", health);
               // ビューに画面表示の処理を依頼する。（診断結果画面）
               RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/healthCheckResult.jsp");
               dispatcher.forward(request, response);
           }
       }
       ```

6. プログラムを作成したら、下記のいずれかでの方法で実行してください。

   - http://localhost:8080/example/HealthCheck にブラウザでリクエストする。
   - 「HealthCheck.java」をEclipseの実行機能で実行する(実行方法は[第5章](chapter05.md)参照)。

## この章で作成したアプリケーションの処理イメージ

![構成イメージ](../img/chapter07/chapter07-06.png)

![構成イメージ](../img/chapter07/chapter07-07.png)