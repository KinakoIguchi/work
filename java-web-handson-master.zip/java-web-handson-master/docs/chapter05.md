# 第5章 フォーム

## フォームを使ったプログラムを作成する

HTML フォームを使って、ユーザー（クライアントサイド）はWeb サイト（サーバーサイド）へデータを送ることができます。

Eclipseの機能を用いて、フォームを使ったプログラムを作成してみましょう。

### 作成するプログラムの画面遷移イメージ

1. フォームを含む入力画面を用意します。（登録情報入力画面）
<br clear="all" />
![手順1](../img/chapter05/chapter05-01.png)

2. 項目を正しく入力して送信（「登録」ボタンをクリック）した場合の画面です。入力した名前と選択した性別が表示されます。（登録結果画面[1]）<br clear="all" />
![手順2](../img/chapter05/chapter05-02.png)

3. 項目に何も入力せずに送信した場合の画面です。エラーメッセージが表示されます。（登録結果画面[2]）
<br clear="all" />
![手順3](../img/chapter05/chapter05-03.png)

### プログラムを作成する

1. 登録情報入力画面に相当するプログラムを作成します。以下のソースに沿って、JSPファイルを作成してください。＊JSPファイルを用意する手順は[第4章](chapter04.md)を参照。

    **formSample.jsp**

    ```jsp
    <%@ page language="java" contentType="text/html; charset=UTF-8"
        pageEncoding="UTF-8"%>
    <!DOCTYPE html>
    <html>
    <head>
    <meta charset="UTF-8">
    <title>ユーザー登録サンプル</title>
    </head>
    <body>
    <form action="/example/FormSampleServlet" method="post">
    名前：<br />
    <input type="text" name="name"><br />
    性別：<br />
    男 <input type="radio" name="gender" value="0">
    女 <input type="radio" name="gender" value="1">
    <input type="submit" value="登録">
    </form>
    </body>
    </html>
    ```

2. 登録情報入力画面のフォームからデータが送信されたときのリクエストを受け付けるサーブレットを作成します。以下のソースに沿って、サーブレットを作成してください。

    **FormSampleServlet.java** (servletパッケージ)

    ```java
    package servlet;

    import java.io.IOException;
    import java.io.PrintWriter;

    import javax.servlet.ServletException;
    import javax.servlet.annotation.WebServlet;
    import javax.servlet.http.HttpServlet;
    import javax.servlet.http.HttpServletRequest;
    import javax.servlet.http.HttpServletResponse;

    @WebServlet("/FormSampleServlet")
    public class FormSampleServlet extends HttpServlet {
        private static final long serialVersionUID = 1L;

        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            // リクエストパラメータを取得
            request.setCharacterEncoding("UTF-8");
            String name = request.getParameter("name");
            String gender = request.getParameter("gender");
            // リクエストパラメータをチェック
            String errorMsg = "";
            if(name == null || name.length() == 0){
                errorMsg += "名前が入力されていません。<br />";
            }
            if(gender == null || gender.length() == 0){
                errorMsg += "性別が選択されていません。<br />";
            } else {
                if(gender.equals("0")){
                    gender = "男性";
                }else if (gender.equals("1")){
                    gender = "女性";
                }
            }
            // 表示するメッセージを設定
            String msg = name + "さん（" + gender +"）を登録しました。";
            if(errorMsg.length() != 0){
                msg = errorMsg;
            }
            // HTMLを出力
            response.setContentType("text/html; charset=UTF-8");
            PrintWriter out =response.getWriter();
            out.println("<html>");
            out.println("<head>");
            out.println("<title>ユーザー登録結果</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<p>" + msg + "</p>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    ```

3. プログラムを作成したら、下記のいずれかでの方法で実行してください。

   - http://localhost:8080/example/formSample.jsp にブラウザでリクエスト(アクセス)する。
   - 「formSample.jsp」をEclipseの実行機能で実行する(実行方法は以下に記載)。
       - Eclise上で実行する.jspファイルを右クリック>実行>サーバーで実行をクリック
           <br clear="all" />
           ![サーバーで実行1](../img/chapter05/chapter05-04.png) 
       - 「ローカルホスト の Tomcat v9.0 サーバー」が選択されていることを確認して「完了」ボタンをクリック
           <br clear="all" />
           ![サーバーで実行2](../img/chapter05/chapter05-05.png)
       - Eclipse上でWebブラウザが起動し、実行対象の.jspファイルの画面が表示される。通常のWebブラウザと同様に、リンクやボタンなどをクリックして操作することも可能

## この章で作成したアプリケーションの処理イメージ

![構成イメージ](../img/chapter05/chapter05-06.png)