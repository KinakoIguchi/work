# 第6章 MVCモデルと処理の遷移

## MVCモデルとは？

MVCモデルは、アプリケーションをモデル(Model)、ビュー(View)、コントローラー(Controller)の要素に分けて開発する考え方、設計・実装の方針です。この方針にもとづいて、①:業務処理やデータの処理、②:処理結果の表示、③:①と②を制御する仕組み、と3つの要素に役割を分けてプログラムを構成します。

|     | 要素                       | 役割                                                                   | Javaプログラム |
| --- | -------------------------- | ---------------------------------------------------------------------- | -------------- |
| ①   | モデル(Model)              | 業務処理やデータの処理を実行する。<br />ビジネスロジックとも呼ばれる。 | -              |
| ②   | ビュー(View)               | 処理結果を表示する。                                                   | JSP            |
| ③   | コントローラー(Controller) | ①と②を制御する。                                                       | サーブレット   |



- MVCモデルによる処理遷移のイメージ
<br clear ="all" />
<img src="../img/chapter06/chapter06-00.png" width="700" />



## 処理をフォワードするプログラム

MVCモデルにもとづいて、処理をフォワードするプログラムを作ってみましょう。具体的には、サーブレットには画面を表示する処理を実装せず、サーブレットからJSPに画面を表示する処理を実行してもらうようにします。

次のサーブレットクラスとJSPファイルを作成し、これらを以下の図のように組み合わせます。
- **ForwardServlet.java**  : リクエストを処理するコントローラー	
- **forward.jsp**  : フォワードした結果の画面を出力するビュー	
<br clear ="all" />

<img src="../img/chapter06/chapter06-01.png" width="700" />



### プログラムを作成する

1.リクエストを処理するコントローラーに相当するプログラムを作成します。以下のソースに沿って、サーブレットを作成してください。
- **ForwardServlet.java** (servletパッケージ)

```java
package servlet;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ForwardServlet")
public class ForwardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher
        = request.getRequestDispatcher("/WEB-INF/jsp/forward.jsp");
        dispatcher.forward(request, response);
    }
}
```



2.フォワードした結果の画面を出力するビューに相当するプログラムを作成します。以下のソースに沿って、JSPを作成してください。
＊「WebContent」フォルダ配下の「WEB-INF」フォルダのなかに、「jsp」フォルダを作成して、ここにJSPファイルを作成してください。
- **forward.jsp** (WEB-INF/jspフォルダ)

```jsp
<!-- 第6章: foward.jsp 正しくフォワードすると表示される-->
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>フォワードのサンプル</title>
</head>
<body>
<p>フォワードされたページです。</p>
</body>
</html>
```



3.プログラムを作成したら、下記のいずれかでの方法で実行してください。
- http://localhost:8080/example/ForwardServlet にブラウザでリクエストする。
- 「ForwardServlet.java」をEclipseの実行機能で実行する。				



## 処理をリダイレクトするプログラム

次は、処理をリダイレクトする作ってみましょう。リダイレクトは、一旦リクエストを受け付けたサーブレットが、クライアント（Webブラウザー）に改めてアクセス先を変更させる（リクエストの受付先を変更させる）処理方式です。


### プログラムを作成する

1.一旦リクエストを受け付けて、別のサーブレットにリダイレクトするサーブレットを作成します。以下のソースに沿って、サーブレットを作成してください。
- **RedirectServlet.java** (servletパッケージ)

```java
package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RedirectServlet")
public class RedirectServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("/example/SampleServlet");
    }
}
```



2.プログラムを作成したら、下記のいずれかでの方法で実行してください。
- http://localhost:8080/example/RedirectServlet にブラウザでリクエストする。
- 「RedirectServlet.java」をEclipseの実行機能で実行する。



### フォワードとリダイレクトの違い

| 観点                        | フォワード                   | リダイレクト                         |
| --------------------------- | ---------------------------- | ------------------------------------ |
| 転送先                      | サーブレット, JSP            | ブラウザがリクエストできるものすべて |
| 転送先のアプリケーション    | 転送元と同じアプリケーション | 制約なし                             |
| アドレスバーに表示されるURL | リクエスト時と同じ           | リダイレクト後のURL                  |
| 【参考】リクエストスコープ  | 引き継ぐ                     | 引き継げない                         |



## この章で作成したアプリケーションの処理イメージ

![構成イメージ](../img/chapter06/chapter06-03.png)
