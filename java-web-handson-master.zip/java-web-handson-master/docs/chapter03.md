# 第3章 サーブレット

## サーブレットを作成する

サーバー上でWebページを動的に生成したりデータ処理を行うために、Javaで作成されたプログラムです。サーブレットはWebサーバー上の「Servletコンテナ」上で動作します。ここでは、TomcatがServletコンテナを実装しています。

Eclipseの機能を用いて、サーブレットを作成してみましょう。

1. 「example」を右クリック選択⇒「新規」⇒「サーブレット」を選択する。<br clear="all" />
![手順1](../img/chapter03/chapter03-01.png)

2. 「サーブレット作成」ウィザードで以下を入力・選択して「次へ」をクリックする。
   - パッケージ名に「servlet」と入力
   - クラス名に「SampleServlet」と入力
<br clear="all" />
![手順2](../img/chapter03/chapter03-02.png)

3. 「サーブレット作成」ウィザードで以下を入力・選択して「次へ」をクリックする。
	- サーブレットの名前「SampleServlet」が表示されていることを確認
	- URLパターン「/SampleServlet」が表示されていることを確認
<br clear="all" />
![手順3](../img/chapter03/chapter03-03.png)

4. 「サーブレット作成」ウィザードで以下を入力・選択して「完了」をクリックする。
	- 「スーパークラスからのコンストラクター」のチェックを外す
	- 作成するメソッドにチェックを入れる。ここでは「doGet」のみ。
<br clear="all" />
![手順4](../img/chapter03/chapter03-04.png)

5. 「example」にJavaファイルが作成されたことを確認する。
<br clear="all" />
![手順5](../img/chapter03/chapter03-05.png)

6. 以下のソースに沿って、足りない部分をコーディングしてみましょう。

    **SampleServlet.java (servletパッケージ)**

    ```java
    package servlet;

    import java.io.IOException;
    import java.io.PrintWriter;
    import java.text.SimpleDateFormat;
    import java.util.Date;

    import javax.servlet.ServletException;
    import javax.servlet.annotation.WebServlet;
    import javax.servlet.http.HttpServlet;
    import javax.servlet.http.HttpServletRequest;
    import javax.servlet.http.HttpServletResponse;

    @WebServlet("/SampleServlet")
    public class SampleServlet extends HttpServlet {
        private static final long serialVersionUID = 1L;

        protected void doGet(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {

            String[] array = { "大吉", "小吉", "凶" };
            int index = (int) (Math.random() * 3);
            String luck = array[index];

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
            Date date = new Date();
            String today = sdf.format(date);

            response.setContentType("text/html; charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<html>");
            out.println("<head>");
            out.println("<title>スッキリ占い</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<p>" + today + "の運勢は... " + luck + "です。</p>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    ```
  
7. サーバーがすでに「始動済み」の場合は、サーバーを停止したあと、開始してください(「停止」の場合は開始のみ)。これにより、サーブレットの追加(.javaファイルの更新)が反映されます。サーバーの開始・停止の方法は[chapter02.md ~ アプリケーションサーバーの開始/停止/再開](chapter02.md#アプリケーションサーバーの開始停止再開)を確認してください。  
プロジェクト上のファイル更新をサーバー上で動作するアプリケーションに反映するためには、以下を実施する必要があります。**.javaファイルの編集結果を確認する場合にサーバーの再起動が必要**な点は特に注意してください。
    - サーブレットなどの.javaファイルの更新: **サーバーの再起動(停止・起動)が必要**。Javaのプログラムはコンパイルが必要なため。
    - .htmlファイル、.cssファイルの更新: **サーバーの再起動は不要**(ファイル更新が即時反映される)。HTMLやCSSはコンパイルが不要のため。

8. 以下のURLにアクセスして、サーブレットの実装結果を確認します。

- URL： http://localhost:8080/example/SampleServlet

## この章で作成したアプリケーションの処理イメージ

![構成イメージ](../img/chapter03/chapter03-06.png)
