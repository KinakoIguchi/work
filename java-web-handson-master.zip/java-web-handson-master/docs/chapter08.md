# 第8章 セッションスコープ

## セッションスコープを使ったプログラムを作成する

複数のリクエスト間で任意のインスタンスを共有・受け渡しを行いたい場合は、セッションスコープを使うことができます。リクエストスコープでは、一つのリクエストが開始してレスポンスが完了するまでの期間しか、インスタンスを保持できませんが、セッションスコープでは、ユーザーがブラウザーを閉じるか、開発者が明示的に破棄するまでインスタンスを保持することができます。

- セッションスコープのイメージ

![構成1](../img/chapter08/chapter08-00.png)



### 作成するプログラムの画面遷移イメージ

擬似的なユーザー登録アプリケーションを作成します。①最初のリクエストでユーザー情報を入力したら、確認画面で入力したデータを出力します。②次のリクエストでユーザー情報を（擬似的に）登録します。このとき、ユーザー情報はクライアント（Webブラウザー）から改めて取得するのではなく、①でセッションスコープに格納したインスタンスから取得します。



1. フォームを含む入力画面を用意します（ユーザー登録入力画面）。「確認」ボタンをクリックすると、確認画面に遷移します。

    ![手順1](../img/chapter08/chapter08-01.png)

2. 入力されたデータを出力する画面です（ユーザー登録確認画面）。「登録」リンクをクリックすると、完了画面に遷移します。「戻る」リンクをクリックすると、入力画面に遷移します。

    ![手順2](../img/chapter08/chapter08-02.png)

3. ユーザー登録が（擬似的に）完了したことを知らせる画面です（ユーザー登録完了画面）。「戻る」リンクをクリックすると、入力画面に遷移します。

    ![手順3](../img/chapter08/chapter08-03.png)



### プログラムを作成する

1. ユーザー情報（ログインID、パスワード、名前）をひとまとめに保持するモデルクラスを作成します。
   - **User.java** (modelパッケージ)

        ```java
        package model;
        
        public class User {
            private String id;
            private String pass;
            private String name;
        
            public User(String id, String pass, String name) {
                this.id = id;
                this.name = name;
                this.pass = pass;
            }
        
            public String getId() {
                return id;
            }
        
            public void setId(String id) {
                this.id = id;
            }
        
            public String getName() {
                return name;
            }
        
            public void setName(String name) {
                this.name = name;
            }
        
            public String getPass() {
                return pass;
            }
        
            public void setPass(String pass) {
                this.pass = pass;
            }
        }
        ```

2. ユーザー登録を（擬似的に）行うモデルを作成します。<br>＊ここでは実際の登録処理は行いません。
   - **RegisterUserLogic.java** (modelパッケージ)

        ```java
        package model;
        
        public class RegisterUserLogic {
            public boolean execute(User user){
                // ユーザー登録処理
                return true;
            }
        }
        ```

3. ユーザー登録入力画面を実現するJSPファイルを作成します。
   - **registerForm.jsp** (WEB-INF/jspフォルダ)

        ```jsp
        <%@ page language="java" contentType="text/html; charset=UTF-8"
            pageEncoding="UTF-8"%>
        <!DOCTYPE html>
        <html>
        <head>
        <meta charset="UTF-8">
        <title>ユーザー登録</title>
        </head>
        <body>
        <form action="/example/RegisterUser" method="post">
        ログインID：<input type="text" name="id" ><br />
        パスワード：<input type="password" name="pass"><br />
        名前：<input type="text" name="name"><br />
        <input type="submit" value="確認">
        </form>
        </body>
        </html>
        ```



4. ユーザー登録確認画面を実現するJSPファイルを作成します。
   - **registerConfirm.jsp** (WEB-INF/jspフォルダ)

        ```jsp
        <%@ page language="java" contentType="text/html; charset=UTF-8"
            pageEncoding="UTF-8"%>
        <%@ page import="model.User" %>
        <%
            User user = (User)session.getAttribute("registerUser");
        %>
        <!DOCTYPE html >
        <html>
        <head>
        <meta charset="UTF-8">
        <title>ユーザー登録（事前確認）</title>
        </head>
        <body>
        <h1>ユーザーを登録します</h1>
        <p>
        ログインID：<%= user.getId() %><br />
        名前：<%= user.getName() %><br />
        </p>
        <a href="RegisterUser">キャンセル</a>
        <a href="RegisterUser?action=done">登録</a>
        </body>
        </html>
        ```
   - このソースを読んで、 JSPがユーザー情報をどこから取得しているかを確認しましょう。

5. ユーザー登録完了画面を実現するJSPファイルを作成します。
   - **registerDone.jsp** (WEB-INF/jspフォルダ)

        ```jsp
        <%@ page language="java" contentType="text/html; charset=UTF-8"
            pageEncoding="UTF-8"%>
        
        <!DOCTYPE html>
        <html>
        <head>
        <meta charset="UTF-8">
        <title>ユーザー登録（完了）</title>
        </head>
        <body>
        <p>登録が完了しました。</p>
        <a href="RegisterUser">戻る</a>
        </body>
        </html>
        ```

6. 各処理の制御を実行するサーブレットを作成します。
   - **RegisterUser.java** (servletパッケージ)

        ```java
        package servlet;
        
        import java.io.IOException;
        
        import javax.servlet.RequestDispatcher;
        import javax.servlet.ServletException;
        import javax.servlet.annotation.WebServlet;
        import javax.servlet.http.HttpServlet;
        import javax.servlet.http.HttpServletRequest;
        import javax.servlet.http.HttpServletResponse;
        import javax.servlet.http.HttpSession;
        
        import model.User;
        import model.RegisterUserLogic;
        
        @WebServlet("/RegisterUser")
        public class RegisterUser extends HttpServlet {
            private static final long serialVersionUID = 1L;
        
            protected void doGet(HttpServletRequest request, 
                HttpServletResponse response)
                throws ServletException, IOException {
                
                String fowardpath = null;
        
                String action = request.getParameter("action");
                if (action == null) {
                    fowardpath = "/WEB-INF/jsp/registerForm.jsp";
                } else if (action.equals("done")) {
                    // セッションスコープを呼び出す
                    HttpSession session = request.getSession();
                    User user = (User) session.getAttribute("registerUser");
        
                    RegisterUserLogic logic = new RegisterUserLogic();
                    logic.execute(user);
                    // セッションスコープを破棄する
                    session.removeAttribute("registerUser");
        
                    fowardpath = "/WEB-INF/jsp/registerDone.jsp";
                }
        
                RequestDispatcher dispatcher
                    = request.getRequestDispatcher(fowardpath);
                dispatcher.forward(request, response);
            }
        
            protected void doPost(HttpServletRequest request,
                HttpServletResponse response)
                throws ServletException, IOException {
                
                request.setCharacterEncoding("UTF-8");
                String id = request.getParameter("id");
                String pass = request.getParameter("pass");
                String name = request.getParameter("name");
        
                User user = new User(id, pass, name);
                // セッションスコープを呼び出す
                HttpSession session = request.getSession();
                session.setAttribute("registerUser", user);
        
                RequestDispatcher dispatcher
                    = request.getRequestDispatcher("/WEB-INF/jsp/registerConfirm.jsp");
                dispatcher.forward(request, response);
            }
        }
        ```

7. プログラムを作成したら、下記のいずれかでの方法で実行してください。
   - http://localhost:8080/example/RegisterUser にブラウザでリクエストする。
   - 「RegisterUser.java」をEclipseの実行機能で実行する。



## この章で作成したアプリケーションの処理イメージ

![構成イメージ](../img/chapter08/chapter08-04.png)

![構成イメージ](../img/chapter08/chapter08-05.png)

![構成イメージ](../img/chapter08/chapter08-06.png)
