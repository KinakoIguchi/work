# 第4章 JSP

## JSPを作成する

JSPとは JavaServer Pages の略で、サーブレットと同じくWebサーバー上の「Servletコンテナ」上で動作します。JSPでは、HTMLページの中にJavaのコードを埋め込む要領でコーディングします（ファイルの拡張子は「＊.jsp」）。HTMLページの出力が実装の主な目的の場合には、サーブレットではなくJSPを作成するほうが適しているでしょう。

Eclipseの機能を用いて、JSPを作成してみましょう。

1. 「example」を右クリック選択⇒「新規」⇒「JSPファイル」を選択する。<br clear="all" />
![手順1](../img/chapter04/chapter04-01.png)

2. 「新規JSPファイル」ウィザードで以下を入力・選択して「次へ」をクリックする。
   - 保存場所を指定する。デフォルトで「WebContent」フォルダが選択される。基本的に、JSPファイルはこのフォルダ配下に保存する。
   - ファイル名「sample.jsp」を指定
<br clear="all" />
![手順2](../img/chapter04/chapter04-02.png)

3. 「新規JSPファイル」ウィザードで以下を入力・選択して「完了」をクリックする。
	- 「新規JSPファイル (html) 」を選択
<br clear="all" />
![手順3](../img/chapter04/chapter04-03.png)

4. 指定したフォルダにJSPファイルが作成され、エディタに作成したファイル内容が表示されます。
<br clear="all" />
![手順4](../img/chapter04/chapter04-04.png)

5. 以下のソースに沿って、足りない部分をコーディングしてみましょう。

- **sample.jsp**

```jsp	
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.Date"%>
<%@ page import="java.text.SimpleDateFormat"%>
<%
    String[] array = { "大吉", "小吉", "凶" };
    int index = (int) (Math.random() * 3);
    String luck = array[index];

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日");
    Date date = new Date();
    String today = sdf.format(date);
%>
<!DOCTYPE html >
<html>
<head>
<meta charset="UTF-8">
<title>スッキリ占い</title>
</head>
<body>
<!-- HTMLのコメント -->
<%-- JSPのコメント --%>
<p><%= today %>の運勢は... <%= luck %>です。</p>
</body>
</html>
```

- URL： http://localhost:8080/example/sample.jsp

## この章で作成したアプリケーションの処理イメージ

![構成イメージ](../img/chapter04/chapter04-06.png)