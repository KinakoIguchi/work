# 演習1　ReactによるSPA開発を体験してみましょう！（1）

## 演習準備
VisualStudioCode上でspa-basic-sampleプロジェクトを開きます。 「File」→「Open Folder」でspa-basic-sampleを選択していただくと開けます。
もしくはspa-basic-sampleフォルダを右クリックして「Codeを開く」でも開けます。  
そしてコマンドプロンプトから「npm run dev」を実行してアプリケーションを起動してください。「アプリケーション起動確認_SPF01.pptx」に記載されている手順通りです。

## 演習1-1
- Reactのコンポーネント内でState（状態）を保持し、そのStateを変更するサンプルを実装します。（Statefulコンポーネント、クラスコンポーネント）
- ボタン押下により数値を１ずつ加算していくサンプルを実装していきます。  
![演習1-1-1](/img/ex001/img001.png)

### 演習1-1 解説

`js/containers/Content.jsx`を開きます。ファイルを開くときは左メニューから探して開いても良いですが、VisualStudioCode上で`ctrl+p`を押すとファイル名の検索欄が出てくるので、それを利用するとすぐに開けます。

演習1-1を行うと、`js/containers/Content.jsx`のソースコードは下記のようになります。この後に、それぞれについて詳細を説明していますので、コピー＆ペーストではなく、実際に書きながら行ってください。

  ```javascript
    import React, { Component } from 'react';

    class Content extends Component {
      // (1)
      constructor(props) {
        super(props);
        this.state = {
          number: 0,
        };
      }
      // (2)
      countUp = () => {
        this.setState({ number: this.state.number + 1 });
      }
      // (3)
      render() {
        return (
          <React.Fragment>
            <div>SPAフロントエンド開発入門</div>
            <div>
              {this.state.number}
            </div>
            <button onClick={this.countUp}>+1</button>
          </React.Fragment>
        );
      }
    }

    export default Content;
  ```
 
#### (1)constructorの作成  
クラスの内部にconstructorを作成し、現在の数値の状態を保持する変数numberを`this.state`の中でオブジェクト型で宣言します。numberの初期値は0とします。  
constructorはコンポーネントの初期化処理を行う部分であり、クラスコンポーネント特有の機能です。  
またJavaScriptのわかりづらい部分である「this」についてですが、今回出てきている「this」はクラスコンポーネント自身を指しています。

`js/containers/Content.jsx`  
```javascript
    constructor(props) {
      super(props);
      this.state = {
        number: 0,
      };
    }
```

#### (2)値の加算(状態の更新)
次に数値を１ずつ加算する関数countUpを作成します。`setState`という関数を使用して状態の更新を行います。
このsetStateはクラスコンポーネントが持っている機能なので`this.setState`として呼び出します。  
そしてsetStateの中ではオブジェクト型で、`key`にnumberを、`value`に現在の値(this.state.numberで呼び出せます)+1を加算した値をセットします。これで状態の更新を行うことができます。

```javascript
    countUp = () => {
      this.setState({ number: this.state.number + 1 });
    }
``` 

ちなみに、`setState`が実行されて値の更新が行われると、その後`render()`が呼び出され、再描画されて更新後の値が画面に表示されるようになります。  
そのため、setStateを使わず`this.state.number = this.state.number + 1;`と直接状態に代入しても、Reactコンポーネントが保持している状態は更新されますが`render()`は呼び出されないので、
画面の再描画が行われず画面上は何も変化しません。  
`this.setState({ number: this.state.number + 1 });`を`this.state.number = this.state.number + 1;`にしてみると、その動作が確認できますので、試してみてください。


#### (3)状態の表示
次にrenderを書き換えます。renderの中のreturn内で書いた要素が画面に描画されます。
変数などを要素内に入れる場合は`{}`で囲むことで、組み込むことができます。今回はクラスコンポーネントが保持している`number`を表示するので、`{this.state.number}`を要素内に組み込んでいます。
また、クリックされたときにcountUpを呼び出すボタンを設置しています.

```javascript
    render() {
        return (
          <React.Fragment>
            <div>SPAフロントエンド開発入門</div>
            <div>
              {this.state.number}
            </div>
          <button onClick={this.countUp}>+1</button>
        </React.Fragment>
      );
   }
```

コードを書き終えたらブラウザで画面を更新して動作確認をしてみてください。  またブラウザのデベロッパーツール（F12を押すと出てくると思います）を開いて、
上部タブの「Elements」を開くと、画面に描画されているHTML要素が表示されるかと思います。それを開きながら「+1」ボタンを押すと、数値の部分だけしか変更されてないことが確認できるかと思います。 
これがDOMの一部分を更新する、SPAの特徴です。

ボタンを押下して数値が１ずつ増えたら演習1-1は終了です。  

## 演習1-2
- 作成したサンプルに、以下の3つの機能を追加実装してください。
  - １ずつ減算するボタンの設置
  - 数値を0にするリセットボタンの設置
  - 各ボタン（加算／減算／リセット）を押下した際に、メッセージを表示  
  ![演習1-2-1](/img/ex001/img002.png)
  ![演習1-2-2](/img/ex001/img003.png)
  ![演習1-2-3](/img/ex001/img004.png)
  
  
#### `演習1-1で作成したコードに付け足しながら、実装してみてください。下に解説が書かれていますが、ほとんど実装内容は演習1-1同じですので、まずは自力で頑張ってみてください。`




### 演習1-2 解説
演習1-1と同じ流れで作成します。js/containers/Content.jsxを開きます。  
演習1-1では保持する状態はnumberのみでしたが、演習1-2ではメッセージも保持する必要があるため、変数messageを追加します。初期値も同様に設定します。
- js/containers/Content.jsx  

```javascript
    constructor(props) {
      super(props);
      this.state = {
        number: 0,
        message: 'ボタンを押してください。',
      };
    }
```

次に１ずつ減算する関数と、数値を０にする関数を作成します。また、演習1-1で作成したcountUp関数にはmessageを更新する処理を追記します。
- js/containers/Content.jsx  

```javascript
    countUp = () => {
      this.setState({ number: this.state.number + 1 });
      this.setState({ message: '1加算しました。' });
    }
```

```javascript  
    countDown = () => {
      this.setState({ number: this.state.number - 1 });
      this.setState({ message: '1減算しました。' });
    }
```

```javascript  
    countReset = () => {
      this.setState({ number: 0 });
      this.setState({ message: 'リセットしました。' });
    }
```

最後に、それぞれの関数を呼び出すために減算ボタンとリセットボタンを作成します。
- js/containers/Content.jsx  

```javascript
    <button onClick={this.countDown}>-1</button>
```

```javascript
    <button onClick={this.countReset}>Reset</button>
```

ちなみに、`this.setState`の中身はオブジェクト型なので、下記のようにまとめて書くこともできます。
```javascript
    countReset = () => {
      this.setState({
        number: 0,
        message: 'リセットしました。',
      });
    }
```

以上で演習1-2は終了です。書けた方は動作確認をしてみてください。  
解答は解答フォルダ1-2を参照してください。