# 演習2　ReactによるSPA開発を体験してみましょう！（2）
演習2は、演習1で作成したコードの書き換えが中心のため、画面上での変化はありません。
演習2を行って、最終的に演習1と同様の動作をしていれば、問題ないです。
## 演習2-1
- 演習1でクラスコンポーネントを作成したので、次に状態を保持しない関数コンポーネント(Statelessコンポーネント)を実装します。
- 演習1で、クラスコンポーネントの中に埋め込まれていた数値の変更ボタン（+1／-1／リセット）を、関数コンポーネント（Statelessコンポーネント）として分離します。
- 一般的に状態を渡すコンポーネントを「親コンポーネント」、状態を受け取るコンポーネントを「子コンポーネント」と呼びます。「子コンポーネント」から状態を受け取るコンポーネントを「孫コンポーネントと呼びます」
![proptypes](/img/ex002/img001.png)


- PropTypesについての説明  
Reactの子コンポーネントが親から渡される値(propsと呼ばれています)を受け取る際に、値の型チェックを行う機能です。条件を満たしていないときはブラウザのデベロッパーツール画面のコンソールに警告が出ます。  
この機能があることで、「このコンポーネントにどのような値を渡す必要があるのか」がわかりやすくなり、バグも防ぎやすくなります。  
以下がPropTypesでよく使用される型定義です
    - PropTypes.string　　・・・　文字列
    - PropTypes.number　・・・　数値
    - PropTypes.bool　　　・・・　真偽値
    - PropTypes.func　　　・・・　関数
    - PropTypes.array　　・・・　配列　　　　など  
    - PropTypes.string.isRequired　・・・　文字列型で必須  

### 演習2-1 解説
`js/containers/Content.jsx`を開きます。 
#### ①関数コンポーネントの作成
まずボタンを関数コンポーネントButtonとして作成します。引数の`props`には`Content.jsx`からButtonに渡される値が入ります。今回はonClickしたときの関数と、Buttonのラベル名をpropsとして渡します。

```javascript
const Button = props => {
  return (
    <button onClick={props.onClick}>{props.label}</button>
  );
};
class Content extends Component {
// 省略
```

#### ②PropTypesでの型定義
次にButtonに渡される値`props`の型定義を、PropTypesを用いて行います。まずPropTypesをimportして利用できるようにします。

```javascript
    import React, { Component } from 'react';
    import PropTypes from 'prop-types';
```

親コンポーネントから渡される値はボタンのラベル名とクリックしたときの関数です。どちらもボタンを構成するためには必要な値なので、`.isRequired`を付けて必須にします。  
そして`label`には文字列、`onClick`には関数の型を定義します。「プロップタイプス」の先頭が大文字と小文字の2つがあるので、入力ミスに気をつけてください。

最後に`Button`コンポーネントに、定義した`propTypes`の情報を代入します。これでButtonコンポーネントが受け取る値(props)の型定義ができました。
```javascript
const Button = props => {
  return (
    <button onClick={props.onClick}>{props.label}</button>
  );
};
const propTypes = {
  label: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired,
};
Button.propTypes = propTypes;
```

#### ③クラスコンポーネントから関数コンポーネントを呼び出す
Buttonの関数コンポーネントが完成したので、クラスコンポーネントから呼び出します。もともとContentコンポーネントではHTMLのbuttonタグが埋め込まれていました。
```javascript
    return (
      <React.Fragment>
        <div>SPAフロントエンド開発入門</div>
        <div>
          {this.state.number}
        </div>
        <button onClick={this.countUp}>+1</button>
        <button onClick={this.countDown}>-1</button>
        <button onClick={this.countReset}>Reset</button>
        <div>{this.state.message}</div>
      </React.Fragment>
    );
```
この部分を先ほど作成した`Button`コンポーネントに変更します。

```javascript
    return (
      <React.Fragment>
        <div>SPAフロントエンド開発入門</div>
        <div>
          {this.state.number}
        </div>
        <Button label="+1" onClick={this.countUp} />
        <Button label="-1" onClick={this.countDown} />
        <Button label="Reset" onClick={this.countReset} />
        <div>{this.state.message}</div>
      </React.Fragment>
    );
```
`<Button>`タグの中に`label`と`onClick`が定義されています。これが`Button`コンポーネントに`props`として1つにまとめられて渡されています。  

画面上では特に変化はないですが、ソースコード上だとクラスコンポーネントと関数コンポーネントの2つに分離することができました。

以上で演習2-1は終了です。  


## 演習2-2
演習2-1で作成したButtonコンポーネント(関数コンポーネント)を別ファイルに分離し、importして使うようにします。  
別ファイルに分離することで、他のコンポーネントファイルからも、このButtonコンポーネントを利用しやすくなります。Buttonコンポーネントの再利用性が高くなります。
![component](/img/ex002/img002.png)

### 演習2-2 解説
#### ①新規ファイルの作成
別ファイルに分離するため、js配下にcomponentsフォルダを作成し、さらにその中にButton.jsxを作成してください。(`js/components/Button.jsx`となります)

`js/components/Button.jsx`のソースコードは、ほぼ演習2-1で作成したButtonコンポーネントをそのまま持ってきたような内容です。
  ```javascript
    import React from 'react';
    import PropTypes from 'prop-types';

    const Button = props => (
      <button onClick={props.onClick}>{props.label}</button>
    );

    const propTypes = {
      label: PropTypes.string.isRequired,
      onClick: PropTypes.func.isRequired,
    };
    Button.propTypes = propTypes;
  ```

さらに、ほかのファイルから`Button.jsx`がimportできるように`js/components/Button.jsx`の最後にexport文を追記します。

```javascript
  　// 省略
    const propTypes = {
      label: PropTypes.string.isRequired,
      onClick: PropTypes.func.isRequired,
    };
    export default Button; // 追記
```

#### ②関数コンポーネントのimport
次に`js/containers/Content.jsx`内から、別ファイルに分離した`Button.jsx`をimportします。  
またButtonコンポーネントを別ファイルに分離したので、`js/containers/Content.jsx`の中に書かれているButtonコンポーネントは削除して大丈夫です。
`PropTypes`もButtonコンポーネントで使用していたので、削除して大丈夫です。

```javascript
import React, { Component } from 'react';
// import PropTypes from 'prop-types'; 削除
import Button from '../components/Button';// 追記

/* 削除
const Button = props => {
  return (
    <button onClick={props.onClick}>{props.label}</button>
  );
};
const propTypes = {
  label: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired,
};
Button.propTypes = propTypes;
*/


class Content extends Component {
// 省略
```


以上で演習2-2は終了です。演習2-1, 2-2ともに画面での見た目上の変更はありません。  