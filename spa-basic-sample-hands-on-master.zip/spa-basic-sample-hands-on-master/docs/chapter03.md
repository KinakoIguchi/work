# 演習3　ReactにReduxを組み込んでみましょう！
演習3からは、Reactだけでなく、「[Redux](https://redux.js.org/)」という状態管理のライブラリを使用していきます。
ReduxはFluxと呼ばれるFacebook社が提唱するデータ管理のアーキテクチャを実現するためのフレームワークです。 
演習2までは、Reactのクラスコンポーネント(Statefulコンポーネント)で数値などの状態を保持してきました。その状態の保持を今回からはReduxで行うようにします。

Reactに比べ、Reduxを使用すると状態を変更するための記述が増えるので、学習コストが高くなるのが一般的です。
またアプリケーションの規模が大きくならないと、Reduxの利点が中々把握しづらいです。  
そのため今回の演習では、以下のことを理解するのを目指して、Reduxの演習に取り組んでみてください。
- ReactとReduxの2つの方法で、アプリケーションの状態を保持することができる
- Reduxでの状態の保持の仕方、状態の変更の仕方を理解する 

### Reduxの特徴
- アプリケーションの全ての状態をReduxのStoreで一括管理することができるため、Reactコンポーネントで状態を管理する必要がなくなります  
Reactコンポーネントは状態を保持したり変更したりすることができますが、その影響によりコンポーネント内の記述量が増えていきます。
本来、Reactコンポーネントは「画面の表示」のみを行う、シンプルな設計にすることが推奨されています。
画面表示の記述と、状態変更の記述が同じファイル内に書かれていると、扱う状態が増えていくに連れて、どんどんコードの見通しが悪くなるためです。  
それを防ぐために、状態の管理はReduxに任せて、ReactコンポーネントではReduxのStoreから状態を取り出して画面表示を行う、というReactとReduxの組み合わせが一般的になりました。

- データフローが一方向なため、アプリケーションの構造がシンプルになります  
Reduxのデータフローは、下図のようになります。Reduxが提供する機能として、「Store」「Action」「Reducer」の3つがあります。

 ![演習3-1-1](/img/ex003/img001.png) 

後の演習で、1つずつ詳しく実装していきますが、大体のReduxを使用した状態変更の流れを説明します。

1. Storeから状態(State)を取り出す  
Reactコンポーネントから、ReduxのStoreに保持されている状態を取り出して、画面に表示します。

2. Reactコンポーネントから、ReduxのActionを実行  
画面上で、「+1」ボタン押下などの操作が行われ、状態を変更する必要が発生したら、ReactコンポーネントからReduxのActionを実行します。  
状況により、このActionを実行するときに、状態の変更後の値を引数としてセットする場合もあります。

3. ActionからStoreに状態の変更が発生したことを通知  
Actionから、状態変更の内容(加算、減算など)や、状態変更後の値を、Storeに伝えます。

4. StoreからReducerへ、状態の変更を命令  
Actionから通知（状態変更の内容や、状態変更後の値）を受け取ったStoreは、その受け取った内容と、Storeが保持している現在の「状態(state)」を、Reducerに渡します。  
注意点として、この4.の内容はReduxのライブラリ内で自動的に行われるため、コードを書いたりする必要がありません。そのため開発していてもここの動きは特に意識しないのですが、
一応Reduxは裏でこのように動いている、ということだけ認識しておいてください。

5. 状態の変更をReducerで実施  
Storeから受け取った内容(現在の状態や、変更内容)をもとに、Reducerで状態の変更を行います。

6. 変更後の新しい状態を、ReducerからStoreへ渡す  
状態を変更し、更新した状態をStoreへ渡します。

7. 画面の表示を更新  
StoreがReducerから新しい状態を受け取ると、その状態をReactコンポーネントへ渡します。  
Reactコンポーネントでは、Storeから受け取る状態が変更されたことを検知して、再描画が自動的に行われます。この動作により、画面に新しい状態が表示されます。  
この7.の動作も、6.でReducerから更新後の新しい状態をStoreに渡せば、自動的に変更の差分を検知してReactコンポーネントの再描画が行われるので、
開発時には特に意識する必要はありません。


Reduxを使用した状態変更は、上記の1~7のフローを必ず行います。そのため、ある状態が、どこから、どのように変更されるかが整理され、コードが追いやすくデバッグもしやすくなります。



## 演習3-1
演習3-1では、先ほどReactで実装した数値の加算処理を、Reduxを使用して行えるようにします。  
書き込むファイルを間違えないよう気をつけながら、ハンズオンを進めていってください。  

### 演習3-1 解説
Action, Reducer, Storeの順に実装を行った後に、ReactとReduxを結合して、ReactコンポーネントからStoreの値を取り出す処理を実装します。
#### ---Actionの実装-------------------------------------------------
Actionは、Storeが保持している状態に対して変更を行う際の起点となります。

まずActionTypes.jsでActionTypeを定義します。  
ActionTypeは文字通りActionの種類(加算、減算など)を定義します。このActionTypeは、Reducerでも処理を振り分ける際に利用します。

`js/constants/ActionTypes.js`  
```javascript
    export const COUNT_UP = 'COUNT_UP';
```

次に、Actionを作成します。  
`js/actions/index.js`  

```javascript  
    import { createAction } from 'redux-actions';
    import { COUNT_UP } from '../constants/ActionTypes';

    export const countUp = createAction(
        COUNT_UP,
        num => ({ amount: num }),
    );
```
JavaScriptを理解していないと少し難しいですが、`redux-actions`というライブラリの`createAction`という機能を利用して、Actionを作成します。
第一引数にActionType(COUNT_UP)、第二引数にアロー関数を設定します。アロー関数では引数にReactコンポーネントから受け取る値(num)、
returnとしてreducerに渡す値（上記の例では`{ amount: num }`）を設定します。

これで加算処理のActionの作成は完了です。ここで定義した`countUp`関数をexportして外部ファイルから扱えるようにしています。
これにより、Reactコンポーネントから`countUp`関数を利用できるようになります。


#### ---Reducerの実装-------------------------------------------------
Reducerでは、Actionの発行内容に応じて、状態を変更します。
先ほども説明しましたが、Reduxの処理の流れとしてはActionの後にStoreを経由して、Actionの内容と現在のStoreの状態がReducerへ渡されます。
しかしこの処理はReduxの内部で行われているので、実装時には気にする必要はありません。  
そのためActionを作成したら、次にReducerの処理を実装していきます。

`js/reducers/counter.js`  
##### ・ライブラリやActionTypesのimport  
`redux-actions`のライブラリから`handleActions`という関数をimportします。
reducerではActionから発行された内容をActionTypes（COUNT_UPなど）を利用して振り分けて、状態の更新処理を行います。そのために、ActionTypesから`COUNT_UP`をimportしています。
`handleActions`はその振り分けるコードをシンプルに書くことができるので利用される事が多いです。  
`handleActions`を利用しない場合は[switch文](https://developer.mozilla.org/ja/docs/Web/JavaScript/Reference/Statements/switch)でも同様の実装ができます。
reducerの記事を調べると、switch文で書かれているものも多く見ますが、今回は`handleActions`を使用します。

```javascript
  import { handleActions } from 'redux-actions';
  import { COUNT_UP } from '../constants/ActionTypes';
```

##### ・状態の定義
reducerに、アプリケーションで使用する状態`number`を定義します。  
状態はStoreに保存されますが、状態を定義する場所はreducerであることに気をつけてください。

```javascript 
  import { handleActions } from 'redux-actions';
  import { COUNT_UP } from '../constants/ActionTypes';

  const initialState = {
    number: 0,
  };

```


##### ・Actionの発行内容を振り分け、更新処理を実装  
先ほどimportした`handleActions`を利用します。第一引数にオブジェクト型で更新処理を、第二引数に先ほど定義した状態をセットします。

```javascript 
  import { handleActions } from 'redux-actions';
  import { COUNT_UP } from '../constants/ActionTypes';

  const initialState = {
    number: 0,
  };

  const counter = handleActions({
    [COUNT_UP]: (state, action) => ({
    ...state,
    number: state.number + action.payload.amount,
    }),
  }, initialState);

  export default counter;
```
最後にこのReducerの内容を、Store生成時に利用するため、`export`を付け加えて他のファイルから利用できるようにします。

`handleActions`の中の第一引数にセットした更新処理のコードについてもう少し説明します。

```javascript
const counter = handleActions({
    [COUNT_UP]: (state, action) => ({
    ...state,
    number: state.number + action.payload.amount,
    }),
  }, initialState);
```
第一引数にはオブジェクト型で、`key`にはActionのタイプがセットされ、`value`に`state`と`action`を引数にとったアロー関数がセットされています。


まず`state`には、Storeから受け取った現在の状態が入っています。そのため先ほど定義した`number`を取り出したければ、`state.number`と記述します。  

そして`action`にはActionの発行内容の情報が入っています。様々な情報が入っていますが、主に使用するのが`action.payload`の中身の値です。`action.payload`の中には、
Actionを作成したときにreducerに渡す値として設定した値が入ります。  
先ほど作成した`js/actions/index.js`で説明すると、オブジェクト`{ amount: num }`の部分です。
そのため、actionから渡される値を利用したい場合、reducerではオブジェクトのkeyを指定して、`action.payload.amount`というふうに記述することで利用できます。  
今回はamountというkey名にしていますが、ここはどんな名前を付けても良いです。

```javascript
    export const countUp = createAction(
        COUNT_UP,
        num => ({ amount: num }),
    );
```

次にアロー関数でreturnしている部分についてです。

```javascript
    [COUNT_UP]: (state, action) => ({
      ...state,
      number: state.number + action.payload.amount,
    }),
```

`...state`と`number: state.number + action.payload.amount`をオブジェクト型でまとめている部分です。  
状態を更新してreturnすることで、Storeに新しい値を返してます。
`number: state.number + action.payload.amount`についてですが、keyにセットした`number`は先ほど状態として定義したnumberを指しています。
そのためここでは、Storeから受け取った現在の状態`state.number`にactionから受け取った値`action.payload.amount`を加算して、numberの状態を更新しています。

もう一つの`...state`の`...`はJavaScriptの[スプレッド構文](https://developer.mozilla.org/ja/docs/Web/JavaScript/Reference/Operators/Spread_syntax)というものです。
スプレッド構文はオブジェクトや配列の中身を全て展開する機能を持っています。

わかりづらいと思うので、`...state`を記述している理由を、例をあげて説明します。  
現在はnumberという値しか定義していませんが、例えばnumber以外にも状態が増えていったとします。
```javascript
  const initialState = {
    number: 0,
    sampleA: 'サンプルA',
    sampleB: 'サンプルB',
  };
```

このときに、カウントアップのActionが発行されて、numberの値を更新するために以下のように記述したとします。
```javaScript
    [COUNT_UP]: (state, action) => ({
      number: state.number + action.payload.amount,
    }),
```
このように記述するとnumberの値だけが入ったオブジェクトが、新しい状態としてStoreに保存されます。そのため、`sampleA`と`sampleB`が無くなってしまうのです。  
それを防ぐためには下記のように書く必要があります。
```javascript
    [COUNT_UP]: (state, action) => ({
      number: state.number + action.payload.amount,
      sampleA, // keyとvalueが同じ値のときは省略して書けます。{sampleA: sampleA} →　{sampleA}
      sampleB,
    }),
```
こうすると、変更が何もなかった`sampleA`と`sampleB`が無くなることはありません。  

しかしもし状態がものすごいたくさん必要になった場合、変更のないものをいちいち書くのは面倒くさくなりますし、バグの原因にもなります。そこで利用するのがスプレッド構文です。  
スプレッド構文はオブジェクトの中身を展開するので、下記の2つは同じ意味になります。

```javascript
// 記述は違うが、コードの意味は同じ
{
    ...state,
}

{
   number,
   sampleA,
   sampleB
}
```

そのため、reducerでstateの更新をする場合は、まず変更前の状態stateの中身をスプレッド構文で展開します。
その後、変更する必要があるものだけを更新することで、状態が抜け落ちることを防ぐことができます。

```javascript
    [COUNT_UP]: (state, action) => ({
      ...state,// ここで変更前の状態をまとめてコピー
      number: state.number + action.payload.amount, // 変更箇所だけを記載
    }),
```

説明が長くなりましたが、とりあえずreducerで状態を更新するときは
 1. まず「...state」で変更前の状態を丸々コピー
 2. 次に変更がある状態だけを個別に指定して更新

の手順を忘れずに行うようにしてください。

#### ---Storeの実装-------------------------------------------------
Storeの実装について説明します。しかし先述してる通り、Storeの処理はReduxのライブラリ内で行われているため、そこまで実装することありません。  
またAction、Reducerに比べると、触る機会はほとんどありません。そのため今回は既にコードは記述済です。

`store/configureStore.dev.js`
```javascript
import { createStore, applyMiddleware } from 'redux';
import { createLogger } from 'redux-logger';
import counter from '../reducers/counter';

export default function configureStore() {
  const store = createStore(
    counter,
    applyMiddleware(createLogger()),
  );
  return store;
}
```
このファイル内の`configureStore()`を実行されると、`redux`ライブラリから取り出した`createStore`が実行されます。`createStore`の引数にはreducerを入れます。
ここでは先ほど作成した`counter`のreducerをセットしています。  

またreducer以外に`applyMiddleware`関数を使用して、ミドルウェアライブラリをセットして、アプリケーション内で利用できるようにしています。
`redux-logger`ライブラリから取り出した`createLogger`をここにセットすることで、デベロッパーツールのコンソール画面に、Reduxの状態変化の様子が表示されます。

この`createStore`が実行されると、reducerに定義した状態が、Storeに保存されるようになります。



#### ---Reactコンポーネントの実装-------------------------------------------------

Reactコンポーネントの実装に入る前に、「Storeの実装」で説明した、`configureStore()`を実行してStoreを作成し、`Content.jsx`コンポーネントでReduxの機能を利用できるようにします。  
ルートディレクトリに格納されている`index.jsx`ファイルを下記のように変更します。このファイルは、Reactアプリケーションで一番最初に画面描画されるファイルです。  
`spa-basic-sample/index.jsx`
```javascript
import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import configureStore from './js/store/configureStore';
import Content from './js/containers/Content';

const store = configureStore();

render(
  <Provider store={store}>
    <Content />
  </Provider>,
  document.getElementById('root'),
);
```
`const store = configureStore();`でStoreの作成を行い、その結果を変数`store`に格納しています。  
そしてその変数`store`を`react-redux`ライブラリから取り出した`Provider`コンポーネントに組み込みます。
この`Provider`コンポーネントに囲まれたReactコンポーネント(コード上はContent)は、Reduxの機能(Storeの状態を受け取る、Actionを発行する)を使用できるようになります。  
またContentコンポーネント配下の子コンポーネント(Button.jsxなど)も、Reduxの機能を使用することができます。  

これで、ReactコンポーネントがReduxの機能を使用するための下準備が完了しました。


次に、実際にReactコンポーネントからReduxの機能を使用するための実装を行っていきます。下記の順で説明します。  
- ReactコンポーネントからActionを発行するための実装
- Reactコンポーネントから、ReduxのStoreに保持されている状態を受け取る実装

対象ファイルは`js/containers/Content.jsx`です。

このあたりはプログラミングでたまに使われる「おまじない」的な要素が多くなります。
最初のうちは、コードの詳しい動きというよりは、「こう書けば、こう動くんだな」という認識で大丈夫です。
React/Reduxの開発に慣れないと、このあたりの動きをちゃんと理解するのは難しいです。
ライブラリを使用した実装が多いため、ちゃんと処理を追うと、ライブラリの中身のコードも追いかけなくてはいけなくなるためです。


##### ReactコンポーネントからActionを発行するための実装
まず必要なものをimportします。
```javascript 
import React, { Component } from 'react';
import { bindActionCreators } from 'redux'; // 追加
import { connect } from 'react-redux';// 追加
import PropTypes from 'prop-types';// 追加
import * as CounterActions from '../actions';// 追加
import Button from '../components/Button';

class Content extends Component {
// 省略
```
`bindActionCreators`はAction発行の処理を扱いやすくするために使用します。  
`connect`はReactコンポーネントをReduxと接続するために使用します。  
`CounterActions`は先ほどactionで作成した関数(countUp)が入ります。`* as CounterActions`と表記することで、actionの関数が複数になっても、1つの`CounterActions`にまとめることができます。


まず、ReactコンポーネントとReduxを`connect`を使用して結合します。コードの一番下のexport文を下記のように変更してください。
```javascript
// 省略
export default connect(null, null)(Content);
```

次にActionを発行するための準備をします。
```javascript
//省略
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(CounterActions, dispatch),
  };
}

export default connect(null, mapDispatchToProps)(Content);
```
`mapDispathToProps`という関数が出てきていますが、これを`connect`の中にセットします。
そして`mapDispatchToProps`の中で、ReactコンポーネントからActionを発行するための準備が行われます。

`bindActionCreators`の第一引数に`js/actions/index.js`に定義したaction関数(coutUp)を1つにまとめた`CounterActions`をセットします。  
この記述により、Actionを発行できる関数に加工され、`actions`の中に格納されます。  

コードがかなり複雑ですが、「mapDispatchToPropsの中で、Action発行のための準備が行われている」ことだけを理解してもらえれば大丈夫です。


次に、`mapDispatchToProps`でAction関数を加工して格納した`actions`は、`connect`関数からpropsとしてReactコンポーネントに渡されるものなので、
`actions`のpropTypesを定義します。

```javascript
//省略
const propTypes = {
  actions: PropTypes.object.isRequired,
};
Content.propTypes = propTypes;

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(CounterActions, dispatch),
  };
}

export default connect(null, mapDispatchToProps)(Content);
```

最後に、「+1」ボタンを押下したときに、Actionを発行するようにします。
```javascript
  countUp = () => {
    // this.setState({ number: this.state.number + 1 }); 削除
    const { actions } = this.props;
    actions.countUp(1);
    this.setState({ message: '1加算しました。' });
  }
```
propsとして受け取った`actions`から、`countUp`のActionを発行することができました。

`countUp`の引数`1`は、先ほど実装したActionを作成する`createAction`第二引数のアロー関数内の`num`に入ります。  
`js/actions/index.js`  
```javascript  
    import { createAction } from 'redux-actions';
    import { COUNT_UP } from '../constants/ActionTypes';

    export const countUp = createAction(
        COUNT_UP,
        num => ({ amount: num }),
    );
```

この状態で、ブラウザ上で「F12」キーを押下してデベロッパーツール画面を開いてください。また上部タブの「Console」クリックして開いてください。  
そして「+1」ボタンを押下すると下図のように、ボタンを押すたびにactionが発行されているのがわかるかと思います。
このようにコンソール画面に表示されていれば、コンポーネントからActionが正しく発行されています。

 ![演習3-1-1](/img/ex003/console.png)
 
中身を見てみると、「prev state」が変更前のStoreの状態、「next state」が変更後のStoreの状態が記載されており、「action」には種類や渡されている値が入っています。  
しかしまだ画面に表示されている数字は、Reactコンポーネントが保持している`number`を表示しているので、何も変わりません。
次の作業で、画面に表示される数字を、ReduxのStoreに保存されている`number`を表示するように変更します。




##### Reactコンポーネントから、ReduxのStoreに保持されている状態を受け取る実装
ReactコンポーネントからActionを発行することができたので、次にStoreに保存されている状態を受け取る処理を実装します。

`mapStateToProps`というものを追記します。
```javascript
//省略
const propTypes = {
  actions: PropTypes.object.isRequired,
  number: PropTypes.number.isRequired,
};
Content.propTypes = propTypes;

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(CounterActions, dispatch),
  };
}

function mapStateToProps(state) {
  return {
    number: state.number,
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(Content);
```
`mapStateToProps`では、現在Storeに保存されている状態`state.number`を、コンポーネントでは`number`として受け取るように加工しています。
またこの受け取った`number`も、`connect`関数からpropsとしてReactコンポーネントに渡されるものなので、propTypesで`number`の型定義を行っています。

最後に、propsとして受け取った`number`を画面に表示します。

```javascript
  render() {
    return (
      <React.Fragment>
        <div>SPAフロントエンド開発入門</div>
        <div>
          {*/ this.state.number 削除*/}
        　{this.props.number}
        </div>
        <Button label="+1" onClick={this.countUp} />
        <Button label="-1" onClick={this.countDown} />
        <Button label="Reset" onClick={this.countReset} />
        <div>{this.state.message}</div>
      </React.Fragment>
    );
  }
```

この状態で「+1」ボタンを押すと、画面に表示されている数字も変更されるかと思います。

 ![演習3-1-1](/img/ex003/console1.png)

以上で演習3-1は終了です。

説明が長く、理解するのが中々に難しいとは思いますが、最初のうちは全てを理解しようと思わなくて大丈夫です。  
Reduxの処理の流れである、ReactコンポーネントからActionが発行され、Reducerで状態が代わり、StoreからReactコンポーネントに状態が渡されている、
という内容を最低限理解してもらえれば大丈夫です。


#### `下に解説が書かれていますが、ほとんど実装内容は演習3-1同じですので、まずは自力で頑張ってみてください。`


## 演習3-2
Reduxを用いて加算の処理を行うことができたので、Reactの演習のときと同様に、以下の処理をReduxを使用して書き換えてください。Action名や関数名などは自由に付けて構いません。
   - １ずつ減算
   - 数値を0にリセット
   - 各ボタンを押下した際の、メッセージを表示
   
今回は状態や機能の追加なので、Storeあたりは触る必要はありません。実装の順番としては下記のようになるかと思います。
1. Actionの作成（ActionTypesの作成、Action関数の作成）
2. reducerの作成（減算、リセットなどの状態変更の実装）
3. Reactコンポーネントの改修（Actionの発行処理や、状態をReduxから受け取るように変更）


演習3-1で実装した流れを参考に、減算、リセット、メッセージの表示変更を実装してみてください。
   

  
### 演習3-2 解説
演習3-1と同様に進めます。
#### Actionの作成
ActionTypesを作成します。
`js/constants/ActionTypes.js`  
```javascript
    export const COUNT_DOWN = 'COUNT_DOWN';
    export const COUNT_RESET = 'COUNT_RESET';
    export const CHANGE_MESSAGE = 'CHANGE_MESSAGE';
```
  
Action関数を作成します。  
ActionTypesを呼び出すためにimportを以下のように書き換えます。  
`js/actions/index.js`

```javascript
    import { COUNT_UP, COUNT_DOWN, COUNT_RESET, CHANGE_MESSAGE } from '../constants/ActionTypes';
```

countUp以外のAction関数を追加します。
```javascript
export const countUp = createAction(
  COUNT_UP,
  num => ({ amount: num }),
);
export const countDown = createAction(
  COUNT_DOWN,
  num => ({ amount: num }),
);

export const countReset = createAction(
  COUNT_RESET,
  num => ({ amount: num }),
);

export const changeMessage = createAction(
  CHANGE_MESSAGE,
  msg => ({ message: msg }),
);
```

Actionの作成は完了です。

#### Reducerの作成
`js/reducers/counter.js`  
ActionTypesのimportをします。  
```javascript
import { COUNT_UP, COUNT_DOWN, COUNT_RESET, CHANGE_MESSAGE } from '../constants/ActionTypes';
```

Actionが増えた分、更新処理を以下のように書き加えます。  
```javascript
     const counter = handleActions({
        [COUNT_UP]: (state, action) => ({
          ...state,
          number: state.number + action.payload.amount,
        }),
        [COUNT_DOWN]: (state, action) => ({
          ...state,
          number: state.number - action.payload.amount,
        }),
        [COUNT_RESET]: (state, action) => ({
          ...state,
          number: action.payload.amount,
        }),
        [CHANGE_MESSAGE]: (state, action) => ({
          ...state,
          message: action.payload.message,
        }),
      }, initialState);
```
reducerの作成は完了です。

#### Reactコンポーネントの改修
状態`message`が増えた分、mapStateToPropsを書き換えて、Storeに保存されている`message`を取り出します。
`js/containers/Content.jsx`    
```javascript
      function mapStateToProps(state) {
        return {
          number: state.number,
          message: state.message,
        };
      }
```

`props`として`message`を新たに受け取るようになったので、propTypesを以下のように書き換えます。
`js/containers/Content.jsx`  
```javascript
      const propTypes = {
        actions: PropTypes.object.isRequired,
        number: PropTypes.number.isRequired,
        message: PropTypes.string.isRequired,
      };
```


changeMessageをcountUpに追記し、countUp以外も同様にActionを発行するように書き換えます。

```javascript
      countUp = () => {
        const { actions } = this.props;
        actions.countUp(1);
        actions.changeMessage('1加算しました。');
      }
      countDown = () => {
        const { actions } = this.props;
        actions.countDown(1);
        actions.changeMessage('1減算しました。');
      }
      countReset = () => {
        const { actions } = this.props;
        actions.countReset(0);
        actions.changeMessage('リセットしました。');
      }
```

最後に、Storeから取り出したmessageを画面上に表示します。
  - js/containers/Content.jsx  

    ```javascript
      <div>
        {this.props.message}
      </div>
    ```

コードを書き終えたら、演習3-1と同様に動作確認をしてみてください。  
問題がなければボタン押下でActionが発行され、状態が更新されます。  
以上で演習3-2は終了です。
