# 概要
課題１で作成したTodoリストに、ReduxやMaterial-UIを組み合わせて改修してみましょう。


## Todo.jsxの表示

課題1で作成した`Todo.jsx`を、`Content.jsx`内からimportしてPaperタグの下に表示します。

```javascript
// 省略
import AppBar from '@material-ui/core/AppBar';
import Paper from '@material-ui/core/Paper';
import Todo from './Todo'; // 追加
import * as CounterActions from '../actions';
// 省略
    return (
      <div style={style.content}>
        <AppBar position="static">
          <div style={style.title}>SPAフロントエンド開発入門</div>
        </AppBar>
        <Paper className={classes.Paper} elevation={6}>
          <div style={style.count}>
            {this.props.number}
          </div>
          <div>
            <Button label="+1" onClick={this.countUp} style={style.button} color="primary" />
            <Button label="-1" onClick={this.countDown} style={style.button} color="secondary" />
            <Button label="Reset" onClick={this.countReset} style={style.button} />
          </div>
          <div>{this.props.message}</div>
        </Paper>
        <Todo />
      </div>
    );
```
`Todo.jsx`内にある「SPAフロントエンド入門」という文字は削除していただいても構いません。

現在`Todo.jsx`では、Todoリストの配列や入力された文字の状態をReactコンポーネントで保持しています。今回はこの状態管理をReduxで行えるように変更していきます。  
今までの演習で作成したファイル(action、reducerなど)と同じ場所に追記していって頂いて構いません。  

各ステップの解答は`\\dsfs200.dcs-is.in.dcs.co.jp\dcs-is211\pe0019385145\01.技術者育成研修\11.SPAによるフロントエンド開発\02_演習\追加課題　解答\課題_2`に置いてありますが、なるべくこれまで演習でやってきたことを参考に自力で頑張ってみてください。


### 1. Reduxに状態を定義
`Todo.jsx`で保持している`todoList`配列と入力文字列`value`を、`js/reducers/counter.js`に追加して、ReduxでもTodoリストの配列と、入力した文字列を保持できるようにします。

通常であれば`counter.js`ではなく新しく`todo.js`というreducerファイルを作成した方が、どのファイルにどの状態が記述されているか探しやすくなりますが、今回はそのまま`counter.js`に追記して大丈夫です。  


### 2. Reduxで定義した状態をReactコンポーネントで表示
１．の実装で、Reduxに新しく`todoList`と`value`が保持されるようになりました。

次に、`Todo.jsx`でReduxで保持した2つの値を取得して表示するようにします。すでに作成済の`Contents.jsx`でも`number`と`message`を取り出す処理が書かれているので、それを参考にしてください。  
取り出すために`mapStateToProps`を使用します。actionを発行する`mapDispatchToProps`はまだ使用しないので、connect関数の記述は下記のようにできます。  
```javascript
export default connect(mapStateToProps, null)(Todo);
```



### 3. 入力文字列の状態変更を実装
入力欄に入力された文字列を変更する処理から実装します。  
実装内容としては、入力された文字列をactionの引数に渡し、reducerで状態`value`の値を受け取った値に変更する、といった内容です。  
`Todo.jsx`からactionを発行するために、先ほど使用しなかった`mapStateToProps`も追記して、発行できるようにしてください。  
actionとreducerのファイルを新規で作成しても構いませんし、`js/actions/index.js`や`js/reducers/counter.js`にそのまま追記しても構いません。  
演習3を同じような実装なので、参考にしてみてください。


### 4. Todoリストの状態変更を実装
入力欄に文字を記入し追加ボタンを押下したら、reducerで`todoList`配列にその文字列を追加するよう実装します。また入力欄に記入されてる文字列もクリアします。
`Todo.jsx`の`addTodo`メソッドで追加後の新しい配列`newTodoList`をactionとして発行することもできますが、そういった状態の変更に関する処理はReactコンポーネントではなく、reducerに記述することが推奨されています。Reactはなるべくレンダリング以外の処理は記述しないようにしましょう。  
reduer内で状態変更の処理を追加するには、下記のような記述で可能です。アロー関数によりreturn文が省略されていましたが、何か処理を記述したい場合はアロー関数の記述の仕方を変更します。
```javascript
  [ADD_TODO]: (state, action) => {
    // todoList配列にactionから受け取った文字列を追加して、newTodoListを作成
    return ({
      ...state,
      // todoListやvalueの状態更新
    });
  }
```

Todo追加の実装ができましたら、削除の実装もしてみてください。追加とほぼ同様の記述で実装できると思います。


### 5. Material-UIの組み込み
Todoの機能実装が完了したので、最後にMaterial-UIを適用して、見た目を少しカッコよくしていきましょう。今回node_modulesに入っているMaterial-UIライブラリのバージョンがv3.xなので、ドキュメントも[v3](https://v3.material-ui.com/versions/)のものを見るようにしてください。左メニューの「Component Demos」でどんなコンポーネントが用意されてるか、わかりやすく掲載されています。  　

ネット上からマテリアルデザインで作成されたTodoリストを探してそれを目指して作成していただいても構いません。特にデザインが思いつかない方は、下図の画面作成を目指してみてください。  

![演習1-1-1](/img/task02/img001.png)

この画面では入力欄に[TextField](https://v3.material-ui.com/demos/text-fields/)を、Todoリスト項目の表示に[Cards](https://v3.material-ui.com/demos/cards/)、[IconButton](https://v3.material-ui.com/demos/buttons/#icon-buttons)を使用しています。またstyleディレクトリにCSSinJSを追加し、見た目を整えています。  
コードは`\\dsfs200.dcs-is.in.dcs.co.jp\dcs-is211\pe0019385145\01.技術者育成研修\11.SPAによるフロントエンド開発\02_演習\追加課題　解答\課題_2\5_Material-UIの組み込み`から確認できます。

Materia-UIのコンポーネントは他にも様々なものがあるので、試しに使用してみてください。例えばTodoの追加、削除が実行されたら[Snackbars](https://v3.material-ui.com/demos/snackbars/)で利用者に通知をしたり、削除ボタンを押下した際にすぐ削除せずに確認のポップアップを[Dialogs](https://v3.material-ui.com/demos/dialogs/)で実装してみたりと、拡張しようと思えば色々できますので遊んでみてください。


