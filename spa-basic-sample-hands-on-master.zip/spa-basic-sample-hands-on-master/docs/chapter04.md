# 演習4　React/ReduxにCSSを組み込んでみましょう！
## CSSinJSとは何か
- 特徴
  - JavaScriptファイル内でCSSを扱うことが可能。通常はCSSはCSSファイルに記述する必要がある。
  - 各コンポーネントごとにCSSが記述されたjsファイルをimportすればよいので、クラス名の衝突などを防げる
  - スタイルの合成が可能
  - 動的な値を使った計算が可能　

## 演習4-1
### React/ReduxアプリケーションにCSSinJSを組み込む
現状の画面は左上に寄っていて見えづらい状態になっています。この状態にCSSを当てて、下図のように少し見た目を整えます。
 ![演習4-1-1](/img/ex004/img001.png)  
 
 CSSを利用しますが、今回はCSSの研修ではないのでCSSが既に記述されたファイル`style/content.js`を利用します。
 拡張子が`.js`なのでJavaScriptファイルなのですが、オブジェクトの中にはCSSのような記述があることがわかると思います。これがCSSinJSの特徴です。

### 演習4-1 解説
#### ①CSSinJSファイルをimport
CSSinJSファイルを呼び出すために、`js/containers/Content.jsx`にimport文を追記します。 
```javascript
    import style from '../../style/content';
```
`style`の中に、CSSinJSファイルの中身が入りました。

#### ②コンポーネントにCSSを適用
importしてきたCSS情報を各タグに埋め込んでいきます。HTMLタグにはstyle属性が用意されているので、それに割り当てていきます。
`style/content.js`のオブジェクトの中身の`key`で割り当てるCSS情報を指定します。
  ```javascript
    render() {
      return (
        <div style={style.content}>
          <div style={style.title}>SPAフロントエンド開発入門</div>
          <div style={style.count}>
            {this.props.number}
          </div>
          <div>
            <Button label="+1" onClick={this.countUp} style={style.button} />
            <Button label="-1" onClick={this.countDown} style={style.button} />
            <Button label="Reset" onClick={this.countReset} style={style.button} />
          </div>
          <div>{this.props.message}</div>
        </div>
      );
    }
  ```

#### ③ButtonコンポーネントでCSS情報を受取る
Buttonコンポーネント(`js/components/Button.jsx`)はpropsでstyleを受け取っているので、もう少し追記が必要です。  
propsとして`style`を受け取っているので、型定義を追記します。styleはオブジェクト型で受け取っています。
  ```javascript
    const propTypes = {
      label: PropTypes.string.isRequired,
      onClick: PropTypes.func.isRequired,
      style: PropTypes.object.isRequired, // 追記
    };
  ```

最後に、propsの中のstyleにCSS情報が入っているので、`button`タグのstyle属性にセットして作業完了です。
  ```javascript
    const Button = props => (
      <button onClick={props.onClick} style={props.style}>{props.label}</button>
    );
  ```

以上で演習4-1は終了です。
他にもCSSinJSの記述を増やしてみたりして、見た目を整えてみてもらっても構いません。











