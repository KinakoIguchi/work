# 概要
今まで学んだReactの機能を使って、追加と削除機能を持ったTodoリストを作成してみましょう。  
下記のドキュメントに沿っていけばTodoリストを作成できますが、一部は独自に実装していただく必要があります。  
また最初から独自に実装していただいても構いません。   

## Todoリスト作成の準備

`js/containers/`の中に新しく`Todo.jsx`を作成してください。  
`Content.jsx`の中身はこの後の演習でも使用するので保存しておいてください。

```javascript
import React, { Component } from 'react';

class Todo extends Component {
  render() {
    return (
      <React.Fragment>
        <div>SPAフロントエンド開発入門</div>
      </React.Fragment>
    );
  }
}

export default Todo;
```
`localhost:3000`の画面に`Todo.jsx`の内容が表示されるように、階層が一番上にあるindex.jsxの中身を下記のように`Content.jsx`から`Todo.jsx`に変更してください。

```javascript
import React from 'react';
import { render } from 'react-dom';
// import Content from './js/containers/Content';
import Todo from './js/containers/Todo';


render(
  // <Content />,
  <Todo />,
  document.getElementById('root'),
);

```

### 1. 入力欄の実装
入力欄の実装にはHTMLの[inputタグ](http://www.htmq.com/html5/input.shtml)を利用します。  
inputタグにはイベントハンドラとして`onChange`が用意されています。これは入力、削除などのキーボード操作が行われinputタグのvalueが変化すると、設定した関数が実行されます。関数が実行されるときに、イベント情報が引数として渡されます。そのため、`event.target.value`とした場合は、inputタグ内の入力情報を受け取ることができます。

今回は入力内容を状態として保持し、キーボード操作を行うたびにその状態を変更していき、文字の入力を実装します。

コード内のコメントアウト部分を実装してみてください。
```javascript
  constructor(props) {
    super(props);
    this.state = {
      /* (1) 入力欄に入る文字の状態 */
    };
  }
  changeValue = (event) => {
    console.log(event.target.value);
    /* (3) (1)の状態を更新 */
  }
  render() {
    const { value } = this.state;
    return (
      <React.Fragment>
        <div>SPAフロントエンド開発入門</div>
        <input
          value={　/* (2) (1)で定義した文字の状態をvalueに設定　*/　}
          onChange={event => this.changeValue(event)}
        />
      </React.Fragment>
    );
  }
```
入力欄に文字が記入できるようになれば、実装完了です。


### 2. Todoリストの一覧を実装
最初にTodoリストを代入する配列を状態として新たに定義します。
今回は初期状態として3つの文字列を入れておきます。
```javascript
  constructor(props) {
    super(props);
    this.state = {
      todoList: ['sample1', 'sample2', 'sample3'],
    };
  }
  // 省略
```
3つの文字列が入ったtodoList配列を、一つずつ[liタグ](http://www.htmq.com/html/li.shtml)で一覧表示します。
方法はたくさんありますが、今回はJavaScriptの[map](https://developer.mozilla.org/ja/docs/Web/JavaScript/Reference/Global_Objects/Array/map)という機能を利用します。

mapは引数として与えた関数を、配列の全ての要素に対して実行し、その結果を一つずつ配列として返します。
下記は参考サイトでのサンプルです。
```javascript
const array1 = [1, 4, 9, 16];

// pass a function to map
const map1 = array1.map(x => x * 2);

console.log(map1);
// expected output: Array [2, 8, 18, 32]
```
コードを見てわかるとおり、array1の配列の中身を一つずつ取り出し、2を掛けてその結果を配列に格納して返しています。  
繰り返し処理でよく使われるfor文でも同様のことはできますが、mapの方がコードの記述がシンプルで記述量が少ないため、ネット上のドキュメントや記事でもmapが使われることが多いです。  

今回は配列の中身をliタグに変換していくので、下記のようになります。
```javascript
  render() {
    const { value, todoList } = this.state;
    const list = todoList.map((data, index) => <li key={index}>{data}</li>);
    return (
      <React.Fragment>
        <div>SPAフロントエンド開発入門</div>
        <input
          value={value}
          onChange={e => this.changeValue(e)}
        />
        {list}
      </React.Fragment>
    );
  }
```
map内に設定した関数の引数が`(data, index)`となっていますが、`data`にはtodoList配列の文字列が入ります。そして`index`は配列のインデックス番号になります。  
その`index`はliタグにkeyとして設定しています。このkeyに設定する値は一意であればいいので、例えば時刻や乱数などを設定しても大丈夫です。
それぞれのliタグに一意のkeyをセットすることで、Reactでは無駄なレンダリングを抑えることができます。その仕組は公式ドキュメントに[記載](https://ja.reactjs.org/docs/reconciliation.html#recursing-on-children)されていますので、興味があればご覧ください。  
ちなみにこのkeyを設定しないと、ブラウザのコンソール画面でkeyを設定してくださいという内容のwarningが出てきます。 warningなので動作は正常に行われていますが、もし表示するリストが何千何万となったときには恐らくレンダリングに支障が出て画面がカクつくようになるはずです。

変数`list`の中身は、map関数から返されたliタグが配列として格納されています。`console.log`でlistの中身をコンソール画面に表示してみると中身が確認できます。  
あとはこの`list`をinputタグの下に組み込むと、画面に表示されます。

### 3. Todoの追加機能を実装
１.で実装した入力欄に入力された文字を、２.で定義した`todoList`配列に追加する機能を実装します。

配列に新たな文字列を追加する方法はいくつかありますが、[concat](https://developer.mozilla.org/ja/docs/Web/JavaScript/Reference/Global_Objects/Array/concat)というJavaScriptの機能がわかりやすいと思うので参考にしてみてください。
また`todoList`の配列を更新した後に、入力内容を保持している`value`の状態を空文字に更新することで、追加ボタンを押下したら入力欄をクリアする仕様にすることができます。

```javascript
import React, { Component } from 'react';
class Todo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: 'test',
      todoList: ['sample1', 'sample2', 'sample3'],
    };
  }
  changeValue = (e) => {
    console.log(e.target.value);
    this.setState({ value: e.target.value });
  }
  addTodo = () => {
    /* (1) todoListの配列に入力欄の文字列valueを追加する処理*/
    /* (2) 入力欄の文字列valueをクリアする処理 */
  }
  render() {
    const { value, todoList } = this.state;
    const list = todoList.map((data, index) => <li key={index}>{data}</li>);
    return (
      <React.Fragment>
        <div>SPAフロントエンド開発入門</div>
        <input
          value={value}
          onChange={e => this.changeValue(e)}
        />
        <button type="button" onClick={() => this.addTodo()}>追加</button>
        {list}
      </React.Fragment>
    );
  }
}
export default Todo;
```

### 4. Todoの削除機能を実装
Todoリストの削除機能を実装します。  
まず最初にliタグの中に削除のボタンを追加します。
```javascript
    const list = todoList.map((data, index) => (
      <li key={index}>
        {data}
        <button type="button" onClick={() => this.deleteTodo(data)}>
          削除
        </button>
      </li>
    ));
```
追加したボタンをクリックしたときに`deleteTodo`を実行し、引数としてクリックした箇所のTodoの文字列を渡します。
そして`deleteTodo`関数の中で、Todoリストの情報が入っている`todoList`配列から引数として渡した文字列と一致するものを探して、該当の文字列を`todoList`配列から抜き出して、削除完了となります。

この内容を実装するときに便利なものが、JavaScriptの[filter](https://developer.mozilla.org/ja/docs/Web/JavaScript/Reference/Global_Objects/Array/filter)という機能です。  
先程出てきた`map`と同様で、配列内の全ての要素に対して処理を実施します。

下記は参考サイトでのサンプルです。
```javascript
const words = ['spray', 'limit', 'elite', 'exuberant', 'destruction', 'present'];

const result = words.filter(word => word.length > 6);

console.log(result);
// expected output: Array ["exuberant", "destruction", "present"]
```
filter内の関数では真偽値`true`か`false`を返すようにします。サンプルでは「配列の要素の文字列が6文字より多い」であればtrue、そうでなければfalseとなります。  
このときに`true`であればその文字列は残していき、最終的に変数`result`に配列として渡します。恐らくサンプルコードを見れば動作のイメージはできるかと思います。

ほとんどサンプルコードと同じ内容になりますが、コメントアウト部分にfilterを用いた削除機能を実装してみてください。

```javascript
import React, { Component } from 'react';

class Todo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: 'test',
      todoList: ['sample1', 'sample2', 'sample3'],
    };
  }
  changeValue = (e) => {
    console.log(e.target.value);
    this.setState({ value: e.target.value });
  }
  addTodo = () => {
    const { value, todoList } = this.state;
    const newTodoList = todoList.concat(value);
    this.setState({ todoList: newTodoList });
    this.setState({ value: '' });
  }
  deleteTodo = (data) => {
    /* (1)filter関数を用いて削除機能を実装 */
    /* 引数dataにはクリックしたTodoの文字列が入っています */
  }
  render() {
    const { value, todoList } = this.state;
    const list = todoList.map((data, index) => (
      <li key={index}>
        {data}
        <button type="button" onClick={() => this.deleteTodo(data)}>
          削除
        </button>
      </li>
    ));
    return (
      <React.Fragment>
        <div>SPAフロントエンド開発入門</div>
        <input
          value={value}
          onChange={e => this.changeValue(e)}
        />
        <button type="button" onClick={() => this.addTodo()}>追加</button>
        {list}
      </React.Fragment>
    );
  }
}

export default Todo;
```

`map`、`filter`以外にも配列の中身を操作できる便利なメソッドがJavaScriptでは用意されているので、気になる方は[こちらの記事](https://qiita.com/itagakishintaro/items/29e301f3125760b81302)をご覧ください。


### 事後作業
一通りの実装が終わりましたら、先ほどコメントアウトした`Content.jsx`を元に戻して、続きの演習を進めてください。新しく作成した`Todo.jsx`はこの後の課題2でも使用しますので、そのままにしておいてください。

```javascript

import React from 'react';
import { render } from 'react-dom';
import Content from './js/containers/Content';
// import Todo from './js/containers/Todo';


render(
  <Content />,
  // <Todo />,
  document.getElementById('root'),
);

```

