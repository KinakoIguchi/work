# SPAについて
## SPA(SinglePageApplication)とは
SPAはFlashやSilverlight、Javaアプレットを活用したRIA(リッチ・インターネット・アプリケーション)に代わる技術として誕生した、従来のWeb技術でデスクトップアプリケーションのような操作性を実現するアーキテクチャです。    
名前に「Single Page」とあるように、1枚のHTMLに対してJavaScriptで動的に変更を加えながら画面の描画を実現しているのが大きな特徴です。


![SPA1](/img/introduction/spa001.png)

　上図のように、従来のWebアプリケーションと異なりSPAではページ全体(HTML,CSS,JavaScript)をロードするのは初回のみです。2回目以降はサーバからJSONデータのみを受け取り、更新が必要な箇所のみリロードするため、画面の反映が早くなります。
## SPAのメリット
クライアントサイドで画面を生成するSPAは、操作性だけでなく、サーバサイドも変わる事によるメリットが挙げられます。
- リッチなUI・操作感の提供
    - クライアントサイドで画面を構成することにより、デスクトップアプリケーションに近いリッチなUIを実現
- 既存のブラウザ上で動作
    - 既存のWeb技術（HTML／JavaSciprt／CSS）のみで構成されているため、RIAと異なり、
    動作にあたって専用のエンジン等が不要
- バックエンドのWebAPI化
    - クライアントとサーバサイドが疎結合になり、クロスプラットフォーム(異なるOSや異なるハードウェア)への対応が容易となる
- 通信量の削減
    - 初回のリソース受け取り以降はJSONデータのやり取りのみとなるため、画面表示に必要な通信量が少ない

## SPAの適用範囲
ブラウザで動作するWebアプリケーション(①)からインストール型のiOS/Androidハイブリッドモバイルアプリ(③)でSPAのアーキテクチャが適用できます。  
![SPA2](/img/introduction/spa002.png)
  
## SPA開発に必要な技術
Facebook社提供のフレームワーク「React」をベースに、SPA開発のデファクトとなっているOSS製品を中心に採用しています。赤い枠で囲んだ範囲が、今回の研修で扱う部分です。

![SPA3](/img/introduction/spa003.png)

普段の開発ではあまり意識することはありませんが、[babel](https://babeljs.io/)と[Webpack](https://webpack.js.org/)はReactアプリケーションに欠かせないものなので、仕組みだけでも理解しておいてください。

- babelについて  
React/Reduxで作成されるアプリケーションはJavaScriptの新しい記述方法(ECMAScript2015以降のバージョン)を使用して記述します。
しかしこの新しいJavaScriptの記述方法は、ブラウザの種類(CHrome,IEなど)によっては対応していない場合があります。
JavaScriptのバージョン更新のスピードに、ブラウザの対応が追いつけていない状態になっているわけです。  
全てのブラウザで問題なく動作するためには、一度古い記述方法に変換する必要があります。これを実現しているのが「Babel」(altJS)です。

- Webpackについて  
ReactでWebアプリケーションを開発するときは、たくさんのJavaScriptライブラリを使用します。Reactもそうですが、Redux、Material-UIなどもJavaScriptライブラリです。
既に事前準備でspa-basic-sampleの起動確認までしていると思いますが、その際に「npm install」を実行して「node_modules」を作成したと思います。  
「npm install」ではspa-basic-sampleフォルダ内にある`package.json`に記載されたJavaScriptライブラリをネット上からダウンロードしています。そのため`package.json`にはreactやreduxの名前も記載されています。  
そしてダウンロードされたJavaScriptライブラリは「node_modules」に全て格納されます。そのため中身を見ると膨大な数のフォルダが入っています。開発するときは「node_modules」からReactなどのライブラリを取り出していきます。
またWebアプリケーションを開発をしていくと、ソースコードファイルがどんどん増えていきます。  
WebpackではWebアプリケーションに必要な全てのファイル(ライブラリから取り出したファイル、作成したJavaScriptファイルやCSSファイルなど)を、1つのJavaScriptファイルに圧縮することができます。
そのためブラウザ表示を行うHTMLファイルからは、Webpackが圧縮して1つにまとめたJavaScriptファイルを読み込むだけでよくなります。この1つのJavaScriptファイルにまとめるときに、同時にbabelでJavaScriptの変換も行っています。




## 参考サイト
- [ゼロから学ぶ！　Single Page Applicationの特徴と主なフレームワーク5選](https://www.atmarkit.co.jp/ait/articles/1702/22/news012.html)
    - SPAの特徴やSPAが誕生した背景について記載されています。
- [babel](https://babeljs.io/)
    - babelの公式ドキュメントサイトです。
- [Webpack](https://webpack.js.org/)
    - Webpackの公式ドキュメントサイトです。