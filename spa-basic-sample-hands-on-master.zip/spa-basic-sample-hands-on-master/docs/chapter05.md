# 演習5　React/ReduxにMaterial-UIを組み込んでみましょう！
## Material-UIとは
Google社の提唱するマテリアルデザインを実現するReact向けコンポーネントを提供するライブラリです。
[Material UI](https://material-ui.com/)のサイトのデモなどを見てみると、Google社が提供しているGmailやYoutubeなどで見たことあるようなデザインがあることがわかります。  
コンポーネントの種類が豊富に用意されているため、それらを組み合わせるだけで見栄えの良いものを作ることができます。  


【マテリアルデザイン】  
 ![Material-UI_1](/img/ex005/img001.png)

【[Material UI](https://material-ui.com/)】  
 ![Material-UI_2](/img/ex005/img002.png)  


## 演習5-1
### React/ReduxアプリケーションにMaterial-UIを組み込む
以下のMaterial-UIのコンポーネントを組み込んで、見た目を変えていきます。
  - [AppBar](https://v3.material-ui.com/demos/app-bar/)  
  ヘッダー要素のコンポーネントです。
  - [Paper](https://v3.material-ui.com/demos/paper/)  
  画面上に紙を乗っけたように表示することができます。
  - [Buttons](https://v3.material-ui.com/demos/buttons/)   
  ボタン要素のコンポーネントです。クリックすると波紋が広がり、ちゃんと押されていることを確認しやすくなっています。
 ![演習5-1-1](/img/ex005/img003.png)

### 演習5-1 解説
#### ContentコンポーネントにMaterial-UIを適用
Material-UIを使用するために必要なライブラリをimportで追加します。  
`Content.jsx`では`AppBar`と`Paper`を適用します。

`js/containers/Content.jsx`  
```javascript
import { withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Paper from '@material-ui/core/Paper';
```
`withStyles`はMaterial-UIのコンポーネントにCSSを適用するときに必要になります。この適用方法は少しクセがあるので、こういう書き方をする、という理解で大丈夫です。

下記のようにexport文の中に`withStyles`をコンポーネントに組み込みます。`withStyles`の引数にはCSS情報を入れます。
```javascript
export default connect(mapStateToProps, mapDispatchToProps)((withStyles(style))(Content));
```
こうすると、Reactコンポーネントは`withStyles`からpropsとして`classes`というものを受け取り、それを利用すると、
CSSinJSで記述されたCSS情報を、Material-UIのコンポーネントに適用することができます。  
propsとして受け取るので、`classes`をpropTypesの型定義に追加する必要があります。

Material-UIは、「SPAフロントエンド開発入門」の文字をヘッダーとして`AppBar`コンポーネントを適用し、それ以外は`Paper`コンポーネントの上に表示します。

以上を踏まえて、コードを下記のように書き換えます。
```javascript
// 省略
class Content extends Component {
  // 省略
  render() {
    const { classes } = this.props;
    return (
      <div style={style.content}>
        <AppBar position="static">
          <div style={style.title}>SPAフロントエンド開発入門</div>
        </AppBar>
        <Paper className={classes.Paper} elevation={6}>
          <div style={style.count}>
            {this.props.number}
          </div>
          <div>
            <Button label="+1" onClick={this.countUp} style={style.button} color="primary" />
            <Button label="-1" onClick={this.countDown} style={style.button} color="secondary" />
            <Button label="Reset" onClick={this.countReset} style={style.button} />
          </div>
          <div>{this.props.message}</div>
        </Paper>
      </div>
    );
  }
}

const propTypes = {
  actions: PropTypes.object.isRequired,
  number: PropTypes.number.isRequired,
  message: PropTypes.string.isRequired,
  classes: PropTypes.object.isRequired,// 追加
};
// 省略

export default connect(mapStateToProps, mapDispatchToProps)((withStyles(style))(Content));
```

`AppBar`コンポーネントや`Paper`に渡せるプロパティは各コンポーネントのドキュメントのAPIページから確認できます。（[AppBar API](https://v3.material-ui.com/api/app-bar/)、[Paper API](https://v3.material-ui.com/api/paper/)）

また`color`プロパティに「primary」や「secondary」が設定されていますが、この2つの色はMaterial-UIでデフォルトで設定されています。
そのため、システムのテーマに合わせて、「primary」や「secondary」の色を変更することは可能です。



#### ButtonコンポーネントにMaterial-UIを適用
次にButtonコンポーネントにMaterial-UIのButtonを適用します。  
- まずMaterial-UIからButtonをimportします。
```javascript
import FlatButton from '@material-ui/core/Button';
```
名前が被ってしまうため、Material-UIからimportしてくるButtonコンポーネントは、「FlatButton」と名付けました。

- ボタンをMaterial-UIのコンポーネントに書き換えます。  
`js/components/Button.jsx`  
```javascript
    const Button = props => (
      <FlatButton variant="contained" color={props.color} onClick={props.onClick} style={props.style}>
        {props.label}
      </FlatButton>
    );
```
`FlatButton`内のプロパティ`variant`はボタンの形を決めてるものです。
他にも種類があるので、[Button API](https://v3.material-ui.com/api/button/)を見て`variant`に設定できるものを確認して変更してみてください。

- ボタンの色を指定するcolorが増えたためpropTypesに追記します

```javascript
    const propTypes = {
      label: PropTypes.string.isRequired,
      onClick: PropTypes.func.isRequired,
      style: PropTypes.object.isRequired,
      color: PropTypes.string,
    };
```

コードを書き終えたら画面を更新してMaterial-UIが適用されているか確認してください。  
以上で演習5-1は終了です。