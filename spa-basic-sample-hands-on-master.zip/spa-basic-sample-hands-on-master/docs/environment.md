# 環境構築
## 事前準備のお願い
- 以下ファイルをダウンロードし、解凍してください（解凍先は任意です）。
- \\\dsfs200.dcs-is.in.dcs.co.jp\dcs-is211\pe0019385145\01.技術者育成研修\11.SPAによるフロントエンド開発\01_講座資料
  - spa-basic-sample.zip

###  注意事項 
SPA開発演習準備（localhostの起動）

  1. コマンドプロンプトを起動し、spa-basic-sampleまで移動
  2. 「npm install」を入力し実行（今回の演習で使用するライブラリを取得し、
node_modulesを作成します）
  3. 「npm run dev」を入力し実行
  4. http://localhost:3000/ にアクセスし、「Hello World」と表示されたら完了

  - npm installはERRORが発生していなければ正しく実行されています。
  - 一度エラーが発生しても、2~3回npm installを再実行してください。
  - npm install実行終了後、プロジェクト内に「node_modules」が自動生成されます。
  - もしnpm installが通らない方は、
   \\\dsfs200.dcs-is.in.dcs.co.jp\dcs-is211\pe0019385145\01.技術者育成研修\11.SPAによるフロントエンド開発\01_講座資料 から、ご使用の端末に合わせて32bit、64bitどちらかのnode_modulesをローカルに落としてください。zip解凍後、「node_modules」フォルダを各プロジェクト配下に格納してください。


演習の解答について
- 各演習の解答は以下のフォルダに格納されています。演習の解説通りに実装することでアプリケーションは完成しますが、詰まってしまったときは解答を参考にしてみてください。
  - \\\dsfs200.dcs-is.in.dcs.co.jp\dcs-is211\pe0019385145\01.技術者育成研修\11.SPAによるフロントエンド開発\02_演習\解答